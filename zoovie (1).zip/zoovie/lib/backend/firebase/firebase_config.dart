import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyAwiMk6fJrMBYW6qlJMUyUCLU0AoXTqXdI",
            authDomain: "zoovie-aa138.firebaseapp.com",
            projectId: "zoovie-aa138",
            storageBucket: "zoovie-aa138.appspot.com",
            messagingSenderId: "209135763025",
            appId: "1:209135763025:web:788287d61242497aa58270",
            measurementId: "G-TNHV2GFXLN"));
  } else {
    await Firebase.initializeApp();
  }
}
