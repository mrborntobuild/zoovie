import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class AppUpdateRecord extends FirestoreRecord {
  AppUpdateRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "app_version" field.
  String? _appVersion;
  String get appVersion => _appVersion ?? '';
  bool hasAppVersion() => _appVersion != null;

  // "updates" field.
  List<String>? _updates;
  List<String> get updates => _updates ?? const [];
  bool hasUpdates() => _updates != null;

  void _initializeFields() {
    _appVersion = snapshotData['app_version'] as String?;
    _updates = getDataList(snapshotData['updates']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('app_update');

  static Stream<AppUpdateRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => AppUpdateRecord.fromSnapshot(s));

  static Future<AppUpdateRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => AppUpdateRecord.fromSnapshot(s));

  static AppUpdateRecord fromSnapshot(DocumentSnapshot snapshot) =>
      AppUpdateRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static AppUpdateRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      AppUpdateRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'AppUpdateRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is AppUpdateRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createAppUpdateRecordData({
  String? appVersion,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'app_version': appVersion,
    }.withoutNulls,
  );

  return firestoreData;
}

class AppUpdateRecordDocumentEquality implements Equality<AppUpdateRecord> {
  const AppUpdateRecordDocumentEquality();

  @override
  bool equals(AppUpdateRecord? e1, AppUpdateRecord? e2) {
    const listEquality = ListEquality();
    return e1?.appVersion == e2?.appVersion &&
        listEquality.equals(e1?.updates, e2?.updates);
  }

  @override
  int hash(AppUpdateRecord? e) =>
      const ListEquality().hash([e?.appVersion, e?.updates]);

  @override
  bool isValidKey(Object? o) => o is AppUpdateRecord;
}
