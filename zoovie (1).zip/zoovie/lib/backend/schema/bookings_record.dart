import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class BookingsRecord extends FirestoreRecord {
  BookingsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "business_ID" field.
  DocumentReference? _businessID;
  DocumentReference? get businessID => _businessID;
  bool hasBusinessID() => _businessID != null;

  // "business_name" field.
  String? _businessName;
  String get businessName => _businessName ?? '';
  bool hasBusinessName() => _businessName != null;

  // "business_location" field.
  LatLng? _businessLocation;
  LatLng? get businessLocation => _businessLocation;
  bool hasBusinessLocation() => _businessLocation != null;

  // "business_address" field.
  String? _businessAddress;
  String get businessAddress => _businessAddress ?? '';
  bool hasBusinessAddress() => _businessAddress != null;

  // "business_logo" field.
  String? _businessLogo;
  String get businessLogo => _businessLogo ?? '';
  bool hasBusinessLogo() => _businessLogo != null;

  // "users" field.
  List<DocumentReference>? _users;
  List<DocumentReference> get users => _users ?? const [];
  bool hasUsers() => _users != null;

  // "event_title" field.
  String? _eventTitle;
  String get eventTitle => _eventTitle ?? '';
  bool hasEventTitle() => _eventTitle != null;

  // "created" field.
  DateTime? _created;
  DateTime? get created => _created;
  bool hasCreated() => _created != null;

  // "eventDateStart" field.
  DateTime? _eventDateStart;
  DateTime? get eventDateStart => _eventDateStart;
  bool hasEventDateStart() => _eventDateStart != null;

  // "eventDateEnd" field.
  DateTime? _eventDateEnd;
  DateTime? get eventDateEnd => _eventDateEnd;
  bool hasEventDateEnd() => _eventDateEnd != null;

  // "cancelled" field.
  bool? _cancelled;
  bool get cancelled => _cancelled ?? false;
  bool hasCancelled() => _cancelled != null;

  // "note" field.
  String? _note;
  String get note => _note ?? '';
  bool hasNote() => _note != null;

  // "hidden_by" field.
  List<DocumentReference>? _hiddenBy;
  List<DocumentReference> get hiddenBy => _hiddenBy ?? const [];
  bool hasHiddenBy() => _hiddenBy != null;

  void _initializeFields() {
    _businessID = snapshotData['business_ID'] as DocumentReference?;
    _businessName = snapshotData['business_name'] as String?;
    _businessLocation = snapshotData['business_location'] as LatLng?;
    _businessAddress = snapshotData['business_address'] as String?;
    _businessLogo = snapshotData['business_logo'] as String?;
    _users = getDataList(snapshotData['users']);
    _eventTitle = snapshotData['event_title'] as String?;
    _created = snapshotData['created'] as DateTime?;
    _eventDateStart = snapshotData['eventDateStart'] as DateTime?;
    _eventDateEnd = snapshotData['eventDateEnd'] as DateTime?;
    _cancelled = snapshotData['cancelled'] as bool?;
    _note = snapshotData['note'] as String?;
    _hiddenBy = getDataList(snapshotData['hidden_by']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('bookings');

  static Stream<BookingsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => BookingsRecord.fromSnapshot(s));

  static Future<BookingsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => BookingsRecord.fromSnapshot(s));

  static BookingsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      BookingsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static BookingsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      BookingsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'BookingsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is BookingsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createBookingsRecordData({
  DocumentReference? businessID,
  String? businessName,
  LatLng? businessLocation,
  String? businessAddress,
  String? businessLogo,
  String? eventTitle,
  DateTime? created,
  DateTime? eventDateStart,
  DateTime? eventDateEnd,
  bool? cancelled,
  String? note,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'business_ID': businessID,
      'business_name': businessName,
      'business_location': businessLocation,
      'business_address': businessAddress,
      'business_logo': businessLogo,
      'event_title': eventTitle,
      'created': created,
      'eventDateStart': eventDateStart,
      'eventDateEnd': eventDateEnd,
      'cancelled': cancelled,
      'note': note,
    }.withoutNulls,
  );

  return firestoreData;
}

class BookingsRecordDocumentEquality implements Equality<BookingsRecord> {
  const BookingsRecordDocumentEquality();

  @override
  bool equals(BookingsRecord? e1, BookingsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.businessID == e2?.businessID &&
        e1?.businessName == e2?.businessName &&
        e1?.businessLocation == e2?.businessLocation &&
        e1?.businessAddress == e2?.businessAddress &&
        e1?.businessLogo == e2?.businessLogo &&
        listEquality.equals(e1?.users, e2?.users) &&
        e1?.eventTitle == e2?.eventTitle &&
        e1?.created == e2?.created &&
        e1?.eventDateStart == e2?.eventDateStart &&
        e1?.eventDateEnd == e2?.eventDateEnd &&
        e1?.cancelled == e2?.cancelled &&
        e1?.note == e2?.note &&
        listEquality.equals(e1?.hiddenBy, e2?.hiddenBy);
  }

  @override
  int hash(BookingsRecord? e) => const ListEquality().hash([
        e?.businessID,
        e?.businessName,
        e?.businessLocation,
        e?.businessAddress,
        e?.businessLogo,
        e?.users,
        e?.eventTitle,
        e?.created,
        e?.eventDateStart,
        e?.eventDateEnd,
        e?.cancelled,
        e?.note,
        e?.hiddenBy
      ]);

  @override
  bool isValidKey(Object? o) => o is BookingsRecord;
}
