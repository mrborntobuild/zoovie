import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class BusinessCategoryRecord extends FirestoreRecord {
  BusinessCategoryRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  bool hasCategory() => _category != null;

  void _initializeFields() {
    _category = snapshotData['category'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('business_category');

  static Stream<BusinessCategoryRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => BusinessCategoryRecord.fromSnapshot(s));

  static Future<BusinessCategoryRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => BusinessCategoryRecord.fromSnapshot(s));

  static BusinessCategoryRecord fromSnapshot(DocumentSnapshot snapshot) =>
      BusinessCategoryRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static BusinessCategoryRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      BusinessCategoryRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'BusinessCategoryRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is BusinessCategoryRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createBusinessCategoryRecordData({
  String? category,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'category': category,
    }.withoutNulls,
  );

  return firestoreData;
}

class BusinessCategoryRecordDocumentEquality
    implements Equality<BusinessCategoryRecord> {
  const BusinessCategoryRecordDocumentEquality();

  @override
  bool equals(BusinessCategoryRecord? e1, BusinessCategoryRecord? e2) {
    return e1?.category == e2?.category;
  }

  @override
  int hash(BusinessCategoryRecord? e) =>
      const ListEquality().hash([e?.category]);

  @override
  bool isValidKey(Object? o) => o is BusinessCategoryRecord;
}
