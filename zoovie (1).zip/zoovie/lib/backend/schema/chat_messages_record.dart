import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChatMessagesRecord extends FirestoreRecord {
  ChatMessagesRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  // "chat" field.
  DocumentReference? _chat;
  DocumentReference? get chat => _chat;
  bool hasChat() => _chat != null;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  bool hasMessage() => _message != null;

  // "time" field.
  DateTime? _time;
  DateTime? get time => _time;
  bool hasTime() => _time != null;

  // "chat_image" field.
  String? _chatImage;
  String get chatImage => _chatImage ?? '';
  bool hasChatImage() => _chatImage != null;

  // "image_message" field.
  bool? _imageMessage;
  bool get imageMessage => _imageMessage ?? false;
  bool hasImageMessage() => _imageMessage != null;

  // "deleted" field.
  bool? _deleted;
  bool get deleted => _deleted ?? false;
  bool hasDeleted() => _deleted != null;

  // "text_message" field.
  bool? _textMessage;
  bool get textMessage => _textMessage ?? false;
  bool hasTextMessage() => _textMessage != null;

  // "reply" field.
  bool? _reply;
  bool get reply => _reply ?? false;
  bool hasReply() => _reply != null;

  // "replied_to_message" field.
  String? _repliedToMessage;
  String get repliedToMessage => _repliedToMessage ?? '';
  bool hasRepliedToMessage() => _repliedToMessage != null;

  // "reply_post_owner" field.
  DocumentReference? _replyPostOwner;
  DocumentReference? get replyPostOwner => _replyPostOwner;
  bool hasReplyPostOwner() => _replyPostOwner != null;

  // "voice_message" field.
  String? _voiceMessage;
  String get voiceMessage => _voiceMessage ?? '';
  bool hasVoiceMessage() => _voiceMessage != null;

  // "voice" field.
  bool? _voice;
  bool get voice => _voice ?? false;
  bool hasVoice() => _voice != null;

  // "love" field.
  List<DocumentReference>? _love;
  List<DocumentReference> get love => _love ?? const [];
  bool hasLove() => _love != null;

  // "thumb" field.
  List<DocumentReference>? _thumb;
  List<DocumentReference> get thumb => _thumb ?? const [];
  bool hasThumb() => _thumb != null;

  // "laugh" field.
  List<DocumentReference>? _laugh;
  List<DocumentReference> get laugh => _laugh ?? const [];
  bool hasLaugh() => _laugh != null;

  // "fire" field.
  List<DocumentReference>? _fire;
  List<DocumentReference> get fire => _fire ?? const [];
  bool hasFire() => _fire != null;

  // "thankyou" field.
  List<DocumentReference>? _thankyou;
  List<DocumentReference> get thankyou => _thankyou ?? const [];
  bool hasThankyou() => _thankyou != null;

  // "sad" field.
  List<DocumentReference>? _sad;
  List<DocumentReference> get sad => _sad ?? const [];
  bool hasSad() => _sad != null;

  // "reaction_count" field.
  int? _reactionCount;
  int get reactionCount => _reactionCount ?? 0;
  bool hasReactionCount() => _reactionCount != null;

  // "typing" field.
  bool? _typing;
  bool get typing => _typing ?? false;
  bool hasTyping() => _typing != null;

  void _initializeFields() {
    _user = snapshotData['user'] as DocumentReference?;
    _chat = snapshotData['chat'] as DocumentReference?;
    _message = snapshotData['message'] as String?;
    _time = snapshotData['time'] as DateTime?;
    _chatImage = snapshotData['chat_image'] as String?;
    _imageMessage = snapshotData['image_message'] as bool?;
    _deleted = snapshotData['deleted'] as bool?;
    _textMessage = snapshotData['text_message'] as bool?;
    _reply = snapshotData['reply'] as bool?;
    _repliedToMessage = snapshotData['replied_to_message'] as String?;
    _replyPostOwner = snapshotData['reply_post_owner'] as DocumentReference?;
    _voiceMessage = snapshotData['voice_message'] as String?;
    _voice = snapshotData['voice'] as bool?;
    _love = getDataList(snapshotData['love']);
    _thumb = getDataList(snapshotData['thumb']);
    _laugh = getDataList(snapshotData['laugh']);
    _fire = getDataList(snapshotData['fire']);
    _thankyou = getDataList(snapshotData['thankyou']);
    _sad = getDataList(snapshotData['sad']);
    _reactionCount = castToType<int>(snapshotData['reaction_count']);
    _typing = snapshotData['typing'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('chat_messages');

  static Stream<ChatMessagesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ChatMessagesRecord.fromSnapshot(s));

  static Future<ChatMessagesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ChatMessagesRecord.fromSnapshot(s));

  static ChatMessagesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ChatMessagesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ChatMessagesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ChatMessagesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ChatMessagesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ChatMessagesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChatMessagesRecordData({
  DocumentReference? user,
  DocumentReference? chat,
  String? message,
  DateTime? time,
  String? chatImage,
  bool? imageMessage,
  bool? deleted,
  bool? textMessage,
  bool? reply,
  String? repliedToMessage,
  DocumentReference? replyPostOwner,
  String? voiceMessage,
  bool? voice,
  int? reactionCount,
  bool? typing,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'user': user,
      'chat': chat,
      'message': message,
      'time': time,
      'chat_image': chatImage,
      'image_message': imageMessage,
      'deleted': deleted,
      'text_message': textMessage,
      'reply': reply,
      'replied_to_message': repliedToMessage,
      'reply_post_owner': replyPostOwner,
      'voice_message': voiceMessage,
      'voice': voice,
      'reaction_count': reactionCount,
      'typing': typing,
    }.withoutNulls,
  );

  return firestoreData;
}

class ChatMessagesRecordDocumentEquality
    implements Equality<ChatMessagesRecord> {
  const ChatMessagesRecordDocumentEquality();

  @override
  bool equals(ChatMessagesRecord? e1, ChatMessagesRecord? e2) {
    const listEquality = ListEquality();
    return e1?.user == e2?.user &&
        e1?.chat == e2?.chat &&
        e1?.message == e2?.message &&
        e1?.time == e2?.time &&
        e1?.chatImage == e2?.chatImage &&
        e1?.imageMessage == e2?.imageMessage &&
        e1?.deleted == e2?.deleted &&
        e1?.textMessage == e2?.textMessage &&
        e1?.reply == e2?.reply &&
        e1?.repliedToMessage == e2?.repliedToMessage &&
        e1?.replyPostOwner == e2?.replyPostOwner &&
        e1?.voiceMessage == e2?.voiceMessage &&
        e1?.voice == e2?.voice &&
        listEquality.equals(e1?.love, e2?.love) &&
        listEquality.equals(e1?.thumb, e2?.thumb) &&
        listEquality.equals(e1?.laugh, e2?.laugh) &&
        listEquality.equals(e1?.fire, e2?.fire) &&
        listEquality.equals(e1?.thankyou, e2?.thankyou) &&
        listEquality.equals(e1?.sad, e2?.sad) &&
        e1?.reactionCount == e2?.reactionCount &&
        e1?.typing == e2?.typing;
  }

  @override
  int hash(ChatMessagesRecord? e) => const ListEquality().hash([
        e?.user,
        e?.chat,
        e?.message,
        e?.time,
        e?.chatImage,
        e?.imageMessage,
        e?.deleted,
        e?.textMessage,
        e?.reply,
        e?.repliedToMessage,
        e?.replyPostOwner,
        e?.voiceMessage,
        e?.voice,
        e?.love,
        e?.thumb,
        e?.laugh,
        e?.fire,
        e?.thankyou,
        e?.sad,
        e?.reactionCount,
        e?.typing
      ]);

  @override
  bool isValidKey(Object? o) => o is ChatMessagesRecord;
}
