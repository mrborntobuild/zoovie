import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class LegalPoliciesRecord extends FirestoreRecord {
  LegalPoliciesRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "privacy_policy" field.
  String? _privacyPolicy;
  String get privacyPolicy => _privacyPolicy ?? '';
  bool hasPrivacyPolicy() => _privacyPolicy != null;

  // "terms_of_use" field.
  String? _termsOfUse;
  String get termsOfUse => _termsOfUse ?? '';
  bool hasTermsOfUse() => _termsOfUse != null;

  // "community_standards" field.
  String? _communityStandards;
  String get communityStandards => _communityStandards ?? '';
  bool hasCommunityStandards() => _communityStandards != null;

  void _initializeFields() {
    _privacyPolicy = snapshotData['privacy_policy'] as String?;
    _termsOfUse = snapshotData['terms_of_use'] as String?;
    _communityStandards = snapshotData['community_standards'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('legal_policies');

  static Stream<LegalPoliciesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => LegalPoliciesRecord.fromSnapshot(s));

  static Future<LegalPoliciesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => LegalPoliciesRecord.fromSnapshot(s));

  static LegalPoliciesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      LegalPoliciesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static LegalPoliciesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      LegalPoliciesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'LegalPoliciesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is LegalPoliciesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createLegalPoliciesRecordData({
  String? privacyPolicy,
  String? termsOfUse,
  String? communityStandards,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'privacy_policy': privacyPolicy,
      'terms_of_use': termsOfUse,
      'community_standards': communityStandards,
    }.withoutNulls,
  );

  return firestoreData;
}

class LegalPoliciesRecordDocumentEquality
    implements Equality<LegalPoliciesRecord> {
  const LegalPoliciesRecordDocumentEquality();

  @override
  bool equals(LegalPoliciesRecord? e1, LegalPoliciesRecord? e2) {
    return e1?.privacyPolicy == e2?.privacyPolicy &&
        e1?.termsOfUse == e2?.termsOfUse &&
        e1?.communityStandards == e2?.communityStandards;
  }

  @override
  int hash(LegalPoliciesRecord? e) => const ListEquality()
      .hash([e?.privacyPolicy, e?.termsOfUse, e?.communityStandards]);

  @override
  bool isValidKey(Object? o) => o is LegalPoliciesRecord;
}
