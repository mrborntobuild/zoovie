import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class NotificationsRecord extends FirestoreRecord {
  NotificationsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "date_created" field.
  DateTime? _dateCreated;
  DateTime? get dateCreated => _dateCreated;
  bool hasDateCreated() => _dateCreated != null;

  // "receiver_ID" field.
  DocumentReference? _receiverID;
  DocumentReference? get receiverID => _receiverID;
  bool hasReceiverID() => _receiverID != null;

  // "sender_ID" field.
  DocumentReference? _senderID;
  DocumentReference? get senderID => _senderID;
  bool hasSenderID() => _senderID != null;

  // "sender_username" field.
  String? _senderUsername;
  String get senderUsername => _senderUsername ?? '';
  bool hasSenderUsername() => _senderUsername != null;

  // "sender_profile_picture" field.
  String? _senderProfilePicture;
  String get senderProfilePicture => _senderProfilePicture ?? '';
  bool hasSenderProfilePicture() => _senderProfilePicture != null;

  // "followers" field.
  bool? _followers;
  bool get followers => _followers ?? false;
  bool hasFollowers() => _followers != null;

  // "post_image" field.
  String? _postImage;
  String get postImage => _postImage ?? '';
  bool hasPostImage() => _postImage != null;

  // "like" field.
  bool? _like;
  bool get like => _like ?? false;
  bool hasLike() => _like != null;

  // "comment" field.
  String? _comment;
  String get comment => _comment ?? '';
  bool hasComment() => _comment != null;

  // "its_comment" field.
  bool? _itsComment;
  bool get itsComment => _itsComment ?? false;
  bool hasItsComment() => _itsComment != null;

  // "reward" field.
  bool? _reward;
  bool get reward => _reward ?? false;
  bool hasReward() => _reward != null;

  // "post_ID" field.
  DocumentReference? _postID;
  DocumentReference? get postID => _postID;
  bool hasPostID() => _postID != null;

  // "notification" field.
  String? _notification;
  String get notification => _notification ?? '';
  bool hasNotification() => _notification != null;

  // "video_cover" field.
  String? _videoCover;
  String get videoCover => _videoCover ?? '';
  bool hasVideoCover() => _videoCover != null;

  void _initializeFields() {
    _dateCreated = snapshotData['date_created'] as DateTime?;
    _receiverID = snapshotData['receiver_ID'] as DocumentReference?;
    _senderID = snapshotData['sender_ID'] as DocumentReference?;
    _senderUsername = snapshotData['sender_username'] as String?;
    _senderProfilePicture = snapshotData['sender_profile_picture'] as String?;
    _followers = snapshotData['followers'] as bool?;
    _postImage = snapshotData['post_image'] as String?;
    _like = snapshotData['like'] as bool?;
    _comment = snapshotData['comment'] as String?;
    _itsComment = snapshotData['its_comment'] as bool?;
    _reward = snapshotData['reward'] as bool?;
    _postID = snapshotData['post_ID'] as DocumentReference?;
    _notification = snapshotData['notification'] as String?;
    _videoCover = snapshotData['video_cover'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('notifications');

  static Stream<NotificationsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => NotificationsRecord.fromSnapshot(s));

  static Future<NotificationsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => NotificationsRecord.fromSnapshot(s));

  static NotificationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      NotificationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static NotificationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      NotificationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'NotificationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is NotificationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createNotificationsRecordData({
  DateTime? dateCreated,
  DocumentReference? receiverID,
  DocumentReference? senderID,
  String? senderUsername,
  String? senderProfilePicture,
  bool? followers,
  String? postImage,
  bool? like,
  String? comment,
  bool? itsComment,
  bool? reward,
  DocumentReference? postID,
  String? notification,
  String? videoCover,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'date_created': dateCreated,
      'receiver_ID': receiverID,
      'sender_ID': senderID,
      'sender_username': senderUsername,
      'sender_profile_picture': senderProfilePicture,
      'followers': followers,
      'post_image': postImage,
      'like': like,
      'comment': comment,
      'its_comment': itsComment,
      'reward': reward,
      'post_ID': postID,
      'notification': notification,
      'video_cover': videoCover,
    }.withoutNulls,
  );

  return firestoreData;
}

class NotificationsRecordDocumentEquality
    implements Equality<NotificationsRecord> {
  const NotificationsRecordDocumentEquality();

  @override
  bool equals(NotificationsRecord? e1, NotificationsRecord? e2) {
    return e1?.dateCreated == e2?.dateCreated &&
        e1?.receiverID == e2?.receiverID &&
        e1?.senderID == e2?.senderID &&
        e1?.senderUsername == e2?.senderUsername &&
        e1?.senderProfilePicture == e2?.senderProfilePicture &&
        e1?.followers == e2?.followers &&
        e1?.postImage == e2?.postImage &&
        e1?.like == e2?.like &&
        e1?.comment == e2?.comment &&
        e1?.itsComment == e2?.itsComment &&
        e1?.reward == e2?.reward &&
        e1?.postID == e2?.postID &&
        e1?.notification == e2?.notification &&
        e1?.videoCover == e2?.videoCover;
  }

  @override
  int hash(NotificationsRecord? e) => const ListEquality().hash([
        e?.dateCreated,
        e?.receiverID,
        e?.senderID,
        e?.senderUsername,
        e?.senderProfilePicture,
        e?.followers,
        e?.postImage,
        e?.like,
        e?.comment,
        e?.itsComment,
        e?.reward,
        e?.postID,
        e?.notification,
        e?.videoCover
      ]);

  @override
  bool isValidKey(Object? o) => o is NotificationsRecord;
}
