import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OfferRecord extends FirestoreRecord {
  OfferRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  bool hasImage() => _image != null;

  // "product_name" field.
  String? _productName;
  String get productName => _productName ?? '';
  bool hasProductName() => _productName != null;

  // "product_description" field.
  String? _productDescription;
  String get productDescription => _productDescription ?? '';
  bool hasProductDescription() => _productDescription != null;

  // "price" field.
  double? _price;
  double get price => _price ?? 0.0;
  bool hasPrice() => _price != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _image = snapshotData['image'] as String?;
    _productName = snapshotData['product_name'] as String?;
    _productDescription = snapshotData['product_description'] as String?;
    _price = castToType<double>(snapshotData['price']);
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('offer')
          : FirebaseFirestore.instance.collectionGroup('offer');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('offer').doc(id);

  static Stream<OfferRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => OfferRecord.fromSnapshot(s));

  static Future<OfferRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => OfferRecord.fromSnapshot(s));

  static OfferRecord fromSnapshot(DocumentSnapshot snapshot) => OfferRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static OfferRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      OfferRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'OfferRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is OfferRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createOfferRecordData({
  String? image,
  String? productName,
  String? productDescription,
  double? price,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'image': image,
      'product_name': productName,
      'product_description': productDescription,
      'price': price,
    }.withoutNulls,
  );

  return firestoreData;
}

class OfferRecordDocumentEquality implements Equality<OfferRecord> {
  const OfferRecordDocumentEquality();

  @override
  bool equals(OfferRecord? e1, OfferRecord? e2) {
    return e1?.image == e2?.image &&
        e1?.productName == e2?.productName &&
        e1?.productDescription == e2?.productDescription &&
        e1?.price == e2?.price;
  }

  @override
  int hash(OfferRecord? e) => const ListEquality()
      .hash([e?.image, e?.productName, e?.productDescription, e?.price]);

  @override
  bool isValidKey(Object? o) => o is OfferRecord;
}
