import 'dart:async';

import '/backend/algolia/serialization_util.dart';
import '/backend/algolia/algolia_manager.dart';
import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PartnersRecord extends FirestoreRecord {
  PartnersRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "address" field.
  String? _address;
  String get address => _address ?? '';
  bool hasAddress() => _address != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  bool hasCategory() => _category != null;

  // "banner" field.
  String? _banner;
  String get banner => _banner ?? '';
  bool hasBanner() => _banner != null;

  // "location" field.
  LatLng? _location;
  LatLng? get location => _location;
  bool hasLocation() => _location != null;

  // "businessID" field.
  DocumentReference? _businessID;
  DocumentReference? get businessID => _businessID;
  bool hasBusinessID() => _businessID != null;

  // "public" field.
  String? _public;
  String get public => _public ?? '';
  bool hasPublic() => _public != null;

  // "logo" field.
  String? _logo;
  String get logo => _logo ?? '';
  bool hasLogo() => _logo != null;

  // "discount" field.
  int? _discount;
  int get discount => _discount ?? 0;
  bool hasDiscount() => _discount != null;

  // "Monday" field.
  String? _monday;
  String get monday => _monday ?? '';
  bool hasMonday() => _monday != null;

  // "Tuesday" field.
  String? _tuesday;
  String get tuesday => _tuesday ?? '';
  bool hasTuesday() => _tuesday != null;

  // "Wednesday" field.
  String? _wednesday;
  String get wednesday => _wednesday ?? '';
  bool hasWednesday() => _wednesday != null;

  // "Thursday" field.
  String? _thursday;
  String get thursday => _thursday ?? '';
  bool hasThursday() => _thursday != null;

  // "Friday" field.
  String? _friday;
  String get friday => _friday ?? '';
  bool hasFriday() => _friday != null;

  // "Saturday" field.
  String? _saturday;
  String get saturday => _saturday ?? '';
  bool hasSaturday() => _saturday != null;

  // "Sunday" field.
  String? _sunday;
  String get sunday => _sunday ?? '';
  bool hasSunday() => _sunday != null;

  // "xPoints" field.
  int? _xPoints;
  int get xPoints => _xPoints ?? 0;
  bool hasXPoints() => _xPoints != null;

  void _initializeFields() {
    _displayName = snapshotData['display_name'] as String?;
    _email = snapshotData['email'] as String?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _address = snapshotData['address'] as String?;
    _category = snapshotData['category'] as String?;
    _banner = snapshotData['banner'] as String?;
    _location = snapshotData['location'] as LatLng?;
    _businessID = snapshotData['businessID'] as DocumentReference?;
    _public = snapshotData['public'] as String?;
    _logo = snapshotData['logo'] as String?;
    _discount = castToType<int>(snapshotData['discount']);
    _monday = snapshotData['Monday'] as String?;
    _tuesday = snapshotData['Tuesday'] as String?;
    _wednesday = snapshotData['Wednesday'] as String?;
    _thursday = snapshotData['Thursday'] as String?;
    _friday = snapshotData['Friday'] as String?;
    _saturday = snapshotData['Saturday'] as String?;
    _sunday = snapshotData['Sunday'] as String?;
    _xPoints = castToType<int>(snapshotData['xPoints']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('partners');

  static Stream<PartnersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PartnersRecord.fromSnapshot(s));

  static Future<PartnersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PartnersRecord.fromSnapshot(s));

  static PartnersRecord fromSnapshot(DocumentSnapshot snapshot) =>
      PartnersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PartnersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PartnersRecord._(reference, mapFromFirestore(data));

  static PartnersRecord fromAlgolia(AlgoliaObjectSnapshot snapshot) =>
      PartnersRecord.getDocumentFromData(
        {
          'display_name': snapshot.data['display_name'],
          'email': snapshot.data['email'],
          'phone_number': snapshot.data['phone_number'],
          'address': snapshot.data['address'],
          'category': snapshot.data['category'],
          'banner': snapshot.data['banner'],
          'location': convertAlgoliaParam(
            snapshot.data,
            ParamType.LatLng,
            false,
          ),
          'businessID': convertAlgoliaParam(
            snapshot.data['businessID'],
            ParamType.DocumentReference,
            false,
          ),
          'public': snapshot.data['public'],
          'logo': snapshot.data['logo'],
          'discount': convertAlgoliaParam(
            snapshot.data['discount'],
            ParamType.int,
            false,
          ),
          'Monday': snapshot.data['Monday'],
          'Tuesday': snapshot.data['Tuesday'],
          'Wednesday': snapshot.data['Wednesday'],
          'Thursday': snapshot.data['Thursday'],
          'Friday': snapshot.data['Friday'],
          'Saturday': snapshot.data['Saturday'],
          'Sunday': snapshot.data['Sunday'],
          'xPoints': convertAlgoliaParam(
            snapshot.data['xPoints'],
            ParamType.int,
            false,
          ),
        },
        PartnersRecord.collection.doc(snapshot.objectID),
      );

  static Future<List<PartnersRecord>> search({
    String? term,
    FutureOr<LatLng>? location,
    int? maxResults,
    double? searchRadiusMeters,
    bool useCache = false,
  }) =>
      FFAlgoliaManager.instance
          .algoliaQuery(
            index: 'partners',
            term: term,
            maxResults: maxResults,
            location: location,
            searchRadiusMeters: searchRadiusMeters,
            useCache: useCache,
          )
          .then((r) => r.map(fromAlgolia).toList());

  @override
  String toString() =>
      'PartnersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PartnersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPartnersRecordData({
  String? displayName,
  String? email,
  String? phoneNumber,
  String? address,
  String? category,
  String? banner,
  LatLng? location,
  DocumentReference? businessID,
  String? public,
  String? logo,
  int? discount,
  String? monday,
  String? tuesday,
  String? wednesday,
  String? thursday,
  String? friday,
  String? saturday,
  String? sunday,
  int? xPoints,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'display_name': displayName,
      'email': email,
      'phone_number': phoneNumber,
      'address': address,
      'category': category,
      'banner': banner,
      'location': location,
      'businessID': businessID,
      'public': public,
      'logo': logo,
      'discount': discount,
      'Monday': monday,
      'Tuesday': tuesday,
      'Wednesday': wednesday,
      'Thursday': thursday,
      'Friday': friday,
      'Saturday': saturday,
      'Sunday': sunday,
      'xPoints': xPoints,
    }.withoutNulls,
  );

  return firestoreData;
}

class PartnersRecordDocumentEquality implements Equality<PartnersRecord> {
  const PartnersRecordDocumentEquality();

  @override
  bool equals(PartnersRecord? e1, PartnersRecord? e2) {
    return e1?.displayName == e2?.displayName &&
        e1?.email == e2?.email &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.address == e2?.address &&
        e1?.category == e2?.category &&
        e1?.banner == e2?.banner &&
        e1?.location == e2?.location &&
        e1?.businessID == e2?.businessID &&
        e1?.public == e2?.public &&
        e1?.logo == e2?.logo &&
        e1?.discount == e2?.discount &&
        e1?.monday == e2?.monday &&
        e1?.tuesday == e2?.tuesday &&
        e1?.wednesday == e2?.wednesday &&
        e1?.thursday == e2?.thursday &&
        e1?.friday == e2?.friday &&
        e1?.saturday == e2?.saturday &&
        e1?.sunday == e2?.sunday &&
        e1?.xPoints == e2?.xPoints;
  }

  @override
  int hash(PartnersRecord? e) => const ListEquality().hash([
        e?.displayName,
        e?.email,
        e?.phoneNumber,
        e?.address,
        e?.category,
        e?.banner,
        e?.location,
        e?.businessID,
        e?.public,
        e?.logo,
        e?.discount,
        e?.monday,
        e?.tuesday,
        e?.wednesday,
        e?.thursday,
        e?.friday,
        e?.saturday,
        e?.sunday,
        e?.xPoints
      ]);

  @override
  bool isValidKey(Object? o) => o is PartnersRecord;
}
