import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PointsRecord extends FirestoreRecord {
  PointsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "vendor" field.
  DocumentReference? _vendor;
  DocumentReference? get vendor => _vendor;
  bool hasVendor() => _vendor != null;

  // "transaction" field.
  double? _transaction;
  double get transaction => _transaction ?? 0.0;
  bool hasTransaction() => _transaction != null;

  // "beneree_fee" field.
  double? _benereeFee;
  double get benereeFee => _benereeFee ?? 0.0;
  bool hasBenereeFee() => _benereeFee != null;

  // "buyerID" field.
  DocumentReference? _buyerID;
  DocumentReference? get buyerID => _buyerID;
  bool hasBuyerID() => _buyerID != null;

  // "buyer_points" field.
  int? _buyerPoints;
  int get buyerPoints => _buyerPoints ?? 0;
  bool hasBuyerPoints() => _buyerPoints != null;

  // "referrerID" field.
  DocumentReference? _referrerID;
  DocumentReference? get referrerID => _referrerID;
  bool hasReferrerID() => _referrerID != null;

  // "referrer_points" field.
  int? _referrerPoints;
  int get referrerPoints => _referrerPoints ?? 0;
  bool hasReferrerPoints() => _referrerPoints != null;

  // "time" field.
  DateTime? _time;
  DateTime? get time => _time;
  bool hasTime() => _time != null;

  // "location" field.
  LatLng? _location;
  LatLng? get location => _location;
  bool hasLocation() => _location != null;

  // "scanned" field.
  bool? _scanned;
  bool get scanned => _scanned ?? false;
  bool hasScanned() => _scanned != null;

  // "scanTime" field.
  DateTime? _scanTime;
  DateTime? get scanTime => _scanTime;
  bool hasScanTime() => _scanTime != null;

  // "scanLocation" field.
  LatLng? _scanLocation;
  LatLng? get scanLocation => _scanLocation;
  bool hasScanLocation() => _scanLocation != null;

  // "cancelledByWendor" field.
  bool? _cancelledByWendor;
  bool get cancelledByWendor => _cancelledByWendor ?? false;
  bool hasCancelledByWendor() => _cancelledByWendor != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "logo" field.
  String? _logo;
  String get logo => _logo ?? '';
  bool hasLogo() => _logo != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "withdrawal" field.
  bool? _withdrawal;
  bool get withdrawal => _withdrawal ?? false;
  bool hasWithdrawal() => _withdrawal != null;

  // "pending" field.
  bool? _pending;
  bool get pending => _pending ?? false;
  bool hasPending() => _pending != null;

  void _initializeFields() {
    _vendor = snapshotData['vendor'] as DocumentReference?;
    _transaction = castToType<double>(snapshotData['transaction']);
    _benereeFee = castToType<double>(snapshotData['beneree_fee']);
    _buyerID = snapshotData['buyerID'] as DocumentReference?;
    _buyerPoints = castToType<int>(snapshotData['buyer_points']);
    _referrerID = snapshotData['referrerID'] as DocumentReference?;
    _referrerPoints = castToType<int>(snapshotData['referrer_points']);
    _time = snapshotData['time'] as DateTime?;
    _location = snapshotData['location'] as LatLng?;
    _scanned = snapshotData['scanned'] as bool?;
    _scanTime = snapshotData['scanTime'] as DateTime?;
    _scanLocation = snapshotData['scanLocation'] as LatLng?;
    _cancelledByWendor = snapshotData['cancelledByWendor'] as bool?;
    _title = snapshotData['title'] as String?;
    _logo = snapshotData['logo'] as String?;
    _name = snapshotData['name'] as String?;
    _withdrawal = snapshotData['withdrawal'] as bool?;
    _pending = snapshotData['pending'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('points');

  static Stream<PointsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PointsRecord.fromSnapshot(s));

  static Future<PointsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PointsRecord.fromSnapshot(s));

  static PointsRecord fromSnapshot(DocumentSnapshot snapshot) => PointsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PointsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PointsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PointsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PointsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPointsRecordData({
  DocumentReference? vendor,
  double? transaction,
  double? benereeFee,
  DocumentReference? buyerID,
  int? buyerPoints,
  DocumentReference? referrerID,
  int? referrerPoints,
  DateTime? time,
  LatLng? location,
  bool? scanned,
  DateTime? scanTime,
  LatLng? scanLocation,
  bool? cancelledByWendor,
  String? title,
  String? logo,
  String? name,
  bool? withdrawal,
  bool? pending,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'vendor': vendor,
      'transaction': transaction,
      'beneree_fee': benereeFee,
      'buyerID': buyerID,
      'buyer_points': buyerPoints,
      'referrerID': referrerID,
      'referrer_points': referrerPoints,
      'time': time,
      'location': location,
      'scanned': scanned,
      'scanTime': scanTime,
      'scanLocation': scanLocation,
      'cancelledByWendor': cancelledByWendor,
      'title': title,
      'logo': logo,
      'name': name,
      'withdrawal': withdrawal,
      'pending': pending,
    }.withoutNulls,
  );

  return firestoreData;
}

class PointsRecordDocumentEquality implements Equality<PointsRecord> {
  const PointsRecordDocumentEquality();

  @override
  bool equals(PointsRecord? e1, PointsRecord? e2) {
    return e1?.vendor == e2?.vendor &&
        e1?.transaction == e2?.transaction &&
        e1?.benereeFee == e2?.benereeFee &&
        e1?.buyerID == e2?.buyerID &&
        e1?.buyerPoints == e2?.buyerPoints &&
        e1?.referrerID == e2?.referrerID &&
        e1?.referrerPoints == e2?.referrerPoints &&
        e1?.time == e2?.time &&
        e1?.location == e2?.location &&
        e1?.scanned == e2?.scanned &&
        e1?.scanTime == e2?.scanTime &&
        e1?.scanLocation == e2?.scanLocation &&
        e1?.cancelledByWendor == e2?.cancelledByWendor &&
        e1?.title == e2?.title &&
        e1?.logo == e2?.logo &&
        e1?.name == e2?.name &&
        e1?.withdrawal == e2?.withdrawal &&
        e1?.pending == e2?.pending;
  }

  @override
  int hash(PointsRecord? e) => const ListEquality().hash([
        e?.vendor,
        e?.transaction,
        e?.benereeFee,
        e?.buyerID,
        e?.buyerPoints,
        e?.referrerID,
        e?.referrerPoints,
        e?.time,
        e?.location,
        e?.scanned,
        e?.scanTime,
        e?.scanLocation,
        e?.cancelledByWendor,
        e?.title,
        e?.logo,
        e?.name,
        e?.withdrawal,
        e?.pending
      ]);

  @override
  bool isValidKey(Object? o) => o is PointsRecord;
}
