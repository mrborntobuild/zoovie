import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class ReportedPostsRecord extends FirestoreRecord {
  ReportedPostsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "postID" field.
  DocumentReference? _postID;
  DocumentReference? get postID => _postID;
  bool hasPostID() => _postID != null;

  // "user_id" field.
  DocumentReference? _userId;
  DocumentReference? get userId => _userId;
  bool hasUserId() => _userId != null;

  // "report_reason" field.
  String? _reportReason;
  String get reportReason => _reportReason ?? '';
  bool hasReportReason() => _reportReason != null;

  // "report_description" field.
  String? _reportDescription;
  String get reportDescription => _reportDescription ?? '';
  bool hasReportDescription() => _reportDescription != null;

  // "report_user_comment" field.
  String? _reportUserComment;
  String get reportUserComment => _reportUserComment ?? '';
  bool hasReportUserComment() => _reportUserComment != null;

  void _initializeFields() {
    _postID = snapshotData['postID'] as DocumentReference?;
    _userId = snapshotData['user_id'] as DocumentReference?;
    _reportReason = snapshotData['report_reason'] as String?;
    _reportDescription = snapshotData['report_description'] as String?;
    _reportUserComment = snapshotData['report_user_comment'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('reported_posts');

  static Stream<ReportedPostsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ReportedPostsRecord.fromSnapshot(s));

  static Future<ReportedPostsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ReportedPostsRecord.fromSnapshot(s));

  static ReportedPostsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ReportedPostsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ReportedPostsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ReportedPostsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ReportedPostsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ReportedPostsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createReportedPostsRecordData({
  DocumentReference? postID,
  DocumentReference? userId,
  String? reportReason,
  String? reportDescription,
  String? reportUserComment,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'postID': postID,
      'user_id': userId,
      'report_reason': reportReason,
      'report_description': reportDescription,
      'report_user_comment': reportUserComment,
    }.withoutNulls,
  );

  return firestoreData;
}

class ReportedPostsRecordDocumentEquality
    implements Equality<ReportedPostsRecord> {
  const ReportedPostsRecordDocumentEquality();

  @override
  bool equals(ReportedPostsRecord? e1, ReportedPostsRecord? e2) {
    return e1?.postID == e2?.postID &&
        e1?.userId == e2?.userId &&
        e1?.reportReason == e2?.reportReason &&
        e1?.reportDescription == e2?.reportDescription &&
        e1?.reportUserComment == e2?.reportUserComment;
  }

  @override
  int hash(ReportedPostsRecord? e) => const ListEquality().hash([
        e?.postID,
        e?.userId,
        e?.reportReason,
        e?.reportDescription,
        e?.reportUserComment
      ]);

  @override
  bool isValidKey(Object? o) => o is ReportedPostsRecord;
}
