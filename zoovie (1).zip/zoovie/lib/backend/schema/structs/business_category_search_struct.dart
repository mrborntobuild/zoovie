// ignore_for_file: unnecessary_getters_setters
import '/backend/algolia/serialization_util.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BusinessCategorySearchStruct extends FFFirebaseStruct {
  BusinessCategorySearchStruct({
    List<String>? suggested,
    List<String>? categories,
    bool? searching,
    String? selected,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _suggested = suggested,
        _categories = categories,
        _searching = searching,
        _selected = selected,
        super(firestoreUtilData);

  // "suggested" field.
  List<String>? _suggested;
  List<String> get suggested => _suggested ?? const [];
  set suggested(List<String>? val) => _suggested = val;
  void updateSuggested(Function(List<String>) updateFn) =>
      updateFn(_suggested ??= []);
  bool hasSuggested() => _suggested != null;

  // "categories" field.
  List<String>? _categories;
  List<String> get categories => _categories ?? const [];
  set categories(List<String>? val) => _categories = val;
  void updateCategories(Function(List<String>) updateFn) =>
      updateFn(_categories ??= []);
  bool hasCategories() => _categories != null;

  // "searching" field.
  bool? _searching;
  bool get searching => _searching ?? false;
  set searching(bool? val) => _searching = val;
  bool hasSearching() => _searching != null;

  // "selected" field.
  String? _selected;
  String get selected => _selected ?? '';
  set selected(String? val) => _selected = val;
  bool hasSelected() => _selected != null;

  static BusinessCategorySearchStruct fromMap(Map<String, dynamic> data) =>
      BusinessCategorySearchStruct(
        suggested: getDataList(data['suggested']),
        categories: getDataList(data['categories']),
        searching: data['searching'] as bool?,
        selected: data['selected'] as String?,
      );

  static BusinessCategorySearchStruct? maybeFromMap(dynamic data) => data is Map
      ? BusinessCategorySearchStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'suggested': _suggested,
        'categories': _categories,
        'searching': _searching,
        'selected': _selected,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'suggested': serializeParam(
          _suggested,
          ParamType.String,
          true,
        ),
        'categories': serializeParam(
          _categories,
          ParamType.String,
          true,
        ),
        'searching': serializeParam(
          _searching,
          ParamType.bool,
        ),
        'selected': serializeParam(
          _selected,
          ParamType.String,
        ),
      }.withoutNulls;

  static BusinessCategorySearchStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      BusinessCategorySearchStruct(
        suggested: deserializeParam<String>(
          data['suggested'],
          ParamType.String,
          true,
        ),
        categories: deserializeParam<String>(
          data['categories'],
          ParamType.String,
          true,
        ),
        searching: deserializeParam(
          data['searching'],
          ParamType.bool,
          false,
        ),
        selected: deserializeParam(
          data['selected'],
          ParamType.String,
          false,
        ),
      );

  static BusinessCategorySearchStruct fromAlgoliaData(
          Map<String, dynamic> data) =>
      BusinessCategorySearchStruct(
        suggested: convertAlgoliaParam<String>(
          data['suggested'],
          ParamType.String,
          true,
        ),
        categories: convertAlgoliaParam<String>(
          data['categories'],
          ParamType.String,
          true,
        ),
        searching: convertAlgoliaParam(
          data['searching'],
          ParamType.bool,
          false,
        ),
        selected: convertAlgoliaParam(
          data['selected'],
          ParamType.String,
          false,
        ),
        firestoreUtilData: const FirestoreUtilData(
          clearUnsetFields: false,
          create: true,
        ),
      );

  @override
  String toString() => 'BusinessCategorySearchStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is BusinessCategorySearchStruct &&
        listEquality.equals(suggested, other.suggested) &&
        listEquality.equals(categories, other.categories) &&
        searching == other.searching &&
        selected == other.selected;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([suggested, categories, searching, selected]);
}

BusinessCategorySearchStruct createBusinessCategorySearchStruct({
  bool? searching,
  String? selected,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    BusinessCategorySearchStruct(
      searching: searching,
      selected: selected,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

BusinessCategorySearchStruct? updateBusinessCategorySearchStruct(
  BusinessCategorySearchStruct? businessCategorySearch, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    businessCategorySearch
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addBusinessCategorySearchStructData(
  Map<String, dynamic> firestoreData,
  BusinessCategorySearchStruct? businessCategorySearch,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (businessCategorySearch == null) {
    return;
  }
  if (businessCategorySearch.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields = !forFieldValue &&
      businessCategorySearch.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final businessCategorySearchData = getBusinessCategorySearchFirestoreData(
      businessCategorySearch, forFieldValue);
  final nestedData =
      businessCategorySearchData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields =
      businessCategorySearch.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getBusinessCategorySearchFirestoreData(
  BusinessCategorySearchStruct? businessCategorySearch, [
  bool forFieldValue = false,
]) {
  if (businessCategorySearch == null) {
    return {};
  }
  final firestoreData = mapToFirestore(businessCategorySearch.toMap());

  // Add any Firestore field values
  businessCategorySearch.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getBusinessCategorySearchListFirestoreData(
  List<BusinessCategorySearchStruct>? businessCategorySearchs,
) =>
    businessCategorySearchs
        ?.map((e) => getBusinessCategorySearchFirestoreData(e, true))
        .toList() ??
    [];
