// ignore_for_file: unnecessary_getters_setters
import '/backend/algolia/serialization_util.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BusinessPortalUpdateStruct extends FFFirebaseStruct {
  BusinessPortalUpdateStruct({
    String? backgroundPicture,
    String? logo,
    double? discount,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _backgroundPicture = backgroundPicture,
        _logo = logo,
        _discount = discount,
        super(firestoreUtilData);

  // "background_picture" field.
  String? _backgroundPicture;
  String get backgroundPicture => _backgroundPicture ?? '';
  set backgroundPicture(String? val) => _backgroundPicture = val;
  bool hasBackgroundPicture() => _backgroundPicture != null;

  // "logo" field.
  String? _logo;
  String get logo => _logo ?? '';
  set logo(String? val) => _logo = val;
  bool hasLogo() => _logo != null;

  // "discount" field.
  double? _discount;
  double get discount => _discount ?? 0.0;
  set discount(double? val) => _discount = val;
  void incrementDiscount(double amount) => _discount = discount + amount;
  bool hasDiscount() => _discount != null;

  static BusinessPortalUpdateStruct fromMap(Map<String, dynamic> data) =>
      BusinessPortalUpdateStruct(
        backgroundPicture: data['background_picture'] as String?,
        logo: data['logo'] as String?,
        discount: castToType<double>(data['discount']),
      );

  static BusinessPortalUpdateStruct? maybeFromMap(dynamic data) => data is Map
      ? BusinessPortalUpdateStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'background_picture': _backgroundPicture,
        'logo': _logo,
        'discount': _discount,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'background_picture': serializeParam(
          _backgroundPicture,
          ParamType.String,
        ),
        'logo': serializeParam(
          _logo,
          ParamType.String,
        ),
        'discount': serializeParam(
          _discount,
          ParamType.double,
        ),
      }.withoutNulls;

  static BusinessPortalUpdateStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      BusinessPortalUpdateStruct(
        backgroundPicture: deserializeParam(
          data['background_picture'],
          ParamType.String,
          false,
        ),
        logo: deserializeParam(
          data['logo'],
          ParamType.String,
          false,
        ),
        discount: deserializeParam(
          data['discount'],
          ParamType.double,
          false,
        ),
      );

  static BusinessPortalUpdateStruct fromAlgoliaData(
          Map<String, dynamic> data) =>
      BusinessPortalUpdateStruct(
        backgroundPicture: convertAlgoliaParam(
          data['background_picture'],
          ParamType.String,
          false,
        ),
        logo: convertAlgoliaParam(
          data['logo'],
          ParamType.String,
          false,
        ),
        discount: convertAlgoliaParam(
          data['discount'],
          ParamType.double,
          false,
        ),
        firestoreUtilData: const FirestoreUtilData(
          clearUnsetFields: false,
          create: true,
        ),
      );

  @override
  String toString() => 'BusinessPortalUpdateStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is BusinessPortalUpdateStruct &&
        backgroundPicture == other.backgroundPicture &&
        logo == other.logo &&
        discount == other.discount;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([backgroundPicture, logo, discount]);
}

BusinessPortalUpdateStruct createBusinessPortalUpdateStruct({
  String? backgroundPicture,
  String? logo,
  double? discount,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    BusinessPortalUpdateStruct(
      backgroundPicture: backgroundPicture,
      logo: logo,
      discount: discount,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

BusinessPortalUpdateStruct? updateBusinessPortalUpdateStruct(
  BusinessPortalUpdateStruct? businessPortalUpdate, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    businessPortalUpdate
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addBusinessPortalUpdateStructData(
  Map<String, dynamic> firestoreData,
  BusinessPortalUpdateStruct? businessPortalUpdate,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (businessPortalUpdate == null) {
    return;
  }
  if (businessPortalUpdate.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && businessPortalUpdate.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final businessPortalUpdateData =
      getBusinessPortalUpdateFirestoreData(businessPortalUpdate, forFieldValue);
  final nestedData =
      businessPortalUpdateData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields =
      businessPortalUpdate.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getBusinessPortalUpdateFirestoreData(
  BusinessPortalUpdateStruct? businessPortalUpdate, [
  bool forFieldValue = false,
]) {
  if (businessPortalUpdate == null) {
    return {};
  }
  final firestoreData = mapToFirestore(businessPortalUpdate.toMap());

  // Add any Firestore field values
  businessPortalUpdate.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getBusinessPortalUpdateListFirestoreData(
  List<BusinessPortalUpdateStruct>? businessPortalUpdates,
) =>
    businessPortalUpdates
        ?.map((e) => getBusinessPortalUpdateFirestoreData(e, true))
        .toList() ??
    [];
