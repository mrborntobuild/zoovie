// ignore_for_file: unnecessary_getters_setters
import '/backend/algolia/serialization_util.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChatGPTBlockStruct extends FFFirebaseStruct {
  ChatGPTBlockStruct({
    DateTime? firstMessageDate,
    int? messageCount,
    int? hours,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _firstMessageDate = firstMessageDate,
        _messageCount = messageCount,
        _hours = hours,
        super(firestoreUtilData);

  // "first_message_date" field.
  DateTime? _firstMessageDate;
  DateTime? get firstMessageDate => _firstMessageDate;
  set firstMessageDate(DateTime? val) => _firstMessageDate = val;
  bool hasFirstMessageDate() => _firstMessageDate != null;

  // "message_count" field.
  int? _messageCount;
  int get messageCount => _messageCount ?? 0;
  set messageCount(int? val) => _messageCount = val;
  void incrementMessageCount(int amount) =>
      _messageCount = messageCount + amount;
  bool hasMessageCount() => _messageCount != null;

  // "hours" field.
  int? _hours;
  int get hours => _hours ?? 0;
  set hours(int? val) => _hours = val;
  void incrementHours(int amount) => _hours = hours + amount;
  bool hasHours() => _hours != null;

  static ChatGPTBlockStruct fromMap(Map<String, dynamic> data) =>
      ChatGPTBlockStruct(
        firstMessageDate: data['first_message_date'] as DateTime?,
        messageCount: castToType<int>(data['message_count']),
        hours: castToType<int>(data['hours']),
      );

  static ChatGPTBlockStruct? maybeFromMap(dynamic data) => data is Map
      ? ChatGPTBlockStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'first_message_date': _firstMessageDate,
        'message_count': _messageCount,
        'hours': _hours,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'first_message_date': serializeParam(
          _firstMessageDate,
          ParamType.DateTime,
        ),
        'message_count': serializeParam(
          _messageCount,
          ParamType.int,
        ),
        'hours': serializeParam(
          _hours,
          ParamType.int,
        ),
      }.withoutNulls;

  static ChatGPTBlockStruct fromSerializableMap(Map<String, dynamic> data) =>
      ChatGPTBlockStruct(
        firstMessageDate: deserializeParam(
          data['first_message_date'],
          ParamType.DateTime,
          false,
        ),
        messageCount: deserializeParam(
          data['message_count'],
          ParamType.int,
          false,
        ),
        hours: deserializeParam(
          data['hours'],
          ParamType.int,
          false,
        ),
      );

  static ChatGPTBlockStruct fromAlgoliaData(Map<String, dynamic> data) =>
      ChatGPTBlockStruct(
        firstMessageDate: convertAlgoliaParam(
          data['first_message_date'],
          ParamType.DateTime,
          false,
        ),
        messageCount: convertAlgoliaParam(
          data['message_count'],
          ParamType.int,
          false,
        ),
        hours: convertAlgoliaParam(
          data['hours'],
          ParamType.int,
          false,
        ),
        firestoreUtilData: const FirestoreUtilData(
          clearUnsetFields: false,
          create: true,
        ),
      );

  @override
  String toString() => 'ChatGPTBlockStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is ChatGPTBlockStruct &&
        firstMessageDate == other.firstMessageDate &&
        messageCount == other.messageCount &&
        hours == other.hours;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([firstMessageDate, messageCount, hours]);
}

ChatGPTBlockStruct createChatGPTBlockStruct({
  DateTime? firstMessageDate,
  int? messageCount,
  int? hours,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    ChatGPTBlockStruct(
      firstMessageDate: firstMessageDate,
      messageCount: messageCount,
      hours: hours,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

ChatGPTBlockStruct? updateChatGPTBlockStruct(
  ChatGPTBlockStruct? chatGPTBlock, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    chatGPTBlock
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addChatGPTBlockStructData(
  Map<String, dynamic> firestoreData,
  ChatGPTBlockStruct? chatGPTBlock,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (chatGPTBlock == null) {
    return;
  }
  if (chatGPTBlock.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && chatGPTBlock.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final chatGPTBlockData =
      getChatGPTBlockFirestoreData(chatGPTBlock, forFieldValue);
  final nestedData =
      chatGPTBlockData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = chatGPTBlock.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getChatGPTBlockFirestoreData(
  ChatGPTBlockStruct? chatGPTBlock, [
  bool forFieldValue = false,
]) {
  if (chatGPTBlock == null) {
    return {};
  }
  final firestoreData = mapToFirestore(chatGPTBlock.toMap());

  // Add any Firestore field values
  chatGPTBlock.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getChatGPTBlockListFirestoreData(
  List<ChatGPTBlockStruct>? chatGPTBlocks,
) =>
    chatGPTBlocks?.map((e) => getChatGPTBlockFirestoreData(e, true)).toList() ??
    [];
