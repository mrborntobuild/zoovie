// ignore_for_file: unnecessary_getters_setters
import '/backend/algolia/serialization_util.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CommentDataStruct extends FFFirebaseStruct {
  CommentDataStruct({
    bool? itsAReply,
    DocumentReference? repliedToComment,
    DocumentReference? postReference,
    String? replyingToUser,
    DocumentReference? replyingToReply,
    DocumentReference? userID,
    bool? typing,
    DocumentReference? userId,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _itsAReply = itsAReply,
        _repliedToComment = repliedToComment,
        _postReference = postReference,
        _replyingToUser = replyingToUser,
        _replyingToReply = replyingToReply,
        _userID = userID,
        _typing = typing,
        _userId = userId,
        super(firestoreUtilData);

  // "its_a_reply" field.
  bool? _itsAReply;
  bool get itsAReply => _itsAReply ?? false;
  set itsAReply(bool? val) => _itsAReply = val;
  bool hasItsAReply() => _itsAReply != null;

  // "replied_to_comment" field.
  DocumentReference? _repliedToComment;
  DocumentReference? get repliedToComment => _repliedToComment;
  set repliedToComment(DocumentReference? val) => _repliedToComment = val;
  bool hasRepliedToComment() => _repliedToComment != null;

  // "post_reference" field.
  DocumentReference? _postReference;
  DocumentReference? get postReference => _postReference;
  set postReference(DocumentReference? val) => _postReference = val;
  bool hasPostReference() => _postReference != null;

  // "replying_to_user" field.
  String? _replyingToUser;
  String get replyingToUser => _replyingToUser ?? '';
  set replyingToUser(String? val) => _replyingToUser = val;
  bool hasReplyingToUser() => _replyingToUser != null;

  // "replying_to_reply" field.
  DocumentReference? _replyingToReply;
  DocumentReference? get replyingToReply => _replyingToReply;
  set replyingToReply(DocumentReference? val) => _replyingToReply = val;
  bool hasReplyingToReply() => _replyingToReply != null;

  // "userID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  set userID(DocumentReference? val) => _userID = val;
  bool hasUserID() => _userID != null;

  // "typing" field.
  bool? _typing;
  bool get typing => _typing ?? false;
  set typing(bool? val) => _typing = val;
  bool hasTyping() => _typing != null;

  // "user_id" field.
  DocumentReference? _userId;
  DocumentReference? get userId => _userId;
  set userId(DocumentReference? val) => _userId = val;
  bool hasUserId() => _userId != null;

  static CommentDataStruct fromMap(Map<String, dynamic> data) =>
      CommentDataStruct(
        itsAReply: data['its_a_reply'] as bool?,
        repliedToComment: data['replied_to_comment'] as DocumentReference?,
        postReference: data['post_reference'] as DocumentReference?,
        replyingToUser: data['replying_to_user'] as String?,
        replyingToReply: data['replying_to_reply'] as DocumentReference?,
        userID: data['userID'] as DocumentReference?,
        typing: data['typing'] as bool?,
        userId: data['user_id'] as DocumentReference?,
      );

  static CommentDataStruct? maybeFromMap(dynamic data) => data is Map
      ? CommentDataStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'its_a_reply': _itsAReply,
        'replied_to_comment': _repliedToComment,
        'post_reference': _postReference,
        'replying_to_user': _replyingToUser,
        'replying_to_reply': _replyingToReply,
        'userID': _userID,
        'typing': _typing,
        'user_id': _userId,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'its_a_reply': serializeParam(
          _itsAReply,
          ParamType.bool,
        ),
        'replied_to_comment': serializeParam(
          _repliedToComment,
          ParamType.DocumentReference,
        ),
        'post_reference': serializeParam(
          _postReference,
          ParamType.DocumentReference,
        ),
        'replying_to_user': serializeParam(
          _replyingToUser,
          ParamType.String,
        ),
        'replying_to_reply': serializeParam(
          _replyingToReply,
          ParamType.DocumentReference,
        ),
        'userID': serializeParam(
          _userID,
          ParamType.DocumentReference,
        ),
        'typing': serializeParam(
          _typing,
          ParamType.bool,
        ),
        'user_id': serializeParam(
          _userId,
          ParamType.DocumentReference,
        ),
      }.withoutNulls;

  static CommentDataStruct fromSerializableMap(Map<String, dynamic> data) =>
      CommentDataStruct(
        itsAReply: deserializeParam(
          data['its_a_reply'],
          ParamType.bool,
          false,
        ),
        repliedToComment: deserializeParam(
          data['replied_to_comment'],
          ParamType.DocumentReference,
          false,
          collectionNamePath: ['comments'],
        ),
        postReference: deserializeParam(
          data['post_reference'],
          ParamType.DocumentReference,
          false,
          collectionNamePath: ['posts'],
        ),
        replyingToUser: deserializeParam(
          data['replying_to_user'],
          ParamType.String,
          false,
        ),
        replyingToReply: deserializeParam(
          data['replying_to_reply'],
          ParamType.DocumentReference,
          false,
          collectionNamePath: ['comments', 'replies'],
        ),
        userID: deserializeParam(
          data['userID'],
          ParamType.DocumentReference,
          false,
          collectionNamePath: ['users'],
        ),
        typing: deserializeParam(
          data['typing'],
          ParamType.bool,
          false,
        ),
        userId: deserializeParam(
          data['user_id'],
          ParamType.DocumentReference,
          false,
          collectionNamePath: ['users'],
        ),
      );

  static CommentDataStruct fromAlgoliaData(Map<String, dynamic> data) =>
      CommentDataStruct(
        itsAReply: convertAlgoliaParam(
          data['its_a_reply'],
          ParamType.bool,
          false,
        ),
        repliedToComment: convertAlgoliaParam(
          data['replied_to_comment'],
          ParamType.DocumentReference,
          false,
        ),
        postReference: convertAlgoliaParam(
          data['post_reference'],
          ParamType.DocumentReference,
          false,
        ),
        replyingToUser: convertAlgoliaParam(
          data['replying_to_user'],
          ParamType.String,
          false,
        ),
        replyingToReply: convertAlgoliaParam(
          data['replying_to_reply'],
          ParamType.DocumentReference,
          false,
        ),
        userID: convertAlgoliaParam(
          data['userID'],
          ParamType.DocumentReference,
          false,
        ),
        typing: convertAlgoliaParam(
          data['typing'],
          ParamType.bool,
          false,
        ),
        userId: convertAlgoliaParam(
          data['user_id'],
          ParamType.DocumentReference,
          false,
        ),
        firestoreUtilData: const FirestoreUtilData(
          clearUnsetFields: false,
          create: true,
        ),
      );

  @override
  String toString() => 'CommentDataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is CommentDataStruct &&
        itsAReply == other.itsAReply &&
        repliedToComment == other.repliedToComment &&
        postReference == other.postReference &&
        replyingToUser == other.replyingToUser &&
        replyingToReply == other.replyingToReply &&
        userID == other.userID &&
        typing == other.typing &&
        userId == other.userId;
  }

  @override
  int get hashCode => const ListEquality().hash([
        itsAReply,
        repliedToComment,
        postReference,
        replyingToUser,
        replyingToReply,
        userID,
        typing,
        userId
      ]);
}

CommentDataStruct createCommentDataStruct({
  bool? itsAReply,
  DocumentReference? repliedToComment,
  DocumentReference? postReference,
  String? replyingToUser,
  DocumentReference? replyingToReply,
  DocumentReference? userID,
  bool? typing,
  DocumentReference? userId,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    CommentDataStruct(
      itsAReply: itsAReply,
      repliedToComment: repliedToComment,
      postReference: postReference,
      replyingToUser: replyingToUser,
      replyingToReply: replyingToReply,
      userID: userID,
      typing: typing,
      userId: userId,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

CommentDataStruct? updateCommentDataStruct(
  CommentDataStruct? commentData, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    commentData
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addCommentDataStructData(
  Map<String, dynamic> firestoreData,
  CommentDataStruct? commentData,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (commentData == null) {
    return;
  }
  if (commentData.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && commentData.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final commentDataData =
      getCommentDataFirestoreData(commentData, forFieldValue);
  final nestedData =
      commentDataData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = commentData.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getCommentDataFirestoreData(
  CommentDataStruct? commentData, [
  bool forFieldValue = false,
]) {
  if (commentData == null) {
    return {};
  }
  final firestoreData = mapToFirestore(commentData.toMap());

  // Add any Firestore field values
  commentData.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getCommentDataListFirestoreData(
  List<CommentDataStruct>? commentDatas,
) =>
    commentDatas?.map((e) => getCommentDataFirestoreData(e, true)).toList() ??
    [];
