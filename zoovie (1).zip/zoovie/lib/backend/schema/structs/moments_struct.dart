// ignore_for_file: unnecessary_getters_setters
import '/backend/algolia/serialization_util.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MomentsStruct extends FFFirebaseStruct {
  MomentsStruct({
    String? photo,
    String? blurHash,
    String? caption,
    DateTime? lastPosted,
    String? username,
    bool? proAccount,
    String? profilePicture,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _photo = photo,
        _blurHash = blurHash,
        _caption = caption,
        _lastPosted = lastPosted,
        _username = username,
        _proAccount = proAccount,
        _profilePicture = profilePicture,
        super(firestoreUtilData);

  // "photo" field.
  String? _photo;
  String get photo => _photo ?? '';
  set photo(String? val) => _photo = val;
  bool hasPhoto() => _photo != null;

  // "blurHash" field.
  String? _blurHash;
  String get blurHash => _blurHash ?? '';
  set blurHash(String? val) => _blurHash = val;
  bool hasBlurHash() => _blurHash != null;

  // "caption" field.
  String? _caption;
  String get caption => _caption ?? '';
  set caption(String? val) => _caption = val;
  bool hasCaption() => _caption != null;

  // "last_posted" field.
  DateTime? _lastPosted;
  DateTime? get lastPosted => _lastPosted;
  set lastPosted(DateTime? val) => _lastPosted = val;
  bool hasLastPosted() => _lastPosted != null;

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  set username(String? val) => _username = val;
  bool hasUsername() => _username != null;

  // "pro_account" field.
  bool? _proAccount;
  bool get proAccount => _proAccount ?? false;
  set proAccount(bool? val) => _proAccount = val;
  bool hasProAccount() => _proAccount != null;

  // "profile_picture" field.
  String? _profilePicture;
  String get profilePicture => _profilePicture ?? '';
  set profilePicture(String? val) => _profilePicture = val;
  bool hasProfilePicture() => _profilePicture != null;

  static MomentsStruct fromMap(Map<String, dynamic> data) => MomentsStruct(
        photo: data['photo'] as String?,
        blurHash: data['blurHash'] as String?,
        caption: data['caption'] as String?,
        lastPosted: data['last_posted'] as DateTime?,
        username: data['username'] as String?,
        proAccount: data['pro_account'] as bool?,
        profilePicture: data['profile_picture'] as String?,
      );

  static MomentsStruct? maybeFromMap(dynamic data) =>
      data is Map ? MomentsStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'photo': _photo,
        'blurHash': _blurHash,
        'caption': _caption,
        'last_posted': _lastPosted,
        'username': _username,
        'pro_account': _proAccount,
        'profile_picture': _profilePicture,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'photo': serializeParam(
          _photo,
          ParamType.String,
        ),
        'blurHash': serializeParam(
          _blurHash,
          ParamType.String,
        ),
        'caption': serializeParam(
          _caption,
          ParamType.String,
        ),
        'last_posted': serializeParam(
          _lastPosted,
          ParamType.DateTime,
        ),
        'username': serializeParam(
          _username,
          ParamType.String,
        ),
        'pro_account': serializeParam(
          _proAccount,
          ParamType.bool,
        ),
        'profile_picture': serializeParam(
          _profilePicture,
          ParamType.String,
        ),
      }.withoutNulls;

  static MomentsStruct fromSerializableMap(Map<String, dynamic> data) =>
      MomentsStruct(
        photo: deserializeParam(
          data['photo'],
          ParamType.String,
          false,
        ),
        blurHash: deserializeParam(
          data['blurHash'],
          ParamType.String,
          false,
        ),
        caption: deserializeParam(
          data['caption'],
          ParamType.String,
          false,
        ),
        lastPosted: deserializeParam(
          data['last_posted'],
          ParamType.DateTime,
          false,
        ),
        username: deserializeParam(
          data['username'],
          ParamType.String,
          false,
        ),
        proAccount: deserializeParam(
          data['pro_account'],
          ParamType.bool,
          false,
        ),
        profilePicture: deserializeParam(
          data['profile_picture'],
          ParamType.String,
          false,
        ),
      );

  static MomentsStruct fromAlgoliaData(Map<String, dynamic> data) =>
      MomentsStruct(
        photo: convertAlgoliaParam(
          data['photo'],
          ParamType.String,
          false,
        ),
        blurHash: convertAlgoliaParam(
          data['blurHash'],
          ParamType.String,
          false,
        ),
        caption: convertAlgoliaParam(
          data['caption'],
          ParamType.String,
          false,
        ),
        lastPosted: convertAlgoliaParam(
          data['last_posted'],
          ParamType.DateTime,
          false,
        ),
        username: convertAlgoliaParam(
          data['username'],
          ParamType.String,
          false,
        ),
        proAccount: convertAlgoliaParam(
          data['pro_account'],
          ParamType.bool,
          false,
        ),
        profilePicture: convertAlgoliaParam(
          data['profile_picture'],
          ParamType.String,
          false,
        ),
        firestoreUtilData: const FirestoreUtilData(
          clearUnsetFields: false,
          create: true,
        ),
      );

  @override
  String toString() => 'MomentsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is MomentsStruct &&
        photo == other.photo &&
        blurHash == other.blurHash &&
        caption == other.caption &&
        lastPosted == other.lastPosted &&
        username == other.username &&
        proAccount == other.proAccount &&
        profilePicture == other.profilePicture;
  }

  @override
  int get hashCode => const ListEquality().hash([
        photo,
        blurHash,
        caption,
        lastPosted,
        username,
        proAccount,
        profilePicture
      ]);
}

MomentsStruct createMomentsStruct({
  String? photo,
  String? blurHash,
  String? caption,
  DateTime? lastPosted,
  String? username,
  bool? proAccount,
  String? profilePicture,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    MomentsStruct(
      photo: photo,
      blurHash: blurHash,
      caption: caption,
      lastPosted: lastPosted,
      username: username,
      proAccount: proAccount,
      profilePicture: profilePicture,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

MomentsStruct? updateMomentsStruct(
  MomentsStruct? moments, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    moments
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addMomentsStructData(
  Map<String, dynamic> firestoreData,
  MomentsStruct? moments,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (moments == null) {
    return;
  }
  if (moments.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && moments.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final momentsData = getMomentsFirestoreData(moments, forFieldValue);
  final nestedData = momentsData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = moments.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getMomentsFirestoreData(
  MomentsStruct? moments, [
  bool forFieldValue = false,
]) {
  if (moments == null) {
    return {};
  }
  final firestoreData = mapToFirestore(moments.toMap());

  // Add any Firestore field values
  moments.firestoreUtilData.fieldValues.forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getMomentsListFirestoreData(
  List<MomentsStruct>? momentss,
) =>
    momentss?.map((e) => getMomentsFirestoreData(e, true)).toList() ?? [];
