// ignore_for_file: unnecessary_getters_setters
import '/backend/algolia/serialization_util.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class NewPostStruct extends FFFirebaseStruct {
  NewPostStruct({
    String? image,
    String? imageHash,
    List<DocumentReference>? taggedUsers,
    String? location,
    String? videoPath,
    bool? video,
    bool? hideLikeCount,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _image = image,
        _imageHash = imageHash,
        _taggedUsers = taggedUsers,
        _location = location,
        _videoPath = videoPath,
        _video = video,
        _hideLikeCount = hideLikeCount,
        super(firestoreUtilData);

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  set image(String? val) => _image = val;
  bool hasImage() => _image != null;

  // "image_hash" field.
  String? _imageHash;
  String get imageHash => _imageHash ?? '';
  set imageHash(String? val) => _imageHash = val;
  bool hasImageHash() => _imageHash != null;

  // "tagged_users" field.
  List<DocumentReference>? _taggedUsers;
  List<DocumentReference> get taggedUsers => _taggedUsers ?? const [];
  set taggedUsers(List<DocumentReference>? val) => _taggedUsers = val;
  void updateTaggedUsers(Function(List<DocumentReference>) updateFn) =>
      updateFn(_taggedUsers ??= []);
  bool hasTaggedUsers() => _taggedUsers != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  set location(String? val) => _location = val;
  bool hasLocation() => _location != null;

  // "videoPath" field.
  String? _videoPath;
  String get videoPath => _videoPath ?? '';
  set videoPath(String? val) => _videoPath = val;
  bool hasVideoPath() => _videoPath != null;

  // "video" field.
  bool? _video;
  bool get video => _video ?? false;
  set video(bool? val) => _video = val;
  bool hasVideo() => _video != null;

  // "hide_like_count" field.
  bool? _hideLikeCount;
  bool get hideLikeCount => _hideLikeCount ?? false;
  set hideLikeCount(bool? val) => _hideLikeCount = val;
  bool hasHideLikeCount() => _hideLikeCount != null;

  static NewPostStruct fromMap(Map<String, dynamic> data) => NewPostStruct(
        image: data['image'] as String?,
        imageHash: data['image_hash'] as String?,
        taggedUsers: getDataList(data['tagged_users']),
        location: data['location'] as String?,
        videoPath: data['videoPath'] as String?,
        video: data['video'] as bool?,
        hideLikeCount: data['hide_like_count'] as bool?,
      );

  static NewPostStruct? maybeFromMap(dynamic data) =>
      data is Map ? NewPostStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'image': _image,
        'image_hash': _imageHash,
        'tagged_users': _taggedUsers,
        'location': _location,
        'videoPath': _videoPath,
        'video': _video,
        'hide_like_count': _hideLikeCount,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'image': serializeParam(
          _image,
          ParamType.String,
        ),
        'image_hash': serializeParam(
          _imageHash,
          ParamType.String,
        ),
        'tagged_users': serializeParam(
          _taggedUsers,
          ParamType.DocumentReference,
          true,
        ),
        'location': serializeParam(
          _location,
          ParamType.String,
        ),
        'videoPath': serializeParam(
          _videoPath,
          ParamType.String,
        ),
        'video': serializeParam(
          _video,
          ParamType.bool,
        ),
        'hide_like_count': serializeParam(
          _hideLikeCount,
          ParamType.bool,
        ),
      }.withoutNulls;

  static NewPostStruct fromSerializableMap(Map<String, dynamic> data) =>
      NewPostStruct(
        image: deserializeParam(
          data['image'],
          ParamType.String,
          false,
        ),
        imageHash: deserializeParam(
          data['image_hash'],
          ParamType.String,
          false,
        ),
        taggedUsers: deserializeParam<DocumentReference>(
          data['tagged_users'],
          ParamType.DocumentReference,
          true,
          collectionNamePath: ['users'],
        ),
        location: deserializeParam(
          data['location'],
          ParamType.String,
          false,
        ),
        videoPath: deserializeParam(
          data['videoPath'],
          ParamType.String,
          false,
        ),
        video: deserializeParam(
          data['video'],
          ParamType.bool,
          false,
        ),
        hideLikeCount: deserializeParam(
          data['hide_like_count'],
          ParamType.bool,
          false,
        ),
      );

  static NewPostStruct fromAlgoliaData(Map<String, dynamic> data) =>
      NewPostStruct(
        image: convertAlgoliaParam(
          data['image'],
          ParamType.String,
          false,
        ),
        imageHash: convertAlgoliaParam(
          data['image_hash'],
          ParamType.String,
          false,
        ),
        taggedUsers: convertAlgoliaParam<DocumentReference>(
          data['tagged_users'],
          ParamType.DocumentReference,
          true,
        ),
        location: convertAlgoliaParam(
          data['location'],
          ParamType.String,
          false,
        ),
        videoPath: convertAlgoliaParam(
          data['videoPath'],
          ParamType.String,
          false,
        ),
        video: convertAlgoliaParam(
          data['video'],
          ParamType.bool,
          false,
        ),
        hideLikeCount: convertAlgoliaParam(
          data['hide_like_count'],
          ParamType.bool,
          false,
        ),
        firestoreUtilData: const FirestoreUtilData(
          clearUnsetFields: false,
          create: true,
        ),
      );

  @override
  String toString() => 'NewPostStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is NewPostStruct &&
        image == other.image &&
        imageHash == other.imageHash &&
        listEquality.equals(taggedUsers, other.taggedUsers) &&
        location == other.location &&
        videoPath == other.videoPath &&
        video == other.video &&
        hideLikeCount == other.hideLikeCount;
  }

  @override
  int get hashCode => const ListEquality().hash([
        image,
        imageHash,
        taggedUsers,
        location,
        videoPath,
        video,
        hideLikeCount
      ]);
}

NewPostStruct createNewPostStruct({
  String? image,
  String? imageHash,
  String? location,
  String? videoPath,
  bool? video,
  bool? hideLikeCount,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    NewPostStruct(
      image: image,
      imageHash: imageHash,
      location: location,
      videoPath: videoPath,
      video: video,
      hideLikeCount: hideLikeCount,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

NewPostStruct? updateNewPostStruct(
  NewPostStruct? newPost, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    newPost
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addNewPostStructData(
  Map<String, dynamic> firestoreData,
  NewPostStruct? newPost,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (newPost == null) {
    return;
  }
  if (newPost.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && newPost.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final newPostData = getNewPostFirestoreData(newPost, forFieldValue);
  final nestedData = newPostData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = newPost.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getNewPostFirestoreData(
  NewPostStruct? newPost, [
  bool forFieldValue = false,
]) {
  if (newPost == null) {
    return {};
  }
  final firestoreData = mapToFirestore(newPost.toMap());

  // Add any Firestore field values
  newPost.firestoreUtilData.fieldValues.forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getNewPostListFirestoreData(
  List<NewPostStruct>? newPosts,
) =>
    newPosts?.map((e) => getNewPostFirestoreData(e, true)).toList() ?? [];
