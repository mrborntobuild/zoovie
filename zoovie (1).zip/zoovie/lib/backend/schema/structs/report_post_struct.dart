// ignore_for_file: unnecessary_getters_setters
import '/backend/algolia/serialization_util.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';

import '/flutter_flow/flutter_flow_util.dart';

class ReportPostStruct extends FFFirebaseStruct {
  ReportPostStruct({
    String? reason,
    String? reasonDescription,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _reason = reason,
        _reasonDescription = reasonDescription,
        super(firestoreUtilData);

  // "reason" field.
  String? _reason;
  String get reason => _reason ?? '';
  set reason(String? val) => _reason = val;
  bool hasReason() => _reason != null;

  // "reason_description" field.
  String? _reasonDescription;
  String get reasonDescription => _reasonDescription ?? '';
  set reasonDescription(String? val) => _reasonDescription = val;
  bool hasReasonDescription() => _reasonDescription != null;

  static ReportPostStruct fromMap(Map<String, dynamic> data) =>
      ReportPostStruct(
        reason: data['reason'] as String?,
        reasonDescription: data['reason_description'] as String?,
      );

  static ReportPostStruct? maybeFromMap(dynamic data) => data is Map
      ? ReportPostStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'reason': _reason,
        'reason_description': _reasonDescription,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'reason': serializeParam(
          _reason,
          ParamType.String,
        ),
        'reason_description': serializeParam(
          _reasonDescription,
          ParamType.String,
        ),
      }.withoutNulls;

  static ReportPostStruct fromSerializableMap(Map<String, dynamic> data) =>
      ReportPostStruct(
        reason: deserializeParam(
          data['reason'],
          ParamType.String,
          false,
        ),
        reasonDescription: deserializeParam(
          data['reason_description'],
          ParamType.String,
          false,
        ),
      );

  static ReportPostStruct fromAlgoliaData(Map<String, dynamic> data) =>
      ReportPostStruct(
        reason: convertAlgoliaParam(
          data['reason'],
          ParamType.String,
          false,
        ),
        reasonDescription: convertAlgoliaParam(
          data['reason_description'],
          ParamType.String,
          false,
        ),
        firestoreUtilData: const FirestoreUtilData(
          clearUnsetFields: false,
          create: true,
        ),
      );

  @override
  String toString() => 'ReportPostStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is ReportPostStruct &&
        reason == other.reason &&
        reasonDescription == other.reasonDescription;
  }

  @override
  int get hashCode => const ListEquality().hash([reason, reasonDescription]);
}

ReportPostStruct createReportPostStruct({
  String? reason,
  String? reasonDescription,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    ReportPostStruct(
      reason: reason,
      reasonDescription: reasonDescription,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

ReportPostStruct? updateReportPostStruct(
  ReportPostStruct? reportPost, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    reportPost
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addReportPostStructData(
  Map<String, dynamic> firestoreData,
  ReportPostStruct? reportPost,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (reportPost == null) {
    return;
  }
  if (reportPost.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && reportPost.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final reportPostData = getReportPostFirestoreData(reportPost, forFieldValue);
  final nestedData = reportPostData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = reportPost.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getReportPostFirestoreData(
  ReportPostStruct? reportPost, [
  bool forFieldValue = false,
]) {
  if (reportPost == null) {
    return {};
  }
  final firestoreData = mapToFirestore(reportPost.toMap());

  // Add any Firestore field values
  reportPost.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getReportPostListFirestoreData(
  List<ReportPostStruct>? reportPosts,
) =>
    reportPosts?.map((e) => getReportPostFirestoreData(e, true)).toList() ?? [];
