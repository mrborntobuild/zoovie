import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class SubscriptionsRecord extends FirestoreRecord {
  SubscriptionsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "user_ID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  // "subscribrion_plan" field.
  String? _subscribrionPlan;
  String get subscribrionPlan => _subscribrionPlan ?? '';
  bool hasSubscribrionPlan() => _subscribrionPlan != null;

  // "subscribed_at" field.
  DateTime? _subscribedAt;
  DateTime? get subscribedAt => _subscribedAt;
  bool hasSubscribedAt() => _subscribedAt != null;

  // "location" field.
  LatLng? _location;
  LatLng? get location => _location;
  bool hasLocation() => _location != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "stripe_ID" field.
  String? _stripeID;
  String get stripeID => _stripeID ?? '';
  bool hasStripeID() => _stripeID != null;

  void _initializeFields() {
    _userID = snapshotData['user_ID'] as DocumentReference?;
    _subscribrionPlan = snapshotData['subscribrion_plan'] as String?;
    _subscribedAt = snapshotData['subscribed_at'] as DateTime?;
    _location = snapshotData['location'] as LatLng?;
    _email = snapshotData['email'] as String?;
    _stripeID = snapshotData['stripe_ID'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('subscriptions');

  static Stream<SubscriptionsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SubscriptionsRecord.fromSnapshot(s));

  static Future<SubscriptionsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SubscriptionsRecord.fromSnapshot(s));

  static SubscriptionsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SubscriptionsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SubscriptionsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SubscriptionsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SubscriptionsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SubscriptionsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSubscriptionsRecordData({
  DocumentReference? userID,
  String? subscribrionPlan,
  DateTime? subscribedAt,
  LatLng? location,
  String? email,
  String? stripeID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'user_ID': userID,
      'subscribrion_plan': subscribrionPlan,
      'subscribed_at': subscribedAt,
      'location': location,
      'email': email,
      'stripe_ID': stripeID,
    }.withoutNulls,
  );

  return firestoreData;
}

class SubscriptionsRecordDocumentEquality
    implements Equality<SubscriptionsRecord> {
  const SubscriptionsRecordDocumentEquality();

  @override
  bool equals(SubscriptionsRecord? e1, SubscriptionsRecord? e2) {
    return e1?.userID == e2?.userID &&
        e1?.subscribrionPlan == e2?.subscribrionPlan &&
        e1?.subscribedAt == e2?.subscribedAt &&
        e1?.location == e2?.location &&
        e1?.email == e2?.email &&
        e1?.stripeID == e2?.stripeID;
  }

  @override
  int hash(SubscriptionsRecord? e) => const ListEquality().hash([
        e?.userID,
        e?.subscribrionPlan,
        e?.subscribedAt,
        e?.location,
        e?.email,
        e?.stripeID
      ]);

  @override
  bool isValidKey(Object? o) => o is SubscriptionsRecord;
}
