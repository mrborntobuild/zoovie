import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'it', 'es', 'pl', 'fr', 'de'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? itText = '',
    String? esText = '',
    String? plText = '',
    String? frText = '',
    String? deText = '',
  }) =>
      [enText, itText, esText, plText, frText, deText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // resetPasswordConfirmation
  {
    'n0whh8ra': {
      'en': 'Link Sent!',
      'de': 'Link gesendet!',
      'es': '¡Enlace enviado!',
      'fr': 'Lien envoyé !',
      'it': 'Link inviato!',
      'pl': 'Link wysłany!',
    },
    '5s8bxlhn': {
      'en': 'Your password reset link is on its way! Check your inbox!',
      'de':
          'Dein Link zum Zurücksetzen des Passworts ist unterwegs! Überprüfe deinen Posteingang!',
      'es':
          '¡El enlace para restablecer tu contraseña está en camino! ¡Revisa tu bandeja de entrada!',
      'fr':
          'Votre lien de réinitialisation de mot de passe est en cours d\'acheminement ! Vérifiez votre boîte de réception !',
      'it':
          'Il link per il ripristino della password è in arrivo! Controlla la tua casella di posta!',
      'pl':
          'Link do zresetowania hasła jest w drodze! Sprawdź swoją skrzynkę odbiorczą!',
    },
    'ix3j51zb': {
      'en': 'Log in',
      'de': 'Einloggen',
      'es': 'Iniciar sesión',
      'fr': 'Se connecter',
      'it': 'Accedi',
      'pl': 'Zaloguj się',
    },
    '5ftjzqy8': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // Access
  {
    'hosk7e6v': {
      'en': 'Log in',
      'de': 'Einloggen',
      'es': 'Iniciar sesión',
      'fr': 'Se connecter',
      'it': 'Accedi',
      'pl': 'Zaloguj się',
    },
    '6geaps2k': {
      'en': 'Create an account',
      'de': 'Konto erstellen',
      'es': 'Crear una cuenta',
      'fr': 'Créer un compte',
      'it': 'Crea un account',
      'pl': 'Utwórz konto',
    },
    'qyq2amcu': {
      'en': 'By proceeding, you agree to our ',
      'de': 'Durch die Fortsetzung stimmen Sie unseren ',
      'es': 'Al continuar, aceptas nuestros ',
      'fr': 'En procédant, vous acceptez nos ',
      'it': 'Procedendo, accetti i nostri ',
      'pl': 'Kontynuując, zgadzasz się na nasze ',
    },
    '9vkfy8gx': {
      'en': 'Terms of Use ',
      'de': 'Nutzungsbedingungen ',
      'es': 'Condiciones de uso ',
      'fr': 'Conditions d\'utilisation ',
      'it': 'Termini di utilizzo ',
      'pl': 'Warunki korzystania ',
    },
    '7y37u99i': {
      'en': 'and ',
      'de': 'Und ',
      'es': 'y ',
      'fr': 'et ',
      'it': 'E ',
      'pl': 'oraz ',
    },
    '1yoe3uyt': {
      'en': 'Privacy Policy.',
      'de': 'Datenschutzrichtlinie.',
      'es': 'política de privacidad.',
      'fr': 'politique de confidentialité.',
      'it': 'politica sulla riservatezza.',
      'pl': 'Politykę Prywatności.',
    },
    'y8t9av6u': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // legalPolicies
  {
    '970tttc6': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'o5b9s0f8': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'zsg6lw9u': {
      'en': 'Boring, but important',
      'de': 'Langweilig, aber wichtig',
      'es': 'Aburrido, pero importante',
      'fr': 'Ennuyeux, mais important',
      'it': 'Noioso, ma importante',
      'pl': 'Nudne, ale ważne',
    },
    'u17njodh': {
      'en': 'Read and accept to continue.',
      'de': 'Lesen und akzeptieren Sie, um fortzufahren.',
      'es': 'Lee y acepta para continuar.',
      'fr': 'Lisez et acceptez pour continuer.',
      'it': 'Leggi e accetta per continuare',
      'pl': 'Przeczytaj i zaakceptuj, aby kontynuować.',
    },
    'jtfi5wod': {
      'en': 'Terms of Use',
      'de': 'Nutzungsbedingungen',
      'es': 'Términos de Uso',
      'fr': 'Conditions d\'utilisation',
      'it': 'Termini d\'Uso',
      'pl': 'Warunki korzystania',
    },
    'in4qqvq5': {
      'en':
          'Welcome to Beneree! We, Beneree Inc., are excited to have you as part of our community. In these Terms of Use, we\'ll explain in detail how our mobile application works and what you can expect when using it. Please take the time to carefully read and understand these terms before registering and using our services. By accessing and using Beneree, you are agreeing to follow these Terms.',
      'de':
          'Herzlich willkommen bei Beneree! Wir, Beneree Inc., freuen uns, dich als Teil unserer Gemeinschaft begrüßen zu dürfen. In diesen Nutzungsbedingungen erläutern wir im Detail, wie unsere mobile Anwendung funktioniert und was du erwarten kannst, wenn du sie verwendest. Bitte nimm dir die Zeit, diese Bedingungen sorgfältig zu lesen und zu verstehen, bevor du dich registrierst und unsere Dienste nutzt. Durch den Zugriff auf und die Nutzung von Beneree stimmst du zu, diesen Bedingungen zu folgen.',
      'es':
          '¡Bienvenido/a a Beneree! Nosotros, Beneree Inc., estamos emocionados de tenerte como parte de nuestra comunidad. En estos Términos de Uso, te explicaremos en detalle cómo funciona nuestra aplicación móvil y qué puedes esperar al usarla. Por favor, tómate el tiempo para leer y comprender cuidadosamente estos términos antes de registrarte y usar nuestros servicios. Al acceder y usar Beneree, estás aceptando seguir estos Términos.',
      'fr':
          'Bienvenue sur Beneree ! Nous, Beneree Inc., sommes ravis de vous accueillir au sein de notre communauté. Dans ces Conditions d\'Utilisation, nous expliquerons en détail le fonctionnement de notre application mobile et ce à quoi vous pouvez vous attendre en l\'utilisant. Prenez le temps de lire et de comprendre attentivement ces termes avant de vous inscrire et d\'utiliser nos services. En accédant à Beneree et en l\'utilisant, vous acceptez de respecter ces Conditions.',
      'it':
          'Benvenuto/a in Beneree! Noi, Beneree Inc., siamo entusiasti di averti come parte della nostra comunità. In questi Termini d\'Uso, spiegheremo dettagliatamente come funziona la nostra applicazione mobile e cosa puoi aspettarti quando la usi. Ti preghiamo di prenderti il tempo di leggere attentamente e comprendere questi termini prima di registrarti e utilizzare i nostri servizi. Accedendo e utilizzando Beneree, accetti di seguire questi Termini.',
      'pl':
          'Witaj w Beneree! My, Beneree Inc., cieszymy się, że jesteś częścią naszej społeczności. W tych Warunkach Korzystania szczegółowo wyjaśnimy, jak działa nasza aplikacja mobilna i czego możesz się spodziewać, korzystając z niej. Proszę, poświęć czas na dokładne zapoznanie się i zrozumienie tych warunków przed zarejestrowaniem się i korzystaniem z naszych usług. Poprzez dostęp i korzystanie z Beneree, zgadzasz się przestrzegać tych Warunków.',
    },
    'b186gvyj': {
      'en': 'Privacy Policy',
      'de': 'Datenschutzrichtlinie',
      'es': 'Política de Privacidad',
      'fr': 'Politique de Confidentialité',
      'it': 'Informativa sulla Privacy',
      'pl': 'Polityka Prywatności',
    },
    'wf3q30ot': {
      'en':
          'By this Privacy Policy (the “Policy”) we, Beneree Inc., shall provide you all the detailed information about collecting, using, sharing and otherwise processing your Personal data, that was (and will be) collected or generated by Beneree about you while using the App. ',
      'de':
          'Durch diese Datenschutzrichtlinie (die \"Richtlinie\") stellen wir, Beneree Inc., Ihnen alle detaillierten Informationen zur Verfügung über die Sammlung, Nutzung, Weitergabe und sonstige Verarbeitung Ihrer personenbezogenen Daten, die von Beneree über Sie gesammelt oder generiert wurden (und werden), während Sie die App nutzen.',
      'es':
          'Por medio de esta Política de Privacidad (la \"Política\"), nosotros, Beneree Inc., te proporcionaremos toda la información detallada sobre la recopilación, uso, compartición y procesamiento de tus datos personales, que han sido (y serán) recopilados o generados por Beneree sobre ti mientras usas la Aplicación.',
      'fr':
          'Par le biais de cette Politique de Confidentialité (la \"Politique\"), nous, Beneree Inc., vous fournirons toutes les informations détaillées sur la collecte, l\'utilisation, le partage et le traitement de vos données personnelles, qui ont été (et seront) collectées ou générées par Beneree vous concernant lors de l\'utilisation de l\'Application.',
      'it':
          'Con la presente Informativa sulla Privacy (la \"Policy\"), noi, Beneree Inc., forniremo tutte le informazioni dettagliate sulla raccolta, l\'uso, la condivisione e l\'elaborazione dei tuoi dati personali, che sono stati (e saranno) raccolti o generati da Beneree su di te durante l\'utilizzo dell\'App.',
      'pl':
          'Niniejszą Polityką Prywatności („Polityką”) my, Beneree Inc., udostępniamy Ci wszystkie szczegółowe informacje dotyczące zbierania, wykorzystywania, udostępniania i w inny sposób przetwarzania Twoich danych osobowych, które były (i będą) zbierane lub generowane przez Beneree na Twój temat podczas korzystania z Aplikacji.',
    },
    'qflc7wh7': {
      'en': 'Community Standards',
      'de': 'Datenschutzrichtlinie',
      'es': 'Política de Privacidad',
      'fr': 'Politique de Confidentialité',
      'it': 'Informativa sulla Privacy',
      'pl': 'Polityka Prywatności',
    },
    'pmfauu5s': {
      'en':
          'At Beneree, we are committed to fostering a positive and respectful community for all our users. To ensure a safe and enjoyable experience, we have established the following Community Standards.',
      'de':
          'Bei Beneree setzen wir uns dafür ein, eine positive und respektvolle Gemeinschaft für alle unsere Benutzer zu fördern. Um eine sichere und angenehme Erfahrung zu gewährleisten, haben wir die folgenden Community-Standards festgelegt.',
      'es':
          'En Beneree, nos comprometemos a fomentar una comunidad positiva y respetuosa para todos nuestros usuarios. Para garantizar una experiencia segura y placentera, hemos establecido los siguientes Estándares de la Comunidad.',
      'fr':
          'Chez Beneree, nous nous engageons à favoriser une communauté positive et respectueuse pour tous nos utilisateurs. Pour garantir une expérience sûre et agréable, nous avons établi les normes de la communauté suivantes.',
      'it':
          'Da Beneree, ci impegniamo a promuovere una comunità positiva e rispettosa per tutti i nostri utenti. Per garantire un\'esperienza sicura e piacevole, abbiamo stabilito gli standard della community seguenti.',
      'pl':
          'W Beneree zobowiązujemy się do wspierania pozytywnej i szanującej społeczności dla wszystkich naszych użytkowników. Aby zapewnić bezpieczne i przyjemne doświadczenie, ustanowiliśmy następujące Standardy Społeczności.',
    },
    'uh8hhj6z': {
      'en': 'I accept',
      'de': 'Ich akzeptiere',
      'es': 'Acepto',
      'fr': 'J\'accepte',
      'it': 'Accetto',
      'pl': 'Akceptuję',
    },
    '5211vh3i': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // newOnboarding1_name
  {
    'av5fz85g': {
      'en': 'What\'s your name',
      'de': 'Wie heißen Sie',
      'es': 'Cómo te llamas',
      'fr': 'Quel est ton nom',
      'it': 'Come ti chiami',
      'pl': 'Jak masz na imię',
    },
    'bas9wm3e': {
      'en':
          'Add your name so your friends and other Beneree users can find you.',
      'de':
          'Fügen Sie Ihren Namen hinzu, damit Ihre Freunde und andere Beneree-Benutzer Sie finden können.',
      'es':
          'Agrega tu nombre para que tus amigos y otros usuarios de Beneree puedan encontrarte.',
      'fr':
          'Ajoutez votre nom pour que vos amis et les autres utilisateurs de Beneree puissent vous trouver.',
      'it':
          'Aggiungi il tuo nome in modo che i tuoi amici e gli altri utenti di Beneree possano trovarti.',
      'pl':
          'Dodaj swoje imię, aby Twoi znajomi i inni użytkownicy Beneree mogli Cię znaleźć.',
    },
    'dyxyjls2': {
      'en': 'Full name',
      'de': 'Vollständiger Name',
      'es': 'Nombre completo',
      'fr': 'Nom complet',
      'it': 'Nome completo',
      'pl': 'Imię i nazwisko',
    },
    'sxu090yg': {
      'en': 'Name required.',
      'de': 'Name erforderlich.',
      'es': 'Nombre requerido.',
      'fr': 'Nom requis.',
      'it': 'Nome richiesto.',
      'pl': 'Wymagane imię.',
    },
    '36d9qrr1': {
      'en': 'Please choose an option from the dropdown',
      'de': 'Bitte wählen Sie eine Option aus dem Dropdown-Menü.',
      'es': 'Por favor, elige una opción del menú desplegable.',
      'fr': 'Veuillez choisir une option dans la liste déroulante.',
      'it': 'Per favore, scegli un\'opzione dal menu a tendina.',
      'pl': 'Proszę wybrać opcję z rozwijanej listy.',
    },
    'f88djgi8': {
      'en': 'Continue',
      'de': 'Weiter',
      'es': 'Continuar',
      'fr': 'Continuer',
      'it': 'Continua',
      'pl': 'Kontynuuj',
    },
    '57u2xykf': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // password
  {
    'uu67qf52': {
      'en': 'Create a password',
      'de': 'Erstellen Sie ein Passwort',
      'es': 'Crea una contraseña',
      'fr': 'Créez un mot de passe',
      'it': 'Crea una password',
      'pl': 'Utwórz hasło',
    },
    'u1mqb5wa': {
      'en':
          'Create a unique password for your account. Please do not share it with anyone.',
      'de':
          'Erstellen Sie ein einzigartiges Passwort für Ihr Konto. Bitte teilen Sie es nicht mit anderen.',
      'es':
          'Crea una contraseña única para tu cuenta. Por favor, no la compartas con nadie.',
      'fr':
          'Créez un mot de passe unique pour votre compte. Veuillez ne pas le partager avec qui que ce soit.',
      'it':
          'Crea una password unica per il tuo account. Per favore, non condividerla con nessuno.',
      'pl':
          'Utwórz unikalne hasło dla swojego konta. Proszę, nie udostępniaj go nikomu.',
    },
    'rxi8myqn': {
      'en': 'Password',
      'de': 'Passwort',
      'es': 'Contraseña',
      'fr': 'Mot de passe',
      'it': 'Password',
      'pl': 'Hasło',
    },
    '7crfqojh': {
      'en': 'Field is required',
      'de': 'Feld ist erforderlich',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
      'it': 'Il campo è obbligatiorio',
      'pl': 'To pole jest wymagane',
    },
    'ka3cwwyz': {
      'en': 'Please choose an option from the dropdown',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    '3895dcth': {
      'en': 'Continue',
      'de': 'Weiter',
      'es': 'Continuar',
      'fr': 'Continuer',
      'it': 'Continua',
      'pl': 'Kontynuuj',
    },
    'azumdk6f': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // createRew
  {
    '9qxbui2a': {
      'en': 'BenePoints Generator',
      'de': 'BenePoints-Generator',
      'es': 'Generador de BenePoints',
      'fr': 'Générateur de BenePoints',
      'it': 'Generatore di BenePoints',
      'pl': 'Generator BenePoints',
    },
    'ygm1uv68': {
      'en': 'Enter referral code',
      'de': 'Geben Sie den Empfehlungscode ein',
      'es': 'Ingresa el código de referencia',
      'fr': 'Entrez le code de parrainage',
      'it': 'Inserisci il codice di riferimento',
      'pl': 'Wprowadź kod polecający',
    },
    '8jdvh7f9': {
      'en': '\$',
      'de': '\$',
      'es': '\$',
      'fr': '\$',
      'it': '\$',
      'pl': '\$',
    },
    'hl5123lr': {
      'en': '1',
      'de': '1',
      'es': '1',
      'fr': '1',
      'it': '1',
      'pl': '1',
    },
    '7fdri25u': {
      'en': '2',
      'de': '2',
      'es': '2',
      'fr': '2',
      'it': '2',
      'pl': '2',
    },
    'm4s0g781': {
      'en': '3',
      'de': '3',
      'es': '3',
      'fr': '3',
      'it': '3',
      'pl': '3',
    },
    'fb5z0g7c': {
      'en': '4',
      'de': '4',
      'es': '4',
      'fr': '4',
      'it': '4',
      'pl': '4',
    },
    '2dcruvmh': {
      'en': '5',
      'de': '5',
      'es': '5',
      'fr': '5',
      'it': '5',
      'pl': '5',
    },
    'b9u36zx1': {
      'en': '6',
      'de': '6',
      'es': '6',
      'fr': '6',
      'it': '6',
      'pl': '6',
    },
    'bhm1ob75': {
      'en': '7',
      'de': '7',
      'es': '7',
      'fr': '7',
      'it': '7',
      'pl': '7',
    },
    'nkvrbo63': {
      'en': '8',
      'de': '8',
      'es': '8',
      'fr': '8',
      'it': '8',
      'pl': '8',
    },
    'yog6e9xy': {
      'en': '9',
      'de': '9',
      'es': '9',
      'fr': '9',
      'it': '9',
      'pl': '9',
    },
    'hu34nu64': {
      'en': '.',
      'de': '.',
      'es': '.',
      'fr': '.',
      'it': '.',
      'pl': '.',
    },
    'da8c91u5': {
      'en': '0',
      'de': '0',
      'es': '0',
      'fr': '0',
      'it': '0',
      'pl': '0',
    },
    'l3fzdsjw': {
      'en': 'Generate Points',
      'de': 'Punkte Generieren',
      'es': 'Generar Puntos',
      'fr': 'Générer des Points',
      'it': 'Genera Punti',
      'pl': 'Generuj Punkty',
    },
    'tk9xcccq': {
      'en': 'Field is required',
      'de': 'Feld ist erforderlich',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
      'it': 'Il campo è obbligatiorio',
      'pl': 'To pole jest wymagane',
    },
    'y4zkfrt3': {
      'en': 'Please choose an option from the dropdown',
      'de': 'Please choose an option from the dropdown',
      'es': 'Please choose an option from the dropdown',
      'fr': 'Please choose an option from the dropdown',
      'it': 'Please choose an option from the dropdown',
      'pl': 'Please choose an option from the dropdown',
    },
    'xm98thk8': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // postPhoto
  {
    '47keu1gh': {
      'en': 'Next',
      'de': 'Nächste',
      'es': 'Próximo',
      'fr': 'Suivant',
      'it': 'Prossimo',
      'pl': 'Dalej',
    },
    'vem8jzns': {
      'en': 'New post',
      'de': 'Neuer Beitrag',
      'es': 'Nueva publicación',
      'fr': 'Nouveau poste',
      'it': 'Nuova posta',
      'pl': 'Nowy post',
    },
    'jxqjjx2t': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // postPhotoCaption
  {
    'qkz1kdpf': {
      'en': 'Share',
      'de': 'Teilen',
      'es': 'Compartir',
      'fr': 'Partager',
      'it': 'Condividi',
      'pl': 'Udostępnij',
    },
    '34s4qyrc': {
      'en': 'New post',
      'de': 'Neuer Beitrag',
      'es': 'Nueva publicación',
      'fr': 'Nouveau message',
      'it': 'Nuovo post',
      'pl': 'Nowy post',
    },
    'j2ag0iwp': {
      'en': 'Write a caption...',
      'de': 'Schreiben Sie eine Bildunterschrift...',
      'es': 'Escribe una leyenda...',
      'fr': 'Écrivez une légende...',
      'it': 'Scrivi una didascalia...',
      'pl': 'Napisz podpis...',
    },
    '0eczh227': {
      'en': 'Caption required.',
      'de': 'Bildunterschrift erforderlich.',
      'es': 'Leyenda requerida.',
      'fr': 'Légende requise.',
      'it': 'Didascalia obbligatoria.',
      'pl': 'Wymagany podpis.',
    },
    'k14xix8k': {
      'en': 'Please choose an option from the dropdown',
      'de': 'Bitte wählen Sie eine Option aus dem Dropdown-Menü.',
      'es': 'Por favor, elige una opción del menú desplegable.',
      'fr': 'Veuillez choisir une option dans la liste déroulante.',
      'it': 'Per favore, scegli un\'opzione dal menu a tendina.',
      'pl': 'Proszę wybrać opcję z rozwijanej listy.',
    },
    'ht5o7v1z': {
      'en': 'Tag other users',
      'de': 'Markiere andere Benutzer',
      'es': 'Etiqueta a otros usuarios',
      'fr': 'Taguer d\'autres utilisateurs',
      'it': 'Tagga altri utenti',
      'pl': 'Otaguj innych użytkowników',
    },
    '7y3nu342': {
      'en': 'Add location',
      'de': 'Standort hinzufügen',
      'es': 'Agregar ubicación',
      'fr': 'Ajouter un emplacement',
      'it': 'Aggiungi posizione',
      'pl': 'Dodaj lokalizację',
    },
    'k5nz8rns': {
      'en': 'Rome, IT',
      'de': 'Rome, IT',
      'es': 'Rome, IT',
      'fr': 'Rome, IT',
      'it': 'Rome, IT',
      'pl': 'Rome, IT',
    },
    'kbz5m6of': {
      'en': 'Berlin, DE',
      'de': 'Berlin, DE',
      'es': 'Berlin, DE',
      'fr': 'Berlin, DE',
      'it': 'Berlin, DE',
      'pl': 'Berlin, DE',
    },
    'wk5k0n7v': {
      'en': 'Warsaw, PL',
      'de': 'Warsaw, PL',
      'es': 'Warsaw, PL',
      'fr': 'Warsaw, PL',
      'it': 'Warsaw, PL',
      'pl': 'Warsaw, PL',
    },
    'ctcyibzr': {
      'en': 'Madrid, ES',
      'de': 'Madrid, ES',
      'es': 'Madrid, ES',
      'fr': 'Madrid, ES',
      'it': 'Madrid, ES',
      'pl': 'Madrid, ES',
    },
    '4dchg8ir': {
      'en': 'Paris, FR',
      'de': 'Paris, FR',
      'es': 'Paris, FR',
      'fr': 'Paris, FR',
      'it': 'Paris, FR',
      'pl': 'Paris, FR',
    },
    '2ihm3l7p': {
      'en': 'Amsterdam, NL',
      'de': 'Amsterdam, NL',
      'es': 'Amsterdam, NL',
      'fr': 'Amsterdam, NL',
      'it': 'Amsterdam, NL',
      'pl': 'Amsterdam, NL',
    },
    'dxm60tll': {
      'en': 'Hide like count',
      'de': 'Anzahl der Likes ausblenden',
      'es': 'Ocultar recuento de Me gusta',
      'fr': 'Masquer le nombre de J\'aime',
      'it': 'Nascondi il conteggio dei Mi piace',
      'pl': 'Ukryj liczbę polubień',
    },
    '2ibvpz1w': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // AccountSet
  {
    'fli56ua1': {
      'en': 'Congratulations!',
      'de': 'Herzlichen Glückwunsch!',
      'es': '¡Felicidades!',
      'fr': 'Félicitations !',
      'it': 'Congratulazioni!',
      'pl': 'Gratulacje!',
    },
    'qtsx1p8j': {
      'en': 'Your account was successfully created.',
      'de': 'Ihr Konto wurde erfolgreich erstellt.',
      'es': 'Tu cuenta se ha creado exitosamente.',
      'fr': 'Votre compte a été créé avec succès.',
      'it': 'Il tuo account è stato creato con successo.',
      'pl': 'Twoje konto zostało pomyślnie utworzone.',
    },
    'u3a14dr4': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    'tkxi83t1': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // comments
  {
    't9l8l1dh': {
      'en': 'Post',
      'de': 'Post',
      'es': 'Post',
      'fr': 'Post',
      'it': 'Post',
      'pl': 'Post',
    },
    'bol7ajwp': {
      'en': 'Reply',
      'de': 'Antworten',
      'es': 'Responder',
      'fr': 'Répondre',
      'it': 'Rispondi',
      'pl': 'Odpowiedz',
    },
    't23cm3ah': {
      'en': 'Delete',
      'de': 'Löschen',
      'es': 'Borrar',
      'fr': 'Supprimer',
      'it': 'Elimina',
      'pl': 'Usuń',
    },
    'vispldhm': {
      'en': 'Reply',
      'de': 'Antworten',
      'es': 'Responder',
      'fr': 'Répondre',
      'it': 'Rispondi',
      'pl': 'Odpowiedz',
    },
    'xloevxvh': {
      'en': 'Delete',
      'de': 'Löschen',
      'es': 'Borrar',
      'fr': 'Supprimer',
      'it': 'Elimina',
      'pl': 'Usuń',
    },
    'qgpj9k7d': {
      'en': 'Add a comment...',
      'de': 'Einen Kommentar hinzufügen...',
      'es': 'Agregar un comentario...',
      'fr': 'Ajouter un commentaire...',
      'it': 'Aggiungi un commento...',
      'pl': 'Dodaj komentarz...',
    },
    'n84r3bt8': {
      'en': 'Field is required',
      'de': 'Dieses Feld ist erforderlich.',
      'es': 'Campo requerido.',
      'fr': 'Champ requis.',
      'it': 'Campo obbligatorio.',
      'pl': 'To pole jest wymagane.',
    },
    'fqlcx64n': {
      'en': 'Please choose an option from the dropdown',
      'de': 'Bitte wählen Sie eine Option aus dem Dropdown-Menü.',
      'es': 'Por favor, elige una opción del menú desplegable.',
      'fr': 'Veuillez choisir une option dans la liste déroulante.',
      'it': 'Per favore, scegli un\'opzione dal menu a tendina.',
      'pl': 'Proszę wybrać opcję z rozwijanej listy.',
    },
    '45mquj8r': {
      'en': 'Post',
      'de': 'Post',
      'es': 'Post',
      'fr': 'Post',
      'it': 'Post',
      'pl': 'Post',
    },
    'nxh9cgci': {
      'en': 'Add a reply',
      'de': 'Eine Antwort hinzufügen',
      'es': 'Agregar una respuesta',
      'fr': 'Ajouter une réponse',
      'it': 'Aggiungi una risposta',
      'pl': 'Dodaj odpowiedź',
    },
    'kbv0b8xi': {
      'en': 'Field is required',
      'de': 'Dieses Feld ist erforderlich.',
      'es': 'Campo requerido.',
      'fr': 'Champ requis.',
      'it': 'Campo obbligatorio.',
      'pl': 'To pole jest wymagane.',
    },
    '9rg5mzve': {
      'en': 'Please choose an option from the dropdown',
      'de': 'Bitte wählen Sie eine Option aus dem Dropdown-Menü.',
      'es': 'Por favor, elige una opción del menú desplegable.',
      'fr': 'Veuillez choisir une option dans la liste déroulante.',
      'it': 'Per favore, scegli un\'opzione dal menu a tendina.',
      'pl': 'Proszę wybrać opcję z rozwijanej listy.',
    },
    'fhk9aola': {
      'en': 'Post',
      'de': 'Post',
      'es': 'Post',
      'fr': 'Post',
      'it': 'Post',
      'pl': 'Post',
    },
    'gxobg3j7': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // invite
  {
    'f067z0bf': {
      'en': 'Your referral code',
      'de': 'Ihr Empfehlungscode',
      'es': 'Tu código de referencia',
      'fr': 'Votre code de parrainage',
      'it': 'Il tuo codice di riferimento',
      'pl': 'Twój kod polecający',
    },
    'bnzutdj0': {
      'en': 'All you need to do is:',
      'de': 'Alles, was du tun musst, ist:',
      'es': 'Todo lo que necesitas hacer es:',
      'fr': 'Tout ce que vous avez à faire, c\'est :',
      'it': 'Tutto ciò che devi fare è:',
      'pl': 'Wszystko, co musisz zrobić, to:',
    },
    '8vzyekse': {
      'en': '1. Copy your unique referral code.',
      'de': '1. Kopieren Sie Ihren eindeutigen Empfehlungscode.',
      'es': '1. Copie su código de referencia único.',
      'fr': '1. Copiez votre code de parrainage unique.',
      'it': '1. Copia il tuo codice di riferimento univoco.',
      'pl': '1. Skopiuj swój unikalny kod polecający.',
    },
    'bmumpjh9': {
      'en': '2. Share it with friends, family or anyone else, with no limits.',
      'de':
          '2. Teilen Sie ihn mit Ihren Freunden, wo immer Sie möchten, ohne Einschränkungen!',
      'es': '2. Compártelo con amigos, familia o cualquier otro, sin límites.',
      'fr':
          '2. Partagez-le avec des amis, de la famille ou quiconque, sans limites.',
      'it':
          '2. Dillo agli amici, alla famiglia o a chiunque altro, senza limiti.',
      'pl':
          '2. Poleć to znajomym, rodzinie lub każdemu innemu, bez ograniczeń.',
    },
    'l1kjtsev': {
      'en':
          '3. When your friends join with your referral code, you instantly earn 10 points.',
      'de':
          '3. Wenn deine Freunde sich mit deinem Empfehlungscode anmelden, verdienst du sofort 10 Punkte.',
      'es':
          '3. Cuando tus amigos se unen con tu código de referencia, ganas instantáneamente 10 puntos.',
      'fr':
          '3. Lorsque vos amis rejoignent avec votre code de parrainage, vous gagnez instantanément 10 points.',
      'it':
          '3. Quando i tuoi amici si uniscono con il tuo codice di riferimento, guadagni immediatamente 10 punti.',
      'pl':
          '3. Kiedy Twoi przyjaciele dołączają z Twoim kodem polecającym, natychmiast zdobywasz 10 punktów.',
    },
    'a0msnt16': {
      'en':
          '4. Every time your friends subscribe to Beneree Pro, you instantly earn 100 points ⏤ this reward continues with each subscription renewal.',
      'de':
          '4. Jedes Mal, wenn Ihre Freunde Beneree Pro abonnieren, verdienen Sie sofort 100 Punkte ⏤ diese Belohnung setzt sich bei jeder Aboverlängerung fort.',
      'es':
          '4. Cada vez que tus amigos se suscriben a Beneree Pro, ganas instantáneamente 100 puntos: esta recompensa continúa con cada renovación de suscripción.',
      'fr':
          '4. Chaque fois que vos amis s\'abonnent à Beneree Pro, vous gagnez instantanément 100 points ⏤ cette récompense continue à chaque renouvellement d\'abonnement.',
      'it':
          '4. Ogni volta che i tuoi amici sottoscrivono Beneree Pro, guadagni immediatamente 100 punti: questa ricompensa continua con ogni rinnovo dell\'abbonamento.',
      'pl':
          '4. Za każdym razem, gdy Twoi przyjaciele subskrybują Beneree Pro, natychmiast zdobywasz 100 punktów ⏤ ta nagroda trwa przy każdym odnowieniu subskrypcji.',
    },
    'naq3siid': {
      'en':
          '5. There’s no time to waste. Invite people before someone else does it first.',
      'de':
          '4. Es gibt keine Zeit zu verlieren. Laden Sie Menschen ein, bevor es jemand anderes zuerst tut.',
      'es':
          '4. No hay tiempo que perder. Invita a las personas antes de que alguien más lo haga primero.',
      'fr':
          '4. Il n\'y a pas de temps à perdre. Invitez des gens avant que quelqu\'un d\'autre ne le fasse en premier.',
      'it':
          '4. Non c\'è tempo da perdere. Invita le persone prima che qualcun altro lo faccia per primo.',
      'pl':
          '4. Nie ma czasu do stracenia. Zaproś ludzi, zanim ktoś inny zrobi to pierwszy.',
    },
    '93dws4jy': {
      'en': 'Copy your code',
      'de': 'Kopieren Sie Ihren Code',
      'es': 'Copia tu código',
      'fr': 'Copiez votre code',
      'it': 'Copia il tuo codice',
      'pl': 'Skopiuj swój kod',
    },
    'g6qj6y0x': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // publicProfile
  {
    'gvb9fs2r': {
      'en': ' Following',
      'de': ' Folgt',
      'es': ' Siguiendo',
      'fr': ' Suivi',
      'it': ' Seguendo',
      'pl': ' Obserwuje',
    },
    '1vbcr30s': {
      'en': ' Followers',
      'de': ' Anhänger',
      'es': ' Seguidores',
      'fr': ' Abonnés',
      'it': ' Seguaci',
      'pl': ' Obserwujący',
    },
    'snk8muik': {
      'en': 'Message',
      'de': 'Nachricht',
      'es': 'Mensaje',
      'fr': 'Message',
      'it': 'Messaggio',
      'pl': 'Wiadomość',
    },
    'h4e7y7vb': {
      'en': 'Message',
      'de': 'Nachricht',
      'es': 'Mensaje',
      'fr': 'Message',
      'it': 'Messaggio',
      'pl': 'Wiadomość',
    },
    'jc4ia5e6': {
      'en': 'Message',
      'de': 'Nachricht',
      'es': 'Mensaje',
      'fr': 'Message',
      'it': 'Messaggio',
      'pl': 'Wiadomość',
    },
    'xn7opirx': {
      'en': 'Contact',
      'de': 'Kontakt',
      'es': 'Contacto',
      'fr': 'Contact',
      'it': 'Contatto',
      'pl': 'Kontakt',
    },
    '7pucubcx': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
    'j66bpyxe': {
      'en': 'Shop',
      'de': 'Geschäft',
      'es': 'Tienda',
      'fr': 'Magasin',
      'it': 'Negozio',
      'pl': 'Sklep',
    },
    'q4sm4pqn': {
      'en': 'Points',
      'de': 'Punkte',
      'es': 'Puntos',
      'fr': 'Points',
      'it': 'Punti',
      'pl': 'Punkty',
    },
    'jvvrpt1w': {
      'en': 'Chats',
      'de': 'Chats',
      'es': 'Chats',
      'fr': 'Chats',
      'it': 'Chat',
      'pl': 'Czaty',
    },
    '4yj1q407': {
      'en': 'Profile',
      'de': 'Profil',
      'es': 'Perfil',
      'fr': 'Profil',
      'it': 'Profilo',
      'pl': 'Profil',
    },
    '7msdfiwt': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // shareProfile
  {
    'ysmwa3vz': {
      'en': 'Share your QR code so others can follow you',
      'de': 'Teile deinen QR-Code, damit andere dir folgen können.',
      'es': 'Comparte tu código QR para que otros puedan seguirte.',
      'fr': 'Partagez votre code QR afin que les autres puissent vous suivre.',
      'it':
          'Condividi il tuo codice QR in modo che gli altri possano seguirti.',
      'pl': 'Podziel się swoim kodem QR, aby inni mogli cię obserwować.',
    },
    '3nmwb8eb': {
      'en': 'Share profile',
      'de': 'Profil teilen',
      'es': 'Compartir perfil',
      'fr': 'Partager le profil',
      'it': 'Condividi profilo',
      'pl': 'Udostępnij profil',
    },
    'fl46z6q8': {
      'en': 'Copy link',
      'de': 'Link kopieren',
      'es': 'Copiar link',
      'fr': 'Copier le lien',
      'it': 'Copia link',
      'pl': 'Skopiuj link',
    },
    'ozh38cga': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // redeemPoints
  {
    'ogmloqho': {
      'en': 'Redeem Points',
      'de': 'Punkte Einlösen',
      'es': 'Canjear Puntos',
      'fr': 'Échanger des Points',
      'it': 'Riscatta Punti',
      'pl': 'Wymień punkty',
    },
    'wutxrtje': {
      'en': 'PTS',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'g4yzgpjt': {
      'en': 'Available ',
      'de': 'Verfügbar ',
      'es': 'Disponible ',
      'fr': 'Disponible ',
      'it': 'Disponibile ',
      'pl': 'Dostępne ',
    },
    'rm83hytf': {
      'en': 'PTS',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'mb1pw9fi': {
      'en': '1',
      'de': '1',
      'es': '1',
      'fr': '1',
      'it': '1',
      'pl': '1',
    },
    'w4hbcvtn': {
      'en': '2',
      'de': '2',
      'es': '2',
      'fr': '2',
      'it': '2',
      'pl': '2',
    },
    'alsfdz1h': {
      'en': '3',
      'de': '3',
      'es': '3',
      'fr': '3',
      'it': '3',
      'pl': '3',
    },
    '7ounjw34': {
      'en': '4',
      'de': '4',
      'es': '4',
      'fr': '4',
      'it': '4',
      'pl': '4',
    },
    'vlm1ziz4': {
      'en': '5',
      'de': '5',
      'es': '5',
      'fr': '5',
      'it': '5',
      'pl': '5',
    },
    '3t66mkft': {
      'en': '6',
      'de': '6',
      'es': '6',
      'fr': '6',
      'it': '6',
      'pl': '6',
    },
    '0ul61e7a': {
      'en': '7',
      'de': '7',
      'es': '7',
      'fr': '7',
      'it': '7',
      'pl': '7',
    },
    '7a6rypf0': {
      'en': '8',
      'de': '8',
      'es': '8',
      'fr': '8',
      'it': '8',
      'pl': '8',
    },
    's9si4w1l': {
      'en': '9',
      'de': '9',
      'es': '9',
      'fr': '9',
      'it': '9',
      'pl': '9',
    },
    '5dc2ovoh': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'kmyms8jj': {
      'en': '0',
      'de': '0',
      'es': '0',
      'fr': '0',
      'it': '0',
      'pl': '0',
    },
    '2ppvgd1b': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // search
  {
    'zfv3innt': {
      'en': 'Search',
      'de': 'Suchen',
      'es': 'Buscar',
      'fr': 'Recherche',
      'it': 'Ricerca',
      'pl': 'Szukaj',
    },
    'odg80rme': {
      'en': 'Search',
      'de': 'Suchen',
      'es': 'Buscar',
      'fr': 'Recherche',
      'it': 'Ricerca',
      'pl': 'Szukaj',
    },
    'ko8wsuzb': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // usersToChat
  {
    '1ltmmhtw': {
      'en': 'New message',
      'de': 'Nouveau message',
      'es': 'Nuevo mensaje',
      'fr': 'Nouveau message',
      'it': 'Nuovo messaggio',
      'pl': 'Nowa wiadomość',
    },
    'ftm1ap5g': {
      'en': 'Find someone to chat with...',
      'de': 'Finde jemanden zum Chatten...',
      'es': 'Encuentra a alguien con quien chatear...',
      'fr': 'Trouver quelqu\'un avec qui discuter...',
      'it': 'Trova qualcuno con cui chattare...',
      'pl': 'Znajdź kogoś do rozmowy...',
    },
    'xpe8cx7a': {
      'en': 'Message',
      'de': 'Nachricht',
      'es': 'Mensaje',
      'fr': 'Message',
      'it': 'Messaggio',
      'pl': 'Wiadomość',
    },
    'ig4xffl7': {
      'en': 'Message',
      'de': 'Nachricht',
      'es': 'Mensaje',
      'fr': 'Message',
      'it': 'Messaggio',
      'pl': 'Wiadomość',
    },
    'c6mscc9a': {
      'en': 'Message',
      'de': 'Nachricht',
      'es': 'Mensaje',
      'fr': 'Message',
      'it': 'Messaggio',
      'pl': 'Wiadomość',
    },
    'knir0xq0': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // chats
  {
    '7zxfq2xj': {
      'en': 'Chats',
      'de': 'Chats',
      'es': 'charlas',
      'fr': 'Chats',
      'it': 'Chat',
      'pl': 'Czaty',
    },
    'v9ou0bhr': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
    '69b3ik9l': {
      'en': 'Events',
      'de': 'Geschäft',
      'es': 'Comercio',
      'fr': 'Boutique',
      'it': 'Negozio',
      'pl': 'Sklep',
    },
    '1ccuqbwe': {
      'en': 'History',
      'de': 'Punkte',
      'es': 'Puntos',
      'fr': 'Points',
      'it': 'Punti',
      'pl': 'Punkty',
    },
    'kmnoc8y9': {
      'en': 'Chats',
      'de': 'Chats',
      'es': 'Chats',
      'fr': 'Chats',
      'it': 'Chat',
      'pl': 'Czaty',
    },
    'ht3nnqtr': {
      'en': 'Profile',
      'de': 'Profil',
      'es': 'Perfil',
      'fr': 'Profil',
      'it': 'Profilo',
      'pl': 'Profil',
    },
    '4alluun8': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // image_message
  {
    '6ra0jhze': {
      'en': 'Message',
      'de': 'Nachricht',
      'es': 'Mensaje',
      'fr': 'Message',
      'it': 'Messaggio',
      'pl': 'Wiadomość',
    },
    'v0bdcg6x': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // following_followers
  {
    'ahi8xqho': {
      'en': 'Following',
      'de': 'Folge ich',
      'es': 'Siguiendo',
      'fr': 'Abonné',
      'it': 'Segui',
      'pl': 'Obserwujesz',
    },
    'h32pkkub': {
      'en': 'Followers',
      'de': 'Anhänger',
      'es': 'Seguidores',
      'fr': 'Suiveurs',
      'it': 'Seguaci',
      'pl': 'Obserwujący',
    },
    'lto1p89b': {
      'en': 'Search',
      'de': 'Suchen',
      'es': 'Buscar',
      'fr': 'Recherche',
      'it': 'Ricerca',
      'pl': 'Szukaj',
    },
    'goeetc5o': {
      'en': 'Search',
      'de': 'Suchen',
      'es': 'Buscar',
      'fr': 'Recherche',
      'it': 'Ricerca',
      'pl': 'Szukaj',
    },
    'f5hupntf': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // messages
  {
    'p1c9d6cp': {
      'en': 'Cancel',
      'de': 'Stornieren',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
    't1xklrzz': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // following_followers_2
  {
    '0puvxfb8': {
      'en': 'Following',
      'de': 'Folge ich',
      'es': 'Siguiendo',
      'fr': 'Abonné',
      'it': 'Segui',
      'pl': 'Obserwowani',
    },
    '7li3m9uo': {
      'en': 'Followers',
      'de': 'Anhänger',
      'es': 'Seguidores',
      'fr': 'Suiveurs',
      'it': 'Seguaci',
      'pl': 'Obserwujący',
    },
    'ophw42je': {
      'en': 'Search',
      'de': 'Suchen',
      'es': 'Buscar',
      'fr': 'Recherche',
      'it': 'Ricerca',
      'pl': 'Szukaj',
    },
    '18flkfiq': {
      'en': 'Search',
      'de': 'Suchen',
      'es': 'Buscar',
      'fr': 'Recherche',
      'it': 'Ricerca',
      'pl': 'Szukaj',
    },
    'a5pm749i': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // professionalAccount
  {
    'uzpf0edm': {
      'en': 'Details',
      'de': 'Einzelheiten',
      'es': 'Detalles',
      'fr': 'Détails',
      'it': 'Dettagli',
      'pl': 'Detale',
    },
    '63v1xdlp': {
      'en': 'Next',
      'de': 'Nächste',
      'es': 'Próximo',
      'fr': 'Suivant',
      'it': 'Prossimo',
      'pl': 'Dalej',
    },
    'rfcvv19k': {
      'en': 'Add logo',
      'de': 'Logo hinzufügen',
      'es': 'Agregar logotipo',
      'fr': 'Ajouter un logo',
      'it': 'Aggiungi logo',
      'pl': 'Dodaj logo',
    },
    '4i8q84el': {
      'en': 'About business',
      'de': 'Über das Unternehmen',
      'es': 'Acerca del negocio',
      'fr': 'À propos de l\'entreprise',
      'it': 'Informazioni sull\'attività',
      'pl': 'O firmie',
    },
    'nactsp65': {
      'en': 'Business Name',
      'de': 'Unternehmensname',
      'es': 'Nombre del negocio',
      'fr': 'Nom de l\'entreprise',
      'it': 'Nome dell\'azienda',
      'pl': 'Nazwa firmy',
    },
    'g80urwg6': {
      'en': 'Username',
      'de': 'Nutzername',
      'es': 'Nombre de usuario',
      'fr': 'Nom d\'utilisateur',
      'it': 'Nome utente',
      'pl': 'Nazwa użytkownika',
    },
    'opm7pmne': {
      'en': 'Bio',
      'de': 'Bio',
      'es': 'biografía',
      'fr': 'Bio',
      'it': 'Bio',
      'pl': 'Bio',
    },
    'w7b8czju': {
      'en': 'Website',
      'de': 'Webseite',
      'es': 'Sitio web',
      'fr': 'Site web',
      'it': 'Sito web',
      'pl': 'Strona internetowa',
    },
    '3zv9so3o': {
      'en': 'Public business information',
      'de': 'Öffentliche Geschäftsinformationen',
      'es': 'información comercial pública',
      'fr': 'Informations commerciales publiques',
      'it': 'Informazioni commerciali pubbliche',
      'pl': 'Publiczne informacje o firmie',
    },
    'ill9dn2d': {
      'en': 'Category',
      'de': 'Kategorie',
      'es': 'Categoría',
      'fr': 'Catégorie',
      'it': 'Categoria',
      'pl': 'Kategoria',
    },
    'ow963a2x': {
      'en': 'Address',
      'de': 'Adresse',
      'es': 'DIRECCIÓN',
      'fr': 'Adresse',
      'it': 'Indirizzo',
      'pl': 'Adres',
    },
    'vxlnk97g': {
      'en': 'Phone',
      'de': 'Telefon',
      'es': 'Teléfono',
      'fr': 'Téléphone',
      'it': 'Telefono',
      'pl': 'Telefon',
    },
    '3utpwog7': {
      'en': 'Email',
      'de': 'Email',
      'es': 'Correo electrónico',
      'fr': 'E-mail',
      'it': 'E-mail',
      'pl': 'E-mail',
    },
    'w3l9m5k6': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // addPhotoLocation
  {
    'qdmi0blk': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Fait',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    'zsb8kyui': {
      'en': 'Location',
      'de': 'Standort',
      'es': 'Ubicación',
      'fr': 'Emplacement',
      'it': 'Posizione',
      'pl': 'Lokalizacja',
    },
    'ubi0dhww': {
      'en': 'Location',
      'de': 'Standort',
      'es': 'Ubicación',
      'fr': 'Emplacement',
      'it': 'Posizione',
      'pl': 'Lokalizacja',
    },
    '6icur5l2': {
      'en': 'Rome, IT',
      'de': 'Rom, IT',
      'es': 'Roma, TI',
      'fr': 'Rome, IT',
      'it': 'Roma, IT',
      'pl': 'Rzym, IT',
    },
    '7yl5yidl': {
      'en':
          'Add a location so users know where your photo was taken or what it might be a picture of.',
      'de':
          'Füge einen Standort hinzu, damit Benutzer wissen, wo dein Foto aufgenommen wurde oder worum es auf dem Bild gehen könnte.',
      'es':
          'Agrega una ubicación para que los usuarios sepan dónde se tomó tu foto o de qué podría ser una imagen.',
      'fr':
          'Ajoutez un emplacement pour que les utilisateurs sachent où votre photo a été prise ou ce que pourrait être l\'image.',
      'it':
          'Aggiungi una posizione in modo che gli utenti sappiano dove è stata scattata la tua foto o di cosa potrebbe trattarsi l\'immagine.',
      'pl':
          'Dodaj lokalizację, aby użytkownicy wiedzieli, gdzie zostało zrobione twoje zdjęcie lub o co może chodzić na zdjęciu.',
    },
    'jcdnqokc': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // addBusinessName
  {
    '2na8y88t': {
      'en': 'Name',
      'de': 'Name',
      'es': 'Nombre',
      'fr': 'Nom',
      'it': 'Nome',
      'pl': 'Nazwa',
    },
    'm8l0ka92': {
      'en': 'Help people find your business by using its name.',
      'de':
          'Helfen Sie Menschen, Ihr Unternehmen zu finden, indem Sie seinen Namen verwenden.',
      'es': 'Ayude a las personas a encontrar su negocio usando su nombre.',
      'fr': 'Aidez les gens à trouver votre entreprise en utilisant son nom.',
      'it':
          'Aiuta le persone a trovare la tua attività utilizzando il suo nome.',
      'pl': 'Pomóż innym znaleźć Twoją firmę, używając jej nazwy.',
    },
    'geb3aq9g': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Fait',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    'a3xjdqta': {
      'en': 'Name',
      'de': 'Name',
      'es': 'Nombre',
      'fr': 'Nom',
      'it': 'Nome',
      'pl': 'Nazwa',
    },
    'x3nkyp4a': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // addBusinessWebsite
  {
    'q0txbvqd': {
      'en': 'Website',
      'de': 'Webseite',
      'es': 'Sitio web',
      'fr': 'Site web',
      'it': 'Sito web',
      'pl': 'Strona internetowa',
    },
    '5zwqcvxi': {
      'en':
          'Share your website link to provide clients with direct access to more information about your business.',
      'de':
          'Teilen Sie Ihren Website-Link, um Kunden direkten Zugriff auf weitere Informationen über Ihr Unternehmen zu ermöglichen.',
      'es':
          'Comparta el enlace de su sitio web para proporcionar a los clientes acceso directo a más información sobre su negocio.',
      'fr':
          'Partagez le lien de votre site Web pour fournir aux clients un accès direct à plus d\'informations sur votre entreprise.',
      'it':
          'Condividi il link del tuo sito web per fornire ai clienti l\'accesso diretto a maggiori informazioni sulla tua attività.',
      'pl':
          'Udostępnij link do swojej strony internetowej, aby zapewnić klientom bezpośredni dostęp do większej ilości informacji o Twojej firmie.',
    },
    'd16b4a47': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    '8w7wo6j1': {
      'en': 'Website',
      'de': 'Webseite',
      'es': 'Sitio web',
      'fr': 'Site web',
      'it': 'Sito web',
      'pl': 'Strona internetowa',
    },
    'ljme76gx': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // addBusinessBio
  {
    'k33j4ig0': {
      'en': 'Bio',
      'de': 'Bio',
      'es': 'biografía',
      'fr': 'Bio',
      'it': 'Bio',
      'pl': 'Bio',
    },
    '8j5c5myo': {
      'en':
          'Write a short and engaging bio that tells your brand\'s story, expertise and passion. Show potential clients what makes you special and stand out.',
      'de':
          'Schreiben Sie eine kurze und ansprechende Biografie, die die Geschichte Ihrer Marke, Ihre Expertise und Leidenschaft erzählt. Zeigen Sie potenziellen Kunden, was Sie besonders und herausragend macht.',
      'es':
          'Escribe una biografía corta y atractiva que cuente la historia de tu marca, experiencia y pasión. Muestra a los posibles clientes lo que te hace especial y destacado.',
      'fr':
          'Rédigez une biographie courte et captivante qui raconte l\'histoire de votre marque, votre expertise et votre passion. Montrez aux clients potentiels ce qui vous rend spécial et unique.',
      'it':
          'Scrivi una breve e coinvolgente biografia che racconti la storia del tuo marchio, la tua esperienza e la passione. Mostra ai potenziali clienti ciò che ti rende speciale e unico.',
      'pl':
          'Napisz krótką i angażującą biografię, która opowie historię Twojej marki, ekspertyzę i pasję. Pokaż potencjalnym klientom, co cię wyróżnia i czyni wyjątkowym.',
    },
    'vcp2tcn0': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    'flr5scnw': {
      'en': 'Bio',
      'de': 'Bio',
      'es': 'biografía',
      'fr': 'Bio',
      'it': 'Bio',
      'pl': 'Bio',
    },
    'euuaubs9': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // editBusinessProfile
  {
    'ddxoykgl': {
      'en': 'Details',
      'de': 'Einzelheiten',
      'es': 'Detalles',
      'fr': 'Détails',
      'it': 'Dettagli',
      'pl': 'Detale',
    },
    't1o0m6ux': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    '5cbuyal3': {
      'en': 'Add logo',
      'de': 'Logo hinzufügen',
      'es': 'Agregar logotipo',
      'fr': 'Ajouter un logo',
      'it': 'Aggiungi logo',
      'pl': 'Dodaj logo',
    },
    '9w881y2q': {
      'en': 'About business',
      'de': 'Über das Unternehmen',
      'es': 'Acerca del negocio',
      'fr': 'À propos de l\'entreprise',
      'it': 'Informazioni sull\'attività',
      'pl': 'O firmie',
    },
    '2tww6tqq': {
      'en': 'Name',
      'de': 'Unternehmensname',
      'es': 'Nombre del negocio',
      'fr': 'Nom de l\'entreprise',
      'it': 'Nome dell\'azienda',
      'pl': 'Nazwa firmy',
    },
    'cu1rktef': {
      'en': 'Username',
      'de': 'Nutzername',
      'es': 'Nombre de usuario',
      'fr': 'Nom d\'utilisateur',
      'it': 'Nome utente',
      'pl': 'Nazwa użytkownika',
    },
    'y3ef84we': {
      'en': 'Bio',
      'de': 'Bio',
      'es': 'Biografía',
      'fr': 'Bio',
      'it': 'Bio',
      'pl': 'Bio',
    },
    'hrcc4ryr': {
      'en': 'Website',
      'de': 'Webseite',
      'es': 'Sitio web',
      'fr': 'Site web',
      'it': 'Sito web',
      'pl': 'Strona internetowa',
    },
    'qe3nwq3r': {
      'en': 'Public business information',
      'de': 'Öffentliche Unternehmensinformationen',
      'es': 'Información pública de la empresa',
      'fr': 'Informations publiques sur l\'entreprise',
      'it': 'Informazioni pubbliche dell\'azienda',
      'pl': 'Publiczne informacje o firmie',
    },
    'paeqq6e9': {
      'en': 'Category',
      'de': 'Kategorie',
      'es': 'Categoría',
      'fr': 'Catégorie',
      'it': 'Categoria',
      'pl': 'Kategoria',
    },
    '2vzhf1bi': {
      'en': 'Address',
      'de': 'Adresse',
      'es': 'DIRECCIÓN',
      'fr': 'Adresse',
      'it': 'Indirizzo',
      'pl': 'Adres',
    },
    '2jbwh3kt': {
      'en': 'Phone',
      'de': 'Telefon',
      'es': 'Teléfono',
      'fr': 'Téléphone',
      'it': 'Telefono',
      'pl': 'Telefon',
    },
    'ryj9zsr4': {
      'en': 'Email',
      'de': 'Email',
      'es': 'Correo electrónico',
      'fr': 'E-mail',
      'it': 'E-mail',
      'pl': 'E-mail',
    },
    'ockk3jw7': {
      'en': 'Check for updates',
      'de': 'Auf Updates prüfen',
      'es': 'Buscar actualizaciones',
      'fr': 'Vérifier les mises à jour',
      'it': 'Controlla gli aggiornamenti',
      'pl': 'Sprawdź aktualizacje',
    },
    'um70rx8j': {
      'en': 'Delete business account',
      'de': 'Lösche das Geschäftskonto',
      'es': 'Eliminar cuenta de empresa',
      'fr': 'Supprimer le compte professionnel',
      'it': 'Elimina l\'account aziendale',
      'pl': 'Usuń konto firmowe',
    },
    'vuwj1wuz': {
      'en': 'Delete account',
      'de': 'Konto löschen',
      'es': 'Borrar cuenta',
      'fr': 'Supprimer le compte',
      'it': 'Elimina account',
      'pl': 'Usuń konto',
    },
    'pi61xn80': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // addBusinessUsername
  {
    '2nr6axo9': {
      'en': 'Username',
      'de': 'Benutzername',
      'es': 'Nombre de usuario',
      'fr': 'Nom d\'utilisateur',
      'it': 'Nome utente',
      'pl': 'Nazwa użytkownika',
    },
    '41lzpbj3': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'elx35r11': {
      'en': 'This username isn\'t available. Please try another one.',
      'de':
          'Dieser Benutzername ist nicht verfügbar. Bitte versuche einen anderen.',
      'es':
          'Este nombre de usuario no está disponible. Por favor, prueba otro.',
      'fr':
          'Ce nom d\'utilisateur n\'est pas disponible. Veuillez en essayer un autre.',
      'it': 'Questo nome utente non è disponibile. Prova un altro.',
      'pl': 'Ta nazwa użytkownika jest niedostępna. Spróbuj innej.',
    },
    'x4a4443v': {
      'en':
          'This is your current username. If you would like to change it start typing and create a new one. If not, simply go back.',
      'de':
          'Dies ist dein aktueller Benutzername. Um ihn zu ändern, beginne einen neuen einzugeben. Wenn nicht, gehe einfach zurück.',
      'es':
          'Este es tu nombre de usuario actual. Para cambiarlo, comienza a escribir uno nuevo. Si no, simplemente regresa.',
      'fr':
          'Ceci est votre nom d\'utilisateur actuel. Pour le changer, commencez à taper un nouveau. Sinon, revenez simplement en arrière.',
      'it':
          'Questo è il tuo attuale nome utente. Per cambiarlo, inizia a digitare uno nuovo. In caso contrario, torna semplicemente indietro.',
      'pl':
          'To jest twoja obecna nazwa użytkownika. Aby ją zmienić, wpisz nową nazwę. Jeżeli nie chcesz zmienić, po prostu wróć.',
    },
    '1sons7og': {
      'en': 'Field is required',
      'de': 'Feld ist erforderlich',
      'es': 'Campo requerido',
      'fr': 'Champ requis',
      'it': 'Campo obbligatorio',
      'pl': 'To pole jest wymagane',
    },
    'hwo5pt8b': {
      'en': 'Please choose an option from the dropdown',
      'de': 'Bitte eine Option aus dem Dropdown-Menü auswählen',
      'es': 'Por favor, elige una opción del menú desplegable',
      'fr': 'Veuillez choisir une option dans la liste déroulante',
      'it': 'Scegliere un\'opzione dal menu a tendina',
      'pl': 'Proszę wybrać opcję z rozwijanego menu',
    },
    'yvybkmrr': {
      'en':
          'Create a username that will help people find your business. For example, use your business name.',
      'de':
          'Erstelle einen Benutzernamen, der Menschen dabei hilft, dein Unternehmen zu finden. Verwende zum Beispiel den Namen deines Unternehmens.',
      'es':
          'Crea un nombre de usuario que ayudará a las personas a encontrar tu negocio. Por ejemplo, utiliza el nombre de tu negocio.',
      'fr':
          'Créez un nom d\'utilisateur qui aidera les gens à trouver votre entreprise. Par exemple, utilisez le nom de votre entreprise.',
      'it':
          'Crea un nome utente che aiuterà le persone a trovare la tua attività. Ad esempio, usa il nome della tua azienda.',
      'pl':
          'Stwórz nazwę użytkownika, która pomoże ludziom znaleźć Twoją firmę. Na przykład, użyj nazwy swojego biznesu.',
    },
    'ssa1puij': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    '8de6j6j3': {
      'en': 'Username',
      'de': 'Benutzername',
      'es': 'Nombre de usuario',
      'fr': 'Nom d\'utilisateur',
      'it': 'Nome utente',
      'pl': 'Nazwa użytkownika',
    },
    'kexos3q5': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // addBusinessPhone
  {
    'u9v1r8gf': {
      'en': 'Phone',
      'de': 'Telefon',
      'es': 'Teléfono',
      'fr': 'Téléphone',
      'it': 'Telefono',
      'pl': 'Telefon',
    },
    'kbpmch4z': {
      'en':
          'Add your business phone number so clients will be able to easily contact you.',
      'de':
          'Füge deine Geschäftsnummer hinzu, damit Kunden dich leicht kontaktieren können.',
      'es':
          'Agrega el número de teléfono de tu negocio para que los clientes puedan contactarte fácilmente.',
      'fr':
          'Ajoutez le numéro de téléphone de votre entreprise pour que les clients puissent vous contacter facilement.',
      'it':
          'Aggiungi il numero di telefono della tua azienda in modo che i clienti possano contattarti facilmente.',
      'pl':
          'Dodaj numer telefonu swojej firmy, aby klienci mogli się z tobą łatwo skontaktować.',
    },
    '4ipiytid': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    '6bvthvh7': {
      'en': 'Phone',
      'de': 'Telefon',
      'es': 'Teléfono',
      'fr': 'Téléphone',
      'it': 'Telefono',
      'pl': 'Telefon',
    },
    'igj7luxk': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // addBusinessCategory
  {
    '0015o8tu': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    'svhgw06m': {
      'en': 'Your business category',
      'de': 'Die Kategorie Ihres Unternehmens',
      'es': 'La categoría de tu negocio',
      'fr': 'La catégorie de votre entreprise',
      'it': 'La categoria della tua azienda',
      'pl': 'Kategoria Twojego biznesu',
    },
    'p2o4mv3g': {
      'en':
          'Choose the most fitting business category that accurately represents the nature of your business, making it easier for clients to discover you',
      'de':
          'Wähle die am besten passende Geschäftskategorie aus, die die Natur deines Unternehmens genau repräsentiert und es Kunden erleichtert, dich zu entdecken.',
      'es':
          'Elige la categoría de negocio más adecuada que represente con precisión la naturaleza de tu negocio, facilitando que los clientes te descubran.',
      'fr':
          'Choisissez la catégorie d\'entreprise la plus appropriée qui représente avec précision la nature de votre entreprise, ce qui facilitera la découverte par les clients.',
      'it':
          'Scegli la categoria di attività più adatta che rappresenta accuratamente la natura della tua azienda, rendendoti più facilmente scopribile dai clienti.',
      'pl':
          'Wybierz najodpowiedniejszą kategorię biznesu, która dokładnie odzwierciedla charakter Twojego biznesu i ułatwia klientom jego odkrycie.',
    },
    'qewjdpe1': {
      'en': 'Search',
      'de': 'Suchen',
      'es': 'Buscar',
      'fr': 'Rechercher',
      'it': 'Ricerca',
      'pl': 'Szukaj',
    },
    'c8lvnnhl': {
      'en': 'Selected',
      'de': 'Ausgewählt',
      'es': 'Seleccionado',
      'fr': 'Sélectionné',
      'it': 'Selezionato',
      'pl': 'Wybrano',
    },
    'uz433ipq': {
      'en': 'Suggested',
      'de': 'Vorgeschlagen',
      'es': 'Sugerido',
      'fr': 'Suggéré',
      'it': 'Suggerito',
      'pl': 'Sugerowane',
    },
    '8hioy0lu': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // addBusinessEmail
  {
    'ro0d8ql8': {
      'en': 'Email',
      'de': 'E-mail',
      'es': 'E-mail',
      'fr': 'E-mail',
      'it': 'E-mail',
      'pl': 'E-mail',
    },
    't3v2in61': {
      'en': 'Add your email so clients will be able to easily contact you.',
      'de':
          'Füge deine E-Mail-Adresse hinzu, damit Kunden dich leicht kontaktieren können.',
      'es':
          'Agrega tu correo electrónico para que los clientes puedan contactarte fácilmente.',
      'fr':
          'Ajoutez votre adresse e-mail pour que les clients puissent vous contacter facilement.',
      'it':
          'Aggiungi la tua email in modo che i clienti possano contattarti facilmente.',
      'pl':
          'Dodaj swój adres e-mail, aby klienci mogli się z tobą łatwo skontaktować.',
    },
    'uyap98pf': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    '9eddbfuk': {
      'en': 'Email',
      'de': 'Email',
      'es': 'E-mail',
      'fr': 'E-mail',
      'it': 'E-mail',
      'pl': 'E-mail',
    },
    'mme6bbob': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // addBusinessAddress
  {
    'zxej19ui': {
      'en': 'Address',
      'de': 'Adresse',
      'es': 'Dirección',
      'fr': 'Adresse',
      'it': 'Indirizzo',
      'pl': 'Adres',
    },
    'y5857tjy': {
      'en': 'City/Town',
      'de': 'Stadt/Stadt',
      'es': 'Ciudad/Pueblo',
      'fr': 'Ville/Ville',
      'it': 'Città/Paese',
      'pl': 'Miasto',
    },
    'g57l7u45': {
      'en': 'Postal code',
      'de': 'Postleitzahl',
      'es': 'Código Postal',
      'fr': 'Code Postal',
      'it': 'Codice Postale',
      'pl': 'Kod pocztowy',
    },
    '8dqneabw': {
      'en': 'Country',
      'de': 'Land',
      'es': 'País',
      'fr': 'Pays',
      'it': 'Paese',
      'pl': 'Kraj',
    },
    'ips8upih': {
      'en':
          'Add your business address so clients can easily locate and visit your establishment.',
      'de':
          'Füge die Adresse deines Unternehmens hinzu, damit Kunden deine Einrichtung leicht finden und besuchen können.',
      'es':
          'Agrega la dirección de tu negocio para que los clientes puedan ubicar y visitar fácilmente tu establecimiento.',
      'fr':
          'Ajoutez l\'adresse de votre entreprise afin que les clients puissent facilement localiser et visiter votre établissement.',
      'it':
          'Aggiungi l\'indirizzo della tua attività affinché i clienti possano facilmente individuare e visitare la tua struttura.',
      'pl':
          'Dodaj adres swojego biznesu, aby klienci mogli łatwo znaleźć i odwiedzić Twoją placówkę.',
    },
    '38eanilt': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    'ymh8i29m': {
      'en': 'Location',
      'de': 'Standort',
      'es': 'Ubicación',
      'fr': 'Emplacement',
      'it': 'Posizione',
      'pl': 'Lokalizacja',
    },
    '14022gc5': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // profileDisplay
  {
    'fwrcf84x': {
      'en': ' Following ',
      'de': 'Folge ich',
      'es': 'Siguiendo',
      'fr': 'Abonnement',
      'it': 'Segui',
      'pl': 'Obserwujesz',
    },
    '2dxx6sqr': {
      'en': ' ',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    '821dxrg1': {
      'en': 'Shop',
      'de': 'Laden',
      'es': 'Tienda',
      'fr': 'Boutique',
      'it': 'Negozio',
      'pl': 'Sklep',
    },
    'tv5gsy6d': {
      'en': 'Follow',
      'de': 'Folgen',
      'es': 'Seguir',
      'fr': 'Suivre',
      'it': 'Segui',
      'pl': 'Obserwuj',
    },
    'z0z7cnwo': {
      'en': 'Message',
      'de': 'Nachricht',
      'es': 'Mensaje',
      'fr': 'Message',
      'it': 'Messaggio',
      'pl': 'Wiadomość',
    },
    '4u5c1as9': {
      'en': 'Contact',
      'de': 'Kontakt',
      'es': 'Contacto',
      'fr': 'Contact',
      'it': 'Contatto',
      'pl': 'Kontakt',
    },
    'ztcib66p': {
      'en': 'Public profile appearance settings',
      'de': 'Einstellungen für das Erscheinungsbild des öffentlichen Profils',
      'es': 'Configuración de la apariencia del perfil público',
      'fr': 'Paramètres d\'apparence du profil public',
      'it': 'Impostazioni dell\'aspetto del profilo pubblico',
      'pl': 'Ustawienia wyglądu publicznego profilu',
    },
    '0xdogme4': {
      'en': 'Display business category',
      'de': 'Zeige Unternehmenskategorie',
      'es': 'Mostrar categoría de negocio',
      'fr': 'Afficher la catégorie de l\'entreprise',
      'it': 'Mostra categoria aziendale',
      'pl': 'Wyświetl kategorię biznesu',
    },
    'cz6ny44g': {
      'en': 'Display business website',
      'de': 'Zeige Unternehmenswebsite',
      'es': 'Mostrar sitio web de la empresa',
      'fr': 'Afficher le site web de l\'entreprise',
      'it': 'Mostra sito web dell\'azienda',
      'pl': 'Wyświetl stronę internetową firmy',
    },
    '6m04xxuv': {
      'en': 'Allow people to contact you',
      'de': 'Erlaube Menschen, dich zu kontaktieren',
      'es': 'Permite que las personas te contacten',
      'fr': 'Autoriser les gens à vous contacter',
      'it': 'Consenti alle persone di contattarti',
      'pl': 'Pozwól ludziom się z tobą skontaktować',
    },
    'utvqjtgy': {
      'en': 'Feature your business in Shops section',
      'de': 'Hebe dein Unternehmen im Shops-Bereich hervor',
      'es': 'Destaca tu negocio en la sección de Tiendas',
      'fr': 'Mettez en avant votre entreprise dans la section Boutiques',
      'it': 'Metti in evidenza la tua azienda nella sezione Negozi',
      'pl': 'Wyróżnij swój biznes w sekcji Sklepy',
    },
    'rdui7t6w': {
      'en': 'Verify your business page',
      'de': 'Verifiziere deine Unternehmensseite',
      'es': 'Verifica tu página de negocio',
      'fr': 'Vérifiez votre page d\'entreprise',
      'it': 'Verifica la tua pagina aziendale',
      'pl': 'Zweryfikuj swoją stronę biznesową',
    },
    '0j48s07l': {
      'en':
          'Locked features are only available for Beneree Pro Business users. Upgrade your account to unlock full potential of Beneree.',
      'de':
          'Gesperrte Funktionen sind nur für Beneree Pro Business-Nutzer verfügbar. Upgrade dein Konto, um das volle Potenzial von Beneree freizuschalten.',
      'es':
          'Las funciones bloqueadas solo están disponibles para los usuarios de Beneree Pro Business. Actualiza tu cuenta para desbloquear todo el potencial de Beneree.',
      'fr':
          'Les fonctionnalités verrouillées sont uniquement disponibles pour les utilisateurs de Beneree Pro Business. Mettez à niveau votre compte pour débloquer le plein potentiel de Beneree.',
      'it':
          'Le funzionalità bloccate sono disponibili solo per gli utenti Beneree Pro Business. Aggiorna il tuo account per sbloccare il pieno potenziale di Beneree.',
      'pl':
          'Zablokowane funkcje są dostępne tylko dla użytkowników Beneree Pro Business. Zaktualizuj swoje konto, aby odblokować pełny potencjał Beneree.',
    },
    'gljdvwtg': {
      'en': 'Switch to Professional Account',
      'de': 'Wechsel zu einem Professionellen Konto',
      'es': 'Cambiar a Cuenta Profesional',
      'fr': 'Passer à un Compte Professionnel',
      'it': 'Passa a un Account Professionale',
      'pl': 'Przełącz się na Konto Profesjonalne',
    },
    'qquqxnuf': {
      'en': 'Profile display',
      'de': 'Profildarstellung',
      'es': 'Visualización del perfil',
      'fr': 'Affichage du profil',
      'it': 'Visualizzazione del profilo',
      'pl': 'Wyświetlanie profilu',
    },
    'kx9chgb2': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // categorySearch
  {
    '6mu52iey': {
      'en': 'Search',
      'de': 'Suche',
      'es': 'Búsqueda',
      'fr': 'Recherche',
      'it': 'Ricerca',
      'pl': 'Szukaj',
    },
    '1ub6fjgx': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    'vijuk106': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // addBusinessPassword
  {
    'qjr1h9i4': {
      'en': 'Password',
      'de': 'Passwort',
      'es': 'Contraseña',
      'fr': 'Mot de passe',
      'it': 'Password',
      'pl': 'Hasło',
    },
    'hbh5jsa8': {
      'en':
          'Create a unique password for your business account. Please do not share it with anyone.',
      'de':
          'Erstelle ein einzigartiges Passwort für dein Geschäftskonto. Bitte teile es mit niemandem.',
      'es':
          'Crea una contraseña única para tu cuenta de negocio. Por favor, no la compartas con nadie.',
      'fr':
          'Créez un mot de passe unique pour votre compte professionnel. Veuillez ne le partager avec personne.',
      'it':
          'Crea una password unica per il tuo account aziendale. Per favore, non condividerla con nessuno.',
      'pl':
          'Stwórz unikalne hasło dla swojego konta biznesowego. Proszę, nie udostępniaj go nikomu.',
    },
    'q47mrbs5': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    't4yvifzk': {
      'en': 'Password',
      'de': 'Passwort',
      'es': 'Contraseña',
      'fr': 'Mot de passe',
      'it': 'Password',
      'pl': 'Hasło',
    },
    'dn37cj9j': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // businessAccountCreated
  {
    '6dvz01m4': {
      'en': 'Congratulations!',
      'de': 'Herzlichen Glückwunsch!',
      'es': '¡Felicidades!',
      'fr': 'Félicitations !',
      'it': 'Congratulazioni!',
      'pl': 'Gratulacje!',
    },
    '9xh8ymnk': {
      'en':
          'Your business profile was successfully created. \nStart creating posts, engaging with the community and experiencing all the benefits that Beneree brings you!',
      'de':
          'Ihr Unternehmensprofil wurde erfolgreich erstellt.\nBeginnen Sie mit dem Erstellen von Beiträgen, der Interaktion mit der Community und dem Erleben aller Vorteile, die Ihnen Beneree bietet!',
      'es':
          '¡Tu perfil de negocio se creó con éxito!\n¡Comienza a crear publicaciones, interactuar con la comunidad y experimentar todos los beneficios que Beneree te brinda!',
      'fr':
          'Votre profil d\'entreprise a été créé avec succès.\nCommencez à créer des publications, à vous engager avec la communauté et à profiter de tous les avantages que Beneree vous apporte !',
      'it':
          'Il tuo profilo aziendale è stato creato con successo.\nInizia a creare post, interagire con la community e sperimentare tutti i vantaggi che Beneree ti offre!',
      'pl':
          'Twoje profil firmowy został pomyślnie utworzony.\nZacznij tworzyć posty, angażować się w społeczność i doświadczać wszystkich korzyści, jakie przynosi Beneree!',
    },
    'pwcz6ygj': {
      'en': 'OK',
      'de': 'OK',
      'es': 'OK',
      'fr': 'OK',
      'it': 'OK',
      'pl': 'OK',
    },
    '4m12785e': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // taggUsers
  {
    '1kg6ohmc': {
      'en': 'Search',
      'de': 'Suchen',
      'es': 'Buscar',
      'fr': 'Recherche',
      'it': 'Ricerca',
      'pl': 'Szukaj',
    },
    'etlt041d': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    '3l9rz5ja': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // postReported
  {
    'kdnnipct': {
      'en': 'Thanks for reporting this post',
      'de': 'Vielen Dank für das Melden dieses Beitrags',
      'es': 'Gracias por reportar esta publicación',
      'fr': 'Merci d\'avoir signalé cette publication',
      'it': 'Grazie per aver segnalato questo post',
      'pl': 'Dziękujemy za zgłoszenie tego posta',
    },
    'xmld7hbm': {
      'en':
          'Your feedback is important in helping us keep the Beneree community safe.',
      'de':
          'Ihr Feedback ist wichtig, um uns zu helfen, die Sicherheit der Beneree-Community zu gewährleisten.',
      'es':
          'Tu opinión es importante para ayudarnos a mantener segura la comunidad de Beneree.',
      'fr':
          'Vos commentaires sont importants pour nous aider à maintenir la sécurité de la communauté Beneree.',
      'it':
          'Il tuo feedback è importante per aiutarci a mantenere la sicurezza della comunità Beneree.',
      'pl':
          'Twoja opinia jest ważna, pomagając nam zapewnić bezpieczeństwo społeczności Beneree.',
    },
    'pjkygq7c': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    '66i7ikn7': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // editName
  {
    '2dculav0': {
      'en': 'Name',
      'de': 'Vollständiger Name',
      'es': 'Nombre completo',
      'fr': 'Nom complet',
      'it': 'Nome completo',
      'pl': 'Imię i nazwisko',
    },
    'mxk8k8es': {
      'en': 'Help people find you by using your name.',
      'de': 'Hilf Menschen, dich zu finden, indem du deinen Namen verwendest.',
      'es': 'Ayuda a las personas a encontrarte usando tu nombre.',
      'fr': 'Aidez les gens à vous trouver en utilisant votre nom.',
      'it': 'Aiuta le persone a trovarti usando il tuo nome.',
      'pl': 'Pomóż ludziom znaleźć cię, używając swojego imienia.',
    },
    'cfkp7qni': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    '5jil32xh': {
      'en': 'Name',
      'de': 'Vollständiger Name',
      'es': 'Nombre completo',
      'fr': 'Nom complet',
      'it': 'Nome completo',
      'pl': 'Imię i nazwisko',
    },
    '8vi372ke': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // profile
  {
    '1cpuuj8y': {
      'en': ' Following ',
      'de': ' Du folgst',
      'es': ' Sigues',
      'fr': ' Vous suivez',
      'it': ' Segui',
      'pl': ' Obserwujesz',
    },
    '8uqcidmd': {
      'en': ' ',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    '7zep77pm': {
      'en': 'Followers',
      'de': ' Anhänger',
      'es': ' Seguidores',
      'fr': ' Abonnés',
      'it': ' Seguaci',
      'pl': ' Obserwujący',
    },
    '5281h6vf': {
      'en': 'Edit profile',
      'de': 'Profil bearbeiten',
      'es': 'Editar perfil',
      'fr': 'Modifier le profil',
      'it': 'Modifica profilo',
      'pl': 'Edytuj profil',
    },
    'otkyxdid': {
      'en': 'Share profile',
      'de': 'Profil teilen',
      'es': 'Compartir perfil',
      'fr': 'Partager le profil',
      'it': 'Condividi profilo',
      'pl': 'Udostępnij profil',
    },
    'xtfu75t1': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
    'fj09iyym': {
      'en': 'Shop',
      'de': 'Geschäft',
      'es': 'Tienda',
      'fr': 'Magasin',
      'it': 'Negozio',
      'pl': 'Sklep',
    },
    'qz0cr63e': {
      'en': 'Points',
      'de': 'Punkte',
      'es': 'Puntos',
      'fr': 'Points',
      'it': 'Punti',
      'pl': 'Punkty',
    },
    '8ieioekr': {
      'en': 'Chats',
      'de': 'Chats',
      'es': 'Chats',
      'fr': 'Chats',
      'it': 'Chat',
      'pl': 'Czaty',
    },
    '2qwj6rc6': {
      'en': 'Profile',
      'de': 'Profil',
      'es': 'Perfil',
      'fr': 'Profil',
      'it': 'Profilo',
      'pl': 'Profil',
    },
    '425ymvz4': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // editProfile
  {
    'vokekuhg': {
      'en': 'Edit profile',
      'de': 'Profil bearbeiten',
      'es': 'Editar perfil',
      'fr': 'Modifier le profil',
      'it': 'Modifica profilo',
      'pl': 'Edytuj profil',
    },
    'vz2xki7j': {
      'en': 'Edit photo',
      'de': 'Foto bearbeiten',
      'es': 'Editar foto',
      'fr': 'Éditer la photo',
      'it': 'Modifica foto',
      'pl': 'Edytuj zdjęcie',
    },
    'fhe261vq': {
      'en': 'About',
      'de': 'Über',
      'es': 'Acerca de',
      'fr': 'À propos de',
      'it': 'Informazioni',
      'pl': 'O tobie',
    },
    'zk0dn80t': {
      'en': 'Name',
      'de': 'Name',
      'es': 'Nombre',
      'fr': 'Nom',
      'it': 'Nome',
      'pl': 'Nazwa',
    },
    'fu87ehnt': {
      'en': 'Username',
      'de': 'Benutzername',
      'es': 'Nombre de usuario',
      'fr': 'Nom d\'utilisateur',
      'it': 'Nome utente',
      'pl': 'Nazwa użytkownika',
    },
    'nq9dtlmc': {
      'en': 'Bio',
      'de': 'Bio',
      'es': 'Bio',
      'fr': 'Bio',
      'it': 'Bio',
      'pl': 'Bio',
    },
    'qov9zqp5': {
      'en': 'Link',
      'de': 'Link',
      'es': 'Enlace',
      'fr': 'Lien',
      'it': 'Link',
      'pl': 'Link',
    },
    'xp2qsmrv': {
      'en': 'Check for updates',
      'de': 'Auf Updates prüfen',
      'es': 'Buscar actualizaciones',
      'fr': 'Vérifier les mises à jour',
      'it': 'Controlla gli aggiornamenti',
      'pl': 'Sprawdź aktualizacje',
    },
    'ttwyz16k': {
      'en': 'Switch to professional account',
      'de': 'Wechseln Sie zum professionellen Konto',
      'es': 'Cambiar a cuenta profesional',
      'fr': 'Passer au compte professionnel',
      'it': 'Passa all\'account professionale',
      'pl': 'Przejdź na konto profesjonalne',
    },
    '4c6tikub': {
      'en': 'Delete account',
      'de': 'Konto löschen',
      'es': 'Borrar cuenta',
      'fr': 'Supprimer le compte',
      'it': 'Elimina account',
      'pl': 'Usuń konto',
    },
    'wxidxmdw': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // editUsername
  {
    'z1ypw3rf': {
      'en': 'Username',
      'de': 'Benutzername',
      'es': 'Nombre de usuario',
      'fr': 'Nom d\'utilisateur',
      'it': 'Nome utente',
      'pl': 'Nazwa użytkownika',
    },
    'hy0z6vnj': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'eszvp0kd': {
      'en': 'This username isn\'t available. Please try another one.',
      'de':
          'Dieser Benutzername ist nicht verfügbar. Bitte versuchen Sie es mit einem anderen.',
      'es':
          'Este nombre de usuario no está disponible. Por favor, prueba otro.',
      'fr':
          'Ce nom d\'utilisateur n\'est pas disponible. Veuillez en essayer un autre.',
      'it':
          'Questo nome utente non è disponibile. Si prega di provarne un altro.',
      'pl': 'Ta nazwa użytkownika jest niedostępna. Proszę spróbować innej.',
    },
    '4vidn899': {
      'en': 'This field is required',
      'de': 'Dieses Feld ist erforderlich.',
      'es': 'Este campo es obligatorio.',
      'fr': 'Ce champ est obligatoire.',
      'it': 'Questo campo è obbligatorio.',
      'pl': 'To pole jest wymagane.',
    },
    '74ohjpla': {
      'en': 'Please choose an option from the dropdown',
      'de': 'Bitte wählen Sie eine Option aus dem Dropdown-Menü aus.',
      'es': 'Por favor, elija una opción del menú desplegable.',
      'fr': 'Veuillez choisir une option dans la liste déroulante.',
      'it': 'Scegliere un\'opzione dal menu a discesa.',
      'pl': 'Proszę wybrać opcję z rozwijanego menu.',
    },
    '7hu3dz7s': {
      'en':
          'Create a username that will help people find you. For example, use your name or nickname.',
      'de':
          'Erstellen Sie einen Benutzernamen, der Menschen dabei hilft, Sie zu finden. Verwenden Sie beispielsweise Ihren Namen oder Spitznamen.',
      'es':
          'Crea un nombre de usuario que ayude a las personas a encontrarte. Por ejemplo, utiliza tu nombre o apodo.',
      'fr':
          'Créez un nom d\'utilisateur qui aidera les gens à vous trouver. Par exemple, utilisez votre nom ou surnom.',
      'it':
          'Crea un nome utente che aiuti le persone a trovarti. Ad esempio, utilizza il tuo nome o soprannome.',
      'pl':
          'Stwórz nazwę użytkownika, która pomoże ludziom cię znaleźć. Na przykład, użyj swojego imienia lub pseudonimu.',
    },
    'ou4nrlj4': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    'h5n4vuo3': {
      'en': 'Username',
      'de': 'Benutzername',
      'es': 'Nombre de usuario',
      'fr': 'Nom d\'utilisateur',
      'it': 'Nome utente',
      'pl': 'Nazwa użytkownika',
    },
    '4zxxrclw': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // editBio
  {
    'qkw9cava': {
      'en': 'Bio',
      'de': 'Bio',
      'es': 'Bio',
      'fr': 'Bio',
      'it': 'Bio',
      'pl': 'Bio',
    },
    '53qm721u': {
      'en':
          'Write a short and engaging bio that tells more about you. Mention your passions, hobbies or profession. Allow people with similar interests to find you!',
      'de':
          'Schreiben Sie eine kurze und ansprechende Biografie, die mehr über Sie verrät. Erwähnen Sie Ihre Leidenschaften, Hobbys oder Beruf. Ermöglichen Sie Menschen mit ähnlichen Interessen, Sie zu finden!',
      'es':
          'Escribe una breve y atractiva biografía que cuente más sobre ti. Menciona tus pasiones, hobbies o profesión. ¡Permite que personas con intereses similares te encuentren!',
      'fr':
          'Rédigez une brève et engageante biographie qui en dit plus sur vous. Mentionnez vos passions, loisirs ou profession. Permettez aux personnes ayant des intérêts similaires de vous trouver !',
      'it':
          'Scrivi una breve e coinvolgente biografia che racconti di più su di te. Menziona le tue passioni, hobby o professione. Permetti alle persone con interessi simili di trovarti!',
      'pl':
          'Napisz krótką i angażującą biografię, która opowie więcej o Tobie. Wspomnij o swoich pasjach, zainteresowaniach lub zawodzie. Pozwól osobom o podobnych zainteresowaniach znaleźć Cię!',
    },
    'dvhakram': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    '1y88qx2e': {
      'en': 'Bio',
      'de': 'Bio',
      'es': 'Bio',
      'fr': 'Bio',
      'it': 'Bio',
      'pl': 'Bio',
    },
    'ilo7ld1y': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // editLink
  {
    'biu3cezg': {
      'en': 'Link',
      'de': 'Link',
      'es': 'Link',
      'fr': 'Link',
      'it': 'Link',
      'pl': 'Link',
    },
    'cfbttzo9': {
      'en': 'Add a link to your profile.',
      'de': 'Füge einen Link zu deinem Profil hinzu.',
      'es': 'Agrega un enlace a tu perfil.',
      'fr': 'Ajoutez un lien vers votre profil.',
      'it': 'Aggiungi un link al tuo profilo.',
      'pl': 'Dodaj link do swojego profilu.',
    },
    'clqqc682': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Terminé',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    '9k0ujf96': {
      'en': 'Link',
      'de': 'Link',
      'es': 'Link',
      'fr': 'Link',
      'it': 'Link',
      'pl': 'Link',
    },
    'e0tp4ona': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // aboutThisAccount
  {
    '2t3he8jf': {
      'en': 'About this account',
      'de': 'Über dieses Konto',
      'es': 'Acerca de esta cuenta',
      'fr': 'À propos de ce compte',
      'it': 'Informazioni su questo account',
      'pl': 'O tym koncie',
    },
    '1sbugbcz': {
      'en':
          'To help our community connect with authentic people we\'re showing information about accounts on Beneree. ',
      'de':
          'Um unserer Gemeinschaft zu helfen, authentische Menschen zu verbinden, zeigen wir Informationen über Beneree-Konten an.',
      'es':
          'Para ayudar a nuestra comunidad a conectarse con personas auténticas, mostramos información sobre las cuentas en Beneree.',
      'fr':
          'Pour aider notre communauté à se connecter avec des personnes authentiques, nous affichons des informations sur les comptes Beneree.',
      'it':
          'Per aiutare la nostra comunità a connettersi con persone autentiche, mostriamo informazioni sugli account su Beneree.',
      'pl':
          'Aby pomóc naszej społeczności nawiązywać autentyczne kontakty, prezentujemy informacje o kontach na Beneree.',
    },
    'brjgtzs8': {
      'en': 'Joined ',
      'de': 'Beigetreten ',
      'es': 'Se unió ',
      'fr': 'Rejoint ',
      'it': 'Iscritto ',
      'pl': 'Dołączył(a) ',
    },
    'rqfjz5nl': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'HomeHome',
    },
  },
  // newOnboarding2_dateofbirth
  {
    'teiwgjo6': {
      'en': 'What\'s your date of birth',
      'de': 'Fügen Sie Ihr Geburtsdatum hinzu',
      'es': 'Agrega tu fecha de nacimiento',
      'fr': 'Ajoutez votre date de naissance',
      'it': 'Aggiungi la tua data di nascita',
      'pl': 'Dodaj swoją datę urodzenia',
    },
    '8yzq3jp8': {
      'en': 'This won\'t be a part of your public profile.',
      'de': 'Dies wird nicht Teil Ihres öffentlichen Profils sein.',
      'es': 'Esto no formará parte de tu perfil público.',
      'fr': 'Ceci ne fera pas partie de votre profil public.',
      'it': 'Questo non farà parte del tuo profilo pubblico.',
      'pl': 'To nie będzie częścią twojego publicznego profilu.',
    },
    '438dhax8': {
      'en': 'Why do I need to provide my date of birth?',
      'de': 'Warum muss ich mein Geburtsdatum angeben?',
      'es': '¿Por qué necesito proporcionar mi fecha de nacimiento?',
      'fr': 'Pourquoi dois-je fournir ma date de naissance ?',
      'it': 'Perché devo fornire la mia data di nascita?',
      'pl': 'Dlaczego muszę podać swoją datę urodzenia?',
    },
    'xo8jrtnc': {
      'en': 'Continue',
      'de': 'Weiter',
      'es': 'Continuar',
      'fr': 'Continuer',
      'it': 'Continua',
      'pl': 'Kontynuuj',
    },
    '657rzp8s': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // username
  {
    'w56xg43g': {
      'en': 'Create a username',
      'de': 'Erstellen Sie einen Benutzernamen',
      'es': 'Crea un nombre de usuario',
      'fr': 'Créez un nom d\'utilisateur',
      'it': 'Crea un nome utente',
      'pl': 'Utwórz nazwę użytkownika',
    },
    'fkkk1j99': {
      'en': 'Add a username for your new profile. You cannot change it later.',
      'de':
          'Fügen Sie einen Benutzernamen für Ihr neues Profil hinzu. Sie können ihn später nicht ändern.',
      'es':
          'Agrega un nombre de usuario para tu nuevo perfil. No podrás cambiarlo más adelante.',
      'fr':
          'Ajoutez un nom d\'utilisateur pour votre nouveau profil. Vous ne pourrez pas le changer plus tard.',
      'it':
          'Aggiungi un nome utente per il tuo nuovo profilo. Non potrai cambiarlo in seguito.',
      'pl':
          'Dodaj nazwę użytkownika dla swojego nowego profilu. Nie będziesz mógł jej później zmienić.',
    },
    '2nwa6ve3': {
      'en': 'Username',
      'de': 'Benutzername',
      'es': 'Nombre de usuario',
      'fr': 'Nom d\'utilisateur',
      'it': 'Nome utente',
      'pl': 'Nazwa użytkownika',
    },
    'hh5a4aqt': {
      'en': 'This username isn\'t available. Please try another one.',
      'de':
          'Dieser Benutzername ist nicht verfügbar. Bitte versuchen Sie es mit einem anderen.',
      'es':
          'Este nombre de usuario no está disponible. Por favor, intenta con otro.',
      'fr':
          'Ce nom d\'utilisateur n\'est pas disponible. Veuillez en essayer un autre.',
      'it': 'Questo nome utente non è disponibile. Prova con un altro.',
      'pl': 'Ta nazwa użytkownika jest niedostępna. Proszę spróbuj innej.',
    },
    'yjtrsfpg': {
      'en': 'Continue',
      'de': 'Weiter',
      'es': 'Continuar',
      'fr': 'Continuer',
      'it': 'Continua',
      'pl': 'Kontynuuj',
    },
    'dsiz4zfi': {
      'en': 'Username required',
      'de': 'Benutzername erforderlich',
      'es': 'Nombre de usuario requerido',
      'fr': 'Nom d\'utilisateur requis',
      'it': 'Nome utente obbligatorio',
      'pl': 'Nazwa użytkownika jest wymagana',
    },
    'put7deon': {
      'en': 'Please choose an option from the dropdown',
      'de': 'Bitte wählen Sie eine Option aus dem Dropdown-Menü',
      'es': 'Por favor, elige una opción del menú desplegable',
      'fr': 'Veuillez choisir une option dans la liste déroulante',
      'it': 'Per favore, scegli un\'opzione dal menu a tendina',
      'pl': 'Proszę wybrać opcję z rozwijanej listy',
    },
    'mi52q4ll': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // email
  {
    'zeqa4dcy': {
      'en': 'What\'s your email',
      'de': 'wie ist deine E-Mailadresse',
      'es': 'Cuál es tu correo electrónico',
      'fr': 'Quel est ton e-mail',
      'it': 'Qual è la tua email',
      'pl': 'Jaki jest Twój adres e-mail',
    },
    'v9o8u7gk': {
      'en':
          'We\'ll notify you about important changes, new features, benefits and other updates.',
      'de':
          'Wir werden dich über wichtige Änderungen, neue Funktionen, Vorteile und andere wichtige Aktualisierungen benachrichtigen.',
      'es':
          'Te notificaremos acerca de cambios importantes, nuevas características, beneficios y otras actualizaciones importantes.',
      'fr':
          'Nous vous informerons des changements importants, des nouvelles fonctionnalités, des avantages et d\'autres mises à jour importantes.',
      'it':
          'We\'ll notify you about important changes, new features, benefits and other important updates.',
      'pl':
          'Powiadomimy cię o ważnych zmianach, nowych funkcjach, korzyściach i innych istotnych aktualizacjach.',
    },
    'n9nalr6s': {
      'en': 'Email',
      'de': 'Email',
      'es': 'Email',
      'fr': 'Email',
      'it': 'Email',
      'pl': 'Email',
    },
    '264n329m': {
      'en': 'Field is required',
      'de': 'Dieses Feld ist erforderlich',
      'es': 'Este campo es obligatorio',
      'fr': 'Ce champ est requis',
      'it': 'Questo campo è obbligatorio',
      'pl': 'To pole jest wymagane',
    },
    'tnvudjia': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'twohvx9p': {
      'en': 'Please choose an option from the dropdown',
      'de': 'Bitte wählen Sie eine Option aus der Dropdown-Liste aus',
      'es': 'Por favor elija una opción del menú desplegable',
      'fr': 'Veuillez choisir une option dans la liste déroulante',
      'it': 'Scegli un\'opzione dal menu a discesa',
      'pl': 'Wybierz opcję z menu rozwijanego',
    },
    'rp2ozcjq': {
      'en': 'Continue',
      'de': 'Weiter',
      'es': 'Continuar',
      'fr': 'Continuer',
      'it': 'Continua',
      'pl': 'Kontynuuj',
    },
    'kmlcy3xe': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // userLogin
  {
    'c1902lr8': {
      'en': 'Welcome back!',
      'de': 'Willkommen zurück!',
      'es': '¡Bienvenido de nuevo!',
      'fr': 'Bienvenue de retour !',
      'it': 'Bentornato/a!',
      'pl': 'Witaj ponownie!',
    },
    '3h7nzg1y': {
      'en': 'We\'re excited to see you again. Please log in.',
      'de': 'Wir freuen uns, dich wiederzusehen. Bitte melde dich an.',
      'es': 'Estamos emocionados de verte de nuevo. Por favor, inicia sesión.',
      'fr': 'Nous sommes ravis de vous revoir. Veuillez vous connecter.',
      'it': 'Siamo entusiasti di rivederti. Per favore, accedi.',
      'pl': 'Cieszymy się, że cię widzimy ponownie. Proszę zaloguj się.',
    },
    '7i9aj5lx': {
      'en': 'Email',
      'de': 'Email',
      'es': 'Email',
      'fr': 'Email',
      'it': 'Email',
      'pl': 'Email',
    },
    '6bsofqv6': {
      'en': 'marcus@email.com',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    '1h89f7lv': {
      'en': 'Password',
      'de': 'Passwort',
      'es': 'Contraseña',
      'fr': 'Mot de passe',
      'it': 'Password',
      'pl': 'Hasło',
    },
    'eip82gmu': {
      'en': 'qwertyuiop',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'ahndj6kv': {
      'en': 'Password',
      'de': 'Passwort',
      'es': 'Contraseña',
      'fr': 'Mot de passe',
      'it': 'Password',
      'pl': 'Hasło',
    },
    'osjvciaz': {
      'en': 'qwertyuiop',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'qknzzo8g': {
      'en': 'Forgot your password?',
      'de': 'Passwort vergessen?',
      'es': '¿Olvidaste tu contraseña?',
      'fr': 'Vous avez oublié votre mot de passe ?',
      'it': 'Hai dimenticato la password?',
      'pl': 'Zapomniałeś hasła?',
    },
    'tc5cat4p': {
      'en': 'Field is required',
      'de': 'Feld ist erforderlich',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
      'it': 'Il campo è obbligatiorio',
      'pl': 'To pole jest wymagane',
    },
    '7wpgychq': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'vqk2b6b5': {
      'en': 'Please choose an option from the dropdown',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    '4wycln3h': {
      'en': 'Field is required',
      'de': 'Feld ist erforderlich',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
      'it': 'Il campo è obbligatiorio',
      'pl': 'To pole jest wymagane',
    },
    'finf3drb': {
      'en': 'Please choose an option from the dropdown',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'irpy0ikb': {
      'en': 'Sign Up',
      'de': 'Einloggen',
      'es': 'Iniciar sesión',
      'fr': 'Se connecter.',
      'it': 'Accedi',
      'pl': 'Zaloguj się',
    },
    'rnbmpojl': {
      'en': 'Log in with phone number',
      'de': 'Melden Sie sich mit der Telefonnummer an',
      'es': 'Iniciar sesión con número de teléfono',
      'fr': 'Connectez-vous avec votre numéro de téléphone',
      'it': 'Accedi con il numero di telefono',
      'pl': 'Zaloguj się numerem telefonu',
    },
    '55w9ibaj': {
      'en': 'Log in with Google',
      'de': 'Einloggen',
      'es': 'Iniciar sesión',
      'fr': 'Se connecter.',
      'it': 'Accedi',
      'pl': 'Zaloguj się',
    },
    'rfbu77gu': {
      'en': 'Don\'t have an account?',
      'de': 'Du hast kein Konto?',
      'es': '¿No tienes una cuenta?',
      'fr': 'Vous n\'avez pas de compte ?',
      'it': 'Non hai un account?',
      'pl': 'Nie masz konta?',
    },
    'rgva5qjo': {
      'en': 'Sign Up',
      'de': 'Registrieren',
      'es': 'Regístrate',
      'fr': 'S\'inscrire',
      'it': 'Registrati',
      'pl': 'Zarejestruj się',
    },
    'khfcddjj': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // newOnboarding3_signup
  {
    '05mp8tu9': {
      'en': 'Hi there!',
      'de': 'Hallo!',
      'es': '¡Hola!',
      'fr': 'Salut !',
      'it': 'Ciao!',
      'pl': 'Cześć!',
    },
    '1taxpl8e': {
      'en': 'Please enter your phone number.',
      'de': 'Geben Sie Ihre Telefonnummer ein.',
      'es': 'Introduce tu número de teléfono.',
      'fr': 'Entrez votre numéro de téléphone.',
      'it': 'Inserisci il tuo numero di telefono.',
      'pl': 'Podaj swój numer telefonu.',
    },
    '6c9oykcc': {
      'en': 'Phone number',
      'de': 'Telefonnummer',
      'es': 'Número de teléfono',
      'fr': 'Numéro de téléphone',
      'it': 'Numero di telefono',
      'pl': 'Numer telefonu',
    },
    'rakecctq': {
      'en': 'Phone number is required.',
      'de': 'Die Telefonnummer ist erforderlich.',
      'es': 'Se requiere un número de teléfono.',
      'fr': 'Le numéro de téléphone est requis.',
      'it': 'Il numero di telefono è obbligatorio.',
      'pl': 'Numer telefonu jest wymagany.',
    },
    '8qfeuhmu': {
      'en': 'Please choose an option from the dropdown',
      'de': 'Bitte wählen Sie eine Option aus dem Dropdown-Menü.',
      'es': 'Por favor, elige una opción del menú desplegable.',
      'fr': 'Veuillez choisir une option dans la liste déroulante.',
      'it': 'Per favore, scegli un\'opzione dal menu a tendina.',
      'pl': 'Proszę wybrać opcję z rozwijanej listy.',
    },
    '0mpc37vt': {
      'en': 'Continue',
      'de': 'Weiter',
      'es': 'Continuar',
      'fr': 'Continuer',
      'it': 'Continua',
      'pl': 'Kontynuuj',
    },
    '6vt1ozde': {
      'en': 'You will receive a verification code to this number.',
      'de': 'Sie erhalten einen Bestätigungscode auf diese Nummer.',
      'es': 'Recibirás un código de verificación en este número.',
      'fr': 'Vous recevrez un code de vérification sur ce numéro.',
      'it': 'Riceverai un codice di verifica a questo numero.',
      'pl': 'Otrzymasz kod weryfikacyjny na ten numer.',
    },
    'nvh68ayg': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // newOnboarding4_verificationCode
  {
    's3jpb0dt': {
      'en': 'Verification code',
      'de': 'Bestätigungscode',
      'es': 'Código de verificación',
      'fr': 'Code de vérification',
      'it': 'Codice di verifica',
      'pl': 'Kod weryfikacyjny',
    },
    'qwrza07h': {
      'en': 'Please enter the code we\'ve sent to ',
      'de': 'Bitte gib den Code ein, den wir gesendet haben ',
      'es': 'Por favor, ingresa el código que hemos enviado a ',
      'fr': 'Veuillez entrer le code que nous avons envoyé au ',
      'it': 'Inserisci il codice che abbiamo inviato a ',
      'pl': 'Proszę wprowadzić kod, który wysłaliśmy na numer ',
    },
    '449nfq9d': {
      'en': 'Verify',
      'de': 'Weiter',
      'es': 'Continuar',
      'fr': 'Continuer',
      'it': 'Continua',
      'pl': 'Kontynuuj',
    },
    'gr3zufrf': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // addProduct
  {
    'ylgulr29': {
      'en': 'Product name',
      'de': 'Produktname',
      'es': 'Nombre del producto',
      'fr': 'Nom du produit',
      'it': 'Nome del prodotto',
      'pl': 'Nazwa produktu',
    },
    'zckkr7s0': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'c0qjgfad': {
      'en': 'Product description',
      'de': 'Produktbeschreibung',
      'es': 'Descripción del producto',
      'fr': 'Description du produit',
      'it': 'Descrizione del prodotto',
      'pl': 'Opis produktu',
    },
    'xwn4ea1d': {
      'en': 'Price',
      'de': 'Preis',
      'es': 'Precio',
      'fr': 'Prix',
      'it': 'Prezzo',
      'pl': 'Cena',
    },
    'eizz4moy': {
      'en': '1.20',
      'de': '1.20',
      'es': '1.20',
      'fr': '1.20',
      'it': '1.20',
      'pl': '1.20',
    },
    'bqfj1h9m': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Fait',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    'goknl7ia': {
      'en': 'Add product',
      'de': 'Produkt hinzufügen',
      'es': 'Agregar producto',
      'fr': 'Ajouter un produit',
      'it': 'Aggiungi prodotto',
      'pl': 'Dodaj produkt',
    },
    'hd758773': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // accountRrestricted
  {
    'zizko14p': {
      'en': 'Account Suspended',
      'de': 'Konto gesperrt',
      'es': 'Cuenta suspendida',
      'fr': 'Compte suspendu',
      'it': 'Account sospeso',
      'pl': 'Konto zawieszone',
    },
    'fzjr5mbd': {
      'en':
          'Your account has been suspended for violating Beneree\'s Terms of Use, Privacy Policy, and Community Standards. You have 30 days to dispute this suspension. If you disagree with our decision, please contact us via email at ',
      'de':
          'Ihr Konto wurde wegen Verstoßes gegen die Nutzungsbedingungen, Datenschutzrichtlinien und Gemeinschaftsstandards von Beneree gesperrt. Sie haben 30 Tage Zeit, um gegen diese Aussetzung Einspruch einzulegen. Wenn Sie mit unserer Entscheidung nicht einverstanden sind, kontaktieren Sie uns bitte per E-Mail unter ',
      'es':
          'Su cuenta ha sido suspendida por violar los Términos de uso, la Política de privacidad y las Normas comunitarias de Beneree. Tienes 30 días para disputar esta suspensión. Si no está de acuerdo con nuestra decisión, contáctenos por correo electrónico a ',
      'fr':
          'Votre compte a été suspendu pour violation des conditions d\'utilisation, de la politique de confidentialité et des standards de la communauté de Beneree. Vous disposez de 30 jours pour contester cette suspension. Si vous n\'êtes pas d\'accord avec notre décision, veuillez nous contacter par e-mail à ',
      'it':
          'Il tuo account è stato sospeso per aver violato i Termini di utilizzo, l\'Informativa sulla privacy e gli Standard della community di Beneree. Hai 30 giorni per contestare questa sospensione. Se non sei d\'accordo con la nostra decisione, ti preghiamo di contattarci via e-mail all\'indirizzo ',
      'pl':
          'Twoje konto zostało zawieszone z powodu naruszenia Warunków użytkowania, Polityki prywatności i Standardów społeczności Beneree. Masz 30 dni na zakwestionowanie zawieszenia. Jeśli nie zgadzasz się z naszą decyzją, skontaktuj się z nami za pośrednictwem poczty elektronicznej pod adresem ',
    },
    'a8mdy6c5': {
      'en': 'hi@beneree.com. ',
      'de': 'hi@beneree.com. ',
      'es': 'hi@beneree.com. ',
      'fr': 'hi@beneree.com. ',
      'it': 'hi@beneree.com. ',
      'pl': 'hi@beneree.com. ',
    },
    '5gwpfetp': {
      'en': 'Log out',
      'de': 'Ausloggen',
      'es': 'Cerrar sesión',
      'fr': 'Se déconnecter',
      'it': 'Disconnettersi',
      'pl': 'Wyloguj',
    },
    'a8xcypjj': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // ChatGPT
  {
    'j6gj9efj': {
      'en': 'Luminary',
      'de': 'Luminary',
      'es': 'Luminary',
      'fr': 'Luminary',
      'it': 'Luminary',
      'pl': 'Luminary',
    },
    'j2eiw1mg': {
      'en': 'LUMINARY',
      'de': 'LUMINARY',
      'es': 'LUMINARY',
      'fr': 'LUMINARY',
      'it': 'LUMINARY',
      'pl': 'LUMINARY',
    },
    '9bunula4': {
      'en': 'Ask me a question...',
      'de': 'Stellen Sie mir eine Frage...',
      'es': 'Hazme una pregunta...',
      'fr': 'Posez-moi une question...',
      'it': 'Fammi una domanda...',
      'pl': 'Zadaj mi pytanie...',
    },
    'ydfyh88y': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // subscription_ConfirmationBusiness
  {
    '3m3hag3k': {
      'en': 'Congratulations!',
      'de': 'Glückwunsch!',
      'es': '¡Felicidades!',
      'fr': 'Toutes nos félicitations!',
      'it': 'Congratulazioni!',
      'pl': 'Gratulacje!',
    },
    'bqzfdtr8': {
      'en':
          'Congratulations on subscribing to Beneree Pro Business! Our dedicated team will contact you within 24 hours to assist you with setting up your shop section profile.',
      'de':
          'Herzlichen Glückwunsch zur Anmeldung bei Beneree Pro Business! Unser spezialisiertes Team wird sich innerhalb von 24 Stunden bei Ihnen melden, um Ihnen bei der Einrichtung Ihres Shop-Bereichs-Profils zu helfen.',
      'es':
          '¡Enhorabuena por suscribirte a Beneree Pro Business! Nuestro equipo especializado se pondrá en contacto contigo en un plazo de 24 horas para ayudarte a configurar el perfil de tu sección de tienda.',
      'fr':
          'Félicitations pour votre abonnement à Beneree Pro Business ! Notre équipe dévouée vous contactera dans les 24 heures pour vous assister dans la configuration de votre profil de la section boutique.',
      'it':
          'Congratulazioni per esserti iscritto a Beneree Pro Business! Il nostro team dedicato si metterà in contatto con te entro 24 ore per assisterti nella configurazione del profilo della sezione negozio.',
      'pl':
          'Gratulacje z powodu zapisania się do Beneree Pro Business! Nasz oddany zespół skontaktuje się z Tobą w ciągu 24 godzin, aby pomóc Ci w konfiguracji profilu sekcji sklepu.',
    },
    'ctzmxv9i': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Fait',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    'qrkjd7ov': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // subscription_Confirmation
  {
    'fp1ztd3l': {
      'en': 'Congratulations!',
      'de': 'Glückwunsch!',
      'es': '¡Felicidades!',
      'fr': 'Toutes nos félicitations!',
      'it': 'Congratulazioni!',
      'pl': 'Gratulacje!',
    },
    'fduvq0wg': {
      'en':
          'You\'ve successfully subscribed to Beneree Pro, and you can now enjoy the full potential of the app!',
      'de':
          'Sie haben sich erfolgreich für Beneree Pro angemeldet und können jetzt das volle Potenzial der App nutzen!',
      'es':
          'Te has suscrito con éxito a Beneree Pro, ¡y ahora puedes disfrutar plenamente del potencial de la aplicación!',
      'fr':
          'Vous vous êtes abonné avec succès à Beneree Pro, et vous pouvez désormais profiter pleinement du potentiel de l\'application !',
      'it':
          'Hai sottoscritto con successo Beneree Pro, e ora puoi godere appieno del potenziale dell\'app!',
      'pl':
          'Z powodzeniem zasubskrybowałeś Beneree Pro i teraz możesz cieszyć się pełnym potencjałem aplikacji!',
    },
    'magdow7b': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Fait',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    'of4ssjo3': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // forgotPassword
  {
    '0gpz0mcu': {
      'en': 'Reset password',
      'de': 'Passwort zurücksetzen',
      'es': 'Restablecer contraseña',
      'fr': 'Réinitialiser le mot de passe',
      'it': 'Reimposta la password',
      'pl': 'Zresetuj hasło',
    },
    'a2xrbdy7': {
      'en': 'Enter your email address.',
      'de': 'Geben Sie Ihre E-Mail-Adresse ein.',
      'es': 'Ingresa tu dirección de correo electrónico.',
      'fr': 'Entrez votre adresse e-mail.',
      'it': 'Inserisci il tuo indirizzo email.',
      'pl': 'Wprowadź swój adres e-mail.',
    },
    'c2r1vt1t': {
      'en': 'Email',
      'de': 'Email',
      'es': 'Email',
      'fr': 'Email',
      'it': 'Email',
      'pl': 'Email',
    },
    'ouxntteh': {
      'en': 'Field is required',
      'de': 'Dieses Feld ist erforderlich.',
      'es': 'Este campo es obligatorio.',
      'fr': 'Ce champ est obligatoire.',
      'it': 'Questo campo è obbligatorio.',
      'pl': 'To pole jest wymagane.',
    },
    'a9jauo2a': {
      'en': 'Please choose an option from the dropdown',
      'de': 'Bitte wählen Sie eine Option aus dem Dropdown-Menü.',
      'es': 'Por favor, elige una opción del menú desplegable.',
      'fr': 'Veuillez choisir une option dans la liste déroulante.',
      'it': 'Scegli un\'opzione dal menu a tendina.',
      'pl': 'Proszę wybrać opcję z rozwijanej listy.',
    },
    'e5t3shi5': {
      'en': 'Continue',
      'de': 'Weiter',
      'es': 'Continuar',
      'fr': 'Continuer',
      'it': 'Continua',
      'pl': 'Kontynuuj',
    },
    'yvugd00n': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // update
  {
    'v2ubjndy': {
      'en': 'Beneree',
      'de': 'Beneree',
      'es': 'Beneree',
      'fr': 'Beneree',
      'it': 'Beneree',
      'pl': 'Beneree',
    },
    'vnifsgce': {
      'en': 'UPDATE',
      'de': 'AKTUALISIEREN',
      'es': 'ACTUALIZAR',
      'fr': 'MISE À JOUR',
      'it': 'AGGIORNAMENTO',
      'pl': 'AKTUALIZUJ',
    },
    '8w23445v': {
      'en': 'UPDATE',
      'de': 'AKTUALISIEREN',
      'es': 'ACTUALIZAR',
      'fr': 'MISE À JOUR',
      'it': 'AGGIORNAMENTO',
      'pl': 'AKTUALIZUJ',
    },
    '4o1g6a4j': {
      'en': 'What\'s New',
      'de': 'Was ist neu',
      'es': 'Qué hay de nuevo',
      'fr': 'Quoi de neuf',
      'it': 'Cosa c\'è di nuovo',
      'pl': 'Co nowego',
    },
    '5lsv3z3d': {
      'en': 'Developer',
      'de': 'Entwickler',
      'es': 'Desarrollador',
      'fr': 'Développeur',
      'it': 'Sviluppatore',
      'pl': 'Deweloper',
    },
    'lqqg9e6y': {
      'en': 'Visit website',
      'de': 'Besuche die Website',
      'es': 'Visita el sitio web',
      'fr': 'Visitez le site Web',
      'it': 'Visita il sito web',
      'pl': 'Odwiedź stronę',
    },
    '6cmhln8k': {
      'en':
          'Download the latest update to benefit from these enhancements. As always, your feedback is incredibly valuable to us. Thank you for being part of our community! 🌟',
      'de':
          'Lade das neueste Update herunter, um von diesen Verbesserungen zu profitieren. Wie immer sind deine Rückmeldungen unglaublich wertvoll für uns. Vielen Dank, dass du Teil unserer Gemeinschaft bist! 🌟',
      'es':
          'Descarga la última actualización para beneficiarte de estas mejoras. Como siempre, tu opinión es increíblemente valiosa para nosotros. ¡Gracias por ser parte de nuestra comunidad! 🌟',
      'fr':
          'Téléchargez la dernière mise à jour pour profiter de ces améliorations. Comme toujours, vos commentaires sont incroyablement précieux pour nous. Merci de faire partie de notre communauté ! 🌟',
      'it':
          'Scarica l\'ultima aggiornamento per beneficiare di queste migliorie. Come sempre, il tuo feedback è incredibilmente prezioso per noi. Grazie per far parte della nostra comunità! 🌟',
      'pl':
          'Pobierz najnowszą aktualizację, aby skorzystać z tych ulepszeń. Jak zawsze, Twoja opinia jest dla nas niezwykle cenna. Dziękujemy, że jesteś częścią naszej społeczności! 🌟',
    },
    'av3ckloo': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // editPost
  {
    'e6bd4v12': {
      'en': 'Share',
      'de': 'Teilen',
      'es': 'Compartir',
      'fr': 'Partager',
      'it': 'Condividi',
      'pl': 'Udostępnij',
    },
    'g0jy9ros': {
      'en': 'Edit post',
      'de': 'Beitrag bearbeiten',
      'es': 'Editar post',
      'fr': 'Modifier le message',
      'it': 'Modifica post',
      'pl': 'Edytuj post',
    },
    'h2jbybns': {
      'en': 'Write a caption...',
      'de': 'Schreiben Sie eine Bildunterschrift...',
      'es': 'Escribe una leyenda...',
      'fr': 'Écrivez une légende...',
      'it': 'Scrivi una didascalia...',
      'pl': 'Napisz podpis...',
    },
    'bqk7v3cz': {
      'en': 'Caption required.',
      'de': 'Bildunterschrift erforderlich.',
      'es': 'Leyenda requerida.',
      'fr': 'Légende requise.',
      'it': 'Didascalia obbligatoria.',
      'pl': 'Wymagany podpis.',
    },
    '67i5w6zk': {
      'en': 'Please choose an option from the dropdown',
      'de': 'Bitte wählen Sie eine Option aus dem Dropdown-Menü.',
      'es': 'Por favor, elige una opción del menú desplegable.',
      'fr': 'Veuillez choisir une option dans la liste déroulante.',
      'it': 'Per favore, scegli un\'opzione dal menu a tendina.',
      'pl': 'Proszę wybrać opcję z rozwijanej listy.',
    },
    'icovqzcy': {
      'en': 'Tag other users',
      'de': 'Markiere andere Benutzer',
      'es': 'Etiqueta a otros usuarios',
      'fr': 'Taguer d\'autres utilisateurs',
      'it': 'Tagga altri utenti',
      'pl': 'Otaguj innych użytkowników',
    },
    '404obxo0': {
      'en': 'Add location',
      'de': 'Standort hinzufügen',
      'es': 'Agregar ubicación',
      'fr': 'Ajouter un emplacement',
      'it': 'Aggiungi posizione',
      'pl': 'Dodaj lokalizację',
    },
    '8wprrpfm': {
      'en': 'Rome, IT',
      'de': 'Rome, IT',
      'es': 'Rome, IT',
      'fr': 'Rome, IT',
      'it': 'Rome, IT',
      'pl': 'Rome, IT',
    },
    'rven6mec': {
      'en': 'Berlin, DE',
      'de': 'Berlin, DE',
      'es': 'Berlin, DE',
      'fr': 'Berlin, DE',
      'it': 'Berlin, DE',
      'pl': 'Berlin, DE',
    },
    'jhjnqrwg': {
      'en': 'Warsaw, PL',
      'de': 'Warsaw, PL',
      'es': 'Warsaw, PL',
      'fr': 'Warsaw, PL',
      'it': 'Warsaw, PL',
      'pl': 'Warsaw, PL',
    },
    'tc8js90c': {
      'en': 'Madrid, ES',
      'de': 'Madrid, ES',
      'es': 'Madrid, ES',
      'fr': 'Madrid, ES',
      'it': 'Madrid, ES',
      'pl': 'Madrid, ES',
    },
    'r35yyhcx': {
      'en': 'Paris, FR',
      'de': 'Paris, FR',
      'es': 'Paris, FR',
      'fr': 'Paris, FR',
      'it': 'Paris, FR',
      'pl': 'Paris, FR',
    },
    '0vuf0v39': {
      'en': 'Amsterdam, NL',
      'de': 'Amsterdam, NL',
      'es': 'Amsterdam, NL',
      'fr': 'Amsterdam, NL',
      'it': 'Amsterdam, NL',
      'pl': 'Amsterdam, NL',
    },
    '6tl4gxbb': {
      'en': 'Hide like count',
      'de': 'Anzahl der Likes ausblenden',
      'es': 'Ocultar recuento de Me gusta',
      'fr': 'Masquer le nombre de J\'aime',
      'it': 'Nascondi il conteggio dei Mi piace',
      'pl': 'Ukryj liczbę polubień',
    },
    '500w6f56': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // createMoment
  {
    'jzvn5h4y': {
      'en': 'Share your moment',
      'de': 'Teilen Sie Ihren Moment',
      'es': 'Comparte tu momento',
      'fr': 'Partagez votre instant',
      'it': 'Condividi il tuo momento',
      'pl': 'Podziel się swoją chwilą',
    },
    'er5ceodi': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // momentPage
  {
    'tvqi71j2': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // withdrawalConfirmation
  {
    '54j9e1jo': {
      'en': 'Success!',
      'de': 'Erfolg!',
      'es': '¡Éxito!',
      'fr': 'Succès!',
      'it': 'Successo!',
      'pl': 'Sukces!',
    },
    'gw4zd5ca': {
      'en': 'Your withdrawal request has been successfully placed.',
      'de': 'Ihre Auszahlungsanfrage wurde erfolgreich gestellt.',
      'es': 'Su solicitud de retiro se ha realizado con éxito.',
      'fr': 'Votre demande de retrait a été placée avec succès.',
      'it': 'La tua richiesta di prelievo è stata effettuata con successo.',
      'pl': 'Twoja prośba o wypłatę została pomyślnie złożona.',
    },
    'znjcyvvt': {
      'en': 'Done',
      'de': 'Erledigt',
      'es': 'Hecho',
      'fr': 'Fait',
      'it': 'Fatto',
      'pl': 'Gotowe',
    },
    'm90ij6l2': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // rewardConfirmation
  {
    'ndr4djcs': {
      'en': 'Congratulations!',
      'de': 'Herzlichen Glückwunsch!',
      'es': '¡Felicidades!',
      'fr': 'Félicitations !',
      'it': 'Congratulazioni!',
      'pl': 'Gratulacje!',
    },
    '4vyys90e': {
      'en':
          'You\'ve just earned an extra loyalty point for supporting a local business. Your support makes a big difference. ',
      'de':
          'Sie haben gerade einen zusätzlichen Treuepunkt verdient, indem Sie ein lokales Unternehmen unterstützt haben. Ihre Unterstützung macht einen großen Unterschied.',
      'es':
          'Acabas de ganar un punto adicional de fidelidad por apoyar a un negocio local. Tu apoyo marca una gran diferencia.',
      'fr':
          'Vous venez de gagner un point de fidélité supplémentaire pour avoir soutenu une entreprise locale. Votre soutien fait toute la différence.',
      'it':
          'Hai appena guadagnato un punto fedeltà extra per aver sostenuto un\'attività locale. Il tuo supporto fa la differenza.',
      'pl':
          'Właśnie zdobyłeś(aś) dodatkowy punkt lojalności za wsparcie lokalnego biznesu. Twoje wsparcie ma duże znaczenie.',
    },
    'vve9lp6h': {
      'en': 'Collect Points',
      'de': 'Punkte sammeln',
      'es': 'Recibir Puntos',
      'fr': 'Collecter des Points',
      'it': 'Riscuoti Punti',
      'pl': 'Odbierz Punkty',
    },
    '7oif77mj': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // points
  {
    'x6l26spm': {
      'en': 'Past Transactions',
      'de': 'Punkte',
      'es': 'Puntos',
      'fr': 'Points',
      'it': 'Punti',
      'pl': 'Punkty',
    },
    'axn7nb90': {
      'en': 'PTS',
      'de': 'PTS',
      'es': 'PTS',
      'fr': 'PTS',
      'it': 'PTS',
      'pl': 'PTS',
    },
    '3uxssz24': {
      'en': 'Available ',
      'de': 'Verfügbar ',
      'es': 'Disponible ',
      'fr': 'Disponible ',
      'it': 'Disponibile ',
      'pl': 'Dostępne ',
    },
    '1kog1wyf': {
      'en': 'Transactions',
      'de': 'Transaktionen',
      'es': 'Actas',
      'fr': 'Transactions',
      'it': 'Transazioni',
      'pl': 'Transakcje',
    },
    'be49jo4c': {
      'en': 'Redeem Points',
      'de': 'Punkte Einlösen',
      'es': 'Canjear Puntos',
      'fr': 'Échanger des Points',
      'it': 'Riscatta Punti',
      'pl': 'Wymień punkty',
    },
    '111nzkdu': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // shop
  {
    '60hhi8hq': {
      'en': 'Find Clubs ',
      'de': '5x Punkte',
      'es': '5x Puntos',
      'fr': '5x Points',
      'it': '5x Punti',
      'pl': '5x Punktów',
    },
    'hmqvsqri': {
      'en':
          'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
      'de':
          'Sammeln Sie 5x Punkte für jeden Dollar, den Sie in Schönheitssalons, Friseursalons und anderen Dienstleistern ausgeben.',
      'es':
          'Gane 5 puntos por cada dólar gastado en salones de belleza, barberos y otros proveedores de servicios.',
      'fr':
          'Gagnez 5x points pour chaque dollar dépensé dans les salons de beauté, les barbiers et autres prestataires de services.',
      'it':
          'Guadagna 5 punti per ogni dollaro speso in saloni di bellezza, barbieri e altri fornitori di servizi.',
      'pl':
          'Zdobądź 5x punktów za każdego dolara wydanego w salonach kosmetycznych, fryzjerskich i innych usługodawcach.',
    },
    'kzhru1dm': {
      'en': '3x Points',
      'de': '3x Punkte',
      'es': '3x Puntos',
      'fr': '3x Points',
      'it': '3x Punti',
      'pl': '3x Punktów',
    },
    'vtnqcg3l': {
      'en':
          'Earn 3x points for every dollar spent in grocery stores, coffee shops, restaurants and more.',
      'de':
          'Verdienen Sie 3-fache Punkte für jeden ausgegebenen Dollar in Lebensmittelgeschäften, Cafés, Restaurants und mehr.',
      'es':
          'Gana 3 veces puntos por cada dólar gastado en tiendas de comestibles, cafeterías, restaurantes y más.',
      'fr':
          'Gagnez 3 fois plus de points pour chaque dollar dépensé dans les épiceries, les cafés, les restaurants et plus encore.',
      'it':
          'Guadagna 3 volte i punti per ogni dollaro speso nei negozi di alimentari, caffè, ristoranti e altro ancora.',
      'pl':
          'Zarabiaj 3 razy więcej punktów za każde wydane dolary w sklepach spożywczych, kawiarniach, restauracjach i nie tylko.',
    },
    'b1joq99x': {
      'en': 'Events Near you',
      'de': 'In deiner Nähe',
      'es': 'Cerca de ti',
      'fr': 'À proximité',
      'it': 'Vicino a te',
      'pl': 'W pobliżu',
    },
    'e23neofq': {
      'en': 'See all',
      'de': 'Alles sehen',
      'es': 'Ver todo',
      'fr': 'Voir tout',
      'it': 'Vedi tutto',
      'pl': 'Wyświetl wszystko',
    },
    'cd5u93p1': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
    'kuvpgtkm': {
      'en': 'Events',
      'de': 'Geschäft',
      'es': 'Tienda',
      'fr': 'Boutique',
      'it': 'Negozio',
      'pl': 'Sklep',
    },
    'rjez356q': {
      'en': 'History',
      'de': 'Punkte',
      'es': 'Puntos',
      'fr': 'Points',
      'it': 'Punti',
      'pl': 'Punkty',
    },
    'gv26nf0b': {
      'en': 'Chats',
      'de': 'Chats',
      'es': 'Chats',
      'fr': 'Chats',
      'it': 'Chat',
      'pl': 'Czaty',
    },
    'hlgtn1o3': {
      'en': 'Profile',
      'de': 'Profil',
      'es': 'Perfil',
      'fr': 'Profil',
      'it': 'Profilo',
      'pl': 'Profil',
    },
    'e5733lhp': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // notifications
  {
    '4dgauh4b': {
      'en': 'Notifications',
      'de': 'Benachrichtigungen',
      'es': 'Notificaciones',
      'fr': 'Notifications',
      'it': 'Notifiche',
      'pl': 'Powiadomienia',
    },
    'b9t6s2la': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // shopDetails
  {
    'fd5fj2cw': {
      'en': 'Event Name',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'i7l9k44d': {
      'en': 'Address',
      'de':
          'Verdienen Sie 5-fache Punkte für jeden ausgegebenen Dollar in Schönheitssalons, Friseuren, anderen Dienstleistern und mehr.',
      'es':
          'Gana 5 veces puntos por cada dólar gastado en salones de belleza, peluquerías, otros proveedores de servicios y más.',
      'fr':
          'Gagnez 5 fois plus de points pour chaque dollar dépensé dans les salons de beauté, les barbiers, les autres fournisseurs de services et plus encore.',
      'it':
          'Guadagna 5 volte i punti per ogni dollaro speso in saloni di bellezza, barbieri, altri fornitori di servizi e altro ancora.',
      'pl':
          'Zarabiaj 5 razy więcej punktów za każde wydane dolary w salonach urody, zakładach fryzjerskich, innych dostawcach usług i nie tylko.',
    },
    '3shec64n': {
      'en': 'What you can find here',
      'de': 'Was Sie hier finden können',
      'es': 'Lo que puedes encontrar aquí',
      'fr': 'Ce que vous pouvez trouver ici',
      'it': 'Cosa puoi trovare qui',
      'pl': 'Co znajdziesz tutaj',
    },
    '948lbzop': {
      'en': 'Go',
      'de': 'Geh',
      'es': 'Ir',
      'fr': 'Allez',
      'it': 'Vai',
      'pl': 'Idź',
    },
    'aevlee6e': {
      'en': 'Chat',
      'de': 'Plaudern',
      'es': 'Charlar',
      'fr': 'Chat',
      'it': 'Chiacchierata',
      'pl': 'Czat',
    },
    '61knajga': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // ScanQRCode
  {
    '426wmuf4': {
      'en': 'Press QR Code to scan',
      'de': 'Drücken Sie zum Scannen den QR-Code',
      'es': 'Presione el código QR para escanear',
      'fr': 'Appuyez sur le code QR pour numériser',
      'it': 'Premi il codice QR per scansionare',
      'pl': 'Naciśnij kod QR, aby zeskanować',
    },
    'c3atwzgc': {
      'en': 'Cancel',
      'de': 'Stornieren',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
    '63xioxt2': {
      'en': 'Next',
      'de': 'Nächste',
      'es': 'Próximo',
      'fr': 'Suivant',
      'it': 'Prossimo',
      'pl': 'Dalej',
    },
    '56o48pz7': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // pointsBusiness
  {
    'epa52q1d': {
      'en': 'Transactions',
      'de': 'Transaktionen',
      'es': 'Actas',
      'fr': 'Transactions',
      'it': 'Transazioni',
      'pl': 'Transakcje',
    },
    '97rm7o5r': {
      'en': 'Fees due ',
      'de': 'Fällige Gebühren ',
      'es': 'Tarifas pendientes ',
      'fr': 'Frais dus ',
      'it': 'Tariffe dovute ',
      'pl': 'Opłaty należne ',
    },
    'l3exb24r': {
      'en': 'Transactions',
      'de': 'Transaktionen',
      'es': 'Actas',
      'fr': 'Transactions',
      'it': 'Transazioni',
      'pl': 'Transakcje',
    },
    'k4nxob2b': {
      'en': 'Pay',
      'de': 'Bezahlen',
      'es': 'Pagar',
      'fr': 'Payer',
      'it': 'Paga',
      'pl': 'Zapłać',
    },
    'tc5fwosp': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // welcome
  {
    'ftjhcg1y': {
      'en': 'PTS',
      'de': 'PTS',
      'es': 'PTS',
      'fr': 'PTS',
      'it': 'PTS',
      'pl': 'PTS',
    },
    '9fvizzqe': {
      'en': 'BeneCard™',
      'de': 'BeneCard™',
      'es': 'BeneCard™',
      'fr': 'BeneCard™',
      'it': 'BeneCard™',
      'pl': 'BeneCard™',
    },
    '3opu4qbm': {
      'en': 'Scan BeneCard™',
      'de': 'BeneCard™ scannen',
      'es': 'Escanear BeneCard™',
      'fr': 'Scanner BeneCard™',
      'it': 'Scannerizza BeneCard™',
      'pl': 'Zeskanuj BeneCard™',
    },
    '8kb8j6ju': {
      'en': 'Invite Friends',
      'de': 'Freunde einladen',
      'es': 'Invitar a amigos',
      'fr': 'Inviter des amis',
      'it': 'Invita amici',
      'pl': 'Zaproś przyjaciół',
    },
    'ycic97om': {
      'en': 'Your',
      'de': 'Deine',
      'es': 'Tu',
      'fr': 'Votre',
      'it': 'La Tua',
      'pl': 'Twoja',
    },
    '4cvmap19': {
      'en': 'BeneCard™',
      'de': 'BeneCard™',
      'es': 'BeneCard™',
      'fr': 'BeneCard™',
      'it': 'BeneCard™',
      'pl': 'BeneCard™',
    },
    'jjqtkhdd': {
      'en':
          'Show your BeneCard™ QR Code after your transaction to collect points.',
      'de':
          'Zeige deinen BeneCard™ QR-Code nach deiner Transaktion, um Punkte zu sammeln.',
      'es':
          'Muestra el código QR de tu BeneCard™ después de la transacción para acumular puntos.',
      'fr':
          'Montrez le code QR de votre BeneCard™ après votre transaction pour accumuler des points.',
      'it':
          'Mostra il codice QR della tua BeneCard™ dopo la transazione per accumulare punti.',
      'pl':
          'Pokaż swój kod QR BeneCard™ po dokonaniu transakcji, aby zbierać punkty.',
    },
    'ni6p0m8s': {
      'en': 'Close',
      'de': 'Schließen',
      'es': 'Cerrar',
      'fr': 'Fermer',
      'it': 'Chiudi',
      'pl': 'Zamknij',
    },
    '4acx22x4': {
      'en': 'Your referral code',
      'de': 'Dein Empfehlungscode',
      'es': 'Tu código de referencia',
      'fr': 'Votre code de parrainage',
      'it': 'Il tuo codice di riferimento',
      'pl': 'Twój kod polecający',
    },
    'lcdzce5f': {
      'en': 'All you need to do is:',
      'de': 'Alles, was du tun musst, ist:',
      'es': 'Todo lo que necesitas hacer es:',
      'fr': 'Tout ce que vous avez à faire, c\'est:',
      'it': 'Tutto quello che devi fare è:',
      'pl': 'Wszystko, co musisz zrobić, to:',
    },
    'd8q3is7w': {
      'en': '1. Copy your unique referral code.',
      'de': '1. Kopiere deinen einzigartigen Empfehlungscode.',
      'es': '1. Copia tu código de referencia único.',
      'fr': '1. Copiez votre code de parrainage unique.',
      'it': '1. Copia il tuo codice di riferimento unico.',
      'pl': '1. Skopiuj swój unikalny kod polecający.',
    },
    'uzbwcip7': {
      'en': '2. Share it with friends, family or anyone else, with no limits.',
      'de':
          '2. Teile es mit Freunden, Familie oder jedem anderen, ohne Einschränkungen.',
      'es':
          '2. Compártelo con amigos, familiares o cualquier otra persona, sin límites.',
      'fr':
          '2. Partagez-le avec des amis, de la famille ou n\'importe qui d\'autre, sans limites.',
      'it':
          '2. Condividilo con amici, famiglia o chiunque altro, senza limiti.',
      'pl':
          '2. Podziel się nim z przyjaciółmi, rodziną lub kimkolwiek, bez ograniczeń.',
    },
    'j4cuk7zt': {
      'en':
          '3. When your friends join with your referral code, you instantly earn 10 points.',
      'de':
          '3. Wenn deine Freunde sich mit deinem Empfehlungscode anmelden, verdienst du sofort 10 Punkte.',
      'es':
          '3. Cuando tus amigos se unen con tu código de referencia, ganas instantáneamente 10 puntos.',
      'fr':
          '3. Lorsque vos amis rejoignent avec votre code de parrainage, vous gagnez instantanément 10 points.',
      'it':
          '3. Quando i tuoi amici si uniscono con il tuo codice di riferimento, guadagni immediatamente 10 punti.',
      'pl':
          '3. Kiedy Twoi przyjaciele dołączają za pomocą Twojego kodu polecającego, natychmiast zdobywasz 10 punktów.',
    },
    '5tv7m1f1': {
      'en':
          '4. Every time your friends subscribe to Beneree Pro, you instantly earn 100 points ⏤ this reward continues with each subscription renewal.',
      'de':
          '4. Jedes Mal, wenn deine Freunde Beneree Pro abonnieren, verdienst du sofort 100 Punkte ⏤ diese Belohnung setzt sich bei jeder Abo-Verlängerung fort.',
      'es':
          '4. Cada vez que tus amigos se suscriben a Beneree Pro, ganas instantáneamente 100 puntos ⏤ esta recompensa continúa con cada renovación de la suscripción.',
      'fr':
          '4. Chaque fois que vos amis s\'abonnent à Beneree Pro, vous gagnez instantanément 100 points ⏤ cette récompense continue à chaque renouvellement d\'abonnement.',
      'it':
          '4. Ogni volta che i tuoi amici sottoscrivono Beneree Pro, guadagni immediatamente 100 punti ⏤ questa ricompensa continua con ogni rinnovo dell\'abbonamento.',
      'pl':
          '4. Za każdym razem, gdy Twoi przyjaciele subskrybują Beneree Pro, natychmiast zdobywasz 100 punktów ⏤ ta nagroda kontynuuje się przy każdym odnowieniu subskrypcji.',
    },
    'jqg1dvrw': {
      'en':
          '5. There’s no time to waste. Invite people before someone else does it first.',
      'de':
          '5. Es gibt keine Zeit zu verlieren. Lade Leute ein, bevor es jemand anderes tut.',
      'es':
          '5. No hay tiempo que perder. Invita a las personas antes de que alguien más lo haga primero.',
      'fr':
          '5. Il n\'y a pas de temps à perdre. Invitez les gens avant que quelqu\'un d\'autre ne le fasse en premier.',
      'it':
          '5. Non c\'è tempo da perdere. Invita le persone prima che qualcun altro lo faccia per primo.',
      'pl':
          '5. Nie ma czasu do stracenia. Zaproś ludzi, zanim zrobi to ktoś inny.',
    },
    's1c03t4q': {
      'en': 'Close',
      'de': 'Schließen',
      'es': 'Cerrar',
      'fr': 'Fermer',
      'it': 'Chiudi',
      'pl': 'Zamknij',
    },
    'ia8tqw9m': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // home
  {
    'jf5pofis': {
      'en': 'Hello World',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'h2crwbsb': {
      'en': 'Hello World',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'dtounuzp': {
      'en': 'Hello World',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'istfz5us': {
      'en': 'Hello World',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'nnihkyl7': {
      'en': 'Hello World',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'w2qi8nfh': {
      'en': 'Hello World',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'g13gomh9': {
      'en': 'Hello World',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'vyen7vud': {
      'en': 'Fun',
      'de': 'Explore',
      'es': 'Explore',
      'fr': 'Explore',
      'it': 'Explore',
      'pl': 'Explore',
    },
    'yhjz5pti': {
      'en': 'Near Me',
      'de': 'Near you',
      'es': 'Near you',
      'fr': 'Near you',
      'it': 'Near you',
      'pl': 'Near you',
    },
    'ztglu49u': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
    'b6eh8i1k': {
      'en': 'Events',
      'de': 'Geschäft',
      'es': 'Tienda',
      'fr': 'Magasin',
      'it': 'Negozio',
      'pl': 'Sklep',
    },
    's1fw2t62': {
      'en': 'History',
      'de': 'Punkte',
      'es': 'Puntos',
      'fr': 'Points',
      'it': 'Punti',
      'pl': 'Punkty',
    },
    'ta9kwegb': {
      'en': 'Chats',
      'de': 'Chats',
      'es': 'Chats',
      'fr': 'Chats',
      'it': 'Chat',
      'pl': 'Czaty',
    },
    'wg00bixy': {
      'en': 'Profile',
      'de': 'Profil',
      'es': 'Perfil',
      'fr': 'Profil',
      'it': 'Profilo',
      'pl': 'Profil',
    },
    'q3zbkmx4': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // postVideo
  {
    'duw0qvxa': {
      'en': 'Next',
      'de': 'Nächste',
      'es': 'Próximo',
      'fr': 'Suivant',
      'it': 'Prossimo',
      'pl': 'Dalej',
    },
    'oxfcuwbn': {
      'en': 'Post a video',
      'de': 'Ein Video posten',
      'es': 'Publicar un video',
      'fr': 'Poster une vidéo',
      'it': 'Pubblica un video',
      'pl': 'Dodaj wideo',
    },
    'l63dy3s3': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // postVideoCaption
  {
    '1qoifbb0': {
      'en': 'Share',
      'de': 'Teilen',
      'es': 'Compartir',
      'fr': 'Partager',
      'it': 'Condividi',
      'pl': 'Udostępnij',
    },
    'ao9qioqq': {
      'en': 'Post a video',
      'de': 'in Video posten',
      'es': 'Publicar un video',
      'fr': 'Poster une vidéo',
      'it': 'Pubblica un video',
      'pl': 'Dodaj wideo',
    },
    'hmdqhzu6': {
      'en': 'Cover',
      'de': 'Cover',
      'es': 'Portada',
      'fr': 'Couverture',
      'it': 'Copertina',
      'pl': 'Okładka',
    },
    'jolpkuhy': {
      'en': 'Write a caption...',
      'de': 'Schreibe eine Überschrift...',
      'es': 'Escribir un subtitulo...',
      'fr': 'Écrivez une légende...',
      'it': 'Scrivere una didascalia...',
      'pl': 'Napisz podpis...',
    },
    '0uv032ls': {
      'en': 'Tag other users',
      'de': 'Markiere andere Benutzer',
      'es': 'Etiquetar a otros usuarios',
      'fr': 'Taguer d\'autres utilisateurs',
      'it': 'Tagga altri utenti',
      'pl': 'Otaguj innych użytkowników',
    },
    'a98rfxf9': {
      'en': 'Add location',
      'de': 'Standort hinzufügen',
      'es': 'Añadir ubicación',
      'fr': 'Ajouter un lieu',
      'it': 'Aggiungi posizione',
      'pl': 'Dodaj lokalizację',
    },
    'yil4eddx': {
      'en': 'Rome, IT',
      'de': 'Rome, IT',
      'es': 'Rome, IT',
      'fr': 'Rome, IT',
      'it': 'Rome, IT',
      'pl': 'Rome, IT',
    },
    'og6vi1lv': {
      'en': 'Berlin, DE',
      'de': 'Berlin, DE',
      'es': 'Berlin, DE',
      'fr': 'Berlin, DE',
      'it': 'Berlin, DE',
      'pl': 'Berlin, DE',
    },
    'n1m5r27k': {
      'en': 'Warsaw, PL',
      'de': 'Warsaw, PL',
      'es': 'Warsaw, PL',
      'fr': 'Warsaw, PL',
      'it': 'Warsaw, PL',
      'pl': 'Warsaw, PL',
    },
    'g0akaekg': {
      'en': 'Madrid, ES',
      'de': 'Madrid, ES',
      'es': 'Madrid, ES',
      'fr': 'Madrid, ES',
      'it': 'Madrid, ES',
      'pl': 'Madrid, ES',
    },
    'udxfvis7': {
      'en': 'Paris, FR',
      'de': 'Paris, FR',
      'es': 'Paris, FR',
      'fr': 'Paris, FR',
      'it': 'Paris, FR',
      'pl': 'Paris, FR',
    },
    'ljn9uye1': {
      'en': 'Amsterdam, NL',
      'de': 'Amsterdam, NL',
      'es': 'Amsterdam, NL',
      'fr': 'Amsterdam, NL',
      'it': 'Amsterdam, NL',
      'pl': 'Amsterdam, NL',
    },
    'br9cq3ez': {
      'en': 'Hide like count',
      'de': 'Anzahl der Likes ausblenden',
      'es': 'Ocultar recuento de Me gusta',
      'fr': 'Masquer le nombre de J\'aime',
      'it': 'Nascondi il conteggio dei Mi piace',
      'pl': 'Ukryj liczbę polubień',
    },
    'j1d2c4ig': {
      'en': 'Field is required',
      'de': 'Dieses Feld ist erforderlich',
      'es': 'Este campo es obligatorio',
      'fr': 'Ce champ est obligatoire',
      'it': 'Il campo è obbligatorio',
      'pl': 'To pole jest wymagane',
    },
    'mfytefuu': {
      'en': 'Please choose an option from the dropdown',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'cvmaebnn': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // userPosts
  {
    'gqom06b7': {
      'en': 'Post',
      'de': 'Post',
      'es': 'Post',
      'fr': 'Post',
      'it': 'Post',
      'pl': 'Post',
    },
    'j0faodqu': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
    'n52084zq': {
      'en': 'Shop',
      'de': 'Geschäft',
      'es': 'Tienda',
      'fr': 'Magasin',
      'it': 'Negozio',
      'pl': 'Sklep',
    },
    's45jcdq3': {
      'en': 'Points',
      'de': 'Punkte',
      'es': 'Puntos',
      'fr': 'Points',
      'it': 'Punti',
      'pl': 'Punkty',
    },
    'm37iz9r0': {
      'en': 'Chats',
      'de': 'Chats',
      'es': 'Chats',
      'fr': 'Chats',
      'it': 'Chat',
      'pl': 'Czaty',
    },
    'f475xc9l': {
      'en': 'Profile',
      'de': 'Profil',
      'es': 'Perfil',
      'fr': 'Profil',
      'it': 'Profilo',
      'pl': 'Profil',
    },
    'zit9v8p8': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // notificationsPost
  {
    '44hxhvht': {
      'en': 'Post',
      'de': 'Post',
      'es': 'Post',
      'fr': 'Post',
      'it': 'Post',
      'pl': 'Post',
    },
    '8p7vcuh6': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
    'fhkwahef': {
      'en': 'Shop',
      'de': 'Geschäft',
      'es': 'Tienda',
      'fr': 'Magasin',
      'it': 'Negozio',
      'pl': 'Sklep',
    },
    '1w2p7nzo': {
      'en': 'Points',
      'de': 'Punkte',
      'es': 'Puntos',
      'fr': 'Points',
      'it': 'Punti',
      'pl': 'Punkty',
    },
    'ioig1jnd': {
      'en': 'Chats',
      'de': 'Chats',
      'es': 'Chats',
      'fr': 'Chats',
      'it': 'Chat',
      'pl': 'Czaty',
    },
    'hrqhl47q': {
      'en': 'Profile',
      'de': 'Profil',
      'es': 'Perfil',
      'fr': 'Profil',
      'it': 'Profilo',
      'pl': 'Profil',
    },
    '3wcdse3b': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // otherUserPosts
  {
    'wgkgise1': {
      'en': 'Post',
      'de': 'Post',
      'es': 'Post',
      'fr': 'Post',
      'it': 'Post',
      'pl': 'Post',
    },
    'yuusc8xu': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
    'zg08bmde': {
      'en': 'Shop',
      'de': 'Geschäft',
      'es': 'Tienda',
      'fr': 'Magasin',
      'it': 'Negozio',
      'pl': 'Sklep',
    },
    'wr34grzn': {
      'en': 'Points',
      'de': 'Punkte',
      'es': 'Puntos',
      'fr': 'Points',
      'it': 'Punti',
      'pl': 'Punkty',
    },
    'bknh1b62': {
      'en': 'Chats',
      'de': 'Chats',
      'es': 'Chats',
      'fr': 'Chats',
      'it': 'Chat',
      'pl': 'Czaty',
    },
    'nv0x2y7e': {
      'en': 'Profile',
      'de': 'Profil',
      'es': 'Perfil',
      'fr': 'Profil',
      'it': 'Profilo',
      'pl': 'Profil',
    },
    'w8p4gn9c': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // userSinglePosts
  {
    'a4gin9tx': {
      'en': 'Post',
      'de': 'Post',
      'es': 'Post',
      'fr': 'Post',
      'it': 'Post',
      'pl': 'Post',
    },
    '7l5dybtj': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
    '6jlbztzp': {
      'en': 'Shop',
      'de': 'Geschäft',
      'es': 'Tienda',
      'fr': 'Magasin',
      'it': 'Negozio',
      'pl': 'Sklep',
    },
    'kk8f344b': {
      'en': 'Points',
      'de': 'Punkte',
      'es': 'Puntos',
      'fr': 'Points',
      'it': 'Punti',
      'pl': 'Punkty',
    },
    'eqrya3xs': {
      'en': 'Chats',
      'de': 'Chats',
      'es': 'Chats',
      'fr': 'Chats',
      'it': 'Chat',
      'pl': 'Czaty',
    },
    'wj6ho4oj': {
      'en': 'Profile',
      'de': 'Profil',
      'es': 'Perfil',
      'fr': 'Profil',
      'it': 'Profilo',
      'pl': 'Profil',
    },
    'tde9pp1k': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // otherUserSinglePost
  {
    'pp9qdj1c': {
      'en': 'Post',
      'de': 'Post',
      'es': 'Post',
      'fr': 'Post',
      'it': 'Post',
      'pl': 'Post',
    },
    'c6tho992': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
    'xtvsqpqj': {
      'en': 'Shop',
      'de': 'Geschäft',
      'es': 'Tienda',
      'fr': 'Magasin',
      'it': 'Negozio',
      'pl': 'Sklep',
    },
    'i5pf5cyn': {
      'en': 'Points',
      'de': 'Punkte',
      'es': 'Puntos',
      'fr': 'Points',
      'it': 'Punti',
      'pl': 'Punkty',
    },
    'qhqfhzjs': {
      'en': 'Chats',
      'de': 'Chats',
      'es': 'Chats',
      'fr': 'Chats',
      'it': 'Chat',
      'pl': 'Czaty',
    },
    'c189ahgg': {
      'en': 'Profile',
      'de': 'Profil',
      'es': 'Perfil',
      'fr': 'Profil',
      'it': 'Profilo',
      'pl': 'Profil',
    },
    '77ns0xyv': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // bookings
  {
    'wft14dte': {
      'en': 'Bookings',
      'de': 'Buchungen',
      'es': 'Reservaciones',
      'fr': 'Réservations',
      'it': 'Prenotazioni',
      'pl': 'Rezerwacje',
    },
    'aowgb65x': {
      'en': 'Directions',
      'de': 'Wegbeschreibung',
      'es': 'Indicaciones',
      'fr': 'Itinéraire',
      'it': 'Indicazioni',
      'pl': 'Nawiguj',
    },
    'io12bg1f': {
      'en': 'Home',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // newOnboarding_login1
  {
    '7gj71k95': {
      'en': 'Welcome back!',
      'de': 'Willkommen zurück!',
      'es': '¡Bienvenido de nuevo!',
      'fr': 'Bienvenue de retour !',
      'it': 'Bentornato/a!',
      'pl': 'Witaj ponownie!',
    },
    'c0qlch22': {
      'en': 'We\'re excited to see you again. Please log in.',
      'de': 'Wir freuen uns, dich wiederzusehen. Bitte melde dich an.',
      'es': 'Estamos emocionados de verte de nuevo. Por favor, inicia sesión.',
      'fr': 'Nous sommes ravis de vous revoir. Veuillez vous connecter.',
      'it': 'Siamo entusiasti di rivederti. Per favore, accedi.',
      'pl': 'Cieszymy się, że cię widzimy ponownie. Proszę zaloguj się.',
    },
    'xmlcfmoo': {
      'en': 'Log in with phone number',
      'de': 'Melden Sie sich mit der Telefonnummer an',
      'es': 'Iniciar sesión con número de teléfono',
      'fr': 'Connectez-vous avec votre numéro de téléphone',
      'it': 'Accedi con il numero di telefono',
      'pl': 'Zaloguj się numerem telefonu',
    },
    'ntc64cx3': {
      'en': 'Enter Phone Number',
      'de': 'Email',
      'es': 'Email',
      'fr': 'Email',
      'it': 'Email',
      'pl': 'Email',
    },
    '4txzdewb': {
      'en': 'Field is required',
      'de': 'Feld ist erforderlich',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
      'it': 'Il campo è obbligatiorio',
      'pl': 'To pole jest wymagane',
    },
    'ng9hmhcp': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'naks5ach': {
      'en': 'Please choose an option from the dropdown',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'aagqnjb3': {
      'en': 'Field is required',
      'de': 'Feld ist erforderlich',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
      'it': 'Il campo è obbligatiorio',
      'pl': 'To pole jest wymagane',
    },
    'x59c1npm': {
      'en': 'Please choose an option from the dropdown',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'l8eiemld': {
      'en': 'Next',
      'de': 'Einloggen',
      'es': 'Iniciar sesión',
      'fr': 'Se connecter.',
      'it': 'Accedi',
      'pl': 'Zaloguj się',
    },
    'ox0qacqp': {
      'en': 'Don\'t have an account?',
      'de': 'Du hast kein Konto?',
      'es': '¿No tienes una cuenta?',
      'fr': 'Vous n\'avez pas de compte ?',
      'it': 'Non hai un account?',
      'pl': 'Nie masz konta?',
    },
    '9vlxaph1': {
      'en': 'Sign Up',
      'de': 'Registrieren',
      'es': 'Regístrate',
      'fr': 'S\'inscrire',
      'it': 'Registrati',
      'pl': 'Zarejestruj się',
    },
    '8bf69hjv': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // newOnboarding_login2
  {
    'cg32um2z': {
      'en': 'Verification code',
      'de': 'Willkommen zurück!',
      'es': '¡Bienvenido de nuevo!',
      'fr': 'Bienvenue de retour !',
      'it': 'Bentornato/a!',
      'pl': 'Witaj ponownie!',
    },
    'lds37rsi': {
      'en': 'Please enter the code we\'ve sent to ',
      'de': 'Wir freuen uns, dich wiederzusehen. Bitte melde dich an.',
      'es': 'Estamos emocionados de verte de nuevo. Por favor, inicia sesión.',
      'fr': 'Nous sommes ravis de vous revoir. Veuillez vous connecter.',
      'it': 'Siamo entusiasti di rivederti. Per favore, accedi.',
      'pl': 'Cieszymy się, że cię widzimy ponownie. Proszę zaloguj się.',
    },
    '9i9tyuqr': {
      'en': 'Field is required',
      'de': 'Feld ist erforderlich',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
      'it': 'Il campo è obbligatiorio',
      'pl': 'To pole jest wymagane',
    },
    'xoja07pe': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'qgnuszvy': {
      'en': 'Please choose an option from the dropdown',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    '2ksxavor': {
      'en': 'Field is required',
      'de': 'Feld ist erforderlich',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
      'it': 'Il campo è obbligatiorio',
      'pl': 'To pole jest wymagane',
    },
    'v9eemt15': {
      'en': 'Please choose an option from the dropdown',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'z7org3u0': {
      'en': 'Next',
      'de': 'Einloggen',
      'es': 'Iniciar sesión',
      'fr': 'Se connecter.',
      'it': 'Accedi',
      'pl': 'Zaloguj się',
    },
    '2ax2t1iy': {
      'en': 'Don\'t have an account?',
      'de': 'Du hast kein Konto?',
      'es': '¿No tienes una cuenta?',
      'fr': 'Vous n\'avez pas de compte ?',
      'it': 'Non hai un account?',
      'pl': 'Nie masz konta?',
    },
    'fa7tylnt': {
      'en': 'Sign Up',
      'de': 'Registrieren',
      'es': 'Regístrate',
      'fr': 'S\'inscrire',
      'it': 'Registrati',
      'pl': 'Zarejestruj się',
    },
    '1o4t4vzb': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // newOnboarding1_emailTest
  {
    'f3a5m1zz': {
      'en': 'Sign Up',
      'de': 'Wie heißen Sie',
      'es': 'Cómo te llamas',
      'fr': 'Quel est ton nom',
      'it': 'Come ti chiami',
      'pl': 'Jak masz na imię',
    },
    'syiqf917': {
      'en': 'Full name',
      'de': 'Vollständiger Name',
      'es': 'Nombre completo',
      'fr': 'Nom complet',
      'it': 'Nome completo',
      'pl': 'Imię i nazwisko',
    },
    '3mzeq3yr': {
      'en': 'Email',
      'de': 'Vollständiger Name',
      'es': 'Nombre completo',
      'fr': 'Nom complet',
      'it': 'Nome completo',
      'pl': 'Imię i nazwisko',
    },
    'o90qagpe': {
      'en': 'Password',
      'de': 'Vollständiger Name',
      'es': 'Nombre completo',
      'fr': 'Nom complet',
      'it': 'Nome completo',
      'pl': 'Imię i nazwisko',
    },
    'i1gb1e6w': {
      'en': 'Confirm Password',
      'de': 'Vollständiger Name',
      'es': 'Nombre completo',
      'fr': 'Nom complet',
      'it': 'Nome completo',
      'pl': 'Imię i nazwisko',
    },
    '7m9oj4tp': {
      'en': 'Continue',
      'de': 'Weiter',
      'es': 'Continuar',
      'fr': 'Continuer',
      'it': 'Continua',
      'pl': 'Kontynuuj',
    },
    'n6iq2ejf': {
      'en': 'Home',
      'de': 'Home',
      'es': 'Home',
      'fr': 'Home',
      'it': 'Home',
      'pl': 'Home',
    },
  },
  // save_chat
  {
    'da1j9zmt': {
      'en': 'Save Chat',
      'de': 'Chat speichern',
      'es': 'Guardar chat',
      'fr': 'Enregistrer la discussion',
      'it': 'Salva chat',
      'pl': 'Zapisz czat',
    },
    'jno7lsj4': {
      'en': 'Save current chat to the history',
      'de': 'Aktuellen Chatverlauf speichern',
      'es': 'Guardar el chat actual en el historial',
      'fr': 'Enregistrer la discussion en cours dans l\'historique',
      'it': 'Salva la chat corrente nella cronologia',
      'pl': 'Zapisz bieżący czat w historii',
    },
    'b73p0o7a': {
      'en': 'Enter your title here...',
      'de': 'Geben Sie Ihren Titel hier ein...',
      'es': 'Ingresa tu título aquí...',
      'fr': 'Entrez votre titre ici...',
      'it': 'Inserisci il tuo titolo qui...',
      'pl': 'Wprowadź swój tytuł tutaj...',
    },
    '22lwmehg': {
      'en': 'Save',
      'de': 'Speichern',
      'es': 'Guardar',
      'fr': 'Enregistrer',
      'it': 'Salva',
      'pl': 'Zapisz',
    },
  },
  // notifications_Empty
  {
    'y4kludsd': {
      'en': 'Nothing to display.',
      'de': 'Rien à afficher.',
      'es': 'Nada que mostrar.',
      'fr': 'Rien ici – pour l’instant.',
      'it': 'Nulla da visualizzare.',
      'pl': 'Nic do wyświetlenia.',
    },
    'up0kombh': {
      'en': 'All notifications will be shown here.',
      'de': 'Alle Benachrichtigungen werden hier angezeigt.',
      'es': 'Todas las notificaciones se mostrarán aquí.',
      'fr': 'Toutes les notifications seront affichées ici.',
      'it': 'Tutte le notifiche saranno mostrate qui.',
      'pl': 'Wszystkie powiadomienia będą pokazane tutaj.',
    },
  },
  // no_transaction
  {
    '868bh9t3': {
      'en': 'No transactions yet!',
      'de': 'Noch keine Transaktionen!',
      'es': '¡Aún no hay transacciones!',
      'fr': 'Aucune transaction pour le moment !',
      'it': 'Nessuna transazione ancora!',
      'pl': 'Brak transakcji!',
    },
    'ynuwi8po': {
      'en': 'All future transactions will be displayed here!',
      'de': 'Alle zukünftigen Transaktionen werden hier angezeigt!',
      'es': '¡Todas las futuras transacciones se mostrarán aquí!',
      'fr': 'Toutes les transactions futures seront affichées ici !',
      'it': 'Tutte le future transazioni saranno visualizzate qui!',
      'pl': 'Wszystkie przyszłe transakcje będą wyświetlane tutaj!',
    },
  },
  // no_rewards
  {
    'suwor4to': {
      'en': 'No rewards yet!',
      'de': 'Noch keine Belohnungen!',
      'es': '¡Aún no hay recompensas!',
      'fr': 'Aucune récompense pour le moment !',
      'it': 'Nessuna ricompensa ancora!',
      'pl': 'Brak nagród!',
    },
    'cze92y1z': {
      'en': 'All future rewards will be displayed here!',
      'de': 'Alle zukünftigen Belohnungen werden hier angezeigt!',
      'es': '¡Todas las futuras recompensas se mostrarán aquí!',
      'fr': 'Toutes les récompenses futures seront affichées ici !',
      'it': 'Tutte le future ricompense saranno visualizzate qui!',
      'pl': 'Wszystkie przyszłe nagrody będą wyświetlane tutaj!',
    },
  },
  // alert_delete_post
  {
    '65j3hen6': {
      'en': 'Delete post?',
      'de': 'Beitrag löschen?',
      'es': '¿Eliminar publicación?',
      'fr': 'Supprimer la publication ?',
      'it': 'Elimina post?',
      'pl': 'Usunąć post?',
    },
    '6kl4cjwa': {
      'en': 'Are you sure you want to delete this post from Beneree? ',
      'de':
          'Bist du sicher, dass du diesen Beitrag von Beneree löschen möchtest?',
      'es': '¿Estás seguro de que deseas eliminar esta publicación de Beneree?',
      'fr': 'Êtes-vous sûr de vouloir supprimer cette publication de Beneree ?',
      'it': 'Sei sicuro di voler eliminare questo post da Beneree?',
      'pl': 'Czy na pewno chcesz usunąć ten post z Beneree?',
    },
    'upmmf3vb': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
    'qiy58on5': {
      'en': 'Delete',
      'de': 'Löschen',
      'es': 'Eliminar',
      'fr': 'Supprimer',
      'it': 'Elimina',
      'pl': 'Usuń',
    },
  },
  // alert_cancel_transaction
  {
    '8cmostr5': {
      'en': 'Cancel Transaction?',
      'de': 'Transaktion abbrechen?',
      'es': '¿Cancelar transacción?',
      'fr': 'Annuler la transaction ?',
      'it': 'Annullare transazione?',
      'pl': 'Anulować transakcję?',
    },
    '3v40agjl': {
      'en':
          'You can only cancel 5 transactions per month. Are you sure you want to cancel this transaction?',
      'de':
          'Du kannst nur 5 Transaktionen pro Monat stornieren. Bist du sicher, dass du diese Transaktion stornieren möchtest?',
      'es':
          'Solo puedes cancelar 5 transacciones al mes. ¿Estás seguro de que quieres cancelar esta transacción?',
      'fr':
          'Vous ne pouvez annuler que 5 transactions par mois. Êtes-vous sûr de vouloir annuler cette transaction ?',
      'it':
          'Puoi annullare solo 5 transazioni al mese. Sei sicuro di voler annullare questa transazione?',
      'pl':
          'Możesz anulować tylko 5 transakcji miesięcznie. Czy na pewno chcesz anulować tę transakcję?',
    },
    '2vxdd11n': {
      'en': 'Cancel Transaction',
      'de': 'Transaktion abbrechen',
      'es': 'Cancelar transacción',
      'fr': 'Annuler la transaction',
      'it': 'Annulla transazione',
      'pl': 'Anuluj transakcję',
    },
    '3dvon0a3': {
      'en': 'Get Help',
      'de': 'Hilfe erhalten',
      'es': 'Obtener ayuda',
      'fr': 'Obtenir de l\'aide',
      'it': 'Ottieni assistenza',
      'pl': 'Pomoc',
    },
    'fvmmpgcp': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
  },
  // alert_delete_account
  {
    'wgd84iow': {
      'en': 'Delete Account?',
      'de': 'Konto löschen?',
      'es': '¿Eliminar cuenta?',
      'fr': 'Supprimer le compte ?',
      'it': 'Eliminare account?',
      'pl': 'Usunąć konto?',
    },
    'ccs2uaxi': {
      'en':
          'Are you sure you want to delete your account? This can\'t be undone.',
      'de':
          'Bist du sicher, dass du dein Konto löschen möchtest? Dies kann nicht rückgängig gemacht werden.',
      'es':
          '¿Estás seguro de que quieres eliminar tu cuenta? Esto no se puede deshacer.',
      'fr':
          'Êtes-vous sûr de vouloir supprimer votre compte ? Cela ne peut pas être annulé.',
      'it':
          'Sei sicuro di voler eliminare il tuo account? Questo non può essere annullato.',
      'pl':
          ' Czy na pewno chcesz usunąć swoje konto? Tej operacji nie można cofnąć.',
    },
    'x07k0exo': {
      'en': 'Delete Account',
      'de': 'Konto löschen',
      'es': 'Eliminar cuenta',
      'fr': 'Supprimer le compte',
      'it': 'Elimina account',
      'pl': 'Usuń konto',
    },
    'ids9p5zr': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
  },
  // no_comments
  {
    '5cprwqxb': {
      'en': 'This post has no likes yet.',
      'de': 'Dieser Beitrag hat noch keine Likes.',
      'es': 'Esta publicación aún no tiene \"Me gusta\".',
      'fr': 'Cette publication n\'a pas encore de mentions \"J\'aime\".',
      'it': 'Questo post non ha ancora mi piace.',
      'pl': 'Ten post jeszcze nie ma polubień.',
    },
  },
  // GPT_no_chats
  {
    'f068oztn': {
      'en': 'You don\'t have any chats saved yet.',
      'de': 'Du hast noch keine Chats gespeichert.',
      'es': 'Aún no tienes ninguna conversación guardada.',
      'fr': 'Vous n\'avez pas encore de discussions enregistrées.',
      'it': 'Non hai ancora salvato nessuna chat.',
      'pl': 'Nie masz jeszcze zapisanych żadnych rozmów.',
    },
  },
  // no_posts_yet
  {
    'du3zokr0': {
      'en': 'No posts yet.',
      'de': 'Noch keine Beiträge.',
      'es': 'Sin publicaciones todavía.',
      'fr': 'Aucune publication pour le moment.',
      'it': 'Nessun post ancora.',
      'pl': 'Brak postów.',
    },
  },
  // no_saved_posts_yet
  {
    'o0a1918f': {
      'en': 'No saved posts yet.',
      'de': 'Noch keine gespeicherten Beiträge.',
      'es': 'Sin publicaciones guardadas todavía.',
      'fr': 'Aucune publication enregistrée pour le moment.',
      'it': 'Nessun post salvato ancora',
      'pl': 'Brak zapisanych postów.',
    },
  },
  // no_saved_posts_yetCopy
  {
    'fewm7s86': {
      'en': 'You have no chats yet.',
      'de': 'Du hast noch keine Chats.',
      'es': 'Aún no tienes chats.',
      'fr': 'Vous n\'avez pas encore de discussions.',
      'it': 'Non hai ancora chat.',
      'pl': 'Nie masz jeszcze żadnych czatów.',
    },
  },
  // messageBubbles_Focused
  {
    'i4xyk7e7': {
      'en': 'Copy',
      'de': 'Kopieren',
      'es': 'Copiar',
      'fr': 'Copier',
      'it': 'Copia',
      'pl': 'Kopiuj',
    },
    '1mdf6qqz': {
      'en': 'Reply',
      'de': 'Antworten',
      'es': 'Responder',
      'fr': 'Répondre',
      'it': 'Rispondi',
      'pl': 'Odpowiedz',
    },
    'ew9wtjhg': {
      'en': 'Delete',
      'de': 'Löschen',
      'es': 'Borrar',
      'fr': 'Supprimer',
      'it': 'Elimina',
      'pl': 'Usuń',
    },
    'gpbsi2rq': {
      'en': 'Copy',
      'de': 'Kopieren',
      'es': 'Copiar',
      'fr': 'Copier',
      'it': 'Copia',
      'pl': 'Kopiuj',
    },
    '69zlwt9t': {
      'en': 'Reply',
      'de': 'Antworten',
      'es': 'Responder',
      'fr': 'Répondre',
      'it': 'Rispondi',
      'pl': 'Odpowiedz',
    },
    'j8cczd2z': {
      'en': 'Delete',
      'de': 'Löschen',
      'es': 'Borrar',
      'fr': 'Supprimer',
      'it': 'Elimina',
      'pl': 'Usuń',
    },
  },
  // reply
  {
    '4jwp256y': {
      'en': 'Reply',
      'de': 'Antworten',
      'es': 'Responder',
      'fr': 'Répondre',
      'it': 'Rispondi',
      'pl': 'Odpowiedz',
    },
  },
  // message_deleted_sender
  {
    's2ygx913': {
      'en': 'This message was deleted.',
      'de': 'Diese Nachricht wurde gelöscht.',
      'es': 'Este mensaje fue eliminado.',
      'fr': 'Ce message a été supprimé.',
      'it': 'Questo messaggio è stato eliminato.',
      'pl': 'Ta wiadomość została usunięta.',
    },
  },
  // message_deleted_receiver
  {
    'pgeuv48k': {
      'en': 'This message was deleted.',
      'de': 'Diese Nachricht wurde gelöscht.',
      'es': 'Este mensaje fue eliminado.',
      'fr': 'Ce message a été supprimé.',
      'it': 'Questo messaggio è stato eliminato.',
      'pl': 'Ta wiadomość została usunięta.',
    },
  },
  // alert_delete_chat
  {
    'e1g14rgl': {
      'en': 'Delete this chat?',
      'de': 'Chat löschen?',
      'es': '¿Eliminar este chat?',
      'fr': 'Supprimer cette discussion ?',
      'it': 'Cancellare questa chat?',
      'pl': 'Usunąć ten czat?',
    },
    'fu6yvxaa': {
      'en': 'Are you sure you want to delete this chat from Beneree? ',
      'de': 'Bist du sicher, dass du diesen Chat von Beneree löschen möchtest?',
      'es': '¿Estás seguro de que deseas eliminar este chat de Beneree?',
      'fr': 'Êtes-vous sûr de vouloir supprimer cette discussion de Beneree ?',
      'it': 'Sei sicuro di voler cancellare questa chat da Beneree?',
      'pl': 'Jesteś pewien, że chcesz usunąć ten czat z Beneree?',
    },
    'dxz46p2z': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
    '7sl9u284': {
      'en': 'Delete',
      'de': 'Löschen',
      'es': 'Eliminar',
      'fr': 'Supprimer',
      'it': 'Cancella',
      'pl': 'Usuń',
    },
  },
  // alert_delete_comment
  {
    'goy7ffgm': {
      'en': 'Delete this comment?',
      'de': 'Kommentar löschen?',
      'es': '¿Eliminar este comentario?',
      'fr': 'Supprimer ce commentaire ?',
      'it': 'Elimina questo commento?',
      'pl': 'Usunąć ten komentarz?',
    },
    'dsiq8ab4': {
      'en': 'Are you sure you want to delete this comment from Beneree? ',
      'de':
          'Bist du sicher, dass du diesen Kommentar von Beneree löschen möchtest?',
      'es': '¿Estás seguro de que deseas eliminar este comentario de Beneree?',
      'fr': 'Êtes-vous sûr de vouloir supprimer ce commentaire de Beneree ?',
      'it': 'Sei sicuro di voler eliminare questo commento da Beneree?',
      'pl': 'Jesteś pewien, że chcesz usunąć ten komentarz z Beneree?',
    },
    'z6x9qgs5': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
    '855jkd74': {
      'en': 'Delete',
      'de': 'Löschen',
      'es': 'Eliminar',
      'fr': 'Supprimer',
      'it': 'Elimina',
      'pl': 'Usuń',
    },
  },
  // alert_delete_reply
  {
    'ofamb7hp': {
      'en': 'Delete this reply?',
      'de': 'Antwort löschen?',
      'es': '¿Eliminar esta respuesta?',
      'fr': 'Supprimer cette réponse ?',
      'it': 'Elimina questa risposta?',
      'pl': 'Usunąć tę odpowiedź?',
    },
    'gojpt0e2': {
      'en': 'Are you sure you want to delete this reply from Beneree? ',
      'de':
          'Bist du sicher, dass du diese Antwort von Beneree löschen möchtest?',
      'es': '¿Estás seguro de que deseas eliminar esta respuesta de Beneree?',
      'fr': 'Êtes-vous sûr de vouloir supprimer cette réponse de Beneree ?',
      'it': 'Sei sicuro di voler eliminare questa risposta da Beneree?',
      'pl': 'Jesteś pewien, że chcesz usunąć tę odpowiedź z Beneree?',
    },
    '0rewi4nq': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
    'mchoq8gn': {
      'en': 'Delete',
      'de': 'Löschen',
      'es': 'Eliminar',
      'fr': 'Supprimer',
      'it': 'Elimina',
      'pl': 'Usuń',
    },
  },
  // date_of_birth
  {
    'ar8y1r31': {
      'en': 'Why do I need to provide my date of birth?',
      'de': 'Warum muss ich mein Geburtsdatum angeben?',
      'es': '¿Por qué necesito proporcionar mi fecha de nacimiento?',
      'fr': 'Pourquoi dois-je fournir ma date de naissance?',
      'it': 'Perché devo fornire la mia data di nascita?',
      'pl': 'Dlaczego muszę podać datę urodzenia?',
    },
    'ou6if6gn': {
      'en':
          'Your date of birth is like your very own magic key to a personalized Beneree experience! \n\nBy sharing this special day with us, we can curate content and rewards tailored just for you! From exciting events to exclusive surprises, we\'re all about celebrating YOU and making every moment count! ',
      'de':
          'Dein Geburtsdatum ist wie dein ganz persönlicher magischer Schlüssel zu einem individuellen Beneree-Erlebnis!\n\nIndem du diesen besonderen Tag mit uns teilst, können wir Inhalte und Belohnungen speziell auf dich zuschneiden! Von aufregenden Veranstaltungen bis hin zu exklusiven Überraschungen dreht sich bei uns alles um DICH, um jeden Moment zu zelebrieren!',
      'es':
          '¡Tu fecha de nacimiento es como tu propia llave mágica para una experiencia personalizada en Beneree!\n\n¡Al compartir este día especial contigo, podemos crear contenido y recompensas personalizadas solo para ti! Desde eventos emocionantes hasta sorpresas exclusivas, ¡nuestra meta es celebrarte a TI y hacer que cada momento cuente!',
      'fr':
          'Votre date de naissance est comme votre clé magique pour une expérience Beneree personnalisée!\n\nEn partageant cette journée spéciale avec nous, nous pouvons créer du contenu et des récompenses sur mesure rien que pour vous ! Des événements excitants aux surprises exclusives, nous sommes là pour vous célébrer VOUS et faire en sorte que chaque moment compte !',
      'it':
          'La tua data di nascita è come la tua chiave magica per un\'esperienza personalizzata su Beneree!\n\nCondividendo con noi questo giorno speciale, possiamo creare contenuti e premi su misura solo per te! Dagli eventi emozionanti alle sorprese esclusive, siamo qui per celebrare TE e rendere ogni momento speciale!',
      'pl':
          'Twoja data urodzenia to jak magiczny klucz do spersonalizowanego doświadczenia na Beneree!\n\nDzięki dzieleniu się tym specjalnym dniem możemy tworzyć treści i nagrody dostosowane specjalnie dla Ciebie! Od ekscytujących wydarzeń do ekskluzywnych niespodzianek, jesteśmy tu, aby świętować CIEBIE i sprawić, że każdy moment będzie wyjątkowy!',
    },
    'i5tvsqdg': {
      'en': 'Got it',
      'de': 'Verstanden',
      'es': 'Entendido',
      'fr': 'Compris',
      'it': 'Capito',
      'pl': 'Rozumiem',
    },
  },
  // alert_premium_feature
  {
    'l3eu3zow': {
      'en': 'Discover the power of Beneree Pro!',
      'de': 'Entdecke die Möglichkeiten von Beneree Pro!',
      'es': '¡Descubre el poder de Beneree Pro!',
      'fr': 'Découvrez la puissance de Beneree Pro !',
      'it': 'Scopri il potere di Beneree Pro!',
      'pl': 'Odkryj moc Beneree Pro!',
    },
    'v5ysb6gk': {
      'en':
          'This exclusive feature is available only for Beneree Pro Business users. Unlock maximum business visibility and potential by upgrading to Beneree Pro. Take your business to new heights with this essential upgrade!',
      'de':
          'Diese exklusive Funktion steht nur Beneree Pro Business-Nutzern zur Verfügung. Schalte die maximale Sichtbarkeit und das Potenzial deines Unternehmens frei, indem du auf Beneree Pro aufrüstest. Bring dein Unternehmen mit diesem essenziellen Upgrade auf ein neues Level!',
      'es':
          'Esta función exclusiva está disponible solo para usuarios empresariales de Beneree Pro. Desbloquea la máxima visibilidad y potencial empresarial al actualizar a Beneree Pro. Lleva tu negocio a nuevas alturas con esta actualización esencial.',
      'fr':
          'Cette fonction exclusive est uniquement disponible pour les utilisateurs professionnels de Beneree Pro. Débloquez la visibilité et le potentiel maximum de votre entreprise en passant à Beneree Pro. Propulsez votre entreprise vers de nouveaux sommets avec cette mise à niveau essentielle !',
      'it':
          'Questa funzione esclusiva è disponibile solo per gli utenti business di Beneree Pro. Sblocca la massima visibilità e il massimo potenziale aziendale passando a Beneree Pro. Porta la tua azienda a nuove vette con questo upgrade essenziale!',
      'pl':
          'Ta ekskluzywna funkcja jest dostępna tylko dla użytkowników biznesowych Beneree Pro. Odblokuj maksymalną widoczność i potencjał biznesowy, aktualizując się do Beneree Pro. Przenieś swój biznes na nowe wyżyny dzięki tej istotnej aktualizacji!',
    },
    'zeyf6r83': {
      'en': 'Discover Beneree Pro',
      'de': 'Beneree Pro entdecken',
      'es': 'Descubre Beneree Pro',
      'fr': 'Découvrir Beneree Pro',
      'it': 'Scopri Beneree Pro',
      'pl': 'Odkryj Beneree Pro',
    },
    'l83dsrq3': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
  },
  // alert_switch_to_professional
  {
    '71x32qfa': {
      'en': 'Switch to Professional?',
      'de': 'Zu Profi wechseln?',
      'es': '¿Cambiar a Profesional?',
      'fr': 'Passer en Professionnel ?',
      'it': 'Passa a Professionale?',
      'pl': 'Przełącz na Profesjonalne?',
    },
    '9r8190c5': {
      'en':
          'By proceeding your account will be switched to a professional account. This process could take up to 30 seconds. Do not exit this page until the process is completed. ',
      'de':
          'Durch die Fortsetzung wird Ihr Konto in ein professionelles Konto umgewandelt. Dieser Vorgang kann bis zu 30 Sekunden dauern. Verlassen Sie diese Seite nicht, bis der Vorgang abgeschlossen ist.',
      'es':
          'Al continuar, tu cuenta se convertirá en una cuenta profesional. Este proceso podría llevar hasta 30 segundos. No salgas de esta página hasta que se complete el proceso.',
      'fr':
          'En procédant, votre compte sera basculé vers un compte professionnel. Ce processus peut prendre jusqu\'à 30 secondes. Ne quittez pas cette page tant que le processus n\'est pas terminé.',
      'it':
          'Procedendo, il tuo account verrà convertito in un account professionale. Questo processo potrebbe richiedere fino a 30 secondi. Non uscire da questa pagina fino a quando il processo non sarà completato.',
      'pl':
          'Kontynuując, Twoje konto zostanie przekształcone w konto profesjonalne. Ten proces może potrwać do 30 sekund. Nie zamykaj tej strony, dopóki proces nie zostanie zakończony.',
    },
    '2ye8nehm': {
      'en': 'Switch to Professional',
      'de': 'Zu Profi wechseln',
      'es': 'Cambiar a Profesional',
      'fr': 'Passer en Professionnel',
      'it': 'Passa a Professionale',
      'pl': 'Przełącz na Profesjonalne',
    },
    'kyc301ia': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
  },
  // no_taggs
  {
    'lw0aak5f': {
      'en': 'No tags yet.',
      'de': 'Noch keine Tags.',
      'es': 'Sin etiquetas aún.',
      'fr': 'Pas encore de tags.',
      'it': 'Nessun tag ancora.',
      'pl': 'Brak tagów.',
    },
  },
  // chatGPTMenu
  {
    'sar57arm': {
      'en': 'New chat',
      'de': 'Neuer Chat',
      'es': 'Nuevo chat',
      'fr': 'Nouveau chat',
      'it': 'Nuova chat',
      'pl': 'Nowy czat',
    },
    'i6ilqoor': {
      'en': 'Save',
      'de': 'Speichern',
      'es': 'Guardar',
      'fr': 'Enregistrer',
      'it': 'Salva',
      'pl': 'Zapisz',
    },
    'didai0ch': {
      'en': 'History',
      'de': 'Verlauf',
      'es': 'Historial',
      'fr': 'Historique',
      'it': 'Cronologia',
      'pl': 'Historia',
    },
  },
  // modal_delete_chat
  {
    'l3okk7c1': {
      'en': 'Delete Chat',
      'de': 'Chat löschen',
      'es': 'Eliminar chat',
      'fr': 'Supprimer la discussion',
      'it': 'Elimina chat',
      'pl': 'Usuń czat',
    },
    'azvqpv21': {
      'en': 'Are you sure you want to delete this chat?',
      'de': 'Bist du sicher, dass du diesen Chat löschen möchtest?',
      'es': '¿Estás seguro de que quieres eliminar esta conversación?',
      'fr': 'Êtes-vous sûr de vouloir supprimer cette conversation?',
      'it': 'Sei sicuro di voler eliminare questa chat?',
      'pl': 'Czy na pewno chcesz usunąć ten czat?',
    },
    '9rjragog': {
      'en': 'Delete',
      'de': 'Löschen',
      'es': 'Eliminar',
      'fr': 'Supprimer',
      'it': 'Elimina',
      'pl': 'Usuń',
    },
    'rm0zmjkb': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
  },
  // modal_post_user
  {
    'n9jfea3a': {
      'en': 'About this account',
      'de': 'Über dieses Konto',
      'es': 'Acerca de esta cuenta',
      'fr': 'À propos de ce compte',
      'it': 'Informazioni su questo account',
      'pl': 'O tym koncie',
    },
    '0d5prhj9': {
      'en': 'Report',
      'de': 'Melden',
      'es': 'Informar',
      'fr': 'Signaler',
      'it': 'Segnala',
      'pl': 'Zgłoś',
    },
    'pwv1xhab': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
  },
  // modal_post_owner
  {
    'ap8kyj14': {
      'en': 'Edit',
      'de': 'Bearbeiten\n',
      'es': 'Editar',
      'fr': 'Modifier',
      'it': 'Modifica',
      'pl': 'Edytuj',
    },
    'lrthx7t0': {
      'en': 'Delete',
      'de': 'Löschen',
      'es': 'Eliminar',
      'fr': 'Supprimer',
      'it': 'Elimina',
      'pl': 'Usuń',
    },
    'w7rgrciz': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
  },
  // modal_report
  {
    '1uu40juw': {
      'en': 'Report',
      'de': 'Melden',
      'es': 'Reportar',
      'fr': 'Signaler',
      'it': 'Segnala',
      'pl': 'Zgłoś',
    },
    'jly96bpx': {
      'en': 'Why do you want to report this post?',
      'de': 'Warum möchten Sie diesen Beitrag melden?',
      'es': '¿Por qué deseas reportar esta publicación?',
      'fr': 'Pourquoi souhaitez-vous signaler cette publication ?',
      'it': 'Perché desideri segnalare questo post?',
      'pl': 'Dlaczego chcesz zgłosić ten post?',
    },
    'd8ao0tdk': {
      'en':
          'If there\'s immediate danger, call your local emergency services in addition to reporting.',
      'de':
          'Wenn akute Gefahr besteht, rufen Sie zusätzlich zu Ihrer Meldung den örtlichen Rettungsdienst an.',
      'es':
          'Si hay peligro inmediato, llama a los servicios de emergencia locales además de reportarlo.',
      'fr':
          'En cas de danger immédiat, appelez les services d\'urgence locaux en plus de signaler.',
      'it':
          'Se c\'è un pericolo immediato, chiama i servizi di emergenza locali oltre a segnalare.',
      'pl':
          'Jeśli istnieje natychmiastowe zagrożenie, zadzwoń również na numer lokalnych służb ratunkowych.',
    },
  },
  // report_reason
  {
    '4pfmhui1': {
      'en': 'Tell us more about the reason for reporting this post',
      'de':
          'Erzählen Sie uns mehr über den Grund für die Meldung dieses Beitrags',
      'es': 'Cuéntanos más sobre la razón para reportar esta publicación',
      'fr':
          'Dites-nous-en plus sur la raison de la signalement de cette publication',
      'it': 'Raccontaci di più sulla ragione della segnalazione di questo post',
      'pl': 'Powiedz nam więcej o przyczynie zgłoszenia tego postu',
    },
    'gzwsm59u': {
      'en': 'Field is required',
      'de': 'Dieses Feld ist erforderlich',
      'es': 'Campo obligatorio',
      'fr': 'Champ requis',
      'it': 'Campo obbligatorio',
      'pl': 'Pole jest wymagane',
    },
    'v2awb2ba': {
      'en': 'Please choose an option from the dropdown',
      'de': 'Bitte wählen Sie eine Option aus dem Dropdown-Menü',
      'es': 'Por favor, elige una opción del menú desplegable',
      'fr': 'Veuillez choisir une option dans la liste déroulante',
      'it': 'Scegli un\'opzione dal menu a tendina',
      'pl': 'Wybierz opcję z rozwijanego menu',
    },
    'ap9te6bq': {
      'en': 'Report',
      'de': 'Melden',
      'es': 'Reportar',
      'fr': 'Signaler',
      'it': 'Segnala',
      'pl': 'Zgłoś',
    },
  },
  // pro_business
  {
    'cctq1yux': {
      'en': 'Maximise your benefits with Beneree Pro Business!',
      'de': 'Maximieren Sie Ihre Vorteile mit Beneree Pro Business!',
      'es': '¡Maximiza tus beneficios con Beneree Pro Business!',
      'fr': 'Maximisez vos avantages avec Beneree Pro Business !',
      'it': 'Massimizza i tuoi vantaggi con Beneree Pro Business!',
      'pl': 'Zmaksymalizuj swoje korzyści dzięki Beneree Pro Business!',
    },
    'v2bg03h1': {
      'en': '24/7 \'Shops\' Visibility',
      'de': 'Shops\' Sichtbarkeit rund um die Uhr (24/7)',
      'es': 'Visibilidad de \'Tiendas\' 24/7',
      'fr': 'Visibilité \'Boutiques\' 24/7',
      'it': 'Visibilità \'Negozi\' 24/7',
      'pl': 'Widoczność \'Sklepów\' 24/7',
    },
    'rjv0rmdy': {
      'en':
          'Gain round-the-clock visibility in our \'Shops\' section, attracting more customers based on their location.',
      'de':
          'Erhalten Sie eine Rund-um-die-Uhr-Sichtbarkeit in unserem \'Shops\'-Bereich und ziehen Sie mehr Kunden aufgrund ihres Standorts an.',
      'es':
          'Obtén visibilidad las 24 horas en nuestra sección de \'Tiendas\', atrayendo a más clientes en función de su ubicación.',
      'fr':
          'Gagnez une visibilité 24 heures sur 24 dans notre section \'Boutiques\', attirant davantage de clients en fonction de leur emplacement.',
      'it':
          'Ottenete visibilità 24 ore su 24 nella nostra sezione \'Negozi\', attirando più clienti in base alla loro posizione.',
      'pl':
          'Zyskaj całodobową widoczność w naszym dziale \'Sklepy\', przyciągając więcej klientów na podstawie ich lokalizacji.',
    },
    'vt8t5gjm': {
      'en': 'Daily Discounts',
      'de': 'Tägliche Rabatte',
      'es': 'Descuentos diarios',
      'fr': 'Remises quotidiennes',
      'it': 'Sconti giornalieri',
      'pl': 'Codzienne rabaty',
    },
    '4eqzn6qw': {
      'en':
          'Offer up to 15% discounts, tailored to your preferences, to boost foot traffic and sales.',
      'de':
          'Bieten Sie Rabatte von bis zu 15%, maßgeschneidert nach Ihren Vorlieben, um den Kundenverkehr und die Verkäufe zu steigern.',
      'es':
          'Ofrece descuentos de hasta el 15%, adaptados a tus preferencias, para aumentar el tráfico de clientes y las ventas.',
      'fr':
          'Proposez des remises allant jusqu\'à 15%, adaptées à vos préférences, pour stimuler la fréquentation et les ventes.',
      'it':
          'Offri sconti fino al 15%, personalizzati secondo le tue preferenze, per aumentare il flusso di clienti e le vendite.',
      'pl':
          'Oferuj rabaty do 15%, dopasowane do Twoich preferencji, aby zwiększyć ruch klientów i sprzedaż.',
    },
    '1ph2lxnt': {
      'en': 'Verified Business Badge',
      'de': 'Verifiziertes Unternehmensabzeichen',
      'es': 'Insignia de Negocio Verificado',
      'fr': 'Badge Entreprise Vérifiée',
      'it': 'Badge Aziendale Verificato',
      'pl': 'Odznaka Zweryfikowanego Biznesu',
    },
    'dh9ete83': {
      'en': 'Showcase your credibility with our verified business badge.',
      'de':
          'Präsentieren Sie Ihre Glaubwürdigkeit mit unserem verifizierten Unternehmensabzeichen.',
      'es':
          'Muestra tu credibilidad con nuestra insignia de negocio verificado.',
      'fr':
          'Mettez en avant votre crédibilité avec notre badge d\'entreprise vérifiée.',
      'it':
          'Mostra la tua credibilità con il nostro badge aziendale verificato.\"',
      'pl':
          'Zaakcentuj swoją wiarygodność naszą odznaką zweryfikowanego biznesu.',
    },
    'gu7yzg9o': {
      'en': 'Reward Program with QR Codes',
      'de': 'Belohnungsprogramm mit QR-Codes',
      'es': 'Programa de Recompensas con Códigos QR',
      'fr': 'Programme de Récompenses avec des Codes QR',
      'it': 'Programma di Ricompensa con Codici QR',
      'pl': 'Program Nagród z Kodami QR',
    },
    'me2o4b4w': {
      'en':
          'Generate QR codes for clients, let them earn rewards, and boost your local and global visibility.',
      'de':
          'Generieren Sie QR-Codes für Ihre Kunden, ermöglichen Sie ihnen, Belohnungen zu verdienen, und steigern Sie Ihre lokale und globale Sichtbarkeit.',
      'es':
          'Genera códigos QR para tus clientes, permíteles ganar recompensas y aumenta tu visibilidad local y global.',
      'fr':
          'Générez des codes QR pour vos clients, laissez-les gagner des récompenses et renforcez votre visibilité locale et mondiale.',
      'it':
          'Genera codici QR per i clienti, permettigli di guadagnare ricompense e aumenta la tua visibilità locale e globale.',
      'pl':
          'Generuj kody QR dla klientów, pozwól im zdobywać nagrody i zwiększ swoją widoczność lokalną i globalną.',
    },
    'k3ipok0j': {
      'en': 'Lowest Success Fee',
      'de': 'Niedrige Gebühr',
      'es': 'Tarifa Baja',
      'fr': 'Frais Bas',
      'it': 'Tariffa Bassa',
      'pl': 'Niska Prowizja',
    },
    'oruq5muv': {
      'en':
          'Benefit from a low 3% success fee, only applied after reaching €1,000 in sales.',
      'de':
          'Profitieren Sie von einer niedrigen Erfolgsgebühr von 3 %, die nur nach Erreichen von 1.000 € Umsatz angewandt wird.',
      'es':
          'Benefíciate de una baja tarifa de éxito del 3%, aplicada solo después de alcanzar €1.000 en ventas.',
      'fr':
          'Bénéficiez d\'une faible commission de succès de 3 %, appliquée uniquement après avoir atteint 1 000 € de ventes.',
      'it':
          'Beneficia di una bassa commissione di successo del 3%, applicata solo dopo aver raggiunto €1.000 in vendite.',
      'pl':
          'Korzystaj z niskiej prowizji w wysokości 3%, stosowanej tylko po osiągnięciu sprzedaży na poziomie 1000 € lub więcej.',
    },
    'ukelfs2f': {
      'en': 'ChatGPT \'Luminary\'',
      'de': 'ChatGPT \'Luminary\'',
      'es': 'ChatGPT \'Luminary\'',
      'fr': 'ChatGPT \'Luminary\'',
      'it': 'ChatGPT \'Luminary\'',
      'pl': 'ChatGPT \'Luminary\'',
    },
    'tkp23kax': {
      'en':
          'Chat endlessly with our AI companion, ChatGPT. Pro members get unlimited chats with ChatGPT to assist and engage.',
      'de':
          'Chatten Sie endlos mit unserem KI-Begleiter, ChatGPT. Pro-Mitglieder erhalten unbegrenzte Chats mit ChatGPT zur Unterstützung und Interaktion.',
      'es':
          'Chatea sin límites con nuestro compañero de IA, ChatGPT. Los miembros Pro obtienen chats ilimitados con ChatGPT para ayudar y participar.',
      'fr':
          'Discutez sans fin avec notre compagnon IA, ChatGPT. Les membres Pro bénéficient de discussions illimitées avec ChatGPT pour aider et s\'engager.',
      'it':
          'Chatta senza limiti con il nostro compagno AI, ChatGPT. I membri Pro ottengono chat illimitate con ChatGPT per assistenza e coinvolgimento.',
      'pl': 'Czatuj bez limitów z Luminary ChatGPT. ',
    },
    'omxn4o7j': {
      'en': 'Annual subscription. ',
      'de': 'Jahresabonnement.',
      'es': 'Suscripción anual.',
      'fr': 'Souscription annuelle.',
      'it': 'Abbonamento annuale.',
      'pl': 'Roczny abonament.',
    },
    'jtayf1oq': {
      'en': '\$99 / year',
      'de': '99 \$/Jahr',
      'es': '\$99 / año',
      'fr': '99 \$/an',
      'it': '\$ 99 / anno',
      'pl': '99 USD / rok',
    },
    'to2mu2di': {
      'en': 'Subscribe to Beneree Pro Business',
      'de': 'Abonnieren Sie Beneree Pro Business',
      'es': 'Suscríbete a Beneree Pro Business',
      'fr': 'Abonnez-vous à Beneree Pro Business',
      'it': 'Iscriviti a Beneree Pro Business',
      'pl': 'Subskrybuj Beneree Pro Business',
    },
    'o5d062vu': {
      'en':
          'By clicking \'Subscribe to Beneree Pro Business\' you agree to our Purchaser Terms of Service. Subscriptions auto-renew until cancelled. Cancel anytime. ',
      'de':
          'Durch Klicken auf \'Abonnieren von Beneree Pro Business\' erklären Sie sich mit unseren Kaufbedingungen einverstanden. Abonnements verlängern sich automatisch, bis sie gekündigt werden. Jederzeit kündbar.',
      'es':
          'Al hacer clic en \'Suscribirse a Beneree Pro Business\', aceptas nuestros Términos de Servicio para Compradores. Las suscripciones se renuevan automáticamente hasta que se cancelan. Puedes cancelar en cualquier momento.',
      'fr':
          'En cliquant sur \'S\'abonner à Beneree Pro Business\', vous acceptez nos Conditions d\'Utilisation pour les Acheteurs. Les abonnements se renouvellent automatiquement jusqu\'à leur annulation. Annulez quand vous le souhaitez.',
      'it':
          'Cliccando su \'Iscriviti a Beneree Pro Business\' accetti i nostri Termini di Servizio per gli Acquirenti. Le iscrizioni si rinnovano automaticamente fino a quando non vengono annullate. Annulla in qualsiasi momento.',
      'pl':
          'Klikając \'Zasubskrybuj Beneree Pro Business\', zgadzasz się na nasze Warunki Obsługi Kupujących. Subskrypcje automatycznie się odnawiają, chyba że zostaną anulowane. Możesz anulować w dowolnym momencie.',
    },
  },
  // modal_no_internet
  {
    'yvcurilz': {
      'en': 'No internet connection.',
      'de': 'Keine Internetverbindung.',
      'es': 'Sin conexión a Internet.',
      'fr': 'Pas de connexion Internet.',
      'it': 'Nessuna connessione internet.',
      'pl': 'Brak połączenia z internetem.',
    },
  },
  // menuFeedPage
  {
    'u93jk2sx': {
      'en': 'Legal Center',
      'de': 'Rechtszentrum',
      'es': 'Centro Legal',
      'fr': 'Centre Juridique',
      'it': 'Centro Legale',
      'pl': 'Centrum Prawne',
    },
    'x0ef4z4h': {
      'en': 'Log out',
      'de': 'Abmelden',
      'es': 'Cerrar sesión',
      'fr': 'Déconnexion',
      'it': 'Esci',
      'pl': 'Wyloguj się',
    },
  },
  // chatGPTEmtyLisy
  {
    'vcoipqsf': {
      'en':
          'You can send maximum 2 chats to \'Luminary\' every 24 hours. Want more? Upgrade your account to Beneree Pro for unlimited chats and premium features!',
      'de':
          'Sie können maximal 2 Chats an \'Luminary\' alle 24 Stunden senden. Möchten Sie mehr? Aktualisieren Sie Ihr Konto auf Beneree Pro für unbegrenzte Chats und Premium-Funktionen!',
      'es':
          'Puedes enviar un máximo de 2 chats a \'Luminary\' cada 24 horas. ¿Quieres más? Actualiza tu cuenta a Beneree Pro para obtener chats ilimitados y funciones premium.',
      'fr':
          'Vous pouvez envoyer au maximum 2 discussions à \'Luminary\' toutes les 24 heures. Vous en voulez plus ? Mettez à jour votre compte vers Beneree Pro pour des discussions illimitées et des fonctionnalités premium !',
      'it':
          'Puoi inviare massimo 2 chat a \'Luminary\' ogni 24 ore. Vuoi di più? Aggiorna il tuo account a Beneree Pro per chat illimitate e funzionalità premium!',
      'pl':
          'Możesz wysłać maksymalnie 2 rozmowy do \'Luminary\' co 24 godziny. Chcesz więcej? Zaktualizuj swoje konto do Beneree Pro, aby uzyskać nielimitowane rozmowy oraz funkcje premium!',
    },
  },
  // user_blocked
  {
    'q5ystu6r': {
      'en': 'User Blocked',
      'de': 'Nutzer blockiert',
      'es': 'Usuario bloqueado',
      'fr': 'Utilisateur bloqué',
      'it': 'Utente bloccato',
      'pl': 'Użytkownik zablokowany',
    },
    'vnkeo9ig': {
      'en':
          'This user has been blocked. If you have any concerns, please contact support.',
      'de':
          'Dieser Benutzer wurde blockiert. Wenn Sie Bedenken haben, wenden Sie sich bitte an den Support.',
      'es':
          'Este usuario ha sido bloqueado. Si tiene alguna inquietud, comuníquese con el soporte.',
      'fr':
          'Cet utilisateur a été bloqué. Si vous avez des inquiétudes, veuillez contacter le support.',
      'it':
          'Questo utente è stato bloccato. In caso di dubbi, contattare l\'assistenza.',
      'pl':
          'Ten użytkownik został zablokowany. Jeśli masz jakiekolwiek wątpliwości, skontaktuj się z pomocą techniczną.',
    },
    'lq1actuh': {
      'en': 'OK',
      'de': 'OK',
      'es': 'OK',
      'fr': 'OK',
      'it': 'OK',
      'pl': 'OK',
    },
  },
  // noShopsNearby
  {
    's35sscbh': {
      'en': 'Sorry, no nearby shops found.',
      'de': 'Leider wurden keine Geschäfte in der Nähe gefunden.',
      'es': 'Lo sentimos, no se encontraron tiendas cercanas.',
      'fr': 'Désolé, aucun magasin à proximité trouvé.',
      'it':
          'Siamo spiacenti, non è stato trovato nessun negozio nelle vicinanze',
      'pl': 'Przykro nam, nie znaleziono żadnych sklepów w pobliżu.',
    },
  },
  // alert_delete_moment
  {
    '2ftd6m07': {
      'en': 'Delete this Moment?',
      'de': 'Diesen Moment löschen?',
      'es': '¿Eliminar este momento?',
      'fr': 'Supprimer ce moment ?',
      'it': 'Eliminare questo momento?',
      'pl': 'Usunąć ten Moment?',
    },
    '40s4e8vc': {
      'en': 'Are you sure you want to delete this Moment from Beneree? ',
      'de':
          'Sind Sie sicher, dass Sie diesen Moment aus Beneree löschen möchten?',
      'es': '¿Estás seguro de que deseas eliminar este Momento de Beneree?',
      'fr': 'Êtes-vous sûr de vouloir supprimer ce moment de Beneree ?',
      'it': 'Sei sicuro di voler eliminare questo Momento da Beneree?',
      'pl': 'Czy na pewno chcesz usunąć ten \'Moment\' z Beneree?',
    },
    'micxovju': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
    '2awvf6y7': {
      'en': 'Delete',
      'de': 'Löschen',
      'es': 'Eliminar',
      'fr': 'Supprimer',
      'it': 'Cancella',
      'pl': 'Usuń',
    },
  },
  // modal_delete_moment
  {
    'e5m940ta': {
      'en': 'Delete Moment',
      'de': 'Moment löschen',
      'es': 'Eliminar momento',
      'fr': 'Supprimer le moment',
      'it': 'Elimina momento',
      'pl': 'Usuń \'Moment\'',
    },
    '2lb9zrwt': {
      'en': 'Are you sure you want to delete this \'Moment\'?',
      'de': 'Sind Sie sicher, dass Sie diesen „Moment“ löschen möchten?',
      'es': '¿Estás seguro de que deseas eliminar este \'Momento\'?',
      'fr': 'Etes-vous sûr de vouloir supprimer ce « Moment » ?',
      'it': 'Sei sicuro di voler eliminare questo \"Momento\"?',
      'pl': 'Czy na pewno chcesz usunąć ten „Moment”?',
    },
    'xrti5pn0': {
      'en': 'Delete',
      'de': 'Löschen',
      'es': 'Eliminar',
      'fr': 'Supprimer',
      'it': 'Elimina',
      'pl': 'Usuń',
    },
    '5nfvo4bi': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
  },
  // BenePointsCard
  {
    'xa8qde3s': {
      'en': 'Your',
      'de': 'Dein',
      'es': 'Su',
      'fr': 'Ton',
      'it': 'Tuo',
      'pl': 'Twoja',
    },
    'lxk6m0fe': {
      'en': 'BenePoints™ Card',
      'de': 'BenePoints™- Karte',
      'es': 'Tarjeta BenePoints™',
      'fr': 'Carte BenePoints™',
      'it': 'Carta BenePoints™',
      'pl': 'Karta BenePoints™',
    },
    'rlk6ak22': {
      'en':
          'Allow the vendor to scan your card so you can collect your BenePoints™',
      'de':
          'Erlauben Sie dem Anbieter, Ihre Karte zu scannen, damit Sie Ihre BenePoints™ sammeln können.',
      'es':
          'Permita que el proveedor escanee su tarjeta para que pueda recoger sus BenePoints™',
      'fr':
          'Autorisez le vendeur à scanner votre carte afin que vous puissiez récupérer vos BenePoints™',
      'it':
          'Consenti al venditore di scansionare la tua carta in modo che tu possa ritirare i tuoi BenePoints™',
      'pl':
          'Pozwól sprzedawcy zeskanować Twoją kartę, aby otrzymać BenePoints™',
    },
    'tq63k291': {
      'en': 'Close',
      'de': 'Schließen',
      'es': 'Cerca',
      'fr': 'Fermer',
      'it': 'Vicino',
      'pl': 'Zamknij',
    },
  },
  // emptylist_nothingToShow
  {
    '0wfe6hg9': {
      'en': 'You don\'t have any bookings yet.',
      'de': 'Sie haben noch keine Buchungen.',
      'es': 'Aún no tienes ninguna reserva.',
      'fr': 'Vous n\'avez pas encore de réservations.',
      'it': 'Non hai ancora nessuna prenotazione.',
      'pl': 'Nie masz jeszcze żadnych rezerwacji.',
    },
  },
  // emptyList_NoNotifications
  {
    'gphgu7mz': {
      'en': 'You don\'t have any notifications.',
      'de': 'Sie haben keine Benachrichtigungen.',
      'es': 'No tienes ninguna notificación.',
      'fr': 'Vous n\'avez aucune notification.',
      'it': 'Non hai alcuna notifica.',
      'pl': 'Nie masz żadnych powiadomień.',
    },
  },
  // modal_select_image_video
  {
    'pakytpq9': {
      'en': 'Share a photo',
      'de': 'Ein Foto teilen',
      'es': 'Compartir una foto',
      'fr': 'Partager une photo',
      'it': 'Condividi una foto',
      'pl': 'Udostępnij zdjęcie',
    },
    'mk7g13kz': {
      'en': 'Share a video',
      'de': 'Ein Video teilen',
      'es': 'Compartir un video',
      'fr': 'Partager une vidéo',
      'it': 'Condividi un video',
      'pl': 'Udostępnij video',
    },
    '0f2q8f06': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
  },
  // alert_delete_notification
  {
    'y4hhm5pv': {
      'en': 'Delete notification?',
      'de': 'Benachrichtigung löschen?',
      'es': '¿Eliminar notificación?',
      'fr': 'Supprimer la notification ?',
      'it': 'Eliminare la notifica?',
      'pl': 'Usunąć powiadomienie?',
    },
    'bg1a1btk': {
      'en': 'Are you sure you want to delete this notification from Beneree? ',
      'de':
          'Sind Sie sicher, dass Sie diese Benachrichtigung aus Beneree löschen möchten?',
      'es':
          '¿Estás seguro de que deseas eliminar esta notificación de Beneree?',
      'fr':
          'Êtes-vous sûr de vouloir supprimer cette notification de Beneree ?',
      'it': 'Sei sicuro di voler eliminare questa notifica da Beneree?',
      'pl': 'Czy na pewno chcesz usunąć to powiadomienie z Beneree?',
    },
    'm1u75c97': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
    'diukpb4v': {
      'en': 'Delete',
      'de': 'Löschen',
      'es': 'Eliminar',
      'fr': 'Supprimer',
      'it': 'Elimina',
      'pl': 'Usuń',
    },
  },
  // modal_new_booking
  {
    'ogmdbnip': {
      'en': 'Cancel',
      'de': 'Abbrechen',
      'es': 'Cancelar',
      'fr': 'Annuler',
      'it': 'Annulla',
      'pl': 'Anuluj',
    },
    'zzchyewu': {
      'en': 'Booking',
      'de': 'Buchung',
      'es': 'Reserva',
      'fr': 'Réservation',
      'it': 'Prenotazione',
      'pl': 'Rezerwacja',
    },
    'hule5nwe': {
      'en': 'Confirm',
      'de': 'Bestätigen',
      'es': 'Confirmar',
      'fr': 'Confirmer',
      'it': 'Conferma',
      'pl': 'Potwierdź',
    },
    '3fgd249f': {
      'en': 'Title',
      'de': 'Titel',
      'es': 'Título',
      'fr': 'Titre',
      'it': 'Titolo',
      'pl': 'Tytuł',
    },
    '919fy9er': {
      'en': 'Note',
      'de': 'Notiz',
      'es': 'Nota',
      'fr': 'Note',
      'it': 'Nota',
      'pl': 'Notatka',
    },
    'y23ixojr': {
      'en': 'Address',
      'de': 'Adresse',
      'es': 'DIRECCIÓN',
      'fr': 'Adresse',
      'it': 'Indirizzo',
      'pl': 'Adres',
    },
    '1x0xpjpe': {
      'en': 'Starts',
      'de': 'Beginn',
      'es': 'Comienza',
      'fr': 'Débute',
      'it': 'Inizio',
      'pl': 'Początek',
    },
    'msovg8b8': {
      'en': 'Ends',
      'de': 'Ende',
      'es': 'Termina',
      'fr': 'Se termine',
      'it': 'Fine',
      'pl': 'Koniec',
    },
    'ci2gb2ba': {
      'en': 'People',
      'de': 'Menschen',
      'es': 'Gente',
      'fr': 'Personnes',
      'it': 'Persone',
      'pl': 'Ludzie',
    },
    'jl8pttfd': {
      'en': 'Search',
      'de': 'Suchen',
      'es': 'Buscar',
      'fr': 'Recherche',
      'it': 'Ricerca',
      'pl': 'Szukaj',
    },
    'r36ojmfz': {
      'en': 'Close',
      'de': 'Schließen',
      'es': 'Cerrar',
      'fr': 'Fermer',
      'it': 'Chiudi',
      'pl': 'Zamknij',
    },
    'onkf9fc0': {
      'en': 'Field is required',
      'de': 'Dieses Feld ist erforderlich',
      'es': 'Este campo es obligatorio',
      'fr': 'Ce champ est obligatoire',
      'it': 'Il campo è obbligatorio',
      'pl': 'To pole jest wymagane',
    },
    'nhg4pfo3': {
      'en': 'Please choose an option from the dropdown',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'ku4mop55': {
      'en': 'Field is required',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'erwii7a8': {
      'en': 'Please choose an option from the dropdown',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // modal_booking_details
  {
    'xx1t3frm': {
      'en': 'Back',
      'de': 'Zurück',
      'es': 'Indietro',
      'fr': 'Retour',
      'it': 'Indietro',
      'pl': 'Powrót',
    },
    '7jr0dz1h': {
      'en': 'Booking',
      'de': 'Buchung',
      'es': 'Reserva',
      'fr': 'Réservation',
      'it': 'Prenotazione',
      'pl': 'Rezerwacja',
    },
    '1bl799pz': {
      'en': 'Update',
      'de': 'Update',
      'es': 'Actualizar',
      'fr': 'MàJ',
      'it': 'Aggiorn',
      'pl': 'Aktualizuj',
    },
    'rfvhsnm2': {
      'en': 'Title',
      'de': 'Titel',
      'es': 'Título',
      'fr': 'Titre',
      'it': 'Titolo',
      'pl': 'Tytuł',
    },
    't734ophf': {
      'en': 'Note',
      'de': 'Notiz',
      'es': 'Nota',
      'fr': 'Note',
      'it': 'Nota',
      'pl': 'Notatka',
    },
    '0rx1eink': {
      'en': 'Address',
      'de': 'Adresse',
      'es': 'Dirección',
      'fr': 'Adresse',
      'it': 'Indirizzo',
      'pl': 'Adres',
    },
    'zmdomtn1': {
      'en': 'Starts',
      'de': 'Beginn',
      'es': 'Comienza',
      'fr': 'Débute',
      'it': 'Inizio',
      'pl': 'Początek',
    },
    '58td0a5s': {
      'en': 'Ends',
      'de': 'Ende',
      'es': 'Termina',
      'fr': 'Se termine',
      'it': 'Fine',
      'pl': 'Koniec',
    },
    'qh6dwlho': {
      'en': 'People',
      'de': 'Menschen',
      'es': 'Gente',
      'fr': 'Personnes',
      'it': 'Persone',
      'pl': 'Ludzie',
    },
    '0lbghett': {
      'en': 'Search',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'd8an9wj7': {
      'en': 'Close',
      'de': 'Schließen',
      'es': 'Cerrar',
      'fr': 'Fermer',
      'it': 'Chiudi',
      'pl': 'Zamknij',
    },
    'msesfrdg': {
      'en': 'Hold to Cancel',
      'de': 'Gedrückt halten, um abzubrechen',
      'es': 'Mantén presionado para cancelar',
      'fr': 'Maintenez pour annuler',
      'it': 'Tieni premuto per annullare',
      'pl': 'Przytrzymaj, aby anulować',
    },
    'f2o59fs8': {
      'en': 'Field is required',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    '1qdn0hsx': {
      'en': 'Please choose an option from the dropdown',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'mf6aq5d2': {
      'en': 'Field is required',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'z2dn6q5j': {
      'en': 'Please choose an option from the dropdown',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
  },
  // bookings_Empty
  {
    'qqvdmv27': {
      'en': 'Nothing to display.',
      'de': 'Hier gibt es nichts anzuzeigen.',
      'es': 'Nada que mostrar.',
      'fr': 'Rien à afficher.',
      'it': 'Nulla da visualizzare.',
      'pl': 'Nic do wyświetlenia',
    },
    'ts4xlv9r': {
      'en': 'All bookings will be shown here.',
      'de': 'Alle Buchungen werden hier angezeigt.',
      'es': 'Todas las reservas se mostrarán aquí.',
      'fr': 'Toutes les réservations seront affichées ici.',
      'it': 'Tutte le prenotazioni saranno mostrate qui.',
      'pl': 'Wszystkie rezerwacje będą pokazane tutaj.',
    },
  },
  // Miscellaneous
  {
    '91tmp9hx': {
      'en': 'Continue',
      'de': 'Zu einem Profi-Konto wechseln',
      'es': 'Cambiar a Cuenta Profesional',
      'fr': 'Passer à un Compte Professionnel',
      'it': 'Passa a un Account Professionale',
      'pl': 'Przełącz na Konto Profesjonalne',
    },
    'kmfousnz': {
      'en': 'Full name',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'wf2oc9li': {
      'en': 'Follow',
      'de': 'Werde professoinell',
      'es': 'Obtener pro',
      'fr': 'Devenir pro',
      'it': 'Ottieni professionista',
      'pl': ' Get Pro',
    },
    'pni3y84b': {
      'en':
          'Your location allows you see people nearby, be discovered by other users and see other recommendations nearby.',
      'de':
          'Ihr Standort ermöglicht es Ihnen, Personen in der Nähe zu sehen, von anderen Benutzern entdeckt zu werden und andere Empfehlungen in der Nähe zu sehen.',
      'es':
          'Tu ubicación te permite ver personas cercanas, ser descubierto por otros usuarios y ver otras recomendaciones cercanas.',
      'fr':
          'Votre emplacement vous permet de voir les personnes à proximité, d\'être découvert par d\'autres utilisateurs et de voir d\'autres recommandations à proximité.',
      'it':
          'La tua posizione ti consente di vedere persone nelle vicinanze, essere scoperto/a da altri utenti e visualizzare altre raccomandazioni nelle vicinanze.',
      'pl':
          'Twoja lokalizacja pozwala ci widzieć osoby w pobliżu, być odkrywanym przez innych użytkowników i widzieć inne polecane miejsca w okolicy.',
    },
    'pq7e7m2g': {
      'en':
          'Allow Beneree to access your camera for capturing and sharing photos.',
      'de':
          'Erlaube Beneree den Zugriff auf deine Kamera, um Fotos aufzunehmen und zu teilen.',
      'es':
          'Permite que Beneree acceda a tu cámara para capturar y compartir fotos.',
      'fr':
          'Autorisez Beneree à accéder à votre caméra pour capturer et partager des photos.',
      'it':
          'Consenti a Beneree di accedere alla tua fotocamera per catturare e condividere foto.',
      'pl':
          'Pozwól Beneree uzyskać dostęp do kamery, aby rejestrować i udostępniać zdjęcia.',
    },
    'jsk6fkxk': {
      'en': 'Allow Beneree access to your photos for easy sharing.',
      'de': 'Erlaube Beneree den Zugriff auf deine Fotos für einfaches Teilen.',
      'es': 'Permite que Beneree acceda a tus fotos para compartir fácilmente.',
      'fr':
          'Autorisez Beneree à accéder à vos photos pour une facilité de partage.',
      'it':
          'Consenti a Beneree di accedere alle tue foto per una condivisione facile.',
      'pl':
          'Pozwól Beneree uzyskać dostęp do swoich zdjęć w celu łatwego udostępniania.',
    },
    'mm5o9vi7': {
      'en': 'Allow Beneree to use your microphone for in app voice messages.',
      'de':
          'Erlaube Beneree, dein Mikrofon für Sprachnachrichten in der App zu verwenden.',
      'es':
          'Permite que Beneree use tu micrófono para mensajes de voz dentro de la aplicación.',
      'fr':
          'Autorisez Beneree à utiliser votre microphone pour des messages vocaux dans l\'application.',
      'it':
          'Consenti a Beneree di utilizzare il tuo microfono per messaggi vocali in-app.',
      'pl':
          'Pozwól Beneree używać mikrofonu do wysyłania wiadomości głosowych w aplikacji.',
    },
    'ur7bzz44': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'j0wojccu': {
      'en': 'Stay updated with Beneree alerts and messages.',
      'de':
          'Bleiben Sie mit Beneree-Benachrichtigungen und -Nachrichten auf dem Laufenden.',
      'es': 'Mantente actualizado/a con las alertas y mensajes de Beneree.',
      'fr': 'Restez informé(e) des alertes et des messages de Beneree.',
      'it': 'Resta aggiornato/a con gli avvisi e i messaggi di Beneree.',
      'pl': 'Pozostań na bieżąco z alertami i wiadomościami od Beneree.',
    },
    'k1ld97bd': {
      'en': 'Error',
      'de': 'Fehler',
      'es': 'Error',
      'fr': 'Erreur',
      'it': 'Errore',
      'pl': 'Błąd',
    },
    'jvimb4ue': {
      'en': 'Password reset email sent!',
      'de': 'E-Mail zum Zurücksetzen des Passworts gesendet!',
      'es': 'Correo electrónico de restablecimiento de contraseña enviado!',
      'fr': 'E-mail de réinitialisation du mot de passe envoyé !',
      'it': 'Email di reimpostazione password inviata!',
      'pl': 'Wiadomość e-mail dotycząca resetowania hasła została wysłana!',
    },
    'gtic4utk': {
      'en': 'Email required!',
      'de': 'Email erforderlich!',
      'es': '¡Correo electronico requerido!',
      'fr': 'Email requis!',
      'it': 'Email obbligatorio!',
      'pl': 'Email wymagany!',
    },
    'xkay2t7l': {
      'en': 'Phone number required and has to start with +',
      'de': 'Telefonnummer erforderlich und muss mit + beginnen',
      'es': 'Se requiere un número de teléfono y debe comenzar con +',
      'fr': 'Numéro de téléphone obligatoire et doit commencer par +',
      'it': 'Il numero di telefono è obbligatorio e deve iniziare con +',
      'pl': 'Numer telefonu jest wymagany i musi zaczynać się od +',
    },
    'ylwatztd': {
      'en': 'Passwords don\'t match',
      'de': 'Passwörter stimmen nicht überein',
      'es': 'Las contraseñas no coinciden',
      'fr': 'Les mots de passe ne correspondent pas',
      'it': 'Le password non corrispondono',
      'pl': 'Hasła się nie zgadzają',
    },
    'shycxpd3': {
      'en': 'Enter SMS verification code',
      'de': 'Geben Sie den SMS-Bestätigungscode ein',
      'es': 'Ingrese el código de verificación de SMS',
      'fr': 'Entrez le code de vérification par SMS',
      'it': 'Inserisci il codice di verifica SMS',
      'pl': 'Wprowadź kod weryfikacyjny SMS',
    },
    '2zum6g5p': {
      'en':
          'Too long sice most recent sign in. Sign in again before deleting your account.',
      'de':
          'Zu lang für die letzte Anmeldung. Melden Sie sich erneut an, bevor Sie Ihr Konto löschen.',
      'es':
          'Demasiado tiempo desde el inicio de sesión más reciente. Vuelva a iniciar sesión antes de eliminar su cuenta.',
      'fr':
          'Trop long depuis la dernière connexion. Reconnectez-vous avant de supprimer votre compte.',
      'it':
          'Troppo tempo dall\'ultimo accesso. Accedi di nuovo prima di eliminare il tuo account.',
      'pl':
          'Za długie od ostatniego logowania. Zaloguj się ponownie przed usunięciem konta.',
    },
    'l252iva4': {
      'en':
          'Too long sice most recent sign in. Sign in again before updating your email.',
      'de':
          'Zu lang für die letzte Anmeldung. Melden Sie sich erneut an, bevor Sie Ihre E-Mail-Adresse aktualisieren.',
      'es':
          'Demasiado tiempo desde el inicio de sesión más reciente. Vuelva a iniciar sesión antes de actualizar su correo electrónico.',
      'fr':
          'Trop long depuis la connexion la plus récente. Reconnectez-vous avant de mettre à jour votre adresse e-mail.',
      'it':
          'Troppo tempo dall\'ultimo accesso. Accedi di nuovo prima di aggiornare la tua email.',
      'pl':
          'Za długie od ostatniego logowania. Zaloguj się ponownie przed aktualizacją adresu e-mail.',
    },
    'zwjx9hng': {
      'en': 'Email change confirmation email sent.',
      'de': 'Bestätigungs-E-Mail zur E-Mail-Änderung gesendet.',
      'es':
          'Correo electrónico de confirmación de cambio de correo electrónico enviado.',
      'fr': 'E-mail de confirmation de changement d\'e-mail envoyé.',
      'it': 'Email di conferma modifica email inviata.',
      'pl': 'Wysłano wiadomość e-mail z potwierdzeniem zmiany adresu e-mail.',
    },
    'qy6oxrb2': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    '4e9wzmrr': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'hxljcvrm': {
      'en': 'Invalid file format',
      'de': 'Ungültiges Dateiformat',
      'es': 'Formato de archivo inválido',
      'fr': 'Format de fichier invalide',
      'it': 'Formato file non valido',
      'pl': 'Nieprawidłowy format pliku',
    },
    'm7z495oh': {
      'en': 'Uploading file...',
      'de': 'Datei wird hochgeladen...',
      'es': 'Cargando archivo...',
      'fr': 'Téléchargement du fichier...',
      'it': 'Caricamento file...',
      'pl': 'Przesyłanie pliku...',
    },
    'zlyqqftr': {
      'en': 'Success!',
      'de': 'Erfolg!',
      'es': '¡Éxito!',
      'fr': 'Succès!',
      'it': 'Successo!',
      'pl': 'Powodzenie!',
    },
    '74wghh7u': {
      'en': 'Failed to upload data',
      'de': 'Daten konnten nicht hochgeladen werden',
      'es': 'Error al cargar datos',
      'fr': 'Échec du téléchargement des données',
      'it': 'Impossibile caricare i dati',
      'pl': 'Nie udało się przesłać danych',
    },
    '0odajbey': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'rmdab7fg': {
      'en': 'Choose source',
      'de': 'Quelle wählen',
      'es': 'Elige la fuente',
      'fr': 'Choisissez la source',
      'it': 'Scegli la fonte',
      'pl': 'Wybierz źródło',
    },
    'xab1oqc1': {
      'en': 'Gallery',
      'de': 'Galerie',
      'es': 'Galería',
      'fr': 'Galerie',
      'it': 'Galleria',
      'pl': 'Galeria',
    },
    'oupwm0fe': {
      'en': 'Gallery (Photo)',
      'de': 'Galerie (Foto)',
      'es': 'Galería (Foto)',
      'fr': 'Galerie (Photos)',
      'it': 'Galleria (foto)',
      'pl': 'Galeria (zdjęcia)',
    },
    'gumm9wf5': {
      'en': 'Gallery (Video)',
      'de': 'Galerie (Video)',
      'es': 'Galería (Vídeo)',
      'fr': 'Galerie (Vidéo)',
      'it': 'Galleria (Video)',
      'pl': 'Galeria (wideo)',
    },
    'vuxnxwsk': {
      'en': 'Camera',
      'de': 'Kamera',
      'es': 'Cámara',
      'fr': 'Caméra',
      'it': 'Telecamera',
      'pl': 'Kamera',
    },
    '54wl40hl': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'vq49qtmb': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    'gb4j7f4y': {
      'en': '',
      'de': '',
      'es': '',
      'fr': '',
      'it': '',
      'pl': '',
    },
    '3j5a7rkr': {
      'en': 'Error',
      'de': 'Error',
      'es': 'Error',
      'fr': 'Error',
      'it': 'Error',
      'pl': 'Error',
    },
  },
].reduce((a, b) => a..addAll(b));
