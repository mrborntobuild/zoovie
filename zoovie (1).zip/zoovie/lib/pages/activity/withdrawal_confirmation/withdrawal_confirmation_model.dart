import '/flutter_flow/flutter_flow_util.dart';
import 'withdrawal_confirmation_widget.dart' show WithdrawalConfirmationWidget;
import 'package:flutter/material.dart';

class WithdrawalConfirmationModel
    extends FlutterFlowModel<WithdrawalConfirmationWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
