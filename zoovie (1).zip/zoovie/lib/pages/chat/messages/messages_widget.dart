import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/components/image_message_receiver/image_message_receiver_widget.dart';
import '/pages/components/image_message_sender/image_message_sender_widget.dart';
import '/pages/components/message_deleted_receiver/message_deleted_receiver_widget.dart';
import '/pages/components/message_deleted_sender/message_deleted_sender_widget.dart';
import '/pages/components/message_emoji/message_emoji_widget.dart';
import '/pages/components/reactions/reactions_widget.dart';
import '/pages/components/replied_receiver/replied_receiver_widget.dart';
import '/pages/components/replied_sender/replied_sender_widget.dart';
import '/pages/components/reply/reply_widget.dart';
import '/pages/components/text_image_message_receiver/text_image_message_receiver_widget.dart';
import '/pages/components/text_image_message_sender/text_image_message_sender_widget.dart';
import '/pages/components/text_message_reveiver/text_message_reveiver_widget.dart';
import '/pages/components/text_message_sender/text_message_sender_widget.dart';
import '/pages/components/voice_message_receiver/voice_message_receiver_widget.dart';
import '/pages/components/voice_message_sender/voice_message_sender_widget.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import 'package:record/record.dart';
import 'messages_model.dart';
export 'messages_model.dart';

class MessagesWidget extends StatefulWidget {
  const MessagesWidget({
    super.key,
    required this.chatReference,
  });

  final DocumentReference? chatReference;

  @override
  State<MessagesWidget> createState() => _MessagesWidgetState();
}

class _MessagesWidgetState extends State<MessagesWidget> {
  late MessagesModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MessagesModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      await widget.chatReference!.update({
        ...mapToFirestore(
          {
            'seen_by': FieldValue.arrayUnion([currentUserReference]),
          },
        ),
      });
    });

    _model.textController ??= TextEditingController();
    _model.textFieldFocusNode ??= FocusNode();
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return StreamBuilder<ChatsRecord>(
      stream: ChatsRecord.getDocument(widget.chatReference!),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
            body: Center(
              child: SizedBox(
                width: 20.0,
                height: 20.0,
                child: SpinKitCircle(
                  color: FlutterFlowTheme.of(context).greyButtonLine,
                  size: 20.0,
                ),
              ),
            ),
          );
        }
        final messagesChatsRecord = snapshot.data!;
        return GestureDetector(
          onTap: () => _model.unfocusNode.canRequestFocus
              ? FocusScope.of(context).requestFocus(_model.unfocusNode)
              : FocusScope.of(context).unfocus(),
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
            appBar: PreferredSize(
              preferredSize: const Size.fromHeight(50.0),
              child: AppBar(
                backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
                automaticallyImplyLeading: false,
                title: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        final firestoreBatch =
                            FirebaseFirestore.instance.batch();
                        try {
                          firestoreBatch.update(widget.chatReference!, {
                            ...mapToFirestore(
                              {
                                'seen_by': FieldValue.arrayUnion(
                                    [currentUserReference]),
                              },
                            ),
                          });

                          firestoreBatch.update(
                              currentUserReference!,
                              createUsersRecordData(
                                newMessage: false,
                              ));
                          FFAppState().update(() {
                            FFAppState().messageReaction = false;
                            FFAppState().replyImageUrl = '';
                          });
                          context.safePop();
                        } finally {
                          await firestoreBatch.commit();
                        }
                      },
                      child: Container(
                        width: 50.0,
                        height: 35.0,
                        decoration: const BoxDecoration(),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SvgPicture.asset(
                              'assets/images/Alt_Arrow_Linear_Left_White.svg',
                              width: 22.0,
                              height: 22.0,
                              fit: BoxFit.cover,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                      child: StreamBuilder<UsersRecord>(
                        stream: UsersRecord.getDocument(
                            messagesChatsRecord.userA == currentUserReference
                                ? messagesChatsRecord.userB!
                                : messagesChatsRecord.userA!),
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 20.0,
                                height: 20.0,
                                child: SpinKitCircle(
                                  color: FlutterFlowTheme.of(context)
                                      .greyButtonLine,
                                  size: 20.0,
                                ),
                              ),
                            );
                          }
                          final rowUsersRecord = snapshot.data!;
                          return InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              context.pushNamed(
                                'publicProfile',
                                queryParameters: {
                                  'userReference': serializeParam(
                                    rowUsersRecord.reference,
                                    ParamType.DocumentReference,
                                  ),
                                }.withoutNulls,
                              );

                              FFAppState().messageReaction = false;
                              FFAppState().replyImageUrl = '';
                            },
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(50.0),
                                  child: CachedNetworkImage(
                                    fadeInDuration: const Duration(milliseconds: 500),
                                    fadeOutDuration:
                                        const Duration(milliseconds: 500),
                                    imageUrl: valueOrDefault<String>(
                                      rowUsersRecord.photoUrl,
                                      'https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/beneree-t2ym3b/assets/ka2n03qkats7/User_Placeholder_Empty.jpg',
                                    ),
                                    width: 38.0,
                                    height: 38.0,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsetsDirectional.fromSTEB(
                                        10.0, 0.0, 0.0, 0.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            Text(
                                              rowUsersRecord.displayName,
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Inter',
                                                        fontSize: 15.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                      ),
                                            ),
                                            if (rowUsersRecord.premiumAccount ==
                                                true)
                                              Padding(
                                                padding: const EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        3.0, 0.0, 0.0, 0.0),
                                                child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                  child: SvgPicture.asset(
                                                    'assets/images/Signed.svg',
                                                    width: 13.0,
                                                    height: 13.0,
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              ),
                                          ],
                                        ),
                                        RichText(
                                          textScaler:
                                              MediaQuery.of(context).textScaler,
                                          text: TextSpan(
                                            children: [
                                              TextSpan(
                                                text:
                                                    rowUsersRecord.displayName,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Inter',
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondaryText,
                                                          fontSize: 12.0,
                                                          letterSpacing: 0.0,
                                                        ),
                                              )
                                            ],
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Inter',
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .secondaryText,
                                                  fontSize: 13.0,
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                          maxLines: 1,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                    Container(
                      width: 50.0,
                      height: 35.0,
                      decoration: const BoxDecoration(),
                      child: const Align(
                        alignment: AlignmentDirectional(0.0, 0.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [],
                        ),
                      ),
                    ),
                  ],
                ),
                actions: const [],
                centerTitle: false,
                elevation: 0.0,
              ),
            ),
            body: SafeArea(
              top: true,
              child: Stack(
                children: [
                  Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Container(
                        width: double.infinity,
                        height: 1.0,
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                        ),
                      ),
                      Expanded(
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color:
                                FlutterFlowTheme.of(context).primaryBackground,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Expanded(
                                child: Container(
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .primaryBackground,
                                  ),
                                  child:
                                      StreamBuilder<List<ChatMessagesRecord>>(
                                    stream: queryChatMessagesRecord(
                                      queryBuilder: (chatMessagesRecord) =>
                                          chatMessagesRecord
                                              .where(
                                                'chat',
                                                isEqualTo: widget.chatReference,
                                              )
                                              .orderBy('time',
                                                  descending: true),
                                    ),
                                    builder: (context, snapshot) {
                                      // Customize what your widget looks like when it's loading.
                                      if (!snapshot.hasData) {
                                        return Center(
                                          child: SizedBox(
                                            width: 30.0,
                                            height: 30.0,
                                            child: SpinKitCircle(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .greyButtonLine,
                                              size: 30.0,
                                            ),
                                          ),
                                        );
                                      }
                                      List<ChatMessagesRecord>
                                          listViewChatMessagesRecordList =
                                          snapshot.data!;
                                      return ListView.builder(
                                        padding: const EdgeInsets.fromLTRB(
                                          0,
                                          0,
                                          0,
                                          7.0,
                                        ),
                                        reverse: true,
                                        scrollDirection: Axis.vertical,
                                        itemCount:
                                            listViewChatMessagesRecordList
                                                .length,
                                        itemBuilder: (context, listViewIndex) {
                                          final listViewChatMessagesRecord =
                                              listViewChatMessagesRecordList[
                                                  listViewIndex];
                                          return Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              if (listViewChatMessagesRecord
                                                      .user ==
                                                  currentUserReference)
                                                Padding(
                                                  padding: const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          15.0, 0.0, 15.0, 0.0),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.end,
                                                    children: [
                                                      Container(
                                                        decoration:
                                                            const BoxDecoration(),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .end,
                                                          children: [
                                                            if (listViewChatMessagesRecord
                                                                    .textMessage &&
                                                                !listViewChatMessagesRecord
                                                                    .deleted &&
                                                                !listViewChatMessagesRecord
                                                                    .reply)
                                                              InkWell(
                                                                splashColor: Colors
                                                                    .transparent,
                                                                focusColor: Colors
                                                                    .transparent,
                                                                hoverColor: Colors
                                                                    .transparent,
                                                                highlightColor:
                                                                    Colors
                                                                        .transparent,
                                                                onLongPress:
                                                                    () async {
                                                                  HapticFeedback
                                                                      .mediumImpact();
                                                                  FFAppState()
                                                                      .update(
                                                                          () {
                                                                    FFAppState()
                                                                            .messageReaction =
                                                                        true;
                                                                    FFAppState()
                                                                            .messageFocusText =
                                                                        listViewChatMessagesRecord
                                                                            .message;
                                                                    FFAppState()
                                                                            .messageFocusColor =
                                                                        true;
                                                                    FFAppState()
                                                                            .currentChatReference =
                                                                        messagesChatsRecord
                                                                            .reference;
                                                                    FFAppState()
                                                                            .replyPostOwner =
                                                                        listViewChatMessagesRecord
                                                                            .user;
                                                                    FFAppState()
                                                                            .messageReference =
                                                                        listViewChatMessagesRecord
                                                                            .reference;
                                                                  });
                                                                },
                                                                child:
                                                                    TextMessageSenderWidget(
                                                                  key: Key(
                                                                      'Keyxtu_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                                  parameter1:
                                                                      listViewChatMessagesRecord
                                                                          .message,
                                                                  parameter2:
                                                                      dateTimeFormat(
                                                                    'Hm',
                                                                    listViewChatMessagesRecord
                                                                        .time!,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  ),
                                                                ),
                                                              ),
                                                            if (listViewChatMessagesRecord
                                                                    .imageMessage &&
                                                                !listViewChatMessagesRecord
                                                                    .deleted &&
                                                                (listViewChatMessagesRecord
                                                                            .message !=
                                                                        ''))
                                                              InkWell(
                                                                splashColor: Colors
                                                                    .transparent,
                                                                focusColor: Colors
                                                                    .transparent,
                                                                hoverColor: Colors
                                                                    .transparent,
                                                                highlightColor:
                                                                    Colors
                                                                        .transparent,
                                                                onLongPress:
                                                                    () async {
                                                                  HapticFeedback
                                                                      .mediumImpact();
                                                                  FFAppState()
                                                                      .update(
                                                                          () {
                                                                    FFAppState()
                                                                            .messageReaction =
                                                                        true;
                                                                    FFAppState()
                                                                            .messageFocusText =
                                                                        listViewChatMessagesRecord
                                                                            .message;
                                                                    FFAppState()
                                                                            .messageFocusColor =
                                                                        true;
                                                                    FFAppState()
                                                                            .currentChatReference =
                                                                        messagesChatsRecord
                                                                            .reference;
                                                                    FFAppState()
                                                                            .replyPostOwner =
                                                                        listViewChatMessagesRecord
                                                                            .user;
                                                                    FFAppState()
                                                                            .messageReference =
                                                                        listViewChatMessagesRecord
                                                                            .reference;
                                                                    FFAppState()
                                                                            .replyImageUrl =
                                                                        listViewChatMessagesRecord
                                                                            .chatImage;
                                                                  });
                                                                },
                                                                child:
                                                                    TextImageMessageSenderWidget(
                                                                  key: Key(
                                                                      'Keyrrm_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                                  parameter1:
                                                                      listViewChatMessagesRecord
                                                                          .chatImage,
                                                                  parameter2:
                                                                      listViewChatMessagesRecord
                                                                          .message,
                                                                  parameter3:
                                                                      dateTimeFormat(
                                                                    'Hm',
                                                                    listViewChatMessagesRecord
                                                                        .time!,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  ),
                                                                ),
                                                              ),
                                                            if (listViewChatMessagesRecord
                                                                    .imageMessage &&
                                                                !listViewChatMessagesRecord
                                                                    .deleted &&
                                                                (listViewChatMessagesRecord
                                                                            .message ==
                                                                        ''))
                                                              InkWell(
                                                                splashColor: Colors
                                                                    .transparent,
                                                                focusColor: Colors
                                                                    .transparent,
                                                                hoverColor: Colors
                                                                    .transparent,
                                                                highlightColor:
                                                                    Colors
                                                                        .transparent,
                                                                onLongPress:
                                                                    () async {
                                                                  HapticFeedback
                                                                      .mediumImpact();
                                                                  FFAppState()
                                                                      .update(
                                                                          () {
                                                                    FFAppState()
                                                                            .messageReaction =
                                                                        true;
                                                                    FFAppState()
                                                                            .messageFocusText =
                                                                        listViewChatMessagesRecord
                                                                            .message;
                                                                    FFAppState()
                                                                            .messageFocusColor =
                                                                        true;
                                                                    FFAppState()
                                                                            .currentChatReference =
                                                                        messagesChatsRecord
                                                                            .reference;
                                                                    FFAppState()
                                                                            .replyPostOwner =
                                                                        listViewChatMessagesRecord
                                                                            .user;
                                                                    FFAppState()
                                                                            .messageReference =
                                                                        listViewChatMessagesRecord
                                                                            .reference;
                                                                    FFAppState()
                                                                            .replyImageUrl =
                                                                        listViewChatMessagesRecord
                                                                            .chatImage;
                                                                  });
                                                                },
                                                                child:
                                                                    ImageMessageSenderWidget(
                                                                  key: Key(
                                                                      'Keyqzv_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                                  parameter1:
                                                                      listViewChatMessagesRecord
                                                                          .chatImage,
                                                                ),
                                                              ),
                                                            if (listViewChatMessagesRecord
                                                                .deleted)
                                                              MessageDeletedSenderWidget(
                                                                key: Key(
                                                                    'Key6d4_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                              ),
                                                            if (listViewChatMessagesRecord
                                                                    .reply &&
                                                                !listViewChatMessagesRecord
                                                                    .deleted)
                                                              InkWell(
                                                                splashColor: Colors
                                                                    .transparent,
                                                                focusColor: Colors
                                                                    .transparent,
                                                                hoverColor: Colors
                                                                    .transparent,
                                                                highlightColor:
                                                                    Colors
                                                                        .transparent,
                                                                onLongPress:
                                                                    () async {
                                                                  HapticFeedback
                                                                      .mediumImpact();
                                                                  FFAppState()
                                                                      .update(
                                                                          () {
                                                                    FFAppState()
                                                                            .messageReaction =
                                                                        true;
                                                                    FFAppState()
                                                                            .messageFocusText =
                                                                        listViewChatMessagesRecord
                                                                            .message;
                                                                    FFAppState()
                                                                            .messageFocusColor =
                                                                        true;
                                                                    FFAppState()
                                                                            .currentChatReference =
                                                                        messagesChatsRecord
                                                                            .reference;
                                                                    FFAppState()
                                                                            .replyPostOwner =
                                                                        listViewChatMessagesRecord
                                                                            .user;
                                                                    FFAppState()
                                                                            .messageReference =
                                                                        listViewChatMessagesRecord
                                                                            .reference;
                                                                  });
                                                                },
                                                                child:
                                                                    RepliedSenderWidget(
                                                                  key: Key(
                                                                      'Key4k6_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                                  parameter1:
                                                                      listViewChatMessagesRecord
                                                                          .replyPostOwner,
                                                                  parameter2:
                                                                      listViewChatMessagesRecord
                                                                          .repliedToMessage,
                                                                  parameter3:
                                                                      listViewChatMessagesRecord
                                                                          .chatImage,
                                                                  parameter4:
                                                                      listViewChatMessagesRecord
                                                                          .message,
                                                                  parameter5:
                                                                      dateTimeFormat(
                                                                    'Hm',
                                                                    listViewChatMessagesRecord
                                                                        .time!,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  ),
                                                                ),
                                                              ),
                                                            if (listViewChatMessagesRecord
                                                                    .voice &&
                                                                !listViewChatMessagesRecord
                                                                    .deleted)
                                                              VoiceMessageSenderWidget(
                                                                key: Key(
                                                                    'Keydlg_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                                parameter1:
                                                                    listViewChatMessagesRecord
                                                                        .user,
                                                                parameter2:
                                                                    listViewChatMessagesRecord
                                                                        .reference,
                                                                parameter3:
                                                                    listViewChatMessagesRecord
                                                                        .voiceMessage,
                                                                parameter4:
                                                                    dateTimeFormat(
                                                                  'Hm',
                                                                  listViewChatMessagesRecord
                                                                      .time!,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                ),
                                                                parameter5:
                                                                    listViewChatMessagesRecord
                                                                        .voice,
                                                              ),
                                                            ReactionsWidget(
                                                              key: Key(
                                                                  'Keyh60_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                              parameter1:
                                                                  listViewChatMessagesRecord
                                                                      .love
                                                                      .length,
                                                              parameter2:
                                                                  listViewChatMessagesRecord
                                                                      .thumb
                                                                      .length,
                                                              parameter3:
                                                                  listViewChatMessagesRecord
                                                                      .laugh
                                                                      .length,
                                                              parameter4:
                                                                  listViewChatMessagesRecord
                                                                      .fire
                                                                      .length,
                                                              parameter5:
                                                                  listViewChatMessagesRecord
                                                                      .thankyou
                                                                      .length,
                                                              parameter6:
                                                                  listViewChatMessagesRecord
                                                                      .sad
                                                                      .length,
                                                            ),
                                                          ]
                                                              .divide(const SizedBox(
                                                                  height: 2.0))
                                                              .addToEnd(
                                                                  const SizedBox(
                                                                      height:
                                                                          2.0)),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              if (listViewChatMessagesRecord
                                                      .user !=
                                                  currentUserReference)
                                                Padding(
                                                  padding: const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          15.0, 0.0, 15.0, 0.0),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        decoration:
                                                            const BoxDecoration(),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            if (listViewChatMessagesRecord
                                                                    .textMessage &&
                                                                !listViewChatMessagesRecord
                                                                    .deleted &&
                                                                !listViewChatMessagesRecord
                                                                    .reply)
                                                              InkWell(
                                                                splashColor: Colors
                                                                    .transparent,
                                                                focusColor: Colors
                                                                    .transparent,
                                                                hoverColor: Colors
                                                                    .transparent,
                                                                highlightColor:
                                                                    Colors
                                                                        .transparent,
                                                                onLongPress:
                                                                    () async {
                                                                  HapticFeedback
                                                                      .mediumImpact();
                                                                  FFAppState()
                                                                      .update(
                                                                          () {
                                                                    FFAppState()
                                                                            .messageReaction =
                                                                        true;
                                                                    FFAppState()
                                                                            .messageFocusText =
                                                                        listViewChatMessagesRecord
                                                                            .message;
                                                                    FFAppState()
                                                                            .messageFocusColor =
                                                                        false;
                                                                    FFAppState()
                                                                            .currentChatReference =
                                                                        messagesChatsRecord
                                                                            .reference;
                                                                    FFAppState()
                                                                            .replyPostOwner =
                                                                        listViewChatMessagesRecord
                                                                            .user;
                                                                    FFAppState()
                                                                            .messageReference =
                                                                        listViewChatMessagesRecord
                                                                            .reference;
                                                                  });
                                                                },
                                                                child:
                                                                    TextMessageReveiverWidget(
                                                                  key: Key(
                                                                      'Keywl5_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                                  parameter1:
                                                                      listViewChatMessagesRecord
                                                                          .message,
                                                                  parameter2:
                                                                      dateTimeFormat(
                                                                    'Hm',
                                                                    listViewChatMessagesRecord
                                                                        .time!,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  ),
                                                                ),
                                                              ),
                                                            if (listViewChatMessagesRecord
                                                                    .imageMessage &&
                                                                !listViewChatMessagesRecord
                                                                    .deleted &&
                                                                (listViewChatMessagesRecord
                                                                            .message !=
                                                                        ''))
                                                              InkWell(
                                                                splashColor: Colors
                                                                    .transparent,
                                                                focusColor: Colors
                                                                    .transparent,
                                                                hoverColor: Colors
                                                                    .transparent,
                                                                highlightColor:
                                                                    Colors
                                                                        .transparent,
                                                                onLongPress:
                                                                    () async {
                                                                  HapticFeedback
                                                                      .mediumImpact();
                                                                  FFAppState()
                                                                      .update(
                                                                          () {
                                                                    FFAppState()
                                                                            .messageReaction =
                                                                        true;
                                                                    FFAppState()
                                                                            .messageFocusText =
                                                                        listViewChatMessagesRecord
                                                                            .message;
                                                                    FFAppState()
                                                                            .messageFocusColor =
                                                                        false;
                                                                    FFAppState()
                                                                            .currentChatReference =
                                                                        messagesChatsRecord
                                                                            .reference;
                                                                    FFAppState()
                                                                            .replyPostOwner =
                                                                        listViewChatMessagesRecord
                                                                            .user;
                                                                    FFAppState()
                                                                            .messageReference =
                                                                        listViewChatMessagesRecord
                                                                            .reference;
                                                                    FFAppState()
                                                                            .replyImageUrl =
                                                                        listViewChatMessagesRecord
                                                                            .chatImage;
                                                                  });
                                                                },
                                                                child:
                                                                    TextImageMessageReceiverWidget(
                                                                  key: Key(
                                                                      'Key7c7_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                                  parameter1:
                                                                      listViewChatMessagesRecord
                                                                          .chatImage,
                                                                  parameter2:
                                                                      listViewChatMessagesRecord
                                                                          .message,
                                                                  parameter3:
                                                                      dateTimeFormat(
                                                                    'Hm',
                                                                    listViewChatMessagesRecord
                                                                        .time!,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  ),
                                                                ),
                                                              ),
                                                            if (listViewChatMessagesRecord
                                                                    .imageMessage &&
                                                                !listViewChatMessagesRecord
                                                                    .deleted &&
                                                                (listViewChatMessagesRecord
                                                                            .message ==
                                                                        ''))
                                                              InkWell(
                                                                splashColor: Colors
                                                                    .transparent,
                                                                focusColor: Colors
                                                                    .transparent,
                                                                hoverColor: Colors
                                                                    .transparent,
                                                                highlightColor:
                                                                    Colors
                                                                        .transparent,
                                                                onLongPress:
                                                                    () async {
                                                                  HapticFeedback
                                                                      .mediumImpact();
                                                                  FFAppState()
                                                                      .update(
                                                                          () {
                                                                    FFAppState()
                                                                            .messageReaction =
                                                                        true;
                                                                    FFAppState()
                                                                            .messageFocusText =
                                                                        listViewChatMessagesRecord
                                                                            .message;
                                                                    FFAppState()
                                                                            .messageFocusColor =
                                                                        false;
                                                                    FFAppState()
                                                                            .currentChatReference =
                                                                        messagesChatsRecord
                                                                            .reference;
                                                                    FFAppState()
                                                                            .replyPostOwner =
                                                                        listViewChatMessagesRecord
                                                                            .user;
                                                                    FFAppState()
                                                                            .messageReference =
                                                                        listViewChatMessagesRecord
                                                                            .reference;
                                                                    FFAppState()
                                                                            .replyImageUrl =
                                                                        listViewChatMessagesRecord
                                                                            .chatImage;
                                                                  });
                                                                },
                                                                child:
                                                                    ImageMessageReceiverWidget(
                                                                  key: Key(
                                                                      'Keyloz_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                                  parameter1:
                                                                      listViewChatMessagesRecord
                                                                          .chatImage,
                                                                ),
                                                              ),
                                                            if (listViewChatMessagesRecord
                                                                .deleted)
                                                              MessageDeletedReceiverWidget(
                                                                key: Key(
                                                                    'Keyl6u_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                              ),
                                                            if (listViewChatMessagesRecord
                                                                    .reply &&
                                                                !listViewChatMessagesRecord
                                                                    .deleted)
                                                              InkWell(
                                                                splashColor: Colors
                                                                    .transparent,
                                                                focusColor: Colors
                                                                    .transparent,
                                                                hoverColor: Colors
                                                                    .transparent,
                                                                highlightColor:
                                                                    Colors
                                                                        .transparent,
                                                                onLongPress:
                                                                    () async {
                                                                  HapticFeedback
                                                                      .mediumImpact();
                                                                  FFAppState()
                                                                      .update(
                                                                          () {
                                                                    FFAppState()
                                                                            .messageReaction =
                                                                        true;
                                                                    FFAppState()
                                                                            .messageFocusText =
                                                                        listViewChatMessagesRecord
                                                                            .message;
                                                                    FFAppState()
                                                                            .messageFocusColor =
                                                                        false;
                                                                    FFAppState()
                                                                            .currentChatReference =
                                                                        messagesChatsRecord
                                                                            .reference;
                                                                    FFAppState()
                                                                            .replyPostOwner =
                                                                        listViewChatMessagesRecord
                                                                            .user;
                                                                    FFAppState()
                                                                            .messageReference =
                                                                        listViewChatMessagesRecord
                                                                            .reference;
                                                                  });
                                                                },
                                                                child:
                                                                    RepliedReceiverWidget(
                                                                  key: Key(
                                                                      'Keywey_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                                  parameter2:
                                                                      listViewChatMessagesRecord
                                                                          .repliedToMessage,
                                                                  parameter3:
                                                                      listViewChatMessagesRecord
                                                                          .chatImage,
                                                                  parameter4:
                                                                      listViewChatMessagesRecord
                                                                          .message,
                                                                  parameter5:
                                                                      dateTimeFormat(
                                                                    'Hm',
                                                                    listViewChatMessagesRecord
                                                                        .time!,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  ),
                                                                  parameter1:
                                                                      listViewChatMessagesRecord
                                                                          .replyPostOwner,
                                                                ),
                                                              ),
                                                            if (listViewChatMessagesRecord
                                                                    .voice &&
                                                                !listViewChatMessagesRecord
                                                                    .deleted)
                                                              VoiceMessageReceiverWidget(
                                                                key: Key(
                                                                    'Keyyyw_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                                parameter3:
                                                                    listViewChatMessagesRecord
                                                                        .voiceMessage,
                                                                parameter4:
                                                                    dateTimeFormat(
                                                                  'Hm',
                                                                  listViewChatMessagesRecord
                                                                      .time!,
                                                                  locale: FFLocalizations.of(
                                                                          context)
                                                                      .languageCode,
                                                                ),
                                                                parameter5:
                                                                    listViewChatMessagesRecord
                                                                        .voice,
                                                                parameter1:
                                                                    listViewChatMessagesRecord
                                                                        .user,
                                                                parameter2:
                                                                    listViewChatMessagesRecord
                                                                        .reference,
                                                              ),
                                                            ReactionsWidget(
                                                              key: Key(
                                                                  'Key6q0_${listViewIndex}_of_${listViewChatMessagesRecordList.length}'),
                                                              parameter1:
                                                                  listViewChatMessagesRecord
                                                                      .love
                                                                      .length,
                                                              parameter2:
                                                                  listViewChatMessagesRecord
                                                                      .thumb
                                                                      .length,
                                                              parameter3:
                                                                  listViewChatMessagesRecord
                                                                      .laugh
                                                                      .length,
                                                              parameter4:
                                                                  listViewChatMessagesRecord
                                                                      .fire
                                                                      .length,
                                                              parameter5:
                                                                  listViewChatMessagesRecord
                                                                      .thankyou
                                                                      .length,
                                                              parameter6:
                                                                  listViewChatMessagesRecord
                                                                      .sad
                                                                      .length,
                                                            ),
                                                          ]
                                                              .divide(const SizedBox(
                                                                  height: 2.0))
                                                              .addToEnd(
                                                                  const SizedBox(
                                                                      height:
                                                                          2.0)),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                            ].divide(const SizedBox(height: 5.0)),
                                          );
                                        },
                                      );
                                    },
                                  ),
                                ),
                              ),
                              if (FFAppState().replyComponent)
                                Container(
                                  width: double.infinity,
                                  height: 50.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: wrapWithModel(
                                    model: _model.replyModel,
                                    updateCallback: () => setState(() {}),
                                    child: const ReplyWidget(),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                        ),
                        child: Stack(
                          children: [
                            if (FFAppState().voiceMessage)
                              Align(
                                alignment: const AlignmentDirectional(0.0, 0.0),
                                child: Padding(
                                  padding: const EdgeInsetsDirectional.fromSTEB(
                                      12.0, 0.0, 12.0, 0.0),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          setState(() {
                                            FFAppState().voiceMessage = false;
                                          });
                                        },
                                        child: Text(
                                          FFLocalizations.of(context).getText(
                                            'p1c9d6cp' /* Cancel */,
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .buttonBlue,
                                                fontSize: 16.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.w500,
                                              ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Padding(
                                          padding:
                                              const EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 5.0, 15.0, 5.0),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Expanded(
                                                child: Lottie.asset(
                                                  'assets/lottie_animations/Animation_-_1689156849445.json',
                                                  height: 22.0,
                                                  fit: BoxFit.fill,
                                                  animate: true,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsetsDirectional.fromSTEB(
                                            7.0, 2.0, 0.0, 2.0),
                                        child: StreamBuilder<ChatsRecord>(
                                          stream: ChatsRecord.getDocument(
                                              widget.chatReference!),
                                          builder: (context, snapshot) {
                                            // Customize what your widget looks like when it's loading.
                                            if (!snapshot.hasData) {
                                              return Center(
                                                child: SizedBox(
                                                  width: 20.0,
                                                  height: 20.0,
                                                  child: SpinKitCircle(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .greyButtonLine,
                                                    size: 20.0,
                                                  ),
                                                ),
                                              );
                                            }
                                            final messageChatsRecord =
                                                snapshot.data!;
                                            return InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  HapticFeedback.mediumImpact();
                                                  await stopAudioRecording(
                                                    audioRecorder:
                                                        _model.audioRecorder,
                                                    audioName:
                                                        'recordedFileBytes.mp3',
                                                    onRecordingComplete:
                                                        (audioFilePath,
                                                            audioBytes) {
                                                      _model.newVoiceMessage =
                                                          audioFilePath;
                                                      _model.recordedFileBytes =
                                                          audioBytes;
                                                    },
                                                  );

                                                  FFAppState().update(() {
                                                    FFAppState().recordedFile =
                                                        _model.newVoiceMessage!;
                                                  });

                                                  firestoreBatch.set(
                                                      ChatMessagesRecord
                                                          .collection
                                                          .doc(),
                                                      createChatMessagesRecordData(
                                                        user:
                                                            currentUserReference,
                                                        chat: widget
                                                            .chatReference,
                                                        message: _model
                                                            .textController
                                                            .text,
                                                        time:
                                                            getCurrentTimestamp,
                                                        voiceMessage: _model
                                                            .newVoiceMessage,
                                                        voice: true,
                                                      ));

                                                  firestoreBatch.update(
                                                      widget.chatReference!, {
                                                    ...createChatsRecordData(
                                                      lastMessage:
                                                          '🎙️ Voice message.',
                                                      time: getCurrentTimestamp,
                                                      lastMessageSentBy:
                                                          currentUserReference,
                                                    ),
                                                    ...mapToFirestore(
                                                      {
                                                        'seen_by': FieldValue
                                                            .arrayRemove([
                                                          messageChatsRecord
                                                                      .userA ==
                                                                  currentUserReference
                                                              ? messageChatsRecord
                                                                  .userB
                                                              : messageChatsRecord
                                                                  .userA
                                                        ]),
                                                      },
                                                    ),
                                                  });
                                                  if (messageChatsRecord
                                                          .userA ==
                                                      currentUserReference) {}
                                                  setState(() {
                                                    FFAppState().voiceMessage =
                                                        false;
                                                  });
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }

                                                setState(() {});
                                              },
                                              child: SvgPicture.asset(
                                                'assets/images/Send_Circle_Blue.svg',
                                                width: 33.0,
                                                height: 33.0,
                                                fit: BoxFit.cover,
                                              ),
                                            );
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            if (!FFAppState().voiceMessage)
                              Align(
                                alignment: const AlignmentDirectional(0.0, 0.0),
                                child: Padding(
                                  padding: const EdgeInsetsDirectional.fromSTEB(
                                      12.0, 0.0, 12.0, 0.0),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SvgPicture.asset(
                                        'assets/images/Plus_Linear_Blue.svg',
                                        width: 26.0,
                                        height: 26.0,
                                        fit: BoxFit.cover,
                                      ),
                                      Expanded(
                                        child: Padding(
                                          padding:
                                              const EdgeInsetsDirectional.fromSTEB(
                                                  8.0, 5.0, 0.0, 5.0),
                                          child: TextFormField(
                                            controller: _model.textController,
                                            focusNode:
                                                _model.textFieldFocusNode,
                                            onChanged: (_) =>
                                                EasyDebounce.debounce(
                                              '_model.textController',
                                              const Duration(milliseconds: 100),
                                              () => setState(() {}),
                                            ),
                                            autofocus: false,
                                            textCapitalization:
                                                TextCapitalization.sentences,
                                            obscureText: false,
                                            decoration: InputDecoration(
                                              isDense: true,
                                              enabledBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .alertLines,
                                                  width: 0.8,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(15.0),
                                              ),
                                              focusedBorder: OutlineInputBorder(
                                                borderSide: const BorderSide(
                                                  color: Color(0x00000000),
                                                  width: 0.8,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(15.0),
                                              ),
                                              errorBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .error,
                                                  width: 0.8,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(15.0),
                                              ),
                                              focusedErrorBorder:
                                                  OutlineInputBorder(
                                                borderSide: BorderSide(
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .error,
                                                  width: 0.8,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(15.0),
                                              ),
                                              filled: true,
                                              fillColor:
                                                  FlutterFlowTheme.of(context)
                                                      .greyButtonLine,
                                              contentPadding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          10.0, 9.0, 10.0, 6.0),
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Inter',
                                                  fontSize: 15.0,
                                                  letterSpacing: 0.0,
                                                ),
                                            maxLines: 5,
                                            minLines: 1,
                                            keyboardType:
                                                TextInputType.multiline,
                                            validator: _model
                                                .textControllerValidator
                                                .asValidator(context),
                                          ),
                                        ),
                                      ),
                                      if (_model.textController.text == '')
                                        Padding(
                                          padding:
                                              const EdgeInsetsDirectional.fromSTEB(
                                                  15.0, 6.0, 0.0, 6.0),
                                          child: InkWell(
                                            splashColor: Colors.transparent,
                                            focusColor: Colors.transparent,
                                            hoverColor: Colors.transparent,
                                            highlightColor: Colors.transparent,
                                            onTap: () async {
                                              context.pushNamed(
                                                'image_message',
                                                queryParameters: {
                                                  'chatReference':
                                                      serializeParam(
                                                    messagesChatsRecord
                                                        .reference,
                                                    ParamType.DocumentReference,
                                                  ),
                                                  'userA': serializeParam(
                                                    messagesChatsRecord.userA,
                                                    ParamType.DocumentReference,
                                                  ),
                                                  'userB': serializeParam(
                                                    messagesChatsRecord.userB,
                                                    ParamType.DocumentReference,
                                                  ),
                                                }.withoutNulls,
                                              );
                                            },
                                            child: SvgPicture.asset(
                                              'assets/images/Camera_Linear_Blue.svg',
                                              width: 26.0,
                                              height: 26.0,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                      if (currentUserReference !=
                                          currentUserReference)
                                        Padding(
                                          padding:
                                              const EdgeInsetsDirectional.fromSTEB(
                                                  15.0, 6.0, 0.0, 6.0),
                                          child: InkWell(
                                            splashColor: Colors.transparent,
                                            focusColor: Colors.transparent,
                                            hoverColor: Colors.transparent,
                                            highlightColor: Colors.transparent,
                                            onTap: () async {
                                              HapticFeedback.mediumImpact();
                                              setState(() {
                                                FFAppState().voiceMessage =
                                                    true;
                                              });
                                              await startAudioRecording(
                                                context,
                                                audioRecorder:
                                                    _model.audioRecorder ??=
                                                        AudioRecorder(),
                                              );
                                            },
                                            child: SvgPicture.asset(
                                              'assets/images/Record_Voice_Linear_Blue.svg',
                                              width: 26.0,
                                              height: 26.0,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                      Stack(
                                        children: [
                                          if (!FFAppState().replyComponent &&
                                              (_model.textController.text !=
                                                      ''))
                                            Padding(
                                              padding: const EdgeInsetsDirectional
                                                  .fromSTEB(7.0, 2.0, 0.0, 2.0),
                                              child: StreamBuilder<ChatsRecord>(
                                                stream: ChatsRecord.getDocument(
                                                    widget.chatReference!),
                                                builder: (context, snapshot) {
                                                  // Customize what your widget looks like when it's loading.
                                                  if (!snapshot.hasData) {
                                                    return Center(
                                                      child: SizedBox(
                                                        width: 20.0,
                                                        height: 20.0,
                                                        child: SpinKitCircle(
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .greyButtonLine,
                                                          size: 20.0,
                                                        ),
                                                      ),
                                                    );
                                                  }
                                                  final messageChatsRecord =
                                                      snapshot.data!;
                                                  return InkWell(
                                                    splashColor:
                                                        Colors.transparent,
                                                    focusColor:
                                                        Colors.transparent,
                                                    hoverColor:
                                                        Colors.transparent,
                                                    highlightColor:
                                                        Colors.transparent,
                                                    onTap: () async {
                                                      final firestoreBatch =
                                                          FirebaseFirestore
                                                              .instance
                                                              .batch();
                                                      try {
                                                        firestoreBatch.set(
                                                            ChatMessagesRecord
                                                                .collection
                                                                .doc(),
                                                            createChatMessagesRecordData(
                                                              user:
                                                                  currentUserReference,
                                                              chat: widget
                                                                  .chatReference,
                                                              message: _model
                                                                  .textController
                                                                  .text,
                                                              time:
                                                                  getCurrentTimestamp,
                                                              textMessage: true,
                                                            ));

                                                        firestoreBatch.update(
                                                            widget
                                                                .chatReference!,
                                                            {
                                                              ...createChatsRecordData(
                                                                lastMessage: _model
                                                                    .textController
                                                                    .text,
                                                                time:
                                                                    getCurrentTimestamp,
                                                                lastMessageSentBy:
                                                                    currentUserReference,
                                                              ),
                                                              ...mapToFirestore(
                                                                {
                                                                  'seen_by':
                                                                      FieldValue
                                                                          .arrayRemove([
                                                                    messageChatsRecord.userA ==
                                                                            currentUserReference
                                                                        ? messageChatsRecord
                                                                            .userB
                                                                        : messageChatsRecord
                                                                            .userA
                                                                  ]),
                                                                },
                                                              ),
                                                            });
                                                        if (messageChatsRecord
                                                                .userA ==
                                                            currentUserReference) {
                                                          firestoreBatch.update(
                                                              messageChatsRecord
                                                                  .userB!,
                                                              createUsersRecordData(
                                                                newMessage:
                                                                    true,
                                                              ));
                                                        } else {
                                                          firestoreBatch.update(
                                                              messageChatsRecord
                                                                  .userA!,
                                                              createUsersRecordData(
                                                                newMessage:
                                                                    true,
                                                              ));
                                                        }

                                                        setState(() {
                                                          _model.textController
                                                              ?.clear();
                                                        });
                                                      } finally {
                                                        await firestoreBatch
                                                            .commit();
                                                      }
                                                    },
                                                    child: SvgPicture.asset(
                                                      'assets/images/Send_Circle_Blue.svg',
                                                      width: 33.0,
                                                      height: 33.0,
                                                      fit: BoxFit.cover,
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                          if (FFAppState().replyComponent &&
                                              (_model.textController.text !=
                                                      ''))
                                            Padding(
                                              padding: const EdgeInsetsDirectional
                                                  .fromSTEB(7.0, 2.0, 0.0, 2.0),
                                              child: StreamBuilder<ChatsRecord>(
                                                stream: ChatsRecord.getDocument(
                                                    widget.chatReference!),
                                                builder: (context, snapshot) {
                                                  // Customize what your widget looks like when it's loading.
                                                  if (!snapshot.hasData) {
                                                    return Center(
                                                      child: SizedBox(
                                                        width: 20.0,
                                                        height: 20.0,
                                                        child: SpinKitCircle(
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .greyButtonLine,
                                                          size: 20.0,
                                                        ),
                                                      ),
                                                    );
                                                  }
                                                  final replyMessageChatsRecord =
                                                      snapshot.data!;
                                                  return InkWell(
                                                    splashColor:
                                                        Colors.transparent,
                                                    focusColor:
                                                        Colors.transparent,
                                                    hoverColor:
                                                        Colors.transparent,
                                                    highlightColor:
                                                        Colors.transparent,
                                                    onTap: () async {
                                                      final firestoreBatch =
                                                          FirebaseFirestore
                                                              .instance
                                                              .batch();
                                                      try {
                                                        firestoreBatch.set(
                                                            ChatMessagesRecord
                                                                .collection
                                                                .doc(),
                                                            createChatMessagesRecordData(
                                                              user:
                                                                  currentUserReference,
                                                              chat: widget
                                                                  .chatReference,
                                                              message: _model
                                                                  .textController
                                                                  .text,
                                                              time:
                                                                  getCurrentTimestamp,
                                                              textMessage: true,
                                                              chatImage:
                                                                  FFAppState()
                                                                      .replyImageUrl,
                                                              imageMessage:
                                                                  false,
                                                              deleted: false,
                                                              reply: true,
                                                              repliedToMessage:
                                                                  FFAppState()
                                                                      .messageFocusText,
                                                              replyPostOwner:
                                                                  FFAppState()
                                                                      .replyPostOwner,
                                                            ));

                                                        firestoreBatch.update(
                                                            widget
                                                                .chatReference!,
                                                            {
                                                              ...createChatsRecordData(
                                                                lastMessage: _model
                                                                    .textController
                                                                    .text,
                                                                time:
                                                                    getCurrentTimestamp,
                                                                lastMessageSentBy:
                                                                    currentUserReference,
                                                              ),
                                                              ...mapToFirestore(
                                                                {
                                                                  'seen_by':
                                                                      FieldValue
                                                                          .arrayRemove([
                                                                    replyMessageChatsRecord.userA ==
                                                                            currentUserReference
                                                                        ? replyMessageChatsRecord
                                                                            .userB
                                                                        : replyMessageChatsRecord
                                                                            .userA
                                                                  ]),
                                                                },
                                                              ),
                                                            });
                                                        setState(() {
                                                          FFAppState()
                                                              .replyImageUrl = '';
                                                          FFAppState()
                                                                  .replyComponent =
                                                              false;
                                                          FFAppState()
                                                                  .replyPostOwner =
                                                              null;
                                                        });
                                                        if (replyMessageChatsRecord
                                                                .userA ==
                                                            currentUserReference) {}
                                                        setState(() {
                                                          _model.textController
                                                              ?.clear();
                                                        });
                                                      } finally {
                                                        await firestoreBatch
                                                            .commit();
                                                      }
                                                    },
                                                    child: SvgPicture.asset(
                                                      'assets/images/Send_Circle_Blue.svg',
                                                      width: 33.0,
                                                      height: 33.0,
                                                      fit: BoxFit.cover,
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  if (FFAppState().messageReaction)
                    wrapWithModel(
                      model: _model.messageEmojiModel,
                      updateCallback: () => setState(() {}),
                      child: MessageEmojiWidget(
                        blueBubble: FFAppState().messageFocusColor,
                        messageText: FFAppState().messageFocusText,
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
