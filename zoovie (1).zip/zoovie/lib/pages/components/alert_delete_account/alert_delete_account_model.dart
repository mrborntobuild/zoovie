import '/flutter_flow/flutter_flow_util.dart';
import 'alert_delete_account_widget.dart' show AlertDeleteAccountWidget;
import 'package:flutter/material.dart';

class AlertDeleteAccountModel
    extends FlutterFlowModel<AlertDeleteAccountWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
