import '/flutter_flow/flutter_flow_util.dart';
import 'alert_delete_chat_widget.dart' show AlertDeleteChatWidget;
import 'package:flutter/material.dart';

class AlertDeleteChatModel extends FlutterFlowModel<AlertDeleteChatWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
