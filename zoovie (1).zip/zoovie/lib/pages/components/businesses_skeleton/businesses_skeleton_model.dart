import '/flutter_flow/flutter_flow_util.dart';
import 'businesses_skeleton_widget.dart' show BusinessesSkeletonWidget;
import 'package:flutter/material.dart';

class BusinessesSkeletonModel
    extends FlutterFlowModel<BusinessesSkeletonWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
