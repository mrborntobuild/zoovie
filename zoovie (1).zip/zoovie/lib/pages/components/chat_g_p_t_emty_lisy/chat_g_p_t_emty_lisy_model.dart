import '/flutter_flow/flutter_flow_util.dart';
import 'chat_g_p_t_emty_lisy_widget.dart' show ChatGPTEmtyLisyWidget;
import 'package:flutter/material.dart';

class ChatGPTEmtyLisyModel extends FlutterFlowModel<ChatGPTEmtyLisyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
