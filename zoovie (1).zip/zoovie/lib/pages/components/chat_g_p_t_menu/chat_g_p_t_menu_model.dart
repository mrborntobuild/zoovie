import '/flutter_flow/flutter_flow_util.dart';
import 'chat_g_p_t_menu_widget.dart' show ChatGPTMenuWidget;
import 'package:flutter/material.dart';

class ChatGPTMenuModel extends FlutterFlowModel<ChatGPTMenuWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
