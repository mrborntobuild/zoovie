import '/flutter_flow/flutter_flow_util.dart';
import 'comments_skeleton_single_widget.dart' show CommentsSkeletonSingleWidget;
import 'package:flutter/material.dart';

class CommentsSkeletonSingleModel
    extends FlutterFlowModel<CommentsSkeletonSingleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
