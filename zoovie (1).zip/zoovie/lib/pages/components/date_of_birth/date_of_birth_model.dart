import '/flutter_flow/flutter_flow_util.dart';
import 'date_of_birth_widget.dart' show DateOfBirthWidget;
import 'package:flutter/material.dart';

class DateOfBirthModel extends FlutterFlowModel<DateOfBirthWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
