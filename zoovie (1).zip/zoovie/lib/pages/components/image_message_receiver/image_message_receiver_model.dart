import '/flutter_flow/flutter_flow_util.dart';
import 'image_message_receiver_widget.dart' show ImageMessageReceiverWidget;
import 'package:flutter/material.dart';

class ImageMessageReceiverModel
    extends FlutterFlowModel<ImageMessageReceiverWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
