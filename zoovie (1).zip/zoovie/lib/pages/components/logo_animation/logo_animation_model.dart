import '/flutter_flow/flutter_flow_util.dart';
import 'logo_animation_widget.dart' show LogoAnimationWidget;
import 'package:flutter/material.dart';

class LogoAnimationModel extends FlutterFlowModel<LogoAnimationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
