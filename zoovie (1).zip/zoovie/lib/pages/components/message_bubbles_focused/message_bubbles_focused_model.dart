import '/flutter_flow/flutter_flow_util.dart';
import 'message_bubbles_focused_widget.dart' show MessageBubblesFocusedWidget;
import 'package:flutter/material.dart';

class MessageBubblesFocusedModel
    extends FlutterFlowModel<MessageBubblesFocusedWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
