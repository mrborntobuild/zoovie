import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'message_bubbles_focused_model.dart';
export 'message_bubbles_focused_model.dart';

class MessageBubblesFocusedWidget extends StatefulWidget {
  const MessageBubblesFocusedWidget({
    super.key,
    this.mesageText,
    this.blueBubble,
  });

  final String? mesageText;
  final bool? blueBubble;

  @override
  State<MessageBubblesFocusedWidget> createState() =>
      _MessageBubblesFocusedWidgetState();
}

class _MessageBubblesFocusedWidgetState
    extends State<MessageBubblesFocusedWidget> with TickerProviderStateMixin {
  late MessageBubblesFocusedModel _model;

  final animationsMap = <String, AnimationInfo>{};

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MessageBubblesFocusedModel());

    animationsMap.addAll({
      'containerOnPageLoadAnimation1': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          MoveEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 400.0.ms,
            begin: const Offset(300.0, 0.0),
            end: const Offset(0.0, 0.0),
          ),
        ],
      ),
      'imageOnPageLoadAnimation1': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 300.0.ms,
            duration: 200.0.ms,
            begin: const Offset(0.0, 0.0),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
      'imageOnPageLoadAnimation2': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 400.0.ms,
            duration: 200.0.ms,
            begin: const Offset(0.0, 0.0),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
      'imageOnPageLoadAnimation3': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 500.0.ms,
            duration: 200.0.ms,
            begin: const Offset(0.0, 0.0),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
      'imageOnPageLoadAnimation4': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 600.0.ms,
            duration: 200.0.ms,
            begin: const Offset(0.0, 0.0),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
      'imageOnPageLoadAnimation5': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 700.0.ms,
            duration: 200.0.ms,
            begin: const Offset(0.0, 0.0),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
      'imageOnPageLoadAnimation6': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 800.0.ms,
            duration: 200.0.ms,
            begin: const Offset(0.0, 0.0),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
      'containerOnPageLoadAnimation2': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          VisibilityEffect(duration: 400.ms),
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 400.0.ms,
            duration: 600.0.ms,
            begin: const Offset(0.8, 0.8),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
      'containerOnPageLoadAnimation3': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          MoveEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 400.0.ms,
            begin: const Offset(300.0, 0.0),
            end: const Offset(0.0, 0.0),
          ),
        ],
      ),
      'imageOnPageLoadAnimation7': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 300.0.ms,
            duration: 200.0.ms,
            begin: const Offset(0.0, 0.0),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
      'imageOnPageLoadAnimation8': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 400.0.ms,
            duration: 200.0.ms,
            begin: const Offset(0.0, 0.0),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
      'imageOnPageLoadAnimation9': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 500.0.ms,
            duration: 200.0.ms,
            begin: const Offset(0.0, 0.0),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
      'imageOnPageLoadAnimation10': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 600.0.ms,
            duration: 200.0.ms,
            begin: const Offset(0.0, 0.0),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
      'imageOnPageLoadAnimation11': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 700.0.ms,
            duration: 200.0.ms,
            begin: const Offset(0.0, 0.0),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
      'imageOnPageLoadAnimation12': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 800.0.ms,
            duration: 200.0.ms,
            begin: const Offset(0.0, 0.0),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
      'containerOnPageLoadAnimation4': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          VisibilityEffect(duration: 400.ms),
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 400.0.ms,
            duration: 600.0.ms,
            begin: const Offset(0.8, 0.8),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
    });
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return StreamBuilder<ChatMessagesRecord>(
      stream: ChatMessagesRecord.getDocument(FFAppState().messageReference!),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Center(
            child: SizedBox(
              width: 20.0,
              height: 20.0,
              child: SpinKitCircle(
                color: FlutterFlowTheme.of(context).greyButtonLine,
                size: 20.0,
              ),
            ),
          );
        }
        final containerChatMessagesRecord = snapshot.data!;
        return InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            FFAppState().update(() {
              FFAppState().messageReaction = false;
            });
          },
          child: Container(
            decoration: const BoxDecoration(),
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (!FFAppState().messageFocusColor)
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Align(
                          alignment: const AlignmentDirectional(-1.0, 0.0),
                          child: ClipRRect(
                            child: Container(
                              width: MediaQuery.sizeOf(context).width * 0.7,
                              decoration: const BoxDecoration(),
                              child: Align(
                                alignment: const AlignmentDirectional(-1.0, 0.0),
                                child: Padding(
                                  padding: const EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 10.0),
                                  child: Container(
                                    width:
                                        MediaQuery.sizeOf(context).width * 0.6,
                                    height: 50.0,
                                    decoration: BoxDecoration(
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryBackground,
                                      borderRadius: BorderRadius.circular(50.0),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsetsDirectional.fromSTEB(
                                          3.0, 0.0, 3.0, 0.0),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    2.0, 0.0, 2.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if (containerChatMessagesRecord
                                                      .love
                                                      .contains(
                                                          currentUserReference)) {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          -(1)),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  } else {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayUnion([
                                                                currentUserReference
                                                              ]),
                                                              'thumb': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'laugh': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'fire': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thankyou': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'sad': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          1),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(0.0),
                                                child: Image.asset(
                                                  'assets/images/image_258.png',
                                                  width: 28.0,
                                                  height: 28.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ).animateOnPageLoad(animationsMap[
                                                'imageOnPageLoadAnimation1']!),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    2.0, 0.0, 2.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if (containerChatMessagesRecord
                                                      .thumb
                                                      .contains(
                                                          currentUserReference)) {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          -(1)),
                                                              'thumb': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  } else {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thumb': FieldValue
                                                                  .arrayUnion([
                                                                currentUserReference
                                                              ]),
                                                              'laugh': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'fire': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thankyou': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'sad': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          1),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(0.0),
                                                child: Image.asset(
                                                  'assets/images/Thumb_Reaction.png',
                                                  width: 28.0,
                                                  height: 28.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ).animateOnPageLoad(animationsMap[
                                                'imageOnPageLoadAnimation2']!),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    2.0, 0.0, 2.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if (containerChatMessagesRecord
                                                      .laugh
                                                      .contains(
                                                          currentUserReference)) {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          -(1)),
                                                              'laugh': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  } else {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thumb': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'laugh': FieldValue
                                                                  .arrayUnion([
                                                                currentUserReference
                                                              ]),
                                                              'fire': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thankyou': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'sad': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          1),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(0.0),
                                                child: Image.asset(
                                                  'assets/images/Haha_Reaction.png',
                                                  width: 28.0,
                                                  height: 28.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ).animateOnPageLoad(animationsMap[
                                                'imageOnPageLoadAnimation3']!),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    2.0, 0.0, 2.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if (containerChatMessagesRecord
                                                      .fire
                                                      .contains(
                                                          currentUserReference)) {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          -(1)),
                                                              'fire': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  } else {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thumb': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'laugh': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'fire': FieldValue
                                                                  .arrayUnion([
                                                                currentUserReference
                                                              ]),
                                                              'thankyou': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'sad': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          1),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(0.0),
                                                child: Image.asset(
                                                  'assets/images/Fire_Reaction.png',
                                                  width: 28.0,
                                                  height: 28.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ).animateOnPageLoad(animationsMap[
                                                'imageOnPageLoadAnimation4']!),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    2.0, 0.0, 2.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if (containerChatMessagesRecord
                                                      .thankyou
                                                      .contains(
                                                          currentUserReference)) {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          -(1)),
                                                              'thankyou': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  } else {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thumb': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'laugh': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'fire': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thankyou':
                                                                  FieldValue
                                                                      .arrayUnion([
                                                                currentUserReference
                                                              ]),
                                                              'sad': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          1),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(0.0),
                                                child: Image.asset(
                                                  'assets/images/Thanks_Reaction.png',
                                                  width: 28.0,
                                                  height: 28.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ).animateOnPageLoad(animationsMap[
                                                'imageOnPageLoadAnimation5']!),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    2.0, 0.0, 2.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if (containerChatMessagesRecord
                                                      .sad
                                                      .contains(
                                                          currentUserReference)) {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          -(1)),
                                                              'sad': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  } else {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thumb': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'laugh': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'fire': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thankyou': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'sad': FieldValue
                                                                  .arrayUnion([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          1),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(0.0),
                                                child: Image.asset(
                                                  'assets/images/Sad_Reaction.png',
                                                  width: 28.0,
                                                  height: 28.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ).animateOnPageLoad(animationsMap[
                                                'imageOnPageLoadAnimation6']!),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ).animateOnPageLoad(animationsMap[
                                      'containerOnPageLoadAnimation1']!),
                                ),
                              ),
                            ),
                          ),
                        ),
                        if (FFAppState().messageFocusText != '')
                          Padding(
                            padding: const EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 10.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Stack(
                                  alignment: const AlignmentDirectional(-1.0, 1.0),
                                  children: [
                                    Container(
                                      constraints: BoxConstraints(
                                        maxWidth:
                                            MediaQuery.sizeOf(context).width *
                                                0.65,
                                      ),
                                      decoration: BoxDecoration(
                                        color: FlutterFlowTheme.of(context)
                                            .greyButtonLine,
                                        borderRadius:
                                            BorderRadius.circular(18.0),
                                      ),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    12.0, 10.0, 12.0, 10.0),
                                            child: Text(
                                              FFAppState()
                                                  .messageFocusText
                                                  .maybeHandleOverflow(
                                                    maxChars: 600,
                                                    replacement: '…',
                                                  ),
                                              maxLines: 10,
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Inter',
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryText,
                                                        fontSize: 15.0,
                                                        letterSpacing: 0.0,
                                                      ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        Align(
                          alignment: const AlignmentDirectional(-1.0, 0.0),
                          child: Container(
                            width: 230.0,
                            decoration: BoxDecoration(
                              color:
                                  FlutterFlowTheme.of(context).greyButtonLine,
                              borderRadius: BorderRadius.circular(15.0),
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                if (FFAppState().messageFocusText != '')
                                  Padding(
                                    padding: const EdgeInsetsDirectional.fromSTEB(
                                        15.0, 10.0, 15.0, 10.0),
                                    child: InkWell(
                                      splashColor: Colors.transparent,
                                      focusColor: Colors.transparent,
                                      hoverColor: Colors.transparent,
                                      highlightColor: Colors.transparent,
                                      onTap: () async {
                                        await Clipboard.setData(ClipboardData(
                                            text:
                                                FFAppState().messageFocusText));
                                        FFAppState().update(() {
                                          FFAppState().messageReaction = false;
                                        });
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                            content: Text(
                                              'Coppied!',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Inter',
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryText,
                                                        letterSpacing: 0.0,
                                                      ),
                                            ),
                                            duration:
                                                const Duration(milliseconds: 4000),
                                            backgroundColor:
                                                FlutterFlowTheme.of(context)
                                                    .secondary,
                                          ),
                                        );
                                      },
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'i4xyk7e7' /* Copy */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Inter',
                                                  fontSize: 15.0,
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                          ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(8.0),
                                            child: SvgPicture.asset(
                                              'assets/images/Copy_Linear_White.svg',
                                              width: 21.0,
                                              height: 21.0,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                if (FFAppState().messageFocusText != '')
                                  Container(
                                    width: double.infinity,
                                    height: 1.0,
                                    decoration: BoxDecoration(
                                      color: FlutterFlowTheme.of(context)
                                          .alertLines,
                                    ),
                                  ),
                                Padding(
                                  padding: const EdgeInsetsDirectional.fromSTEB(
                                      15.0, 10.0, 15.0, 10.0),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      FFAppState().update(() {
                                        FFAppState().messageReaction = false;
                                        FFAppState().replyComponent = true;
                                      });
                                    },
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          FFLocalizations.of(context).getText(
                                            '1mdf6qqz' /* Reply */,
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                fontSize: 15.0,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                        ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          child: SvgPicture.asset(
                                            'assets/images/Rely_Linear_White.svg',
                                            width: 21.0,
                                            height: 21.0,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  width: double.infinity,
                                  height: 1.0,
                                  decoration: BoxDecoration(
                                    color:
                                        FlutterFlowTheme.of(context).alertLines,
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsetsDirectional.fromSTEB(
                                      15.0, 10.0, 15.0, 10.0),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      final firestoreBatch =
                                          FirebaseFirestore.instance.batch();
                                      try {
                                        firestoreBatch.update(
                                            FFAppState().messageReference!, {
                                          ...createChatMessagesRecordData(
                                            deleted: true,
                                          ),
                                          ...mapToFirestore(
                                            {
                                              'love': FieldValue.delete(),
                                              'thumb': FieldValue.delete(),
                                              'laugh': FieldValue.delete(),
                                              'fire': FieldValue.delete(),
                                              'thankyou': FieldValue.delete(),
                                              'sad': FieldValue.delete(),
                                            },
                                          ),
                                        });

                                        firestoreBatch.update(
                                            FFAppState().currentChatReference!,
                                            createChatsRecordData(
                                              lastMessage:
                                                  'This message was deleted.',
                                            ));
                                        FFAppState().update(() {
                                          FFAppState().messageReaction = false;
                                        });
                                      } finally {
                                        await firestoreBatch.commit();
                                      }
                                    },
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          FFLocalizations.of(context).getText(
                                            'ew9wtjhg' /* Delete */,
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .error,
                                                fontSize: 15.0,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                        ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          child: SvgPicture.asset(
                                            'assets/images/Delete_Bin_Linear_Red2.svg',
                                            width: 21.0,
                                            height: 21.0,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ).animateOnPageLoad(
                              animationsMap['containerOnPageLoadAnimation2']!),
                        ),
                      ],
                    ),
                  if (FFAppState().messageFocusColor)
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Align(
                          alignment: const AlignmentDirectional(1.0, 0.0),
                          child: ClipRRect(
                            child: Container(
                              width: MediaQuery.sizeOf(context).width * 0.7,
                              decoration: const BoxDecoration(),
                              child: Align(
                                alignment: const AlignmentDirectional(1.0, 0.0),
                                child: Padding(
                                  padding: const EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 10.0),
                                  child: Container(
                                    width:
                                        MediaQuery.sizeOf(context).width * 0.6,
                                    height: 50.0,
                                    decoration: BoxDecoration(
                                      color: FlutterFlowTheme.of(context)
                                          .greyButtonLine,
                                      borderRadius: BorderRadius.circular(50.0),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsetsDirectional.fromSTEB(
                                          3.0, 0.0, 3.0, 0.0),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    2.0, 0.0, 2.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if (containerChatMessagesRecord
                                                      .love
                                                      .contains(
                                                          currentUserReference)) {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          -(1)),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  } else {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayUnion([
                                                                currentUserReference
                                                              ]),
                                                              'thumb': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'laugh': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'fire': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thankyou': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'sad': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          1),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(0.0),
                                                child: Image.asset(
                                                  'assets/images/image_258.png',
                                                  width: 28.0,
                                                  height: 28.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ).animateOnPageLoad(animationsMap[
                                                'imageOnPageLoadAnimation7']!),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    2.0, 0.0, 2.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if (containerChatMessagesRecord
                                                      .thumb
                                                      .contains(
                                                          currentUserReference)) {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          -(1)),
                                                              'thumb': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  } else {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thumb': FieldValue
                                                                  .arrayUnion([
                                                                currentUserReference
                                                              ]),
                                                              'laugh': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'fire': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thankyou': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'sad': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          1),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(0.0),
                                                child: Image.asset(
                                                  'assets/images/Thumb_Reaction.png',
                                                  width: 28.0,
                                                  height: 28.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ).animateOnPageLoad(animationsMap[
                                                'imageOnPageLoadAnimation8']!),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    2.0, 0.0, 2.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if (containerChatMessagesRecord
                                                      .laugh
                                                      .contains(
                                                          currentUserReference)) {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          -(1)),
                                                              'laugh': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  } else {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thumb': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'laugh': FieldValue
                                                                  .arrayUnion([
                                                                currentUserReference
                                                              ]),
                                                              'fire': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thankyou': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'sad': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          1),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(0.0),
                                                child: Image.asset(
                                                  'assets/images/Haha_Reaction.png',
                                                  width: 28.0,
                                                  height: 28.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ).animateOnPageLoad(animationsMap[
                                                'imageOnPageLoadAnimation9']!),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    2.0, 0.0, 2.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if (containerChatMessagesRecord
                                                      .fire
                                                      .contains(
                                                          currentUserReference)) {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          -(1)),
                                                              'fire': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  } else {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thumb': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'laugh': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'fire': FieldValue
                                                                  .arrayUnion([
                                                                currentUserReference
                                                              ]),
                                                              'thankyou': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'sad': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          1),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(0.0),
                                                child: Image.asset(
                                                  'assets/images/Fire_Reaction.png',
                                                  width: 28.0,
                                                  height: 28.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ).animateOnPageLoad(animationsMap[
                                                'imageOnPageLoadAnimation10']!),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    2.0, 0.0, 2.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if (containerChatMessagesRecord
                                                      .thankyou
                                                      .contains(
                                                          currentUserReference)) {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          -(1)),
                                                              'thankyou': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  } else {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thumb': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'laugh': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'fire': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thankyou':
                                                                  FieldValue
                                                                      .arrayUnion([
                                                                currentUserReference
                                                              ]),
                                                              'sad': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          1),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(0.0),
                                                child: Image.asset(
                                                  'assets/images/Thanks_Reaction.png',
                                                  width: 28.0,
                                                  height: 28.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ).animateOnPageLoad(animationsMap[
                                                'imageOnPageLoadAnimation11']!),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    2.0, 0.0, 2.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if (containerChatMessagesRecord
                                                      .sad
                                                      .contains(
                                                          currentUserReference)) {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          -(1)),
                                                              'sad': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  } else {
                                                    HapticFeedback
                                                        .heavyImpact();

                                                    firestoreBatch.update(
                                                        FFAppState()
                                                            .messageReference!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'love': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thumb': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'laugh': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'fire': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'thankyou': FieldValue
                                                                  .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                              'sad': FieldValue
                                                                  .arrayUnion([
                                                                currentUserReference
                                                              ]),
                                                              'reaction_count':
                                                                  FieldValue
                                                                      .increment(
                                                                          1),
                                                            },
                                                          ),
                                                        });
                                                    FFAppState().update(() {
                                                      FFAppState()
                                                              .messageReaction =
                                                          false;
                                                    });
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(0.0),
                                                child: Image.asset(
                                                  'assets/images/Sad_Reaction.png',
                                                  width: 28.0,
                                                  height: 28.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ).animateOnPageLoad(animationsMap[
                                                'imageOnPageLoadAnimation12']!),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ).animateOnPageLoad(animationsMap[
                                      'containerOnPageLoadAnimation3']!),
                                ),
                              ),
                            ),
                          ),
                        ),
                        if (FFAppState().messageFocusText != '')
                          Padding(
                            padding: const EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 10.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Stack(
                                  alignment: const AlignmentDirectional(1.0, 1.0),
                                  children: [
                                    Container(
                                      constraints: BoxConstraints(
                                        maxWidth:
                                            MediaQuery.sizeOf(context).width *
                                                0.65,
                                      ),
                                      decoration: BoxDecoration(
                                        color: FlutterFlowTheme.of(context)
                                            .buttonBlue,
                                        borderRadius:
                                            BorderRadius.circular(18.0),
                                      ),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    12.0, 10.0, 12.0, 10.0),
                                            child: Text(
                                              FFAppState()
                                                  .messageFocusText
                                                  .maybeHandleOverflow(
                                                    maxChars: 600,
                                                    replacement: '…',
                                                  ),
                                              maxLines: 10,
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Inter',
                                                        color: Colors.white,
                                                        fontSize: 15.0,
                                                        letterSpacing: 0.0,
                                                      ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        Align(
                          alignment: const AlignmentDirectional(1.0, 0.0),
                          child: Container(
                            width: 230.0,
                            decoration: BoxDecoration(
                              color:
                                  FlutterFlowTheme.of(context).greyButtonLine,
                              borderRadius: BorderRadius.circular(15.0),
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                if (FFAppState().messageFocusText != '')
                                  Padding(
                                    padding: const EdgeInsetsDirectional.fromSTEB(
                                        15.0, 10.0, 15.0, 10.0),
                                    child: InkWell(
                                      splashColor: Colors.transparent,
                                      focusColor: Colors.transparent,
                                      hoverColor: Colors.transparent,
                                      highlightColor: Colors.transparent,
                                      onTap: () async {
                                        await Clipboard.setData(ClipboardData(
                                            text:
                                                FFAppState().messageFocusText));
                                        FFAppState().update(() {
                                          FFAppState().messageReaction = false;
                                        });
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                            content: Text(
                                              'Coppied!',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Inter',
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryText,
                                                        letterSpacing: 0.0,
                                                      ),
                                            ),
                                            duration:
                                                const Duration(milliseconds: 4000),
                                            backgroundColor:
                                                FlutterFlowTheme.of(context)
                                                    .secondary,
                                          ),
                                        );
                                      },
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'gpbsi2rq' /* Copy */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Inter',
                                                  fontSize: 15.0,
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                          ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(8.0),
                                            child: SvgPicture.asset(
                                              'assets/images/Copy_Linear_White.svg',
                                              width: 21.0,
                                              height: 21.0,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                if (FFAppState().messageFocusText != '')
                                  Container(
                                    width: double.infinity,
                                    height: 1.0,
                                    decoration: BoxDecoration(
                                      color: FlutterFlowTheme.of(context)
                                          .alertLines,
                                    ),
                                  ),
                                Padding(
                                  padding: const EdgeInsetsDirectional.fromSTEB(
                                      15.0, 10.0, 15.0, 10.0),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      FFAppState().update(() {
                                        FFAppState().messageReaction = false;
                                        FFAppState().replyComponent = true;
                                      });
                                    },
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          FFLocalizations.of(context).getText(
                                            '69zlwt9t' /* Reply */,
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                fontSize: 15.0,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                        ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          child: SvgPicture.asset(
                                            'assets/images/Rely_Linear_White.svg',
                                            width: 21.0,
                                            height: 21.0,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  width: double.infinity,
                                  height: 1.0,
                                  decoration: BoxDecoration(
                                    color:
                                        FlutterFlowTheme.of(context).alertLines,
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsetsDirectional.fromSTEB(
                                      15.0, 10.0, 15.0, 10.0),
                                  child: InkWell(
                                    splashColor: Colors.transparent,
                                    focusColor: Colors.transparent,
                                    hoverColor: Colors.transparent,
                                    highlightColor: Colors.transparent,
                                    onTap: () async {
                                      final firestoreBatch =
                                          FirebaseFirestore.instance.batch();
                                      try {
                                        firestoreBatch.update(
                                            FFAppState().messageReference!, {
                                          ...createChatMessagesRecordData(
                                            deleted: true,
                                          ),
                                          ...mapToFirestore(
                                            {
                                              'love': FieldValue.delete(),
                                              'thumb': FieldValue.delete(),
                                              'laugh': FieldValue.delete(),
                                              'fire': FieldValue.delete(),
                                              'thankyou': FieldValue.delete(),
                                              'sad': FieldValue.delete(),
                                            },
                                          ),
                                        });

                                        firestoreBatch.update(
                                            FFAppState().currentChatReference!,
                                            createChatsRecordData(
                                              lastMessage:
                                                  'This message was deleted.',
                                            ));
                                        FFAppState().update(() {
                                          FFAppState().messageReaction = false;
                                        });
                                      } finally {
                                        await firestoreBatch.commit();
                                      }
                                    },
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          FFLocalizations.of(context).getText(
                                            'j8cczd2z' /* Delete */,
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .error,
                                                fontSize: 15.0,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                        ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          child: SvgPicture.asset(
                                            'assets/images/Delete_Bin_Linear_Red2.svg',
                                            width: 21.0,
                                            height: 21.0,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ).animateOnPageLoad(
                              animationsMap['containerOnPageLoadAnimation4']!),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
