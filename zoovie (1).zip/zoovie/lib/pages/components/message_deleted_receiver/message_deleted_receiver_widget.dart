import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'message_deleted_receiver_model.dart';
export 'message_deleted_receiver_model.dart';

class MessageDeletedReceiverWidget extends StatefulWidget {
  const MessageDeletedReceiverWidget({super.key});

  @override
  State<MessageDeletedReceiverWidget> createState() =>
      _MessageDeletedReceiverWidgetState();
}

class _MessageDeletedReceiverWidgetState
    extends State<MessageDeletedReceiverWidget> {
  late MessageDeletedReceiverModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MessageDeletedReceiverModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxWidth: MediaQuery.sizeOf(context).width * 0.7,
      ),
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).greyButtonLine,
        borderRadius: BorderRadius.circular(18.0),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(15.0, 0.0, 0.0, 0.0),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8.0),
              child: SvgPicture.asset(
                'assets/images/message_removed_white.svg',
                width: 15.0,
                height: 15.0,
                fit: BoxFit.cover,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(5.0, 9.0, 12.0, 9.0),
            child: Text(
              FFLocalizations.of(context).getText(
                'pgeuv48k' /* This message was deleted. */,
              ),
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    color: const Color(0x99FFFFFF),
                    fontSize: 13.0,
                    letterSpacing: 0.0,
                    fontStyle: FontStyle.italic,
                  ),
            ),
          ),
        ],
      ),
    );
  }
}
