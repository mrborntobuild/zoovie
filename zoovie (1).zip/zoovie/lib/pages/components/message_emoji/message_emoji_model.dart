import '/flutter_flow/flutter_flow_util.dart';
import '/pages/components/message_bubbles_focused/message_bubbles_focused_widget.dart';
import 'message_emoji_widget.dart' show MessageEmojiWidget;
import 'package:flutter/material.dart';

class MessageEmojiModel extends FlutterFlowModel<MessageEmojiWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for messageBubbles_Focused component.
  late MessageBubblesFocusedModel messageBubblesFocusedModel;

  @override
  void initState(BuildContext context) {
    messageBubblesFocusedModel =
        createModel(context, () => MessageBubblesFocusedModel());
  }

  @override
  void dispose() {
    messageBubblesFocusedModel.dispose();
  }
}
