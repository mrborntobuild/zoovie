import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/components/message_bubbles_focused/message_bubbles_focused_widget.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'message_emoji_model.dart';
export 'message_emoji_model.dart';

class MessageEmojiWidget extends StatefulWidget {
  const MessageEmojiWidget({
    super.key,
    this.blueBubble,
    this.messageText,
  });

  final bool? blueBubble;
  final String? messageText;

  @override
  State<MessageEmojiWidget> createState() => _MessageEmojiWidgetState();
}

class _MessageEmojiWidgetState extends State<MessageEmojiWidget>
    with TickerProviderStateMixin {
  late MessageEmojiModel _model;

  final animationsMap = <String, AnimationInfo>{};

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MessageEmojiModel());

    animationsMap.addAll({
      'blurOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 200.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
      'messageBubblesFocusedOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ScaleEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 200.0.ms,
            begin: const Offset(0.8, 0.8),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
    });
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(0.0),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: 8.0,
              sigmaY: 8.0,
            ),
            child: InkWell(
              splashColor: Colors.transparent,
              focusColor: Colors.transparent,
              hoverColor: Colors.transparent,
              highlightColor: Colors.transparent,
              onTap: () async {
                FFAppState().update(() {
                  FFAppState().messageReaction = false;
                });
              },
              child: Container(
                width: double.infinity,
                height: double.infinity,
                decoration: const BoxDecoration(
                  color: Color(0x4C000000),
                ),
              ),
            ),
          ),
        ).animateOnPageLoad(animationsMap['blurOnPageLoadAnimation']!),
        Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: wrapWithModel(
                model: _model.messageBubblesFocusedModel,
                updateCallback: () => setState(() {}),
                child: const MessageBubblesFocusedWidget(
                  blueBubble: false,
                ),
              ).animateOnPageLoad(
                  animationsMap['messageBubblesFocusedOnPageLoadAnimation']!),
            ),
          ],
        ),
      ],
    );
  }
}
