import '/flutter_flow/flutter_flow_util.dart';
import 'modal_delete_moment_widget.dart' show ModalDeleteMomentWidget;
import 'package:flutter/material.dart';

class ModalDeleteMomentModel extends FlutterFlowModel<ModalDeleteMomentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
