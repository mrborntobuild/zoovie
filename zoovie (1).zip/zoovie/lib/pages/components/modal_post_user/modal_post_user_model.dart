import '/flutter_flow/flutter_flow_util.dart';
import 'modal_post_user_widget.dart' show ModalPostUserWidget;
import 'package:flutter/material.dart';

class ModalPostUserModel extends FlutterFlowModel<ModalPostUserWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
