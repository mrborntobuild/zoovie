import '/flutter_flow/flutter_flow_util.dart';
import 'moment_view_list_widget.dart' show MomentViewListWidget;
import 'package:flutter/material.dart';

class MomentViewListModel extends FlutterFlowModel<MomentViewListWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
