import '/flutter_flow/flutter_flow_util.dart';
import 'no_posts_yet_widget.dart' show NoPostsYetWidget;
import 'package:flutter/material.dart';

class NoPostsYetModel extends FlutterFlowModel<NoPostsYetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
