import '/flutter_flow/flutter_flow_util.dart';
import 'no_saved_posts_yet_widget.dart' show NoSavedPostsYetWidget;
import 'package:flutter/material.dart';

class NoSavedPostsYetModel extends FlutterFlowModel<NoSavedPostsYetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
