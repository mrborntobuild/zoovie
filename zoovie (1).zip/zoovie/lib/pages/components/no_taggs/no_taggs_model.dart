import '/flutter_flow/flutter_flow_util.dart';
import 'no_taggs_widget.dart' show NoTaggsWidget;
import 'package:flutter/material.dart';

class NoTaggsModel extends FlutterFlowModel<NoTaggsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
