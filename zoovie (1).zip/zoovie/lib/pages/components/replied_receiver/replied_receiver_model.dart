import '/flutter_flow/flutter_flow_util.dart';
import 'replied_receiver_widget.dart' show RepliedReceiverWidget;
import 'package:flutter/material.dart';

class RepliedReceiverModel extends FlutterFlowModel<RepliedReceiverWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
