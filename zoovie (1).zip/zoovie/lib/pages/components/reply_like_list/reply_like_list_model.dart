import '/flutter_flow/flutter_flow_util.dart';
import 'reply_like_list_widget.dart' show ReplyLikeListWidget;
import 'package:flutter/material.dart';

class ReplyLikeListModel extends FlutterFlowModel<ReplyLikeListWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
