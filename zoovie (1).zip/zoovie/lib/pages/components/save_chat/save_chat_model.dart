import '/flutter_flow/flutter_flow_util.dart';
import 'save_chat_widget.dart' show SaveChatWidget;
import 'package:flutter/material.dart';

class SaveChatModel extends FlutterFlowModel<SaveChatWidget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  // State field(s) for ChatTitle widget.
  FocusNode? chatTitleFocusNode;
  TextEditingController? chatTitleTextController;
  String? Function(BuildContext, String?)? chatTitleTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    chatTitleFocusNode?.dispose();
    chatTitleTextController?.dispose();
  }
}
