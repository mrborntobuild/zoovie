import '/flutter_flow/flutter_flow_util.dart';
import 'searching_users_widget.dart' show SearchingUsersWidget;
import 'package:flutter/material.dart';

class SearchingUsersModel extends FlutterFlowModel<SearchingUsersWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
