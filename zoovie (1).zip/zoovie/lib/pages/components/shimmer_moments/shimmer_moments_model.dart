import '/flutter_flow/flutter_flow_util.dart';
import 'shimmer_moments_widget.dart' show ShimmerMomentsWidget;
import 'package:flutter/material.dart';

class ShimmerMomentsModel extends FlutterFlowModel<ShimmerMomentsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
