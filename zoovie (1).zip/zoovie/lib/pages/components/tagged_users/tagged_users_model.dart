import '/flutter_flow/flutter_flow_util.dart';
import 'tagged_users_widget.dart' show TaggedUsersWidget;
import 'package:flutter/material.dart';

class TaggedUsersModel extends FlutterFlowModel<TaggedUsersWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
