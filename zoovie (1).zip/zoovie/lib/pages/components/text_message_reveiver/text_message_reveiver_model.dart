import '/flutter_flow/flutter_flow_util.dart';
import 'text_message_reveiver_widget.dart' show TextMessageReveiverWidget;
import 'package:flutter/material.dart';

class TextMessageReveiverModel
    extends FlutterFlowModel<TextMessageReveiverWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
