import '/flutter_flow/flutter_flow_util.dart';
import 'user_blocked_widget.dart' show UserBlockedWidget;
import 'package:flutter/material.dart';

class UserBlockedModel extends FlutterFlowModel<UserBlockedWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
