import '/flutter_flow/flutter_flow_util.dart';
import 'user_post_skeleton_widget.dart' show UserPostSkeletonWidget;
import 'package:flutter/material.dart';

class UserPostSkeletonModel extends FlutterFlowModel<UserPostSkeletonWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
