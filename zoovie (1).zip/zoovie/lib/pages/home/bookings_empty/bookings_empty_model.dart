import '/flutter_flow/flutter_flow_util.dart';
import 'bookings_empty_widget.dart' show BookingsEmptyWidget;
import 'package:flutter/material.dart';

class BookingsEmptyModel extends FlutterFlowModel<BookingsEmptyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
