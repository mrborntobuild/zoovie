import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_video_player.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/instant_timer.dart';
import '/pages/components/logo_animation/logo_animation_widget.dart';
import '/pages/components/modal_post_owner/modal_post_owner_widget.dart';
import '/pages/components/modal_post_user/modal_post_user_widget.dart';
import '/pages/components/modal_select_image_video/modal_select_image_video_widget.dart';
import '/pages/components/post_like_list/post_like_list_widget.dart';
import '/pages/components/tagged_users/tagged_users_widget.dart';
import '/pages/home/menu_feed_page/menu_feed_page_widget.dart';
import 'dart:async';
import 'dart:math';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import 'dart:math' as math;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:octo_image/octo_image.dart';
import 'package:provider/provider.dart';
import 'home_model.dart';
export 'home_model.dart';

class HomeWidget extends StatefulWidget {
  const HomeWidget({super.key});

  @override
  State<HomeWidget> createState() => _HomeWidgetState();
}

class _HomeWidgetState extends State<HomeWidget> with TickerProviderStateMixin {
  late HomeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  LatLng? currentUserLocationValue;

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HomeModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      currentUserLocationValue =
          await getCurrentUserLocation(defaultLocation: const LatLng(0.0, 0.0));

      await currentUserReference!.update(createUsersRecordData(
        currentLocation: currentUserLocationValue,
      ));
      _model.aPICall = await ZoovieAPIGroup.clubListCall.call();
      _model.instantTimer = InstantTimer.periodic(
        duration: const Duration(milliseconds: 50),
        callback: (timer) async {
          unawaited(
            () async {
              await actions.setStatusBarIconsWhite();
            }(),
          );
        },
        startImmediately: true,
      );
    });

    animationsMap.addAll({
      'containerOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          VisibilityEffect(duration: 200.ms),
          ScaleEffect(
            curve: Curves.elasticOut,
            delay: 200.0.ms,
            duration: 600.0.ms,
            begin: const Offset(0.8, 0.8),
            end: const Offset(1.0, 1.0),
          ),
        ],
      ),
    });
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: WillPopScope(
        onWillPop: () async => false,
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          body: SafeArea(
            top: true,
            child: Stack(
              children: [
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(0.0),
                        child: Container(
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration(
                            color:
                                FlutterFlowTheme.of(context).primaryBackground,
                            borderRadius: BorderRadius.circular(0.0),
                          ),
                          child: Stack(
                            children: [
                              if (FFAppState().exploreFeed == true)
                                Container(
                                  decoration: const BoxDecoration(),
                                  child: Stack(
                                    children: [
                                      StreamBuilder<List<PostsRecord>>(
                                        stream: queryPostsRecord(),
                                        builder: (context, snapshot) {
                                          // Customize what your widget looks like when it's loading.
                                          if (!snapshot.hasData) {
                                            return const SizedBox(
                                              width: double.infinity,
                                              height: double.infinity,
                                              child: LogoAnimationWidget(),
                                            );
                                          }
                                          List<PostsRecord>
                                              carouselPostsRecordList =
                                              snapshot.data!;
                                          return SizedBox(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: CarouselSlider.builder(
                                              itemCount: carouselPostsRecordList
                                                  .length,
                                              itemBuilder:
                                                  (context, carouselIndex, _) {
                                                final carouselPostsRecord =
                                                    carouselPostsRecordList[
                                                        carouselIndex];
                                                return Stack(
                                                  children: [
                                                    Container(
                                                      width: double.infinity,
                                                      height: double.infinity,
                                                      decoration: BoxDecoration(
                                                        color: FlutterFlowTheme
                                                                .of(context)
                                                            .primaryBackground,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(0.0),
                                                      ),
                                                      child: Stack(
                                                        children: [
                                                          if (carouselPostsRecord
                                                                  .video ==
                                                              false)
                                                            Align(
                                                              alignment:
                                                                  const AlignmentDirectional(
                                                                      0.0, 0.0),
                                                              child: ClipRRect(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            0.0),
                                                                child:
                                                                    OctoImage(
                                                                  placeholderBuilder:
                                                                      (_) => SizedBox
                                                                          .expand(
                                                                    child:
                                                                        Image(
                                                                      image: BlurHashImage(
                                                                          carouselPostsRecord
                                                                              .imageHash),
                                                                      fit: BoxFit
                                                                          .cover,
                                                                    ),
                                                                  ),
                                                                  image:
                                                                      CachedNetworkImageProvider(
                                                                    carouselPostsRecord
                                                                        .postImage,
                                                                  ),
                                                                  width: double
                                                                      .infinity,
                                                                  height: double
                                                                      .infinity,
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            ),
                                                          if (carouselPostsRecord
                                                                  .video ==
                                                              true)
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          300.0,
                                                                          0.0,
                                                                          0.0),
                                                              child: Container(
                                                                width: double
                                                                    .infinity,
                                                                height: MediaQuery.sizeOf(
                                                                            context)
                                                                        .height *
                                                                    1.0,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .primaryBackground,
                                                                  image:
                                                                      DecorationImage(
                                                                    fit: BoxFit
                                                                        .cover,
                                                                    image: Image
                                                                        .asset(
                                                                      'assets/images/Video_LogoAnimation.gif',
                                                                    ).image,
                                                                  ),
                                                                ),
                                                                child:
                                                                    FlutterFlowVideoPlayer(
                                                                  path: carouselPostsRecord
                                                                      .videoUrl,
                                                                  videoType:
                                                                      VideoType
                                                                          .network,
                                                                  aspectRatio:
                                                                      0.56,
                                                                  autoPlay:
                                                                      true,
                                                                  looping: true,
                                                                  showControls:
                                                                      false,
                                                                  allowFullScreen:
                                                                      true,
                                                                  allowPlaybackSpeedMenu:
                                                                      false,
                                                                  lazyLoad:
                                                                      true,
                                                                ),
                                                              ),
                                                            ),
                                                          Align(
                                                            alignment:
                                                                const AlignmentDirectional(
                                                                    0.0, 0.0),
                                                            child: Container(
                                                              width: double
                                                                  .infinity,
                                                              height: double
                                                                  .infinity,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: const Color(
                                                                    0x1A010101),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            0.0),
                                                              ),
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment:
                                                                const AlignmentDirectional(
                                                                    0.0, 1.0),
                                                            child: Container(
                                                              width: double
                                                                  .infinity,
                                                              decoration:
                                                                  const BoxDecoration(),
                                                              child: Row(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .end,
                                                                children: [
                                                                  Expanded(
                                                                    child:
                                                                        Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .end,
                                                                      children: [
                                                                        Padding(
                                                                          padding: const EdgeInsetsDirectional.fromSTEB(
                                                                              20.0,
                                                                              0.0,
                                                                              0.0,
                                                                              10.0),
                                                                          child:
                                                                              Row(
                                                                            mainAxisSize:
                                                                                MainAxisSize.max,
                                                                            children:
                                                                                [
                                                                              if (carouselPostsRecord.location != '')
                                                                                Container(
                                                                                  decoration: BoxDecoration(
                                                                                    color: const Color(0xCC2B2B2B),
                                                                                    borderRadius: BorderRadius.circular(7.0),
                                                                                  ),
                                                                                  child: Row(
                                                                                    mainAxisSize: MainAxisSize.min,
                                                                                    children: [
                                                                                      Padding(
                                                                                        padding: const EdgeInsets.all(4.0),
                                                                                        child: SvgPicture.asset(
                                                                                          'assets/images/Location_Bold_White.svg',
                                                                                          width: 15.0,
                                                                                          height: 15.0,
                                                                                          fit: BoxFit.cover,
                                                                                        ),
                                                                                      ),
                                                                                      Padding(
                                                                                        padding: const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 8.0, 0.0),
                                                                                        child: Text(
                                                                                          carouselPostsRecord.location.maybeHandleOverflow(
                                                                                            maxChars: 20,
                                                                                            replacement: '…',
                                                                                          ),
                                                                                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                fontFamily: 'Inter',
                                                                                                color: FlutterFlowTheme.of(context).whiteButton,
                                                                                                fontSize: 12.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w500,
                                                                                              ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              if (carouselPostsRecord.taggedUsers.isNotEmpty)
                                                                                InkWell(
                                                                                  splashColor: Colors.transparent,
                                                                                  focusColor: Colors.transparent,
                                                                                  hoverColor: Colors.transparent,
                                                                                  highlightColor: Colors.transparent,
                                                                                  onTap: () async {
                                                                                    await showModalBottomSheet(
                                                                                      isScrollControlled: true,
                                                                                      backgroundColor: Colors.transparent,
                                                                                      barrierColor: const Color(0xB2000000),
                                                                                      enableDrag: false,
                                                                                      context: context,
                                                                                      builder: (context) {
                                                                                        return GestureDetector(
                                                                                          onTap: () => _model.unfocusNode.canRequestFocus ? FocusScope.of(context).requestFocus(_model.unfocusNode) : FocusScope.of(context).unfocus(),
                                                                                          child: Padding(
                                                                                            padding: MediaQuery.viewInsetsOf(context),
                                                                                            child: TaggedUsersWidget(
                                                                                              postReference: carouselPostsRecord.reference,
                                                                                            ),
                                                                                          ),
                                                                                        );
                                                                                      },
                                                                                    ).then((value) => safeSetState(() {}));
                                                                                  },
                                                                                  child: Container(
                                                                                    decoration: BoxDecoration(
                                                                                      color: const Color(0xCC2B2B2B),
                                                                                      borderRadius: BorderRadius.circular(7.0),
                                                                                    ),
                                                                                    child: Row(
                                                                                      mainAxisSize: MainAxisSize.min,
                                                                                      children: [
                                                                                        Padding(
                                                                                          padding: const EdgeInsets.all(4.0),
                                                                                          child: SvgPicture.asset(
                                                                                            'assets/images/Tagged_Users_Blod_White.svg',
                                                                                            width: 15.0,
                                                                                            height: 15.0,
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                        Padding(
                                                                                          padding: const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 8.0, 0.0),
                                                                                          child: Text(
                                                                                            'With ${'${carouselPostsRecord.taggedUsers.length.toString()}${carouselPostsRecord.taggedUsers.length == 1 ? ' other' : ' others'}'}',
                                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                  fontFamily: 'Inter',
                                                                                                  color: FlutterFlowTheme.of(context).whiteButton,
                                                                                                  fontSize: 12.0,
                                                                                                  letterSpacing: 0.0,
                                                                                                  fontWeight: FontWeight.w500,
                                                                                                ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                            ].divide(const SizedBox(width: 6.0)),
                                                                          ),
                                                                        ),
                                                                        Row(
                                                                          mainAxisSize:
                                                                              MainAxisSize.max,
                                                                          children: [
                                                                            Padding(
                                                                              padding: const EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 15.0, 0.0),
                                                                              child: InkWell(
                                                                                splashColor: Colors.transparent,
                                                                                focusColor: Colors.transparent,
                                                                                hoverColor: Colors.transparent,
                                                                                highlightColor: Colors.transparent,
                                                                                onTap: () async {
                                                                                  if (carouselPostsRecord.userID == currentUserReference) {
                                                                                    context.pushNamed('profile');
                                                                                  } else {
                                                                                    context.pushNamed(
                                                                                      'publicProfile',
                                                                                      queryParameters: {
                                                                                        'userReference': serializeParam(
                                                                                          carouselPostsRecord.userID,
                                                                                          ParamType.DocumentReference,
                                                                                        ),
                                                                                      }.withoutNulls,
                                                                                    );
                                                                                  }
                                                                                },
                                                                                child: Row(
                                                                                  mainAxisSize: MainAxisSize.max,
                                                                                  children: [
                                                                                    Container(
                                                                                      width: 40.0,
                                                                                      height: 40.0,
                                                                                      decoration: const BoxDecoration(),
                                                                                      child: Column(
                                                                                        mainAxisSize: MainAxisSize.max,
                                                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                        children: [
                                                                                          ClipRRect(
                                                                                            borderRadius: BorderRadius.circular(50.0),
                                                                                            child: OctoImage(
                                                                                              placeholderBuilder: (_) => const SizedBox.expand(
                                                                                                child: Image(
                                                                                                  image: BlurHashImage('LEHV6nWB2yk8pyo0adR*.7kCMdnj'),
                                                                                                  fit: BoxFit.cover,
                                                                                                ),
                                                                                              ),
                                                                                              image: CachedNetworkImageProvider(
                                                                                                carouselPostsRecord.userProfilePicture,
                                                                                              ),
                                                                                              width: 32.0,
                                                                                              height: 32.0,
                                                                                              fit: BoxFit.cover,
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                    Text(
                                                                                      carouselPostsRecord.username.maybeHandleOverflow(
                                                                                        maxChars: 20,
                                                                                        replacement: '…',
                                                                                      ),
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Inter',
                                                                                            color: FlutterFlowTheme.of(context).primaryText,
                                                                                            fontSize: 15.0,
                                                                                            letterSpacing: 0.0,
                                                                                            fontWeight: FontWeight.w600,
                                                                                          ),
                                                                                    ),
                                                                                    if (carouselPostsRecord.isUserVerified == true)
                                                                                      Padding(
                                                                                        padding: const EdgeInsetsDirectional.fromSTEB(5.0, 0.0, 0.0, 0.0),
                                                                                        child: SvgPicture.asset(
                                                                                          'assets/images/Verified_Bold_White.svg',
                                                                                          width: 13.0,
                                                                                          height: 13.0,
                                                                                          fit: BoxFit.cover,
                                                                                        ),
                                                                                      ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            if (carouselPostsRecord.userID !=
                                                                                currentUserReference)
                                                                              AuthUserStreamWidget(
                                                                                builder: (context) => FFButtonWidget(
                                                                                  onPressed: () async {
                                                                                    final firestoreBatch = FirebaseFirestore.instance.batch();
                                                                                    try {
                                                                                      if ((currentUserDocument?.following.toList() ?? []).contains(carouselPostsRecord.userID) == false) {
                                                                                        firestoreBatch.update(currentUserReference!, {
                                                                                          ...mapToFirestore(
                                                                                            {
                                                                                              'following': FieldValue.arrayUnion([
                                                                                                carouselPostsRecord.userID
                                                                                              ]),
                                                                                            },
                                                                                          ),
                                                                                        });

                                                                                        firestoreBatch.update(carouselPostsRecord.userID!, {
                                                                                          ...createUsersRecordData(
                                                                                            newNotification: true,
                                                                                          ),
                                                                                          ...mapToFirestore(
                                                                                            {
                                                                                              'followers': FieldValue.arrayUnion([
                                                                                                currentUserReference
                                                                                              ]),
                                                                                            },
                                                                                          ),
                                                                                        });

                                                                                        firestoreBatch.set(
                                                                                            NotificationsRecord.collection.doc(),
                                                                                            createNotificationsRecordData(
                                                                                              dateCreated: getCurrentTimestamp,
                                                                                              receiverID: carouselPostsRecord.userID,
                                                                                              senderID: currentUserReference,
                                                                                              senderUsername: valueOrDefault(currentUserDocument?.username, ''),
                                                                                              senderProfilePicture: currentUserPhoto,
                                                                                              followers: true,
                                                                                              notification: ' started following you. ',
                                                                                            ));
                                                                                        HapticFeedback.lightImpact();
                                                                                      } else {
                                                                                        firestoreBatch.update(currentUserReference!, {
                                                                                          ...mapToFirestore(
                                                                                            {
                                                                                              'following': FieldValue.arrayRemove([
                                                                                                carouselPostsRecord.userID
                                                                                              ]),
                                                                                            },
                                                                                          ),
                                                                                        });

                                                                                        firestoreBatch.update(carouselPostsRecord.userID!, {
                                                                                          ...mapToFirestore(
                                                                                            {
                                                                                              'followers': FieldValue.arrayRemove([
                                                                                                currentUserReference
                                                                                              ]),
                                                                                            },
                                                                                          ),
                                                                                        });
                                                                                        HapticFeedback.lightImpact();
                                                                                      }
                                                                                    } finally {
                                                                                      await firestoreBatch.commit();
                                                                                    }
                                                                                  },
                                                                                  text: (currentUserDocument?.following.toList() ?? []).contains(carouselPostsRecord.userID) == true ? 'Following' : 'Follow',
                                                                                  options: FFButtonOptions(
                                                                                    height: 25.0,
                                                                                    padding: const EdgeInsetsDirectional.fromSTEB(6.0, 0.0, 6.0, 0.0),
                                                                                    iconPadding: const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                                                                                    color: (currentUserDocument?.following.toList() ?? []).contains(carouselPostsRecord.userID) == true ? FlutterFlowTheme.of(context).whiteButton : const Color(0x00FFFFFF),
                                                                                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                          fontFamily: 'Inter',
                                                                                          color: (currentUserDocument?.following.toList() ?? []).contains(carouselPostsRecord.userID) == true ? FlutterFlowTheme.of(context).blackText : FlutterFlowTheme.of(context).primaryText,
                                                                                          fontSize: 13.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FontWeight.w600,
                                                                                        ),
                                                                                    elevation: 0.0,
                                                                                    borderSide: const BorderSide(
                                                                                      color: Color(0xA7FFFFFF),
                                                                                      width: 1.0,
                                                                                    ),
                                                                                    borderRadius: BorderRadius.circular(8.0),
                                                                                  ),
                                                                                  showLoadingIndicator: false,
                                                                                ),
                                                                              ),
                                                                          ],
                                                                        ),
                                                                        Padding(
                                                                          padding: const EdgeInsetsDirectional.fromSTEB(
                                                                              20.0,
                                                                              0.0,
                                                                              0.0,
                                                                              20.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                double.infinity,
                                                                            color:
                                                                                const Color(0x00000000),
                                                                            child:
                                                                                ExpandableNotifier(
                                                                              initialExpanded: false,
                                                                              child: ExpandablePanel(
                                                                                header: Text(
                                                                                  '',
                                                                                  style: FlutterFlowTheme.of(context).displaySmall.override(
                                                                                        fontFamily: 'Inter',
                                                                                        color: FlutterFlowTheme.of(context).primaryText,
                                                                                        fontSize: 0.0,
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                                collapsed: Container(
                                                                                  width: double.infinity,
                                                                                  decoration: const BoxDecoration(),
                                                                                  child: Text(
                                                                                    carouselPostsRecord.caption.maybeHandleOverflow(
                                                                                      maxChars: 35,
                                                                                      replacement: '…',
                                                                                    ),
                                                                                    maxLines: 1,
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Inter',
                                                                                          color: FlutterFlowTheme.of(context).primaryText,
                                                                                          fontSize: 15.0,
                                                                                          letterSpacing: 0.0,
                                                                                          lineHeight: 1.3,
                                                                                        ),
                                                                                  ),
                                                                                ),
                                                                                expanded: SingleChildScrollView(
                                                                                  primary: false,
                                                                                  child: Column(
                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                    children: [
                                                                                      Text(
                                                                                        carouselPostsRecord.caption,
                                                                                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                              fontFamily: 'Inter',
                                                                                              color: FlutterFlowTheme.of(context).primaryText,
                                                                                              fontSize: 15.0,
                                                                                              letterSpacing: 0.0,
                                                                                              lineHeight: 1.3,
                                                                                            ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                                theme: const ExpandableThemeData(
                                                                                  tapHeaderToExpand: true,
                                                                                  tapBodyToExpand: true,
                                                                                  tapBodyToCollapse: true,
                                                                                  headerAlignment: ExpandablePanelHeaderAlignment.top,
                                                                                  hasIcon: false,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width: 65.0,
                                                                    decoration:
                                                                        const BoxDecoration(),
                                                                    child:
                                                                        Padding(
                                                                      padding: const EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          15.0),
                                                                      child:
                                                                          Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize.min,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.end,
                                                                        children: [
                                                                          StreamBuilder<
                                                                              List<PostLikesRecord>>(
                                                                            stream:
                                                                                queryPostLikesRecord(
                                                                              queryBuilder: (postLikesRecord) => postLikesRecord.where(
                                                                                'postID',
                                                                                isEqualTo: carouselPostsRecord.reference,
                                                                              ),
                                                                            ),
                                                                            builder:
                                                                                (context, snapshot) {
                                                                              // Customize what your widget looks like when it's loading.
                                                                              if (!snapshot.hasData) {
                                                                                return const Center(
                                                                                  child: SizedBox(
                                                                                    width: 45.0,
                                                                                    height: 45.0,
                                                                                    child: SpinKitCircle(
                                                                                      color: Color(0x004B39EF),
                                                                                      size: 45.0,
                                                                                    ),
                                                                                  ),
                                                                                );
                                                                              }
                                                                              List<PostLikesRecord> likeWrapperPostLikesRecordList = snapshot.data!;
                                                                              return Container(
                                                                                width: double.infinity,
                                                                                height: 65.0,
                                                                                constraints: const BoxConstraints(
                                                                                  minWidth: 80.0,
                                                                                ),
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(30.0),
                                                                                  border: Border.all(
                                                                                    color: Colors.transparent,
                                                                                    width: 0.0,
                                                                                  ),
                                                                                ),
                                                                                child: Column(
                                                                                  mainAxisSize: MainAxisSize.max,
                                                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                                                  children: [
                                                                                    Align(
                                                                                      alignment: const AlignmentDirectional(0.0, 0.0),
                                                                                      child: Stack(
                                                                                        children: [
                                                                                          Align(
                                                                                            alignment: const AlignmentDirectional(0.0, 0.0),
                                                                                            child: InkWell(
                                                                                              splashColor: Colors.transparent,
                                                                                              focusColor: Colors.transparent,
                                                                                              hoverColor: Colors.transparent,
                                                                                              highlightColor: Colors.transparent,
                                                                                              onTap: () async {
                                                                                                final firestoreBatch = FirebaseFirestore.instance.batch();
                                                                                                try {
                                                                                                  HapticFeedback.lightImpact();

                                                                                                  var postLikesRecordReference = PostLikesRecord.collection.doc();
                                                                                                  firestoreBatch.set(
                                                                                                      postLikesRecordReference,
                                                                                                      createPostLikesRecordData(
                                                                                                        userID: currentUserReference,
                                                                                                        uniqueID: '${currentUserReference?.id}_${carouselPostsRecord.reference.id}',
                                                                                                        postID: carouselPostsRecord.reference,
                                                                                                        dateCreated: getCurrentTimestamp,
                                                                                                      ));
                                                                                                  _model.newLike2 = PostLikesRecord.getDocumentFromData(
                                                                                                      createPostLikesRecordData(
                                                                                                        userID: currentUserReference,
                                                                                                        uniqueID: '${currentUserReference?.id}_${carouselPostsRecord.reference.id}',
                                                                                                        postID: carouselPostsRecord.reference,
                                                                                                        dateCreated: getCurrentTimestamp,
                                                                                                      ),
                                                                                                      postLikesRecordReference);

                                                                                                  firestoreBatch.set(
                                                                                                      NotificationsRecord.collection.doc(),
                                                                                                      createNotificationsRecordData(
                                                                                                        dateCreated: getCurrentTimestamp,
                                                                                                        receiverID: carouselPostsRecord.userID,
                                                                                                        senderID: currentUserReference,
                                                                                                        senderUsername: valueOrDefault(currentUserDocument?.username, ''),
                                                                                                        senderProfilePicture: currentUserPhoto,
                                                                                                        postImage: carouselPostsRecord.postImage,
                                                                                                        like: true,
                                                                                                        postID: carouselPostsRecord.reference,
                                                                                                        notification: ' liked your post. ',
                                                                                                        videoCover: carouselPostsRecord.videoCover,
                                                                                                      ));

                                                                                                  firestoreBatch.update(
                                                                                                      carouselPostsRecord.userID!,
                                                                                                      createUsersRecordData(
                                                                                                        newNotification: true,
                                                                                                      ));
                                                                                                } finally {
                                                                                                  await firestoreBatch.commit();
                                                                                                }

                                                                                                setState(() {});
                                                                                              },
                                                                                              child: ClipRRect(
                                                                                                borderRadius: BorderRadius.circular(8.0),
                                                                                                child: SvgPicture.asset(
                                                                                                  'assets/images/Post_Like_NotActive.svg',
                                                                                                  width: 32.0,
                                                                                                  height: 32.0,
                                                                                                  fit: BoxFit.cover,
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          Align(
                                                                                            alignment: const AlignmentDirectional(0.0, 0.0),
                                                                                            child: StreamBuilder<List<PostLikesRecord>>(
                                                                                              stream: queryPostLikesRecord(
                                                                                                queryBuilder: (postLikesRecord) => postLikesRecord.where(
                                                                                                  'uniqueID',
                                                                                                  isEqualTo: '${currentUserReference?.id}_${carouselPostsRecord.reference.id}',
                                                                                                ),
                                                                                                singleRecord: true,
                                                                                              ),
                                                                                              builder: (context, snapshot) {
                                                                                                // Customize what your widget looks like when it's loading.
                                                                                                if (!snapshot.hasData) {
                                                                                                  return const Center(
                                                                                                    child: SizedBox(
                                                                                                      width: 24.0,
                                                                                                      height: 24.0,
                                                                                                      child: CircularProgressIndicator(
                                                                                                        valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                          Color(0x004B39EF),
                                                                                                        ),
                                                                                                      ),
                                                                                                    ),
                                                                                                  );
                                                                                                }
                                                                                                List<PostLikesRecord> activeHeartPostLikesRecordList = snapshot.data!;
                                                                                                // Return an empty Container when the item does not exist.
                                                                                                if (snapshot.data!.isEmpty) {
                                                                                                  return Container();
                                                                                                }
                                                                                                final activeHeartPostLikesRecord = activeHeartPostLikesRecordList.isNotEmpty ? activeHeartPostLikesRecordList.first : null;
                                                                                                return InkWell(
                                                                                                  splashColor: Colors.transparent,
                                                                                                  focusColor: Colors.transparent,
                                                                                                  hoverColor: Colors.transparent,
                                                                                                  highlightColor: Colors.transparent,
                                                                                                  onTap: () async {
                                                                                                    HapticFeedback.lightImpact();
                                                                                                    unawaited(
                                                                                                      () async {
                                                                                                        await activeHeartPostLikesRecord!.reference.delete();
                                                                                                      }(),
                                                                                                    );
                                                                                                  },
                                                                                                  child: ClipRRect(
                                                                                                    borderRadius: BorderRadius.circular(8.0),
                                                                                                    child: SvgPicture.asset(
                                                                                                      'assets/images/Post_Like_Active.svg',
                                                                                                      width: 32.0,
                                                                                                      height: 32.0,
                                                                                                      fit: BoxFit.cover,
                                                                                                    ),
                                                                                                  ),
                                                                                                );
                                                                                              },
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                    Padding(
                                                                                      padding: const EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 0.0, 0.0),
                                                                                      child: InkWell(
                                                                                        splashColor: Colors.transparent,
                                                                                        focusColor: Colors.transparent,
                                                                                        hoverColor: Colors.transparent,
                                                                                        highlightColor: Colors.transparent,
                                                                                        onTap: () async {
                                                                                          if (carouselPostsRecord.userID == currentUserReference) {
                                                                                            await showModalBottomSheet(
                                                                                              isScrollControlled: true,
                                                                                              backgroundColor: Colors.transparent,
                                                                                              barrierColor: const Color(0xCB000000),
                                                                                              context: context,
                                                                                              builder: (context) {
                                                                                                return GestureDetector(
                                                                                                  onTap: () => _model.unfocusNode.canRequestFocus ? FocusScope.of(context).requestFocus(_model.unfocusNode) : FocusScope.of(context).unfocus(),
                                                                                                  child: Padding(
                                                                                                    padding: MediaQuery.viewInsetsOf(context),
                                                                                                    child: PostLikeListWidget(
                                                                                                      postReference: carouselPostsRecord.reference,
                                                                                                    ),
                                                                                                  ),
                                                                                                );
                                                                                              },
                                                                                            ).then((value) => safeSetState(() {}));
                                                                                          }
                                                                                        },
                                                                                        child: Text(
                                                                                          valueOrDefault<String>(
                                                                                            carouselPostsRecord.hideLikeCount == true
                                                                                                ? 'Likes'
                                                                                                : formatNumber(
                                                                                                    likeWrapperPostLikesRecordList.length,
                                                                                                    formatType: FormatType.compact,
                                                                                                  ),
                                                                                            'Likes',
                                                                                          ),
                                                                                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                fontFamily: 'Inter',
                                                                                                color: FlutterFlowTheme.of(context).primaryText,
                                                                                                fontSize: 12.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w600,
                                                                                              ),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              );
                                                                            },
                                                                          ),
                                                                          StreamBuilder<
                                                                              List<CommentsRecord>>(
                                                                            stream:
                                                                                queryCommentsRecord(
                                                                              queryBuilder: (commentsRecord) => commentsRecord.where(
                                                                                'postID',
                                                                                isEqualTo: carouselPostsRecord.reference,
                                                                              ),
                                                                            ),
                                                                            builder:
                                                                                (context, snapshot) {
                                                                              // Customize what your widget looks like when it's loading.
                                                                              if (!snapshot.hasData) {
                                                                                return const Center(
                                                                                  child: SizedBox(
                                                                                    width: 45.0,
                                                                                    height: 45.0,
                                                                                    child: SpinKitCircle(
                                                                                      color: Color(0x004B39EF),
                                                                                      size: 45.0,
                                                                                    ),
                                                                                  ),
                                                                                );
                                                                              }
                                                                              List<CommentsRecord> commentWrapperCommentsRecordList = snapshot.data!;
                                                                              return Container(
                                                                                width: double.infinity,
                                                                                height: 65.0,
                                                                                decoration: const BoxDecoration(),
                                                                                child: InkWell(
                                                                                  splashColor: Colors.transparent,
                                                                                  focusColor: Colors.transparent,
                                                                                  hoverColor: Colors.transparent,
                                                                                  highlightColor: Colors.transparent,
                                                                                  onTap: () async {
                                                                                    context.pushNamed(
                                                                                      'comments',
                                                                                      queryParameters: {
                                                                                        'postReference': serializeParam(
                                                                                          carouselPostsRecord.reference,
                                                                                          ParamType.DocumentReference,
                                                                                        ),
                                                                                      }.withoutNulls,
                                                                                    );
                                                                                  },
                                                                                  child: Column(
                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                                                    children: [
                                                                                      ClipRRect(
                                                                                        borderRadius: BorderRadius.circular(8.0),
                                                                                        child: SvgPicture.asset(
                                                                                          'assets/images/Post_Comments.svg',
                                                                                          width: 32.0,
                                                                                          height: 32.0,
                                                                                          fit: BoxFit.cover,
                                                                                        ),
                                                                                      ),
                                                                                      Padding(
                                                                                        padding: const EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 0.0, 0.0),
                                                                                        child: Text(
                                                                                          formatNumber(
                                                                                            commentWrapperCommentsRecordList.length,
                                                                                            formatType: FormatType.compact,
                                                                                          ),
                                                                                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                fontFamily: 'Inter',
                                                                                                color: FlutterFlowTheme.of(context).primaryText,
                                                                                                fontSize: 12.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w600,
                                                                                              ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              );
                                                                            },
                                                                          ),
                                                                          Container(
                                                                            width:
                                                                                double.infinity,
                                                                            height:
                                                                                54.0,
                                                                            decoration:
                                                                                const BoxDecoration(),
                                                                            child:
                                                                                Align(
                                                                              alignment: const AlignmentDirectional(0.0, 0.0),
                                                                              child: Stack(
                                                                                children: [
                                                                                  Align(
                                                                                    alignment: const AlignmentDirectional(0.0, 0.0),
                                                                                    child: InkWell(
                                                                                      splashColor: Colors.transparent,
                                                                                      focusColor: Colors.transparent,
                                                                                      hoverColor: Colors.transparent,
                                                                                      highlightColor: Colors.transparent,
                                                                                      onTap: () async {
                                                                                        HapticFeedback.lightImpact();

                                                                                        await SavedPostsRecord.collection.doc().set(createSavedPostsRecordData(
                                                                                              userID: currentUserReference,
                                                                                              postID: carouselPostsRecord.reference,
                                                                                              uniqueID: '${currentUserReference?.id}_${carouselPostsRecord.reference.id}',
                                                                                              postImage: carouselPostsRecord.postImage,
                                                                                              savedDate: getCurrentTimestamp,
                                                                                              video: carouselPostsRecord.video,
                                                                                              videoUrl: carouselPostsRecord.videoUrl,
                                                                                              username: carouselPostsRecord.username,
                                                                                              videoCover: carouselPostsRecord.videoCover,
                                                                                            ));
                                                                                      },
                                                                                      child: ClipRRect(
                                                                                        borderRadius: BorderRadius.circular(8.0),
                                                                                        child: SvgPicture.asset(
                                                                                          'assets/images/Post_Saved_NotActive.svg',
                                                                                          width: 32.0,
                                                                                          height: 32.0,
                                                                                          fit: BoxFit.cover,
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  Align(
                                                                                    alignment: const AlignmentDirectional(0.0, 0.0),
                                                                                    child: StreamBuilder<List<SavedPostsRecord>>(
                                                                                      stream: querySavedPostsRecord(
                                                                                        queryBuilder: (savedPostsRecord) => savedPostsRecord.where(
                                                                                          'uniqueID',
                                                                                          isEqualTo: '${currentUserReference?.id}_${carouselPostsRecord.reference.id}',
                                                                                        ),
                                                                                        singleRecord: true,
                                                                                      ),
                                                                                      builder: (context, snapshot) {
                                                                                        // Customize what your widget looks like when it's loading.
                                                                                        if (!snapshot.hasData) {
                                                                                          return const Center(
                                                                                            child: SizedBox(
                                                                                              width: 0.1,
                                                                                              height: 0.1,
                                                                                              child: SpinKitCircle(
                                                                                                color: Color(0x00010101),
                                                                                                size: 0.1,
                                                                                              ),
                                                                                            ),
                                                                                          );
                                                                                        }
                                                                                        List<SavedPostsRecord> savedPostSavedPostsRecordList = snapshot.data!;
                                                                                        // Return an empty Container when the item does not exist.
                                                                                        if (snapshot.data!.isEmpty) {
                                                                                          return Container();
                                                                                        }
                                                                                        final savedPostSavedPostsRecord = savedPostSavedPostsRecordList.isNotEmpty ? savedPostSavedPostsRecordList.first : null;
                                                                                        return InkWell(
                                                                                          splashColor: Colors.transparent,
                                                                                          focusColor: Colors.transparent,
                                                                                          hoverColor: Colors.transparent,
                                                                                          highlightColor: Colors.transparent,
                                                                                          onTap: () async {
                                                                                            await savedPostSavedPostsRecord!.reference.delete();
                                                                                          },
                                                                                          child: ClipRRect(
                                                                                            borderRadius: BorderRadius.circular(8.0),
                                                                                            child: SvgPicture.asset(
                                                                                              'assets/images/Post_Saved_Active.svg',
                                                                                              width: 32.0,
                                                                                              height: 32.0,
                                                                                              fit: BoxFit.cover,
                                                                                            ),
                                                                                          ),
                                                                                        );
                                                                                      },
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Align(
                                                                            alignment:
                                                                                const AlignmentDirectional(0.0, 0.0),
                                                                            child:
                                                                                Container(
                                                                              width: 70.0,
                                                                              height: 40.0,
                                                                              decoration: const BoxDecoration(),
                                                                              child: InkWell(
                                                                                splashColor: Colors.transparent,
                                                                                focusColor: Colors.transparent,
                                                                                hoverColor: Colors.transparent,
                                                                                highlightColor: Colors.transparent,
                                                                                onTap: () async {
                                                                                  HapticFeedback.lightImpact();
                                                                                  if (carouselPostsRecord.userID == currentUserReference) {
                                                                                    // PostOwner
                                                                                    showModalBottomSheet(
                                                                                      isScrollControlled: true,
                                                                                      backgroundColor: Colors.transparent,
                                                                                      barrierColor: const Color(0xB2000000),
                                                                                      useSafeArea: true,
                                                                                      context: context,
                                                                                      builder: (context) {
                                                                                        return GestureDetector(
                                                                                          onTap: () => _model.unfocusNode.canRequestFocus ? FocusScope.of(context).requestFocus(_model.unfocusNode) : FocusScope.of(context).unfocus(),
                                                                                          child: Padding(
                                                                                            padding: MediaQuery.viewInsetsOf(context),
                                                                                            child: ModalPostOwnerWidget(
                                                                                              postReference: carouselPostsRecord.reference,
                                                                                            ),
                                                                                          ),
                                                                                        );
                                                                                      },
                                                                                    ).then((value) => safeSetState(() {}));
                                                                                  } else {
                                                                                    // PostOwner
                                                                                    showModalBottomSheet(
                                                                                      isScrollControlled: true,
                                                                                      backgroundColor: Colors.transparent,
                                                                                      barrierColor: const Color(0xB2000000),
                                                                                      useSafeArea: true,
                                                                                      context: context,
                                                                                      builder: (context) {
                                                                                        return GestureDetector(
                                                                                          onTap: () => _model.unfocusNode.canRequestFocus ? FocusScope.of(context).requestFocus(_model.unfocusNode) : FocusScope.of(context).unfocus(),
                                                                                          child: Padding(
                                                                                            padding: MediaQuery.viewInsetsOf(context),
                                                                                            child: ModalPostUserWidget(
                                                                                              postReference: carouselPostsRecord.reference,
                                                                                            ),
                                                                                          ),
                                                                                        );
                                                                                      },
                                                                                    ).then((value) => safeSetState(() {}));
                                                                                  }
                                                                                },
                                                                                child: Row(
                                                                                  mainAxisSize: MainAxisSize.max,
                                                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                                                  children: [
                                                                                    ClipRRect(
                                                                                      borderRadius: BorderRadius.circular(8.0),
                                                                                      child: SvgPicture.asset(
                                                                                        'assets/images/Post_More.svg',
                                                                                        width: 25.0,
                                                                                        height: 25.0,
                                                                                        fit: BoxFit.cover,
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          if (carouselPostsRecord.partnerredWith !=
                                                                              null)
                                                                            StreamBuilder<PartnersRecord>(
                                                                              stream: PartnersRecord.getDocument(carouselPostsRecord.partnerredWith!),
                                                                              builder: (context, snapshot) {
                                                                                // Customize what your widget looks like when it's loading.
                                                                                if (!snapshot.hasData) {
                                                                                  return Center(
                                                                                    child: SizedBox(
                                                                                      width: 20.0,
                                                                                      height: 20.0,
                                                                                      child: SpinKitCircle(
                                                                                        color: FlutterFlowTheme.of(context).greyButtonLine,
                                                                                        size: 20.0,
                                                                                      ),
                                                                                    ),
                                                                                  );
                                                                                }
                                                                                final containerPartnersRecord = snapshot.data!;
                                                                                return Container(
                                                                                  width: double.infinity,
                                                                                  height: 50.0,
                                                                                  decoration: const BoxDecoration(),
                                                                                  child: Column(
                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                                                    children: [
                                                                                      Container(
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(10.0),
                                                                                          border: Border.all(
                                                                                            color: FlutterFlowTheme.of(context).primaryText,
                                                                                            width: 1.0,
                                                                                          ),
                                                                                        ),
                                                                                        child: ClipRRect(
                                                                                          borderRadius: BorderRadius.circular(10.0),
                                                                                          child: OctoImage(
                                                                                            placeholderBuilder: (_) => const SizedBox.expand(
                                                                                              child: Image(
                                                                                                image: BlurHashImage('LEHV6nWB2yk8pyo0adR*.7kCMdnj'),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                            image: CachedNetworkImageProvider(
                                                                                              valueOrDefault<String>(
                                                                                                containerPartnersRecord.logo,
                                                                                                'https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/beneree-w6h1vi/assets/htchtfdnjwhc/Profile_Picture_Placeholder.png',
                                                                                              ),
                                                                                            ),
                                                                                            width: 30.0,
                                                                                            height: 30.0,
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                );
                                                                              },
                                                                            ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                );
                                              },
                                              carouselController:
                                                  _model.carouselController1 ??=
                                                      CarouselController(),
                                              options: CarouselOptions(
                                                initialPage: max(
                                                    0,
                                                    min(
                                                        0,
                                                        carouselPostsRecordList
                                                                .length -
                                                            1)),
                                                viewportFraction: 1.0,
                                                disableCenter: true,
                                                enlargeCenterPage: false,
                                                enlargeFactor: 0.0,
                                                enableInfiniteScroll: false,
                                                scrollDirection: Axis.vertical,
                                                autoPlay: false,
                                                onPageChanged: (index, _) =>
                                                    _model.carouselCurrentIndex1 =
                                                        index,
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                      Align(
                                        alignment:
                                            const AlignmentDirectional(0.0, -0.87),
                                        child: Padding(
                                          padding:
                                              const EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 10.0, 0.0, 0.0),
                                          child: Builder(
                                            builder: (context) {
                                              final filterData = functions
                                                  .filterDeletedStatus(
                                                      ZoovieAPIGroup
                                                          .clubListCall
                                                          .data(
                                                            (_model.aPICall
                                                                    ?.jsonBody ??
                                                                ''),
                                                          )!
                                                          .toList())
                                                  .toList();
                                              return SingleChildScrollView(
                                                scrollDirection:
                                                    Axis.horizontal,
                                                child: Row(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  children: List.generate(
                                                      filterData.length,
                                                      (filterDataIndex) {
                                                    final filterDataItem =
                                                        filterData[
                                                            filterDataIndex];
                                                    return Padding(
                                                      padding:
                                                          const EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  20.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Container(
                                                        width: 100.0,
                                                        height: 100.0,
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.white,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      10.0),
                                                          border: Border.all(
                                                            color: FlutterFlowTheme
                                                                    .of(context)
                                                                .primary,
                                                            width: 2.0,
                                                          ),
                                                        ),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          10.0,
                                                                          0.0,
                                                                          10.0,
                                                                          0.0),
                                                              child: Text(
                                                                getJsonField(
                                                                  filterDataItem,
                                                                  r'''$.name''',
                                                                ).toString(),
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .override(
                                                                      fontFamily:
                                                                          'Inter',
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .primaryBackground,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    );
                                                  }).divide(
                                                      const SizedBox(width: 15.0)),
                                                ),
                                              );
                                            },
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              if (FFAppState().exploreFeed == false)
                                Container(
                                  decoration: const BoxDecoration(),
                                  child: Stack(
                                    children: [
                                      StreamBuilder<List<PostsRecord>>(
                                        stream: queryPostsRecord(),
                                        builder: (context, snapshot) {
                                          // Customize what your widget looks like when it's loading.
                                          if (!snapshot.hasData) {
                                            return const SizedBox(
                                              width: double.infinity,
                                              height: double.infinity,
                                              child: LogoAnimationWidget(),
                                            );
                                          }
                                          List<PostsRecord>
                                              carouselPostsRecordList =
                                              snapshot.data!;
                                          return SizedBox(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: CarouselSlider.builder(
                                              itemCount: carouselPostsRecordList
                                                  .length,
                                              itemBuilder:
                                                  (context, carouselIndex, _) {
                                                final carouselPostsRecord =
                                                    carouselPostsRecordList[
                                                        carouselIndex];
                                                return Stack(
                                                  children: [
                                                    Container(
                                                      width: double.infinity,
                                                      height: double.infinity,
                                                      decoration: BoxDecoration(
                                                        color: FlutterFlowTheme
                                                                .of(context)
                                                            .primaryBackground,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(0.0),
                                                      ),
                                                      child: Stack(
                                                        children: [
                                                          if (carouselPostsRecord
                                                                  .video ==
                                                              false)
                                                            Align(
                                                              alignment:
                                                                  const AlignmentDirectional(
                                                                      0.0, 0.0),
                                                              child: ClipRRect(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            0.0),
                                                                child:
                                                                    OctoImage(
                                                                  placeholderBuilder:
                                                                      (_) => SizedBox
                                                                          .expand(
                                                                    child:
                                                                        Image(
                                                                      image: BlurHashImage(
                                                                          carouselPostsRecord
                                                                              .imageHash),
                                                                      fit: BoxFit
                                                                          .cover,
                                                                    ),
                                                                  ),
                                                                  image:
                                                                      CachedNetworkImageProvider(
                                                                    carouselPostsRecord
                                                                        .postImage,
                                                                  ),
                                                                  width: double
                                                                      .infinity,
                                                                  height: double
                                                                      .infinity,
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            ),
                                                          if (carouselPostsRecord
                                                                  .video ==
                                                              true)
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          300.0,
                                                                          0.0,
                                                                          0.0),
                                                              child: Container(
                                                                width: double
                                                                    .infinity,
                                                                height: MediaQuery.sizeOf(
                                                                            context)
                                                                        .height *
                                                                    1.0,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .primaryBackground,
                                                                  image:
                                                                      DecorationImage(
                                                                    fit: BoxFit
                                                                        .cover,
                                                                    image: Image
                                                                        .asset(
                                                                      'assets/images/Video_LogoAnimation.gif',
                                                                    ).image,
                                                                  ),
                                                                ),
                                                                child:
                                                                    FlutterFlowVideoPlayer(
                                                                  path: carouselPostsRecord
                                                                      .videoUrl,
                                                                  videoType:
                                                                      VideoType
                                                                          .network,
                                                                  aspectRatio:
                                                                      0.56,
                                                                  autoPlay:
                                                                      true,
                                                                  looping: true,
                                                                  showControls:
                                                                      false,
                                                                  allowFullScreen:
                                                                      true,
                                                                  allowPlaybackSpeedMenu:
                                                                      false,
                                                                  lazyLoad:
                                                                      true,
                                                                ),
                                                              ),
                                                            ),
                                                          Align(
                                                            alignment:
                                                                const AlignmentDirectional(
                                                                    0.0, 0.0),
                                                            child: Container(
                                                              width: double
                                                                  .infinity,
                                                              height: double
                                                                  .infinity,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: const Color(
                                                                    0x1A010101),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            0.0),
                                                              ),
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment:
                                                                const AlignmentDirectional(
                                                                    0.0, 1.0),
                                                            child: Container(
                                                              width: double
                                                                  .infinity,
                                                              decoration:
                                                                  const BoxDecoration(),
                                                              child: Row(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .end,
                                                                children: [
                                                                  Expanded(
                                                                    child:
                                                                        Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .end,
                                                                      children: [
                                                                        Padding(
                                                                          padding: const EdgeInsetsDirectional.fromSTEB(
                                                                              20.0,
                                                                              0.0,
                                                                              0.0,
                                                                              10.0),
                                                                          child:
                                                                              Row(
                                                                            mainAxisSize:
                                                                                MainAxisSize.max,
                                                                            children:
                                                                                [
                                                                              if (carouselPostsRecord.location != '')
                                                                                Container(
                                                                                  decoration: BoxDecoration(
                                                                                    color: const Color(0xCC2B2B2B),
                                                                                    borderRadius: BorderRadius.circular(7.0),
                                                                                  ),
                                                                                  child: Row(
                                                                                    mainAxisSize: MainAxisSize.min,
                                                                                    children: [
                                                                                      Padding(
                                                                                        padding: const EdgeInsets.all(4.0),
                                                                                        child: SvgPicture.asset(
                                                                                          'assets/images/Location_Bold_White.svg',
                                                                                          width: 15.0,
                                                                                          height: 15.0,
                                                                                          fit: BoxFit.cover,
                                                                                        ),
                                                                                      ),
                                                                                      Padding(
                                                                                        padding: const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 8.0, 0.0),
                                                                                        child: Text(
                                                                                          carouselPostsRecord.location.maybeHandleOverflow(
                                                                                            maxChars: 20,
                                                                                            replacement: '…',
                                                                                          ),
                                                                                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                fontFamily: 'Inter',
                                                                                                color: FlutterFlowTheme.of(context).whiteButton,
                                                                                                fontSize: 12.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w500,
                                                                                              ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              if (carouselPostsRecord.taggedUsers.isNotEmpty)
                                                                                InkWell(
                                                                                  splashColor: Colors.transparent,
                                                                                  focusColor: Colors.transparent,
                                                                                  hoverColor: Colors.transparent,
                                                                                  highlightColor: Colors.transparent,
                                                                                  onTap: () async {
                                                                                    await showModalBottomSheet(
                                                                                      isScrollControlled: true,
                                                                                      backgroundColor: Colors.transparent,
                                                                                      barrierColor: const Color(0xB2000000),
                                                                                      enableDrag: false,
                                                                                      context: context,
                                                                                      builder: (context) {
                                                                                        return GestureDetector(
                                                                                          onTap: () => _model.unfocusNode.canRequestFocus ? FocusScope.of(context).requestFocus(_model.unfocusNode) : FocusScope.of(context).unfocus(),
                                                                                          child: Padding(
                                                                                            padding: MediaQuery.viewInsetsOf(context),
                                                                                            child: TaggedUsersWidget(
                                                                                              postReference: carouselPostsRecord.reference,
                                                                                            ),
                                                                                          ),
                                                                                        );
                                                                                      },
                                                                                    ).then((value) => safeSetState(() {}));
                                                                                  },
                                                                                  child: Container(
                                                                                    decoration: BoxDecoration(
                                                                                      color: const Color(0xCC2B2B2B),
                                                                                      borderRadius: BorderRadius.circular(7.0),
                                                                                    ),
                                                                                    child: Row(
                                                                                      mainAxisSize: MainAxisSize.min,
                                                                                      children: [
                                                                                        Padding(
                                                                                          padding: const EdgeInsets.all(4.0),
                                                                                          child: SvgPicture.asset(
                                                                                            'assets/images/Tagged_Users_Blod_White.svg',
                                                                                            width: 15.0,
                                                                                            height: 15.0,
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                        Padding(
                                                                                          padding: const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 8.0, 0.0),
                                                                                          child: Text(
                                                                                            'With ${'${carouselPostsRecord.taggedUsers.length.toString()}${carouselPostsRecord.taggedUsers.length == 1 ? ' other' : ' others'}'}',
                                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                  fontFamily: 'Inter',
                                                                                                  color: FlutterFlowTheme.of(context).whiteButton,
                                                                                                  fontSize: 12.0,
                                                                                                  letterSpacing: 0.0,
                                                                                                  fontWeight: FontWeight.w500,
                                                                                                ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                            ].divide(const SizedBox(width: 6.0)),
                                                                          ),
                                                                        ),
                                                                        Row(
                                                                          mainAxisSize:
                                                                              MainAxisSize.max,
                                                                          children: [
                                                                            Padding(
                                                                              padding: const EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 15.0, 0.0),
                                                                              child: InkWell(
                                                                                splashColor: Colors.transparent,
                                                                                focusColor: Colors.transparent,
                                                                                hoverColor: Colors.transparent,
                                                                                highlightColor: Colors.transparent,
                                                                                onTap: () async {
                                                                                  if (carouselPostsRecord.userID == currentUserReference) {
                                                                                    context.pushNamed('profile');
                                                                                  } else {
                                                                                    context.pushNamed(
                                                                                      'publicProfile',
                                                                                      queryParameters: {
                                                                                        'userReference': serializeParam(
                                                                                          carouselPostsRecord.userID,
                                                                                          ParamType.DocumentReference,
                                                                                        ),
                                                                                      }.withoutNulls,
                                                                                    );
                                                                                  }
                                                                                },
                                                                                child: Row(
                                                                                  mainAxisSize: MainAxisSize.max,
                                                                                  children: [
                                                                                    Container(
                                                                                      width: 40.0,
                                                                                      height: 40.0,
                                                                                      decoration: const BoxDecoration(),
                                                                                      child: Column(
                                                                                        mainAxisSize: MainAxisSize.max,
                                                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                        children: [
                                                                                          ClipRRect(
                                                                                            borderRadius: BorderRadius.circular(50.0),
                                                                                            child: OctoImage(
                                                                                              placeholderBuilder: (_) => const SizedBox.expand(
                                                                                                child: Image(
                                                                                                  image: BlurHashImage('LEHV6nWB2yk8pyo0adR*.7kCMdnj'),
                                                                                                  fit: BoxFit.cover,
                                                                                                ),
                                                                                              ),
                                                                                              image: CachedNetworkImageProvider(
                                                                                                carouselPostsRecord.userProfilePicture,
                                                                                              ),
                                                                                              width: 32.0,
                                                                                              height: 32.0,
                                                                                              fit: BoxFit.cover,
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                    Text(
                                                                                      carouselPostsRecord.username.maybeHandleOverflow(
                                                                                        maxChars: 20,
                                                                                        replacement: '…',
                                                                                      ),
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            fontFamily: 'Inter',
                                                                                            color: FlutterFlowTheme.of(context).primaryText,
                                                                                            fontSize: 15.0,
                                                                                            letterSpacing: 0.0,
                                                                                            fontWeight: FontWeight.w600,
                                                                                          ),
                                                                                    ),
                                                                                    if (carouselPostsRecord.isUserVerified == true)
                                                                                      Padding(
                                                                                        padding: const EdgeInsetsDirectional.fromSTEB(5.0, 0.0, 0.0, 0.0),
                                                                                        child: SvgPicture.asset(
                                                                                          'assets/images/Verified_Bold_White.svg',
                                                                                          width: 13.0,
                                                                                          height: 13.0,
                                                                                          fit: BoxFit.cover,
                                                                                        ),
                                                                                      ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            if (carouselPostsRecord.userID !=
                                                                                currentUserReference)
                                                                              AuthUserStreamWidget(
                                                                                builder: (context) => FFButtonWidget(
                                                                                  onPressed: () async {
                                                                                    final firestoreBatch = FirebaseFirestore.instance.batch();
                                                                                    try {
                                                                                      if ((currentUserDocument?.following.toList() ?? []).contains(carouselPostsRecord.userID) == false) {
                                                                                        firestoreBatch.update(currentUserReference!, {
                                                                                          ...mapToFirestore(
                                                                                            {
                                                                                              'following': FieldValue.arrayUnion([
                                                                                                carouselPostsRecord.userID
                                                                                              ]),
                                                                                            },
                                                                                          ),
                                                                                        });

                                                                                        firestoreBatch.update(carouselPostsRecord.userID!, {
                                                                                          ...createUsersRecordData(
                                                                                            newNotification: true,
                                                                                          ),
                                                                                          ...mapToFirestore(
                                                                                            {
                                                                                              'followers': FieldValue.arrayUnion([
                                                                                                currentUserReference
                                                                                              ]),
                                                                                            },
                                                                                          ),
                                                                                        });

                                                                                        firestoreBatch.set(
                                                                                            NotificationsRecord.collection.doc(),
                                                                                            createNotificationsRecordData(
                                                                                              dateCreated: getCurrentTimestamp,
                                                                                              receiverID: carouselPostsRecord.userID,
                                                                                              senderID: currentUserReference,
                                                                                              senderUsername: valueOrDefault(currentUserDocument?.username, ''),
                                                                                              senderProfilePicture: currentUserPhoto,
                                                                                              followers: true,
                                                                                              notification: ' started following you. ',
                                                                                            ));
                                                                                        HapticFeedback.lightImpact();
                                                                                      } else {
                                                                                        firestoreBatch.update(currentUserReference!, {
                                                                                          ...mapToFirestore(
                                                                                            {
                                                                                              'following': FieldValue.arrayRemove([
                                                                                                carouselPostsRecord.userID
                                                                                              ]),
                                                                                            },
                                                                                          ),
                                                                                        });

                                                                                        firestoreBatch.update(carouselPostsRecord.userID!, {
                                                                                          ...mapToFirestore(
                                                                                            {
                                                                                              'followers': FieldValue.arrayRemove([
                                                                                                currentUserReference
                                                                                              ]),
                                                                                            },
                                                                                          ),
                                                                                        });
                                                                                        HapticFeedback.lightImpact();
                                                                                      }
                                                                                    } finally {
                                                                                      await firestoreBatch.commit();
                                                                                    }
                                                                                  },
                                                                                  text: (currentUserDocument?.following.toList() ?? []).contains(carouselPostsRecord.userID) == true ? 'Following' : 'Follow',
                                                                                  options: FFButtonOptions(
                                                                                    height: 25.0,
                                                                                    padding: const EdgeInsetsDirectional.fromSTEB(6.0, 0.0, 6.0, 0.0),
                                                                                    iconPadding: const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                                                                                    color: (currentUserDocument?.following.toList() ?? []).contains(carouselPostsRecord.userID) == true ? FlutterFlowTheme.of(context).whiteButton : const Color(0x00FFFFFF),
                                                                                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                          fontFamily: 'Inter',
                                                                                          color: (currentUserDocument?.following.toList() ?? []).contains(carouselPostsRecord.userID) == true ? FlutterFlowTheme.of(context).blackText : FlutterFlowTheme.of(context).primaryText,
                                                                                          fontSize: 13.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FontWeight.w600,
                                                                                        ),
                                                                                    elevation: 0.0,
                                                                                    borderSide: const BorderSide(
                                                                                      color: Color(0xA7FFFFFF),
                                                                                      width: 1.0,
                                                                                    ),
                                                                                    borderRadius: BorderRadius.circular(8.0),
                                                                                  ),
                                                                                  showLoadingIndicator: false,
                                                                                ),
                                                                              ),
                                                                          ],
                                                                        ),
                                                                        Padding(
                                                                          padding: const EdgeInsetsDirectional.fromSTEB(
                                                                              20.0,
                                                                              0.0,
                                                                              0.0,
                                                                              20.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                double.infinity,
                                                                            color:
                                                                                const Color(0x00000000),
                                                                            child:
                                                                                ExpandableNotifier(
                                                                              initialExpanded: false,
                                                                              child: ExpandablePanel(
                                                                                header: Text(
                                                                                  '',
                                                                                  style: FlutterFlowTheme.of(context).displaySmall.override(
                                                                                        fontFamily: 'Inter',
                                                                                        color: FlutterFlowTheme.of(context).primaryText,
                                                                                        fontSize: 0.0,
                                                                                        letterSpacing: 0.0,
                                                                                      ),
                                                                                ),
                                                                                collapsed: Container(
                                                                                  width: double.infinity,
                                                                                  decoration: const BoxDecoration(),
                                                                                  child: Text(
                                                                                    carouselPostsRecord.caption.maybeHandleOverflow(
                                                                                      maxChars: 35,
                                                                                      replacement: '…',
                                                                                    ),
                                                                                    maxLines: 1,
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          fontFamily: 'Inter',
                                                                                          color: FlutterFlowTheme.of(context).primaryText,
                                                                                          fontSize: 15.0,
                                                                                          letterSpacing: 0.0,
                                                                                          lineHeight: 1.3,
                                                                                        ),
                                                                                  ),
                                                                                ),
                                                                                expanded: SingleChildScrollView(
                                                                                  primary: false,
                                                                                  child: Column(
                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                    children: [
                                                                                      Text(
                                                                                        carouselPostsRecord.caption,
                                                                                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                              fontFamily: 'Inter',
                                                                                              color: FlutterFlowTheme.of(context).primaryText,
                                                                                              fontSize: 15.0,
                                                                                              letterSpacing: 0.0,
                                                                                              lineHeight: 1.3,
                                                                                            ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                                theme: const ExpandableThemeData(
                                                                                  tapHeaderToExpand: true,
                                                                                  tapBodyToExpand: true,
                                                                                  tapBodyToCollapse: true,
                                                                                  headerAlignment: ExpandablePanelHeaderAlignment.top,
                                                                                  hasIcon: false,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width: 65.0,
                                                                    decoration:
                                                                        const BoxDecoration(),
                                                                    child:
                                                                        Padding(
                                                                      padding: const EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          15.0),
                                                                      child:
                                                                          Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize.min,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.end,
                                                                        children: [
                                                                          StreamBuilder<
                                                                              List<PostLikesRecord>>(
                                                                            stream:
                                                                                queryPostLikesRecord(
                                                                              queryBuilder: (postLikesRecord) => postLikesRecord.where(
                                                                                'postID',
                                                                                isEqualTo: carouselPostsRecord.reference,
                                                                              ),
                                                                            ),
                                                                            builder:
                                                                                (context, snapshot) {
                                                                              // Customize what your widget looks like when it's loading.
                                                                              if (!snapshot.hasData) {
                                                                                return const Center(
                                                                                  child: SizedBox(
                                                                                    width: 45.0,
                                                                                    height: 45.0,
                                                                                    child: SpinKitCircle(
                                                                                      color: Color(0x004B39EF),
                                                                                      size: 45.0,
                                                                                    ),
                                                                                  ),
                                                                                );
                                                                              }
                                                                              List<PostLikesRecord> likeWrapperPostLikesRecordList = snapshot.data!;
                                                                              return Container(
                                                                                width: double.infinity,
                                                                                height: 65.0,
                                                                                constraints: const BoxConstraints(
                                                                                  minWidth: 80.0,
                                                                                ),
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(30.0),
                                                                                  border: Border.all(
                                                                                    color: Colors.transparent,
                                                                                    width: 0.0,
                                                                                  ),
                                                                                ),
                                                                                child: Column(
                                                                                  mainAxisSize: MainAxisSize.max,
                                                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                                                  children: [
                                                                                    Align(
                                                                                      alignment: const AlignmentDirectional(0.0, 0.0),
                                                                                      child: Stack(
                                                                                        children: [
                                                                                          Align(
                                                                                            alignment: const AlignmentDirectional(0.0, 0.0),
                                                                                            child: InkWell(
                                                                                              splashColor: Colors.transparent,
                                                                                              focusColor: Colors.transparent,
                                                                                              hoverColor: Colors.transparent,
                                                                                              highlightColor: Colors.transparent,
                                                                                              onTap: () async {
                                                                                                final firestoreBatch = FirebaseFirestore.instance.batch();
                                                                                                try {
                                                                                                  HapticFeedback.lightImpact();

                                                                                                  var postLikesRecordReference = PostLikesRecord.collection.doc();
                                                                                                  firestoreBatch.set(
                                                                                                      postLikesRecordReference,
                                                                                                      createPostLikesRecordData(
                                                                                                        userID: currentUserReference,
                                                                                                        uniqueID: '${currentUserReference?.id}_${carouselPostsRecord.reference.id}',
                                                                                                        postID: carouselPostsRecord.reference,
                                                                                                        dateCreated: getCurrentTimestamp,
                                                                                                      ));
                                                                                                  _model.newLike22 = PostLikesRecord.getDocumentFromData(
                                                                                                      createPostLikesRecordData(
                                                                                                        userID: currentUserReference,
                                                                                                        uniqueID: '${currentUserReference?.id}_${carouselPostsRecord.reference.id}',
                                                                                                        postID: carouselPostsRecord.reference,
                                                                                                        dateCreated: getCurrentTimestamp,
                                                                                                      ),
                                                                                                      postLikesRecordReference);

                                                                                                  firestoreBatch.set(
                                                                                                      NotificationsRecord.collection.doc(),
                                                                                                      createNotificationsRecordData(
                                                                                                        dateCreated: getCurrentTimestamp,
                                                                                                        receiverID: carouselPostsRecord.userID,
                                                                                                        senderID: currentUserReference,
                                                                                                        senderUsername: valueOrDefault(currentUserDocument?.username, ''),
                                                                                                        senderProfilePicture: currentUserPhoto,
                                                                                                        postImage: carouselPostsRecord.postImage,
                                                                                                        like: true,
                                                                                                        postID: carouselPostsRecord.reference,
                                                                                                        notification: ' liked your post. ',
                                                                                                        videoCover: carouselPostsRecord.videoCover,
                                                                                                      ));

                                                                                                  firestoreBatch.update(
                                                                                                      carouselPostsRecord.userID!,
                                                                                                      createUsersRecordData(
                                                                                                        newNotification: true,
                                                                                                      ));
                                                                                                } finally {
                                                                                                  await firestoreBatch.commit();
                                                                                                }

                                                                                                setState(() {});
                                                                                              },
                                                                                              child: ClipRRect(
                                                                                                borderRadius: BorderRadius.circular(8.0),
                                                                                                child: SvgPicture.asset(
                                                                                                  'assets/images/Post_Like_NotActive.svg',
                                                                                                  width: 32.0,
                                                                                                  height: 32.0,
                                                                                                  fit: BoxFit.cover,
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          Align(
                                                                                            alignment: const AlignmentDirectional(0.0, 0.0),
                                                                                            child: StreamBuilder<List<PostLikesRecord>>(
                                                                                              stream: queryPostLikesRecord(
                                                                                                queryBuilder: (postLikesRecord) => postLikesRecord.where(
                                                                                                  'uniqueID',
                                                                                                  isEqualTo: '${currentUserReference?.id}_${carouselPostsRecord.reference.id}',
                                                                                                ),
                                                                                                singleRecord: true,
                                                                                              ),
                                                                                              builder: (context, snapshot) {
                                                                                                // Customize what your widget looks like when it's loading.
                                                                                                if (!snapshot.hasData) {
                                                                                                  return const Center(
                                                                                                    child: SizedBox(
                                                                                                      width: 24.0,
                                                                                                      height: 24.0,
                                                                                                      child: CircularProgressIndicator(
                                                                                                        valueColor: AlwaysStoppedAnimation<Color>(
                                                                                                          Color(0x004B39EF),
                                                                                                        ),
                                                                                                      ),
                                                                                                    ),
                                                                                                  );
                                                                                                }
                                                                                                List<PostLikesRecord> activeHeart2PostLikesRecordList = snapshot.data!;
                                                                                                // Return an empty Container when the item does not exist.
                                                                                                if (snapshot.data!.isEmpty) {
                                                                                                  return Container();
                                                                                                }
                                                                                                final activeHeart2PostLikesRecord = activeHeart2PostLikesRecordList.isNotEmpty ? activeHeart2PostLikesRecordList.first : null;
                                                                                                return InkWell(
                                                                                                  splashColor: Colors.transparent,
                                                                                                  focusColor: Colors.transparent,
                                                                                                  hoverColor: Colors.transparent,
                                                                                                  highlightColor: Colors.transparent,
                                                                                                  onTap: () async {
                                                                                                    HapticFeedback.lightImpact();
                                                                                                    unawaited(
                                                                                                      () async {
                                                                                                        await activeHeart2PostLikesRecord!.reference.delete();
                                                                                                      }(),
                                                                                                    );
                                                                                                  },
                                                                                                  child: ClipRRect(
                                                                                                    borderRadius: BorderRadius.circular(8.0),
                                                                                                    child: SvgPicture.asset(
                                                                                                      'assets/images/Post_Like_Active.svg',
                                                                                                      width: 32.0,
                                                                                                      height: 32.0,
                                                                                                      fit: BoxFit.cover,
                                                                                                    ),
                                                                                                  ),
                                                                                                );
                                                                                              },
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                    Padding(
                                                                                      padding: const EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 0.0, 0.0),
                                                                                      child: InkWell(
                                                                                        splashColor: Colors.transparent,
                                                                                        focusColor: Colors.transparent,
                                                                                        hoverColor: Colors.transparent,
                                                                                        highlightColor: Colors.transparent,
                                                                                        onTap: () async {
                                                                                          if (carouselPostsRecord.userID == currentUserReference) {
                                                                                            await showModalBottomSheet(
                                                                                              isScrollControlled: true,
                                                                                              backgroundColor: Colors.transparent,
                                                                                              barrierColor: const Color(0xCB000000),
                                                                                              context: context,
                                                                                              builder: (context) {
                                                                                                return GestureDetector(
                                                                                                  onTap: () => _model.unfocusNode.canRequestFocus ? FocusScope.of(context).requestFocus(_model.unfocusNode) : FocusScope.of(context).unfocus(),
                                                                                                  child: Padding(
                                                                                                    padding: MediaQuery.viewInsetsOf(context),
                                                                                                    child: PostLikeListWidget(
                                                                                                      postReference: carouselPostsRecord.reference,
                                                                                                    ),
                                                                                                  ),
                                                                                                );
                                                                                              },
                                                                                            ).then((value) => safeSetState(() {}));
                                                                                          }
                                                                                        },
                                                                                        child: Text(
                                                                                          valueOrDefault<String>(
                                                                                            carouselPostsRecord.hideLikeCount == true
                                                                                                ? 'Likes'
                                                                                                : formatNumber(
                                                                                                    likeWrapperPostLikesRecordList.length,
                                                                                                    formatType: FormatType.compact,
                                                                                                  ),
                                                                                            'Likes',
                                                                                          ),
                                                                                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                fontFamily: 'Inter',
                                                                                                color: FlutterFlowTheme.of(context).primaryText,
                                                                                                fontSize: 12.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w600,
                                                                                              ),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              );
                                                                            },
                                                                          ),
                                                                          StreamBuilder<
                                                                              List<CommentsRecord>>(
                                                                            stream:
                                                                                queryCommentsRecord(
                                                                              queryBuilder: (commentsRecord) => commentsRecord.where(
                                                                                'postID',
                                                                                isEqualTo: carouselPostsRecord.reference,
                                                                              ),
                                                                            ),
                                                                            builder:
                                                                                (context, snapshot) {
                                                                              // Customize what your widget looks like when it's loading.
                                                                              if (!snapshot.hasData) {
                                                                                return const Center(
                                                                                  child: SizedBox(
                                                                                    width: 45.0,
                                                                                    height: 45.0,
                                                                                    child: SpinKitCircle(
                                                                                      color: Color(0x004B39EF),
                                                                                      size: 45.0,
                                                                                    ),
                                                                                  ),
                                                                                );
                                                                              }
                                                                              List<CommentsRecord> commentWrapperCommentsRecordList = snapshot.data!;
                                                                              return Container(
                                                                                width: double.infinity,
                                                                                height: 65.0,
                                                                                decoration: const BoxDecoration(),
                                                                                child: InkWell(
                                                                                  splashColor: Colors.transparent,
                                                                                  focusColor: Colors.transparent,
                                                                                  hoverColor: Colors.transparent,
                                                                                  highlightColor: Colors.transparent,
                                                                                  onTap: () async {
                                                                                    context.pushNamed(
                                                                                      'comments',
                                                                                      queryParameters: {
                                                                                        'postReference': serializeParam(
                                                                                          carouselPostsRecord.reference,
                                                                                          ParamType.DocumentReference,
                                                                                        ),
                                                                                      }.withoutNulls,
                                                                                    );
                                                                                  },
                                                                                  child: Column(
                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                                                    children: [
                                                                                      ClipRRect(
                                                                                        borderRadius: BorderRadius.circular(8.0),
                                                                                        child: SvgPicture.asset(
                                                                                          'assets/images/Post_Comments.svg',
                                                                                          width: 32.0,
                                                                                          height: 32.0,
                                                                                          fit: BoxFit.cover,
                                                                                        ),
                                                                                      ),
                                                                                      Padding(
                                                                                        padding: const EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 0.0, 0.0),
                                                                                        child: Text(
                                                                                          formatNumber(
                                                                                            commentWrapperCommentsRecordList.length,
                                                                                            formatType: FormatType.compact,
                                                                                          ),
                                                                                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                fontFamily: 'Inter',
                                                                                                color: FlutterFlowTheme.of(context).primaryText,
                                                                                                fontSize: 12.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w600,
                                                                                              ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              );
                                                                            },
                                                                          ),
                                                                          Container(
                                                                            width:
                                                                                double.infinity,
                                                                            height:
                                                                                54.0,
                                                                            decoration:
                                                                                const BoxDecoration(),
                                                                            child:
                                                                                Align(
                                                                              alignment: const AlignmentDirectional(0.0, 0.0),
                                                                              child: Stack(
                                                                                children: [
                                                                                  Align(
                                                                                    alignment: const AlignmentDirectional(0.0, 0.0),
                                                                                    child: InkWell(
                                                                                      splashColor: Colors.transparent,
                                                                                      focusColor: Colors.transparent,
                                                                                      hoverColor: Colors.transparent,
                                                                                      highlightColor: Colors.transparent,
                                                                                      onTap: () async {
                                                                                        HapticFeedback.lightImpact();

                                                                                        await SavedPostsRecord.collection.doc().set(createSavedPostsRecordData(
                                                                                              userID: currentUserReference,
                                                                                              postID: carouselPostsRecord.reference,
                                                                                              uniqueID: '${currentUserReference?.id}_${carouselPostsRecord.reference.id}',
                                                                                              postImage: carouselPostsRecord.postImage,
                                                                                              savedDate: getCurrentTimestamp,
                                                                                              video: carouselPostsRecord.video,
                                                                                              videoUrl: carouselPostsRecord.videoUrl,
                                                                                              username: carouselPostsRecord.username,
                                                                                              videoCover: carouselPostsRecord.videoCover,
                                                                                            ));
                                                                                      },
                                                                                      child: ClipRRect(
                                                                                        borderRadius: BorderRadius.circular(8.0),
                                                                                        child: SvgPicture.asset(
                                                                                          'assets/images/Post_Saved_NotActive.svg',
                                                                                          width: 32.0,
                                                                                          height: 32.0,
                                                                                          fit: BoxFit.cover,
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  Align(
                                                                                    alignment: const AlignmentDirectional(0.0, 0.0),
                                                                                    child: StreamBuilder<List<SavedPostsRecord>>(
                                                                                      stream: querySavedPostsRecord(
                                                                                        queryBuilder: (savedPostsRecord) => savedPostsRecord.where(
                                                                                          'uniqueID',
                                                                                          isEqualTo: '${currentUserReference?.id}_${carouselPostsRecord.reference.id}',
                                                                                        ),
                                                                                        singleRecord: true,
                                                                                      ),
                                                                                      builder: (context, snapshot) {
                                                                                        // Customize what your widget looks like when it's loading.
                                                                                        if (!snapshot.hasData) {
                                                                                          return const Center(
                                                                                            child: SizedBox(
                                                                                              width: 0.1,
                                                                                              height: 0.1,
                                                                                              child: SpinKitCircle(
                                                                                                color: Color(0x00010101),
                                                                                                size: 0.1,
                                                                                              ),
                                                                                            ),
                                                                                          );
                                                                                        }
                                                                                        List<SavedPostsRecord> savedPostSavedPostsRecordList = snapshot.data!;
                                                                                        // Return an empty Container when the item does not exist.
                                                                                        if (snapshot.data!.isEmpty) {
                                                                                          return Container();
                                                                                        }
                                                                                        final savedPostSavedPostsRecord = savedPostSavedPostsRecordList.isNotEmpty ? savedPostSavedPostsRecordList.first : null;
                                                                                        return InkWell(
                                                                                          splashColor: Colors.transparent,
                                                                                          focusColor: Colors.transparent,
                                                                                          hoverColor: Colors.transparent,
                                                                                          highlightColor: Colors.transparent,
                                                                                          onTap: () async {
                                                                                            await savedPostSavedPostsRecord!.reference.delete();
                                                                                          },
                                                                                          child: ClipRRect(
                                                                                            borderRadius: BorderRadius.circular(8.0),
                                                                                            child: SvgPicture.asset(
                                                                                              'assets/images/Post_Saved_Active.svg',
                                                                                              width: 32.0,
                                                                                              height: 32.0,
                                                                                              fit: BoxFit.cover,
                                                                                            ),
                                                                                          ),
                                                                                        );
                                                                                      },
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Align(
                                                                            alignment:
                                                                                const AlignmentDirectional(0.0, 0.0),
                                                                            child:
                                                                                Container(
                                                                              width: 70.0,
                                                                              height: 40.0,
                                                                              decoration: const BoxDecoration(),
                                                                              child: InkWell(
                                                                                splashColor: Colors.transparent,
                                                                                focusColor: Colors.transparent,
                                                                                hoverColor: Colors.transparent,
                                                                                highlightColor: Colors.transparent,
                                                                                onTap: () async {
                                                                                  HapticFeedback.lightImpact();
                                                                                  if (carouselPostsRecord.userID == currentUserReference) {
                                                                                    // PostOwner
                                                                                    showModalBottomSheet(
                                                                                      isScrollControlled: true,
                                                                                      backgroundColor: Colors.transparent,
                                                                                      barrierColor: const Color(0xB2000000),
                                                                                      useSafeArea: true,
                                                                                      context: context,
                                                                                      builder: (context) {
                                                                                        return GestureDetector(
                                                                                          onTap: () => _model.unfocusNode.canRequestFocus ? FocusScope.of(context).requestFocus(_model.unfocusNode) : FocusScope.of(context).unfocus(),
                                                                                          child: Padding(
                                                                                            padding: MediaQuery.viewInsetsOf(context),
                                                                                            child: ModalPostOwnerWidget(
                                                                                              postReference: carouselPostsRecord.reference,
                                                                                            ),
                                                                                          ),
                                                                                        );
                                                                                      },
                                                                                    ).then((value) => safeSetState(() {}));
                                                                                  } else {
                                                                                    // PostOwner
                                                                                    showModalBottomSheet(
                                                                                      isScrollControlled: true,
                                                                                      backgroundColor: Colors.transparent,
                                                                                      barrierColor: const Color(0xB2000000),
                                                                                      useSafeArea: true,
                                                                                      context: context,
                                                                                      builder: (context) {
                                                                                        return GestureDetector(
                                                                                          onTap: () => _model.unfocusNode.canRequestFocus ? FocusScope.of(context).requestFocus(_model.unfocusNode) : FocusScope.of(context).unfocus(),
                                                                                          child: Padding(
                                                                                            padding: MediaQuery.viewInsetsOf(context),
                                                                                            child: ModalPostUserWidget(
                                                                                              postReference: carouselPostsRecord.reference,
                                                                                            ),
                                                                                          ),
                                                                                        );
                                                                                      },
                                                                                    ).then((value) => safeSetState(() {}));
                                                                                  }
                                                                                },
                                                                                child: Row(
                                                                                  mainAxisSize: MainAxisSize.max,
                                                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                                                  children: [
                                                                                    ClipRRect(
                                                                                      borderRadius: BorderRadius.circular(8.0),
                                                                                      child: SvgPicture.asset(
                                                                                        'assets/images/Post_More.svg',
                                                                                        width: 25.0,
                                                                                        height: 25.0,
                                                                                        fit: BoxFit.cover,
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          if (carouselPostsRecord.partnerredWith !=
                                                                              null)
                                                                            StreamBuilder<PartnersRecord>(
                                                                              stream: PartnersRecord.getDocument(carouselPostsRecord.partnerredWith!),
                                                                              builder: (context, snapshot) {
                                                                                // Customize what your widget looks like when it's loading.
                                                                                if (!snapshot.hasData) {
                                                                                  return Center(
                                                                                    child: SizedBox(
                                                                                      width: 20.0,
                                                                                      height: 20.0,
                                                                                      child: SpinKitCircle(
                                                                                        color: FlutterFlowTheme.of(context).greyButtonLine,
                                                                                        size: 20.0,
                                                                                      ),
                                                                                    ),
                                                                                  );
                                                                                }
                                                                                final containerPartnersRecord = snapshot.data!;
                                                                                return Container(
                                                                                  width: double.infinity,
                                                                                  height: 50.0,
                                                                                  decoration: const BoxDecoration(),
                                                                                  child: Column(
                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                                                    children: [
                                                                                      Container(
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(10.0),
                                                                                          border: Border.all(
                                                                                            color: FlutterFlowTheme.of(context).primaryText,
                                                                                            width: 1.0,
                                                                                          ),
                                                                                        ),
                                                                                        child: ClipRRect(
                                                                                          borderRadius: BorderRadius.circular(10.0),
                                                                                          child: OctoImage(
                                                                                            placeholderBuilder: (_) => const SizedBox.expand(
                                                                                              child: Image(
                                                                                                image: BlurHashImage('LEHV6nWB2yk8pyo0adR*.7kCMdnj'),
                                                                                                fit: BoxFit.cover,
                                                                                              ),
                                                                                            ),
                                                                                            image: CachedNetworkImageProvider(
                                                                                              valueOrDefault<String>(
                                                                                                containerPartnersRecord.logo,
                                                                                                'https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/beneree-w6h1vi/assets/htchtfdnjwhc/Profile_Picture_Placeholder.png',
                                                                                              ),
                                                                                            ),
                                                                                            width: 30.0,
                                                                                            height: 30.0,
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                );
                                                                              },
                                                                            ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                );
                                              },
                                              carouselController:
                                                  _model.carouselController2 ??=
                                                      CarouselController(),
                                              options: CarouselOptions(
                                                initialPage: max(
                                                    0,
                                                    min(
                                                        0,
                                                        carouselPostsRecordList
                                                                .length -
                                                            1)),
                                                viewportFraction: 1.0,
                                                disableCenter: true,
                                                enlargeCenterPage: false,
                                                enlargeFactor: 0.0,
                                                enableInfiniteScroll: false,
                                                scrollDirection: Axis.vertical,
                                                autoPlay: false,
                                                onPageChanged: (index, _) =>
                                                    _model.carouselCurrentIndex2 =
                                                        index,
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                      Align(
                                        alignment:
                                            const AlignmentDirectional(0.0, -0.87),
                                        child: FutureBuilder<ApiCallResponse>(
                                          future: ZoovieAPIGroup.clubListCall
                                              .call(),
                                          builder: (context, snapshot) {
                                            // Customize what your widget looks like when it's loading.
                                            if (!snapshot.hasData) {
                                              return Center(
                                                child: SizedBox(
                                                  width: 20.0,
                                                  height: 20.0,
                                                  child: SpinKitCircle(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .greyButtonLine,
                                                    size: 20.0,
                                                  ),
                                                ),
                                              );
                                            }
                                            final rowClubListResponse =
                                                snapshot.data!;
                                            return SingleChildScrollView(
                                              scrollDirection: Axis.horizontal,
                                              child: Row(
                                                mainAxisSize: MainAxisSize.max,
                                                children: [
                                                  Padding(
                                                    padding:
                                                        const EdgeInsetsDirectional
                                                            .fromSTEB(20.0, 0.0,
                                                                0.0, 0.0),
                                                    child: Container(
                                                      width: 100.0,
                                                      height: 100.0,
                                                      decoration: BoxDecoration(
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primary,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10.0),
                                                      ),
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: [
                                                          Text(
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getText(
                                                              'istfz5us' /* Hello World */,
                                                            ),
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Inter',
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 100.0,
                                                    height: 100.0,
                                                    decoration: BoxDecoration(
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .primary,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10.0),
                                                    ),
                                                    child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          FFLocalizations.of(
                                                                  context)
                                                              .getText(
                                                            'nnihkyl7' /* Hello World */,
                                                          ),
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium
                                                              .override(
                                                                fontFamily:
                                                                    'Inter',
                                                                letterSpacing:
                                                                    0.0,
                                                              ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 100.0,
                                                    height: 100.0,
                                                    decoration: BoxDecoration(
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .primary,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10.0),
                                                    ),
                                                    child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          FFLocalizations.of(
                                                                  context)
                                                              .getText(
                                                            'w2qi8nfh' /* Hello World */,
                                                          ),
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium
                                                              .override(
                                                                fontFamily:
                                                                    'Inter',
                                                                letterSpacing:
                                                                    0.0,
                                                              ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 100.0,
                                                    height: 100.0,
                                                    decoration: BoxDecoration(
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .primary,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10.0),
                                                    ),
                                                    child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          FFLocalizations.of(
                                                                  context)
                                                              .getText(
                                                            'g13gomh9' /* Hello World */,
                                                          ),
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium
                                                              .override(
                                                                fontFamily:
                                                                    'Inter',
                                                                letterSpacing:
                                                                    0.0,
                                                              ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ].divide(const SizedBox(width: 15.0)),
                                              ),
                                            );
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              if (FFAppState().switchFeeds == true)
                                InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    setState(() {
                                      FFAppState().switchFeeds = false;
                                    });
                                  },
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Align(
                                        alignment:
                                            const AlignmentDirectional(0.0, -1.0),
                                        child: Padding(
                                          padding:
                                              const EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 95.0, 0.0, 0.0),
                                          child: Container(
                                            width: 140.0,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(0.0),
                                            ),
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(10.0),
                                              child: BackdropFilter(
                                                filter: ImageFilter.blur(
                                                  sigmaX: 20.0,
                                                  sigmaY: 20.0,
                                                ),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    color: const Color(0x65000000),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            0.0),
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      InkWell(
                                                        splashColor:
                                                            Colors.transparent,
                                                        focusColor:
                                                            Colors.transparent,
                                                        hoverColor:
                                                            Colors.transparent,
                                                        highlightColor:
                                                            Colors.transparent,
                                                        onTap: () async {
                                                          HapticFeedback
                                                              .lightImpact();
                                                          setState(() {
                                                            FFAppState()
                                                                    .switchFeeds =
                                                                false;
                                                            FFAppState()
                                                                    .exploreFeed =
                                                                true;
                                                          });
                                                        },
                                                        child: Container(
                                                          width:
                                                              double.infinity,
                                                          decoration:
                                                              const BoxDecoration(),
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        15.0,
                                                                        10.0,
                                                                        15.0,
                                                                        10.0),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              children: [
                                                                Text(
                                                                  FFLocalizations.of(
                                                                          context)
                                                                      .getText(
                                                                    'vyen7vud' /* Fun */,
                                                                  ),
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Inter',
                                                                        fontSize:
                                                                            15.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                ),
                                                                ClipRRect(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              8.0),
                                                                  child:
                                                                      SvgPicture
                                                                          .asset(
                                                                    'assets/images/Explore_Bold_White.svg',
                                                                    width: 16.0,
                                                                    height:
                                                                        16.0,
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        width: double.infinity,
                                                        height: 1.0,
                                                        decoration:
                                                            const BoxDecoration(
                                                          color:
                                                              Color(0x7F171717),
                                                        ),
                                                      ),
                                                      InkWell(
                                                        splashColor:
                                                            Colors.transparent,
                                                        focusColor:
                                                            Colors.transparent,
                                                        hoverColor:
                                                            Colors.transparent,
                                                        highlightColor:
                                                            Colors.transparent,
                                                        onTap: () async {
                                                          HapticFeedback
                                                              .lightImpact();
                                                          setState(() {
                                                            FFAppState()
                                                                    .switchFeeds =
                                                                false;
                                                            FFAppState()
                                                                    .exploreFeed =
                                                                false;
                                                          });
                                                        },
                                                        child: Container(
                                                          decoration:
                                                              const BoxDecoration(),
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        15.0,
                                                                        10.0,
                                                                        15.0,
                                                                        10.0),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              children: [
                                                                Text(
                                                                  FFLocalizations.of(
                                                                          context)
                                                                      .getText(
                                                                    'yhjz5pti' /* Near Me */,
                                                                  ),
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .override(
                                                                        fontFamily:
                                                                            'Inter',
                                                                        fontSize:
                                                                            15.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                      ),
                                                                ),
                                                                ClipRRect(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              8.0),
                                                                  child:
                                                                      SvgPicture
                                                                          .asset(
                                                                    'assets/images/NearYou_Bold_White.svg',
                                                                    width: 16.0,
                                                                    height:
                                                                        16.0,
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ).animateOnPageLoad(animationsMap[
                                              'containerOnPageLoadAnimation']!),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              if (FFAppState().logoAnimation == true)
                                wrapWithModel(
                                  model: _model.logoAnimationModel,
                                  updateCallback: () => setState(() {}),
                                  child: const LogoAnimationWidget(),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      decoration: const BoxDecoration(),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 1.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                          ),
                          Container(
                            height: 50.0,
                            decoration: const BoxDecoration(),
                            child: Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  15.0, 5.0, 15.0, 5.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 50.0,
                                    height: 50.0,
                                    decoration: const BoxDecoration(),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                      children: [
                                        SvgPicture.asset(
                                          'assets/images/Home_Active_White.svg',
                                          width: 24.0,
                                          height: 24.0,
                                          fit: BoxFit.cover,
                                        ),
                                        Text(
                                          FFLocalizations.of(context).getText(
                                            'ztglu49u' /* Home */,
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Inter',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                fontSize: 10.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.w500,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    width: 50.0,
                                    height: 50.0,
                                    decoration: const BoxDecoration(),
                                    child: InkWell(
                                      splashColor: Colors.transparent,
                                      focusColor: Colors.transparent,
                                      hoverColor: Colors.transparent,
                                      highlightColor: Colors.transparent,
                                      onTap: () async {
                                        context.goNamed(
                                          'shop',
                                          extra: <String, dynamic>{
                                            kTransitionInfoKey: const TransitionInfo(
                                              hasTransition: true,
                                              transitionType:
                                                  PageTransitionType.fade,
                                              duration:
                                                  Duration(milliseconds: 0),
                                            ),
                                          },
                                        );
                                      },
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          SvgPicture.asset(
                                            'assets/images/Shop_Not_Active_757575.svg',
                                            width: 25.0,
                                            height: 24.0,
                                            fit: BoxFit.cover,
                                          ),
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'b6eh8i1k' /* Events */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Inter',
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .secondaryText,
                                                  fontSize: 10.0,
                                                  letterSpacing: 0.0,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: 50.0,
                                    height: 50.0,
                                    decoration: const BoxDecoration(),
                                    child: InkWell(
                                      splashColor: Colors.transparent,
                                      focusColor: Colors.transparent,
                                      hoverColor: Colors.transparent,
                                      highlightColor: Colors.transparent,
                                      onTap: () async {
                                        if (valueOrDefault<bool>(
                                                currentUserDocument
                                                    ?.businessAccount,
                                                false) ==
                                            false) {
                                          context.goNamed(
                                            'points',
                                            extra: <String, dynamic>{
                                              kTransitionInfoKey:
                                                  const TransitionInfo(
                                                hasTransition: true,
                                                transitionType:
                                                    PageTransitionType.fade,
                                                duration:
                                                    Duration(milliseconds: 0),
                                              ),
                                            },
                                          );
                                        } else {
                                          context.goNamed(
                                            'pointsBusiness',
                                            extra: <String, dynamic>{
                                              kTransitionInfoKey:
                                                  const TransitionInfo(
                                                hasTransition: true,
                                                transitionType:
                                                    PageTransitionType.fade,
                                                duration:
                                                    Duration(milliseconds: 0),
                                              ),
                                            },
                                          );
                                        }
                                      },
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          SvgPicture.asset(
                                            'assets/images/Points_Bold_Grey.svg',
                                            width: 24.0,
                                            height: 24.0,
                                            fit: BoxFit.cover,
                                          ),
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              's1fw2t62' /* History */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Inter',
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .secondaryText,
                                                  fontSize: 10.0,
                                                  letterSpacing: 0.0,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    width: 50.0,
                                    height: 50.0,
                                    decoration: const BoxDecoration(),
                                    child: Stack(
                                      children: [
                                        Container(
                                          width: double.infinity,
                                          height: double.infinity,
                                          decoration: const BoxDecoration(),
                                          child: InkWell(
                                            splashColor: Colors.transparent,
                                            focusColor: Colors.transparent,
                                            hoverColor: Colors.transparent,
                                            highlightColor: Colors.transparent,
                                            onTap: () async {
                                              context.goNamed(
                                                'chats',
                                                extra: <String, dynamic>{
                                                  kTransitionInfoKey:
                                                      const TransitionInfo(
                                                    hasTransition: true,
                                                    transitionType:
                                                        PageTransitionType.fade,
                                                    duration: Duration(
                                                        milliseconds: 0),
                                                  ),
                                                },
                                              );

                                              await currentUserReference!
                                                  .update(createUsersRecordData(
                                                newMessage: false,
                                              ));
                                            },
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                SvgPicture.asset(
                                                  'assets/images/Messages_Gray_Bold.svg',
                                                  width: 24.0,
                                                  height: 24.0,
                                                  fit: BoxFit.cover,
                                                ),
                                                Text(
                                                  FFLocalizations.of(context)
                                                      .getText(
                                                    'ta9kwegb' /* Chats */,
                                                  ),
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Inter',
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .secondaryText,
                                                        fontSize: 10.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        if (valueOrDefault<bool>(
                                                currentUserDocument?.newMessage,
                                                false) ==
                                            true)
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(1.0, -1.0),
                                            child: Padding(
                                              padding: const EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      0.0, 0.0, 5.0, 22.0),
                                              child: AuthUserStreamWidget(
                                                builder: (context) => Material(
                                                  color: Colors.transparent,
                                                  elevation: 3.0,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            50.0),
                                                  ),
                                                  child: Container(
                                                    width: 7.0,
                                                    height: 7.0,
                                                    decoration: BoxDecoration(
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .error,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              50.0),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    width: 50.0,
                                    height: 50.0,
                                    decoration: const BoxDecoration(),
                                    child: InkWell(
                                      splashColor: Colors.transparent,
                                      focusColor: Colors.transparent,
                                      hoverColor: Colors.transparent,
                                      highlightColor: Colors.transparent,
                                      onTap: () async {
                                        context.goNamed(
                                          'profile',
                                          extra: <String, dynamic>{
                                            kTransitionInfoKey: const TransitionInfo(
                                              hasTransition: true,
                                              transitionType:
                                                  PageTransitionType.fade,
                                              duration:
                                                  Duration(milliseconds: 0),
                                            ),
                                          },
                                        );
                                      },
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          AuthUserStreamWidget(
                                            builder: (context) => ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(50.0),
                                              child: CachedNetworkImage(
                                                fadeInDuration:
                                                    const Duration(milliseconds: 500),
                                                fadeOutDuration:
                                                    const Duration(milliseconds: 500),
                                                imageUrl:
                                                    valueOrDefault<String>(
                                                  currentUserPhoto,
                                                  'https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/beneree-w6h1vi/assets/htchtfdnjwhc/Profile_Picture_Placeholder.png',
                                                ),
                                                width: 26.0,
                                                height: 26.0,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'wg00bixy' /* Profile */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Inter',
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .secondaryText,
                                                  fontSize: 10.0,
                                                  letterSpacing: 0.0,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: MediaQuery.sizeOf(context).width * 0.2,
                        height: 40.0,
                        decoration: const BoxDecoration(),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 45.0,
                              height: 45.0,
                              decoration: const BoxDecoration(),
                              child: InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  FFAppState().update(() {
                                    FFAppState().blurredMenuActive = true;
                                  });
                                },
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    SvgPicture.asset(
                                      'assets/images/More_Menu_Bold_White.svg',
                                      width: 23.0,
                                      height: 23.0,
                                      fit: BoxFit.contain,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 150.0,
                        height: 40.0,
                        decoration: const BoxDecoration(),
                        child: InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            if (FFAppState().exploreFeed == true) {
                              HapticFeedback.lightImpact();
                              setState(() {
                                FFAppState().switchFeeds = true;
                              });
                            } else {
                              HapticFeedback.lightImpact();
                              setState(() {
                                FFAppState().switchFeeds = true;
                              });
                            }
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsetsDirectional.fromSTEB(
                                    5.0, 0.0, 0.0, 0.0),
                                child: Text(
                                  FFAppState().exploreFeed == true
                                      ? 'Fun'
                                      : 'Find',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        fontSize: 19.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsetsDirectional.fromSTEB(
                                    5.0, 0.0, 0.0, 0.0),
                                child: Transform.rotate(
                                  angle: 270.0 * (math.pi / 180),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(8.0),
                                    child: SvgPicture.asset(
                                      'assets/images/Alt_Arrow_Linear_Left_White.svg',
                                      width: 20.0,
                                      height: 20.0,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: MediaQuery.sizeOf(context).width * 0.2,
                        height: 40.0,
                        decoration: const BoxDecoration(),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 10.0, 0.0),
                              child: Container(
                                width: 35.0,
                                height: 45.0,
                                decoration: const BoxDecoration(),
                                child: InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    await showModalBottomSheet(
                                      isScrollControlled: true,
                                      backgroundColor: Colors.transparent,
                                      barrierColor: const Color(0xCB000000),
                                      context: context,
                                      builder: (context) {
                                        return GestureDetector(
                                          onTap: () => _model
                                                  .unfocusNode.canRequestFocus
                                              ? FocusScope.of(context)
                                                  .requestFocus(
                                                      _model.unfocusNode)
                                              : FocusScope.of(context)
                                                  .unfocus(),
                                          child: Padding(
                                            padding: MediaQuery.viewInsetsOf(
                                                context),
                                            child:
                                                const ModalSelectImageVideoWidget(),
                                          ),
                                        );
                                      },
                                    ).then((value) => safeSetState(() {}));
                                  },
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      SvgPicture.asset(
                                        'assets/images/Create_Posts_White_Bold.svg',
                                        width: 23.0,
                                        height: 23.0,
                                        fit: BoxFit.cover,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              width: 35.0,
                              height: 45.0,
                              decoration: const BoxDecoration(),
                              child: InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  context.pushNamed('notifications');

                                  await currentUserReference!
                                      .update(createUsersRecordData(
                                    newNotification: false,
                                  ));
                                },
                                child: SizedBox(
                                  width: 25.0,
                                  height: 25.0,
                                  child: Stack(
                                    children: [
                                      Align(
                                        alignment:
                                            const AlignmentDirectional(1.0, 0.0),
                                        child: SvgPicture.asset(
                                          'assets/images/Notifications_Bold_White.svg',
                                          width: 26.0,
                                          height: 26.0,
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      if (valueOrDefault<bool>(
                                              currentUserDocument
                                                  ?.newNotification,
                                              false) ==
                                          true)
                                        Align(
                                          alignment:
                                              const AlignmentDirectional(1.0, -1.0),
                                          child: Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 5.0, 0.0, 0.0),
                                            child: AuthUserStreamWidget(
                                              builder: (context) => Material(
                                                color: Colors.transparent,
                                                elevation: 3.0,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          50.0),
                                                ),
                                                child: Container(
                                                  width: 9.0,
                                                  height: 9.0,
                                                  decoration: BoxDecoration(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .error,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            50.0),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                if (FFAppState().blurredMenuActive == true)
                  wrapWithModel(
                    model: _model.menuFeedPageModel,
                    updateCallback: () => setState(() {}),
                    child: const MenuFeedPageWidget(),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
