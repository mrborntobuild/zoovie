import '/flutter_flow/flutter_flow_util.dart';
import 'menu_feed_page_widget.dart' show MenuFeedPageWidget;
import 'package:flutter/material.dart';

class MenuFeedPageModel extends FlutterFlowModel<MenuFeedPageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
