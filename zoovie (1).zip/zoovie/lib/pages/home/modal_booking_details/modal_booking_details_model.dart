import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'modal_booking_details_widget.dart' show ModalBookingDetailsWidget;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ModalBookingDetailsModel
    extends FlutterFlowModel<ModalBookingDetailsWidget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  // State field(s) for MainColumn widget.
  ScrollController? mainColumn;
  // State field(s) for eventTitle widget.
  FocusNode? eventTitleFocusNode;
  TextEditingController? eventTitleTextController;
  String? Function(BuildContext, String?)? eventTitleTextControllerValidator;
  String? _eventTitleTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'f2o59fs8' /* Field is required */,
      );
    }

    return null;
  }

  // State field(s) for eventNote widget.
  FocusNode? eventNoteFocusNode;
  TextEditingController? eventNoteTextController;
  String? Function(BuildContext, String?)? eventNoteTextControllerValidator;
  DateTime? datePicked1;
  DateTime? datePicked2;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController3;
  String? Function(BuildContext, String?)? textController3Validator;
  // Algolia Search Results from action on TextField
  List<UsersRecord>? algoliaSearchResults = [];
  // State field(s) for searchResults widget.
  ScrollController? searchResults;
  // State field(s) for taggedUsers widget.
  ScrollController? taggedUsers;

  @override
  void initState(BuildContext context) {
    mainColumn = ScrollController();
    eventTitleTextControllerValidator = _eventTitleTextControllerValidator;
    searchResults = ScrollController();
    taggedUsers = ScrollController();
  }

  @override
  void dispose() {
    mainColumn?.dispose();
    eventTitleFocusNode?.dispose();
    eventTitleTextController?.dispose();

    eventNoteFocusNode?.dispose();
    eventNoteTextController?.dispose();

    textFieldFocusNode?.dispose();
    textController3?.dispose();

    searchResults?.dispose();
    taggedUsers?.dispose();
  }
}
