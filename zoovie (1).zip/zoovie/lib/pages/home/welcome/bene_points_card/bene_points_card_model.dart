import '/flutter_flow/flutter_flow_util.dart';
import 'bene_points_card_widget.dart' show BenePointsCardWidget;
import 'package:flutter/material.dart';

class BenePointsCardModel extends FlutterFlowModel<BenePointsCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
