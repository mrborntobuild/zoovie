import '/flutter_flow/flutter_flow_util.dart';
import 'forgot_password_widget.dart' show ForgotPasswordWidget;
import 'package:flutter/material.dart';

class ForgotPasswordModel extends FlutterFlowModel<ForgotPasswordWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // State field(s) for registrationEmail widget.
  FocusNode? registrationEmailFocusNode;
  TextEditingController? registrationEmailTextController;
  String? Function(BuildContext, String?)?
      registrationEmailTextControllerValidator;
  String? _registrationEmailTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'ouxntteh' /* Field is required */,
      );
    }

    return null;
  }

  @override
  void initState(BuildContext context) {
    registrationEmailTextControllerValidator =
        _registrationEmailTextControllerValidator;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    registrationEmailFocusNode?.dispose();
    registrationEmailTextController?.dispose();
  }
}
