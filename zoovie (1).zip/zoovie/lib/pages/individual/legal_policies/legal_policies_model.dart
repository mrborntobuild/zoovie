import '/flutter_flow/flutter_flow_util.dart';
import 'legal_policies_widget.dart' show LegalPoliciesWidget;
import 'package:flutter/material.dart';

class LegalPoliciesModel extends FlutterFlowModel<LegalPoliciesWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for signupPassword widget.
  FocusNode? signupPasswordFocusNode;
  TextEditingController? signupPasswordTextController;
  late bool signupPasswordVisibility;
  String? Function(BuildContext, String?)?
      signupPasswordTextControllerValidator;
  // State field(s) for signupEmail widget.
  FocusNode? signupEmailFocusNode;
  TextEditingController? signupEmailTextController;
  String? Function(BuildContext, String?)? signupEmailTextControllerValidator;

  @override
  void initState(BuildContext context) {
    signupPasswordVisibility = false;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    signupPasswordFocusNode?.dispose();
    signupPasswordTextController?.dispose();

    signupEmailFocusNode?.dispose();
    signupEmailTextController?.dispose();
  }
}
