import '/flutter_flow/flutter_flow_util.dart';
import 'password_widget.dart' show PasswordWidget;
import 'package:flutter/material.dart';

class PasswordModel extends FlutterFlowModel<PasswordWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // State field(s) for registerPassword widget.
  FocusNode? registerPasswordFocusNode;
  TextEditingController? registerPasswordTextController;
  late bool registerPasswordVisibility;
  String? Function(BuildContext, String?)?
      registerPasswordTextControllerValidator;
  String? _registerPasswordTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        '7crfqojh' /* Field is required */,
      );
    }

    if (val.length < 8) {
      return 'Requires at least 8 characters.';
    }

    return null;
  }

  @override
  void initState(BuildContext context) {
    registerPasswordVisibility = false;
    registerPasswordTextControllerValidator =
        _registerPasswordTextControllerValidator;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    registerPasswordFocusNode?.dispose();
    registerPasswordTextController?.dispose();
  }
}
