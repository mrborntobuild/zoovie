import '/flutter_flow/flutter_flow_util.dart';
import 'reset_password_confirmation_widget.dart'
    show ResetPasswordConfirmationWidget;
import 'package:flutter/material.dart';

class ResetPasswordConfirmationModel
    extends FlutterFlowModel<ResetPasswordConfirmationWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
