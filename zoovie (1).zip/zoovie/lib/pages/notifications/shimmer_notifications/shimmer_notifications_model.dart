import '/flutter_flow/flutter_flow_util.dart';
import 'shimmer_notifications_widget.dart' show ShimmerNotificationsWidget;
import 'package:flutter/material.dart';

class ShimmerNotificationsModel
    extends FlutterFlowModel<ShimmerNotificationsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
