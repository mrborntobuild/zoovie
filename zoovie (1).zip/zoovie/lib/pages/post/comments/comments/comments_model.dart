import '/flutter_flow/flutter_flow_util.dart';
import 'comments_widget.dart' show CommentsWidget;
import 'package:flutter/material.dart';

class CommentsModel extends FlutterFlowModel<CommentsWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey2 = GlobalKey<FormState>();
  final formKey1 = GlobalKey<FormState>();
  // State field(s) for ListView widget.
  ScrollController? listViewController;
  // State field(s) for postComment widget.
  FocusNode? postCommentFocusNode;
  TextEditingController? postCommentTextController;
  String? Function(BuildContext, String?)? postCommentTextControllerValidator;
  String? _postCommentTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'n84r3bt8' /* Field is required */,
      );
    }

    return null;
  }

  // State field(s) for postComment2 widget.
  FocusNode? postComment2FocusNode;
  TextEditingController? postComment2TextController;
  String? Function(BuildContext, String?)? postComment2TextControllerValidator;
  String? _postComment2TextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'kbv0b8xi' /* Field is required */,
      );
    }

    return null;
  }

  @override
  void initState(BuildContext context) {
    listViewController = ScrollController();
    postCommentTextControllerValidator = _postCommentTextControllerValidator;
    postComment2TextControllerValidator = _postComment2TextControllerValidator;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    listViewController?.dispose();
    postCommentFocusNode?.dispose();
    postCommentTextController?.dispose();

    postComment2FocusNode?.dispose();
    postComment2TextController?.dispose();
  }
}
