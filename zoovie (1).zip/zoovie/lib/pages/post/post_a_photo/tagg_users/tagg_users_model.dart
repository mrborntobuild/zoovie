import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'tagg_users_widget.dart' show TaggUsersWidget;
import 'package:flutter/material.dart';

class TaggUsersModel extends FlutterFlowModel<TaggUsersWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Algolia Search Results from action on TextField
  List<UsersRecord>? algoliaSearchResults = [];

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
