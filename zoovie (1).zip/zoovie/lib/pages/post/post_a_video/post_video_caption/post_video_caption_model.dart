import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'post_video_caption_widget.dart' show PostVideoCaptionWidget;
import 'package:flutter/material.dart';

class PostVideoCaptionModel extends FlutterFlowModel<PostVideoCaptionWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  PostsRecord? post;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for postCaption widget.
  FocusNode? postCaptionFocusNode;
  TextEditingController? postCaptionTextController;
  String? Function(BuildContext, String?)? postCaptionTextControllerValidator;
  String? _postCaptionTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'j1d2c4ig' /* Field is required */,
      );
    }

    return null;
  }

  // State field(s) for Switch widget.
  bool? switchValue;

  @override
  void initState(BuildContext context) {
    postCaptionTextControllerValidator = _postCaptionTextControllerValidator;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    postCaptionFocusNode?.dispose();
    postCaptionTextController?.dispose();
  }
}
