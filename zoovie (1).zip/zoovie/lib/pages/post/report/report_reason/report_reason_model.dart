import '/flutter_flow/flutter_flow_util.dart';
import 'report_reason_widget.dart' show ReportReasonWidget;
import 'package:flutter/material.dart';

class ReportReasonModel extends FlutterFlowModel<ReportReasonWidget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  // State field(s) for reportDetails widget.
  FocusNode? reportDetailsFocusNode;
  TextEditingController? reportDetailsTextController;
  String? Function(BuildContext, String?)? reportDetailsTextControllerValidator;
  String? _reportDetailsTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'gzwsm59u' /* Field is required */,
      );
    }

    return null;
  }

  @override
  void initState(BuildContext context) {
    reportDetailsTextControllerValidator =
        _reportDetailsTextControllerValidator;
  }

  @override
  void dispose() {
    reportDetailsFocusNode?.dispose();
    reportDetailsTextController?.dispose();
  }
}
