import '/flutter_flow/flutter_flow_util.dart';
import 'add_business_address_widget.dart' show AddBusinessAddressWidget;
import 'package:flutter/material.dart';

class AddBusinessAddressModel
    extends FlutterFlowModel<AddBusinessAddressWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for BusinessName widget.
  FocusNode? businessNameFocusNode1;
  TextEditingController? businessNameTextController1;
  String? Function(BuildContext, String?)? businessNameTextController1Validator;
  // State field(s) for BusinessName widget.
  FocusNode? businessNameFocusNode2;
  TextEditingController? businessNameTextController2;
  String? Function(BuildContext, String?)? businessNameTextController2Validator;
  // State field(s) for BusinessName widget.
  FocusNode? businessNameFocusNode3;
  TextEditingController? businessNameTextController3;
  String? Function(BuildContext, String?)? businessNameTextController3Validator;
  // State field(s) for BusinessName widget.
  FocusNode? businessNameFocusNode4;
  TextEditingController? businessNameTextController4;
  String? Function(BuildContext, String?)? businessNameTextController4Validator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    businessNameFocusNode1?.dispose();
    businessNameTextController1?.dispose();

    businessNameFocusNode2?.dispose();
    businessNameTextController2?.dispose();

    businessNameFocusNode3?.dispose();
    businessNameTextController3?.dispose();

    businessNameFocusNode4?.dispose();
    businessNameTextController4?.dispose();
  }
}
