import '/flutter_flow/flutter_flow_util.dart';
import 'add_business_bio_widget.dart' show AddBusinessBioWidget;
import 'package:flutter/material.dart';

class AddBusinessBioModel extends FlutterFlowModel<AddBusinessBioWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
