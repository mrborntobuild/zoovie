import '/flutter_flow/flutter_flow_util.dart';
import 'add_business_category_widget.dart' show AddBusinessCategoryWidget;
import 'package:flutter/material.dart';

class AddBusinessCategoryModel
    extends FlutterFlowModel<AddBusinessCategoryWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
