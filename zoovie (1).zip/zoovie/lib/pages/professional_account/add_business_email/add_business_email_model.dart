import '/flutter_flow/flutter_flow_util.dart';
import 'add_business_email_widget.dart' show AddBusinessEmailWidget;
import 'package:flutter/material.dart';

class AddBusinessEmailModel extends FlutterFlowModel<AddBusinessEmailWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for BusinessName widget.
  FocusNode? businessNameFocusNode;
  TextEditingController? businessNameTextController;
  String? Function(BuildContext, String?)? businessNameTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    businessNameFocusNode?.dispose();
    businessNameTextController?.dispose();
  }
}
