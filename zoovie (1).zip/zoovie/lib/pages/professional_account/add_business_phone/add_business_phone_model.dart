import '/flutter_flow/flutter_flow_util.dart';
import 'add_business_phone_widget.dart' show AddBusinessPhoneWidget;
import 'package:flutter/material.dart';

class AddBusinessPhoneModel extends FlutterFlowModel<AddBusinessPhoneWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for BusinessName widget.
  FocusNode? businessNameFocusNode;
  TextEditingController? businessNameTextController;
  String? Function(BuildContext, String?)? businessNameTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    businessNameFocusNode?.dispose();
    businessNameTextController?.dispose();
  }
}
