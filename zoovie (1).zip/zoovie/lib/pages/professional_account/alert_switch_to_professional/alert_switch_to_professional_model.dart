import '/flutter_flow/flutter_flow_util.dart';
import 'alert_switch_to_professional_widget.dart'
    show AlertSwitchToProfessionalWidget;
import 'package:flutter/material.dart';

class AlertSwitchToProfessionalModel
    extends FlutterFlowModel<AlertSwitchToProfessionalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
