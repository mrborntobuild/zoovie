import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'following_followers2_widget.dart' show FollowingFollowers2Widget;
import 'package:flutter/material.dart';

class FollowingFollowers2Model
    extends FlutterFlowModel<FollowingFollowers2Widget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode1;
  TextEditingController? textController1;
  String? Function(BuildContext, String?)? textController1Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode2;
  TextEditingController? textController2;
  String? Function(BuildContext, String?)? textController2Validator;
  // Algolia Search Results from action on TextField
  List<UsersRecord>? algoliaSearchResults = [];

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    textFieldFocusNode1?.dispose();
    textController1?.dispose();

    textFieldFocusNode2?.dispose();
    textController2?.dispose();
  }
}
