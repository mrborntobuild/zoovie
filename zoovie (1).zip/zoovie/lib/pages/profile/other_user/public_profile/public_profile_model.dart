import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'public_profile_widget.dart' show PublicProfileWidget;
import 'package:flutter/material.dart';

class PublicProfileModel extends FlutterFlowModel<PublicProfileWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Backend Call - Create Document] action in NewMessage widget.
  ChatsRecord? newChat;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
