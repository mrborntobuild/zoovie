import '/flutter_flow/flutter_flow_util.dart';
import 'shimmer_grid_widget.dart' show ShimmerGridWidget;
import 'package:flutter/material.dart';

class ShimmerGridModel extends FlutterFlowModel<ShimmerGridWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
