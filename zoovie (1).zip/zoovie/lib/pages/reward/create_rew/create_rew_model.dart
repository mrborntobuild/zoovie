import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'create_rew_widget.dart' show CreateRewWidget;
import 'package:flutter/material.dart';

class CreateRewModel extends FlutterFlowModel<CreateRewWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // State field(s) for ReferralCod widget.
  FocusNode? referralCodFocusNode;
  TextEditingController? referralCodTextController;
  String? Function(BuildContext, String?)? referralCodTextControllerValidator;
  String? _referralCodTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'tk9xcccq' /* Field is required */,
      );
    }

    return null;
  }

  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  PointsRecord? pointsId;

  @override
  void initState(BuildContext context) {
    referralCodTextControllerValidator = _referralCodTextControllerValidator;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    referralCodFocusNode?.dispose();
    referralCodTextController?.dispose();
  }
}
