package com.zoovie.zoovie

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
