const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

exports.onUserDeleted = functions
  .region("europe-west3")
  .auth.user()
  .onDelete(async (user) => {
    let firestore = admin.firestore();
    let userRef = firestore.doc("users/" + user.uid);
    await firestore.collection("users").doc(user.uid).delete();
    await firestore
      .collection("usernames")
      .where("userID", "==", userRef)
      .get()
      .then(async (querySnapshot) => {
        for (var doc of querySnapshot.docs) {
          console.log(`Deleting document ${doc.id} from collection usernames`);
          await doc.ref.delete();
        }
      });
    await firestore
      .collection("posts")
      .where("userID", "==", userRef)
      .get()
      .then(async (querySnapshot) => {
        for (var doc of querySnapshot.docs) {
          console.log(`Deleting document ${doc.id} from collection posts`);
          await doc.ref.delete();
        }
      });
    await firestore
      .collection("comments")
      .where("userID", "==", userRef)
      .get()
      .then(async (querySnapshot) => {
        for (var doc of querySnapshot.docs) {
          console.log(`Deleting document ${doc.id} from collection comments`);
          await doc.ref.delete();
        }
      });
    await firestore
      .collection("partners")
      .where("businessID", "==", userRef)
      .get()
      .then(async (querySnapshot) => {
        for (var doc of querySnapshot.docs) {
          console.log(`Deleting document ${doc.id} from collection partners`);
          await doc.ref.delete();
        }
      });
    await firestore
      .collection("notifications")
      .where("receiver_ID", "==", userRef)
      .get()
      .then(async (querySnapshot) => {
        for (var doc of querySnapshot.docs) {
          console.log(
            `Deleting document ${doc.id} from collection notifications`,
          );
          await doc.ref.delete();
        }
      });
    await firestore
      .collection("saved_posts")
      .where("userID", "==", userRef)
      .get()
      .then(async (querySnapshot) => {
        for (var doc of querySnapshot.docs) {
          console.log(
            `Deleting document ${doc.id} from collection saved_posts`,
          );
          await doc.ref.delete();
        }
      });
    await firestore
      .collection("post_likes")
      .where("userID", "==", userRef)
      .get()
      .then(async (querySnapshot) => {
        for (var doc of querySnapshot.docs) {
          console.log(`Deleting document ${doc.id} from collection post_likes`);
          await doc.ref.delete();
        }
      });
    await firestore
      .collection("chats")
      .where("users", "array-contains", userRef)
      .get()
      .then(async (querySnapshot) => {
        for (var doc of querySnapshot.docs) {
          console.log(`Deleting document ${doc.id} from collection chats`);
          await doc.ref.delete();
        }
      });
    await firestore
      .collection("chat_messages")
      .where("user", "==", userRef)
      .get()
      .then(async (querySnapshot) => {
        for (var doc of querySnapshot.docs) {
          console.log(
            `Deleting document ${doc.id} from collection chat_messages`,
          );
          await doc.ref.delete();
        }
      });
    await firestore
      .collection("referral_codes")
      .where("userID", "==", userRef)
      .get()
      .then(async (querySnapshot) => {
        for (var doc of querySnapshot.docs) {
          console.log(
            `Deleting document ${doc.id} from collection referral_codes`,
          );
          await doc.ref.delete();
        }
      });
    await firestore
      .collection("memories")
      .where("userID", "==", userRef)
      .get()
      .then(async (querySnapshot) => {
        for (var doc of querySnapshot.docs) {
          console.log(`Deleting document ${doc.id} from collection memories`);
          await doc.ref.delete();
        }
      });
    await firestore
      .collection("bookings")
      .where("business_ID", "==", userRef)
      .get()
      .then(async (querySnapshot) => {
        for (var doc of querySnapshot.docs) {
          console.log(`Deleting document ${doc.id} from collection bookings`);
          await doc.ref.delete();
        }
      });
  });
