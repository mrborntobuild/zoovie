import 'package:flutter/material.dart';
import '/backend/backend.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:csv/csv.dart';
import 'package:synchronized/synchronized.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    secureStorage = const FlutterSecureStorage();
    await _safeInitAsync(() async {
      _apiKey = await secureStorage.getString('ff_apiKey') ?? _apiKey;
    });
    await _safeInitAsync(() async {
      _savedConversations =
          (await secureStorage.getStringList('ff_savedConversations'))
                  ?.map((x) {
                try {
                  return jsonDecode(x);
                } catch (e) {
                  print("Can't decode persisted json. Error: $e.");
                  return {};
                }
              }).toList() ??
              _savedConversations;
    });
    await _safeInitAsync(() async {
      _nameChangeLastDate =
          await secureStorage.read(key: 'ff_nameChangeLastDate') != null
              ? DateTime.fromMillisecondsSinceEpoch(
                  (await secureStorage.getInt('ff_nameChangeLastDate'))!)
              : _nameChangeLastDate;
    });
    await _safeInitAsync(() async {
      _excludeFromSearch =
          await secureStorage.getString('ff_excludeFromSearch') ??
              _excludeFromSearch;
    });
    await _safeInitAsync(() async {
      _userReference =
          (await secureStorage.getString('ff_userReference'))?.ref ??
              _userReference;
    });
    await _safeInitAsync(() async {
      _noInternetAnimation =
          await secureStorage.getString('ff_noInternetAnimation') ??
              _noInternetAnimation;
    });
    await _safeInitAsync(() async {
      _blockedUsers = (await secureStorage.getStringList('ff_blockedUsers'))
              ?.map((path) => path.ref)
              .toList() ??
          _blockedUsers;
    });
    await _safeInitAsync(() async {
      _privateMode =
          await secureStorage.getBool('ff_privateMode') ?? _privateMode;
    });
    await _safeInitAsync(() async {
      if (await secureStorage.read(key: 'ff_chatGPTBlock') != null) {
        try {
          final serializedData =
              await secureStorage.getString('ff_chatGPTBlock') ?? '{}';
          _chatGPTBlock = ChatGPTBlockStruct.fromSerializableMap(
              jsonDecode(serializedData));
        } catch (e) {
          print("Can't decode persisted data type. Error: $e.");
        }
      }
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late FlutterSecureStorage secureStorage;

  bool _sideMenuOpen = false;
  bool get sideMenuOpen => _sideMenuOpen;
  set sideMenuOpen(bool value) {
    _sideMenuOpen = value;
  }

  Color _backgroundColour = const Color(0xff000000);
  Color get backgroundColour => _backgroundColour;
  set backgroundColour(Color value) {
    _backgroundColour = value;
  }

  String _apiKey = 'REPLACE API';
  String get apiKey => _apiKey;
  set apiKey(String value) {
    _apiKey = value;
    secureStorage.setString('ff_apiKey', value);
  }

  void deleteApiKey() {
    secureStorage.delete(key: 'ff_apiKey');
  }

  List<dynamic> _currentConversation = [];
  List<dynamic> get currentConversation => _currentConversation;
  set currentConversation(List<dynamic> value) {
    _currentConversation = value;
  }

  void addToCurrentConversation(dynamic value) {
    _currentConversation.add(value);
  }

  void removeFromCurrentConversation(dynamic value) {
    _currentConversation.remove(value);
  }

  void removeAtIndexFromCurrentConversation(int index) {
    _currentConversation.removeAt(index);
  }

  void updateCurrentConversationAtIndex(
    int index,
    dynamic Function(dynamic) updateFn,
  ) {
    _currentConversation[index] = updateFn(_currentConversation[index]);
  }

  void insertAtIndexInCurrentConversation(int index, dynamic value) {
    _currentConversation.insert(index, value);
  }

  List<dynamic> _savedConversations = [];
  List<dynamic> get savedConversations => _savedConversations;
  set savedConversations(List<dynamic> value) {
    _savedConversations = value;
    secureStorage.setStringList(
        'ff_savedConversations', value.map((x) => jsonEncode(x)).toList());
  }

  void deleteSavedConversations() {
    secureStorage.delete(key: 'ff_savedConversations');
  }

  void addToSavedConversations(dynamic value) {
    _savedConversations.add(value);
    secureStorage.setStringList('ff_savedConversations',
        _savedConversations.map((x) => jsonEncode(x)).toList());
  }

  void removeFromSavedConversations(dynamic value) {
    _savedConversations.remove(value);
    secureStorage.setStringList('ff_savedConversations',
        _savedConversations.map((x) => jsonEncode(x)).toList());
  }

  void removeAtIndexFromSavedConversations(int index) {
    _savedConversations.removeAt(index);
    secureStorage.setStringList('ff_savedConversations',
        _savedConversations.map((x) => jsonEncode(x)).toList());
  }

  void updateSavedConversationsAtIndex(
    int index,
    dynamic Function(dynamic) updateFn,
  ) {
    _savedConversations[index] = updateFn(_savedConversations[index]);
    secureStorage.setStringList('ff_savedConversations',
        _savedConversations.map((x) => jsonEncode(x)).toList());
  }

  void insertAtIndexInSavedConversations(int index, dynamic value) {
    _savedConversations.insert(index, value);
    secureStorage.setStringList('ff_savedConversations',
        _savedConversations.map((x) => jsonEncode(x)).toList());
  }

  Color _menuBackgroundColourGPT = const Color(0xffffffff);
  Color get menuBackgroundColourGPT => _menuBackgroundColourGPT;
  set menuBackgroundColourGPT(Color value) {
    _menuBackgroundColourGPT = value;
  }

  bool _sideMenuOpenGPT = false;
  bool get sideMenuOpenGPT => _sideMenuOpenGPT;
  set sideMenuOpenGPT(bool value) {
    _sideMenuOpenGPT = value;
  }

  String _topicMessage = '';
  String get topicMessage => _topicMessage;
  set topicMessage(String value) {
    _topicMessage = value;
  }

  bool _followers = true;
  bool get followers => _followers;
  set followers(bool value) {
    _followers = value;
  }

  bool _likes = false;
  bool get likes => _likes;
  set likes(bool value) {
    _likes = value;
  }

  bool _comments = false;
  bool get comments => _comments;
  set comments(bool value) {
    _comments = value;
  }

  bool _rewards = false;
  bool get rewards => _rewards;
  set rewards(bool value) {
    _rewards = value;
  }

  bool _discover = true;
  bool get discover => _discover;
  set discover(bool value) {
    _discover = value;
  }

  bool _bookmark = false;
  bool get bookmark => _bookmark;
  set bookmark(bool value) {
    _bookmark = value;
  }

  DateTime? _nameChangeLastDate =
      DateTime.fromMillisecondsSinceEpoch(1683799320000);
  DateTime? get nameChangeLastDate => _nameChangeLastDate;
  set nameChangeLastDate(DateTime? value) {
    _nameChangeLastDate = value;
    value != null
        ? secureStorage.setInt(
            'ff_nameChangeLastDate', value.millisecondsSinceEpoch)
        : secureStorage.remove('ff_nameChangeLastDate');
  }

  void deleteNameChangeLastDate() {
    secureStorage.delete(key: 'ff_nameChangeLastDate');
  }

  bool _transactionsTab = true;
  bool get transactionsTab => _transactionsTab;
  set transactionsTab(bool value) {
    _transactionsTab = value;
  }

  bool _rewardsTab = false;
  bool get rewardsTab => _rewardsTab;
  set rewardsTab(bool value) {
    _rewardsTab = value;
  }

  bool _statictics = false;
  bool get statictics => _statictics;
  set statictics(bool value) {
    _statictics = value;
  }

  String _currentNumber = '';
  String get currentNumber => _currentNumber;
  set currentNumber(String value) {
    _currentNumber = value;
  }

  bool _explore = true;
  bool get explore => _explore;
  set explore(bool value) {
    _explore = value;
  }

  String _excludeFromSearch = 'yes';
  String get excludeFromSearch => _excludeFromSearch;
  set excludeFromSearch(String value) {
    _excludeFromSearch = value;
    secureStorage.setString('ff_excludeFromSearch', value);
  }

  void deleteExcludeFromSearch() {
    secureStorage.delete(key: 'ff_excludeFromSearch');
  }

  bool _peopleNearby = true;
  bool get peopleNearby => _peopleNearby;
  set peopleNearby(bool value) {
    _peopleNearby = value;
  }

  bool _peopleFollowingMe = false;
  bool get peopleFollowingMe => _peopleFollowingMe;
  set peopleFollowingMe(bool value) {
    _peopleFollowingMe = value;
  }

  bool _messageReaction = false;
  bool get messageReaction => _messageReaction;
  set messageReaction(bool value) {
    _messageReaction = value;
  }

  String _messageFocusText = '';
  String get messageFocusText => _messageFocusText;
  set messageFocusText(String value) {
    _messageFocusText = value;
  }

  bool _messageFocusColor = false;
  bool get messageFocusColor => _messageFocusColor;
  set messageFocusColor(bool value) {
    _messageFocusColor = value;
  }

  DocumentReference? _currentChatReference;
  DocumentReference? get currentChatReference => _currentChatReference;
  set currentChatReference(DocumentReference? value) {
    _currentChatReference = value;
  }

  bool _replyComponent = false;
  bool get replyComponent => _replyComponent;
  set replyComponent(bool value) {
    _replyComponent = value;
  }

  String _replyImageUrl = '';
  String get replyImageUrl => _replyImageUrl;
  set replyImageUrl(String value) {
    _replyImageUrl = value;
  }

  DocumentReference? _replyPostOwner;
  DocumentReference? get replyPostOwner => _replyPostOwner;
  set replyPostOwner(DocumentReference? value) {
    _replyPostOwner = value;
  }

  List<DocumentReference> _temporaryUserList = [];
  List<DocumentReference> get temporaryUserList => _temporaryUserList;
  set temporaryUserList(List<DocumentReference> value) {
    _temporaryUserList = value;
  }

  void addToTemporaryUserList(DocumentReference value) {
    _temporaryUserList.add(value);
  }

  void removeFromTemporaryUserList(DocumentReference value) {
    _temporaryUserList.remove(value);
  }

  void removeAtIndexFromTemporaryUserList(int index) {
    _temporaryUserList.removeAt(index);
  }

  void updateTemporaryUserListAtIndex(
    int index,
    DocumentReference Function(DocumentReference) updateFn,
  ) {
    _temporaryUserList[index] = updateFn(_temporaryUserList[index]);
  }

  void insertAtIndexInTemporaryUserList(int index, DocumentReference value) {
    _temporaryUserList.insert(index, value);
  }

  bool _messageSelected = false;
  bool get messageSelected => _messageSelected;
  set messageSelected(bool value) {
    _messageSelected = value;
  }

  DocumentReference? _messageReference;
  DocumentReference? get messageReference => _messageReference;
  set messageReference(DocumentReference? value) {
    _messageReference = value;
  }

  bool _typing = false;
  bool get typing => _typing;
  set typing(bool value) {
    _typing = value;
  }

  bool _voiceMessage = false;
  bool get voiceMessage => _voiceMessage;
  set voiceMessage(bool value) {
    _voiceMessage = value;
  }

  bool _playVoiceMessage = true;
  bool get playVoiceMessage => _playVoiceMessage;
  set playVoiceMessage(bool value) {
    _playVoiceMessage = value;
  }

  DocumentReference? _currentVoiceMessageID;
  DocumentReference? get currentVoiceMessageID => _currentVoiceMessageID;
  set currentVoiceMessageID(DocumentReference? value) {
    _currentVoiceMessageID = value;
  }

  String _recordedFile = '';
  String get recordedFile => _recordedFile;
  set recordedFile(String value) {
    _recordedFile = value;
  }

  CommentDataStruct _commentData =
      CommentDataStruct.fromSerializableMap(jsonDecode('{}'));
  CommentDataStruct get commentData => _commentData;
  set commentData(CommentDataStruct value) {
    _commentData = value;
  }

  void updateCommentDataStruct(Function(CommentDataStruct) updateFn) {
    updateFn(_commentData);
  }

  BusinessCategorySearchStruct _businessCategorySelection =
      BusinessCategorySearchStruct.fromSerializableMap(jsonDecode(
          '{\"suggested\":\"[\\\"Coffee Shop\\\",\\\"Restaurant\\\",\\\"Grocery Store\\\",\\\"Clothing Store\\\",\\\"Bakery\\\",\\\"Barbershop\\\",\\\"Hair Salon\\\",\\\"Nail Salon\\\",\\\"Fitness Center\\\",\\\"Yoga Studio\\\",\\\"Jewelry Store\\\",\\\"Furniture Store\\\",\\\"Electronics Store\\\",\\\"Game Shop\\\",\\\"Ice Cream Shop\\\",\\\"Gift Shop\\\",\\\"Auto Repair\\\",\\\"Car Wash\\\",\\\"Freelancer\\\",\\\"Photographer\\\",\\\"Graphic Designer\\\",\\\"App Developer\\\",\\\"Web Developer\\\",\\\"Content Creator\\\",\\\"Social Media Manager\\\",\\\"Pet Store\\\",\\\"Cocktail Bar\\\",\\\"Pub\\\",\\\"Spa\\\",\\\"Gardening Service\\\"]\",\"categories\":\"[\\\"Coffee Shop\\\",\\\"Restaurant\\\",\\\"Grocery Store\\\",\\\"Clothing Store\\\",\\\"Bakery\\\",\\\"Barbershop\\\",\\\"Hair Salon\\\",\\\"Nail Salon\\\",\\\"Fitness Center\\\",\\\"Yoga Studio\\\",\\\"Jewelry Store\\\",\\\"Furniture Store\\\",\\\"Electronics Store\\\",\\\"Game Shop\\\",\\\"Ice Cream Shop\\\",\\\"Gift Shop\\\",\\\"Auto Repair\\\",\\\"Car Wash\\\",\\\"Freelancer\\\",\\\"Photographer\\\",\\\"Graphic Designer\\\",\\\"App Developer\\\",\\\"Web Developer\\\",\\\"Content Creator\\\",\\\"Social Media Manager\\\",\\\"Pet Store\\\",\\\"Cocktail Bar\\\",\\\"Pub\\\",\\\"Spa\\\",\\\"Gardening Service\\\",\\\"Stationery Store\\\",\\\"Flower Shop\\\",\\\"Tattoo Studio\\\",\\\"Car Rental Service\\\",\\\"Bike Shop\\\",\\\"Music Store\\\",\\\"Dance Studio\\\",\\\"Martial Arts Studio\\\",\\\"Wine Shop\\\",\\\"Craft Brewery\\\",\\\"Tailor\\\",\\\"Dry Cleaner\\\",\\\"Wedding Planner\\\",\\\"Event Planner\\\",\\\"Party Supplies Store\\\",\\\"Wedding Venue\\\",\\\"Venue\\\",\\\"Catering Service\\\",\\\"Food Truck\\\",\\\"Bed and Breakfast\\\",\\\"Hotel\\\",\\\"Travel Agency\\\",\\\"Tour Guide\\\",\\\"Language School\\\",\\\"Tutoring Service\\\",\\\"Daycare Center\\\",\\\"Pet Grooming Service\\\",\\\"Photography Studio\\\",\\\"Interior Design Studio\\\",\\\"Architecture Firm\\\",\\\"Accounting Services\\\",\\\"Financial Advisor\\\",\\\"Insurance Agency\\\",\\\"Real Estate Agency\\\",\\\"Legal Services\\\",\\\"Consulting Firm\\\",\\\"Career Coaching\\\",\\\"Chiropractor Services\\\",\\\"Acupuncture Clinic\\\",\\\"Physical Therapy Center\\\",\\\"Dental Clinic\\\",\\\"Orthodontist Services\\\",\\\"Plastic Surgery Clinic\\\",\\\"Dermatology Clinic\\\",\\\"Family Medicine Practice\\\",\\\"Alternative Medicine Clinic\\\",\\\"Home Care Services\\\",\\\"Funeral Services\\\",\\\"Event Venue Rental\\\",\\\"Film Production Company\\\",\\\"Music Production Studio\\\",\\\"Web Design Agency\\\",\\\"Mobile App Development Company\\\",\\\"Marketing Agency\\\",\\\"Advertising Agency\\\",\\\"PR Agency\\\",\\\"Market Research Firm\\\",\\\"HR Consulting Firm\\\",\\\"E-commerce Store\\\",\\\"Printing Services\\\",\\\"Computer Repair Shop\\\",\\\"Phone Accessories Store\\\",\\\"Organic Grocery Store\\\",\\\"Farmers Market\\\",\\\"Health Food Store\\\",\\\"Sports Equipment Store\\\",\\\"Antique Store\\\",\\\"Vintage Clothing Store\\\",\\\"Art Supplies Store\\\",\\\"Comic Book Store\\\",\\\"Board Game Shop\\\",\\\"Toy Store\\\",\\\"Hobby Shop\\\",\\\"Pottery Studio\\\",\\\"Home Decor Store\\\",\\\"Appliance Store\\\",\\\"Technology Repair Shop\\\",\\\"Cooking School\\\",\\\"Photography Prints Marketplace\\\",\\\"Website Templates Marketplace\\\",\\\"Video Editing Services\\\",\\\"Influencer\\\",\\\"Blogger\\\",\\\"Online Tutoring\\\",\\\"Online Therapy\\\",\\\"Online Coaching\\\",\\\"Business Coaching\\\",\\\"Financial Coaching\\\",\\\"Personal Stylist\\\",\\\"Makeup Artist\\\",\\\"Skincare\\\",\\\"Hair Transplant Clinic\\\",\\\"Escape Room Games\\\",\\\"Website Design\\\",\\\"App Page\\\",\\\"YouTuber\\\",\\\"Podcaster\\\",\\\"Fashion Model\\\",\\\"Photo Model\\\",\\\"Makeup Artist\\\",\\\"Hairstylist\\\",\\\"Personal Trainer\\\",\\\"Nutrition Coach\\\",\\\"Artist\\\",\\\"Musician\\\",\\\"Writer\\\",\\\"DJ\\\",\\\"Music Producer\\\"]\"}'));
  BusinessCategorySearchStruct get businessCategorySelection =>
      _businessCategorySelection;
  set businessCategorySelection(BusinessCategorySearchStruct value) {
    _businessCategorySelection = value;
  }

  void updateBusinessCategorySelectionStruct(
      Function(BusinessCategorySearchStruct) updateFn) {
    updateFn(_businessCategorySelection);
  }

  DocumentReference? _userReference;
  DocumentReference? get userReference => _userReference;
  set userReference(DocumentReference? value) {
    _userReference = value;
    value != null
        ? secureStorage.setString('ff_userReference', value.path)
        : secureStorage.remove('ff_userReference');
  }

  void deleteUserReference() {
    secureStorage.delete(key: 'ff_userReference');
  }

  SignupUserStruct _signupUser = SignupUserStruct();
  SignupUserStruct get signupUser => _signupUser;
  set signupUser(SignupUserStruct value) {
    _signupUser = value;
  }

  void updateSignupUserStruct(Function(SignupUserStruct) updateFn) {
    updateFn(_signupUser);
  }

  SwitchToProfessionalStruct _switchToProfessional =
      SwitchToProfessionalStruct.fromSerializableMap(jsonDecode(
          '{\"display_category\":\"true\",\"display_contact\":\"true\",\"display_website\":\"true\",\"display_shop\":\"false\"}'));
  SwitchToProfessionalStruct get switchToProfessional => _switchToProfessional;
  set switchToProfessional(SwitchToProfessionalStruct value) {
    _switchToProfessional = value;
  }

  void updateSwitchToProfessionalStruct(
      Function(SwitchToProfessionalStruct) updateFn) {
    updateFn(_switchToProfessional);
  }

  String _activeBusinessPro = '1';
  String get activeBusinessPro => _activeBusinessPro;
  set activeBusinessPro(String value) {
    _activeBusinessPro = value;
  }

  NewPostStruct _newPost = NewPostStruct();
  NewPostStruct get newPost => _newPost;
  set newPost(NewPostStruct value) {
    _newPost = value;
  }

  void updateNewPostStruct(Function(NewPostStruct) updateFn) {
    updateFn(_newPost);
  }

  String _activeTabProfile = 'posts';
  String get activeTabProfile => _activeTabProfile;
  set activeTabProfile(String value) {
    _activeTabProfile = value;
  }

  String _noInternetAnimation =
      'https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/beneree-t2ym3b/assets/emv3qi9dj72m/No_Internet_Animation.gif';
  String get noInternetAnimation => _noInternetAnimation;
  set noInternetAnimation(String value) {
    _noInternetAnimation = value;
    secureStorage.setString('ff_noInternetAnimation', value);
  }

  void deleteNoInternetAnimation() {
    secureStorage.delete(key: 'ff_noInternetAnimation');
  }

  bool _chatGPTMenuActive = false;
  bool get chatGPTMenuActive => _chatGPTMenuActive;
  set chatGPTMenuActive(bool value) {
    _chatGPTMenuActive = value;
  }

  List<ReportPostStruct> _postReport = [
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Inappropriate Content\",\"reason_description\":\"Report posts with explicit images, hate speech, or harassment to maintain a respectful community.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Misleading Information\",\"reason_description\":\"Help us maintain accurate content by reporting posts with false or misleading information.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Spam\",\"reason_description\":\"Report spammy or repetitive posts to ensure a genuine user experience for everyone.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Copyright Infringement\",\"reason_description\":\"Notify us about posts that violate copyright laws by using unauthorized content.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Cyberbullying\",\"reason_description\":\"Report posts targeting or harassing others to prevent online abuse.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Fake Accounts\",\"reason_description\":\"Report posts from fake or impersonating accounts to protect against misinformation.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Nudity or Explicit Content\",\"reason_description\":\"Help us keep the platform safe by reporting posts with explicit or pornographic content.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Scams or Fraudulent Activities\",\"reason_description\":\"Report suspicious posts that may involve scams or fraudulent activities.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Hate Speech or Discrimination\",\"reason_description\":\"Notify us about posts promoting hate speech or discrimination to foster a positive environment.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Violent Content\",\"reason_description\":\"Report posts with violent or harmful content to ensure the safety of our users.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Privacy Violation\",\"reason_description\":\"Report posts that invade someone\'s privacy by sharing personal information without consent.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Malicious Links or Content\",\"reason_description\":\"Help protect others by reporting posts with suspicious links or malware.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Offensive Language\",\"reason_description\":\"Report posts with offensive language to maintain a respectful atmosphere for all users.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Duplicate Content\",\"reason_description\":\"Help keep the feed clutter-free by reporting duplicate or identical posts.\"}')),
    ReportPostStruct.fromSerializableMap(jsonDecode(
        '{\"reason\":\"Exploitative Content\",\"reason_description\":\"Report posts that appear to exploit vulnerable individuals or groups to create a safe platform for everyone.\"}'))
  ];
  List<ReportPostStruct> get postReport => _postReport;
  set postReport(List<ReportPostStruct> value) {
    _postReport = value;
  }

  void addToPostReport(ReportPostStruct value) {
    _postReport.add(value);
  }

  void removeFromPostReport(ReportPostStruct value) {
    _postReport.remove(value);
  }

  void removeAtIndexFromPostReport(int index) {
    _postReport.removeAt(index);
  }

  void updatePostReportAtIndex(
    int index,
    ReportPostStruct Function(ReportPostStruct) updateFn,
  ) {
    _postReport[index] = updateFn(_postReport[index]);
  }

  void insertAtIndexInPostReport(int index, ReportPostStruct value) {
    _postReport.insert(index, value);
  }

  bool _waitingList = false;
  bool get waitingList => _waitingList;
  set waitingList(bool value) {
    _waitingList = value;
  }

  List<DocumentReference> _blockedUsers = [];
  List<DocumentReference> get blockedUsers => _blockedUsers;
  set blockedUsers(List<DocumentReference> value) {
    _blockedUsers = value;
    secureStorage.setStringList(
        'ff_blockedUsers', value.map((x) => x.path).toList());
  }

  void deleteBlockedUsers() {
    secureStorage.delete(key: 'ff_blockedUsers');
  }

  void addToBlockedUsers(DocumentReference value) {
    _blockedUsers.add(value);
    secureStorage.setStringList(
        'ff_blockedUsers', _blockedUsers.map((x) => x.path).toList());
  }

  void removeFromBlockedUsers(DocumentReference value) {
    _blockedUsers.remove(value);
    secureStorage.setStringList(
        'ff_blockedUsers', _blockedUsers.map((x) => x.path).toList());
  }

  void removeAtIndexFromBlockedUsers(int index) {
    _blockedUsers.removeAt(index);
    secureStorage.setStringList(
        'ff_blockedUsers', _blockedUsers.map((x) => x.path).toList());
  }

  void updateBlockedUsersAtIndex(
    int index,
    DocumentReference Function(DocumentReference) updateFn,
  ) {
    _blockedUsers[index] = updateFn(_blockedUsers[index]);
    secureStorage.setStringList(
        'ff_blockedUsers', _blockedUsers.map((x) => x.path).toList());
  }

  void insertAtIndexInBlockedUsers(int index, DocumentReference value) {
    _blockedUsers.insert(index, value);
    secureStorage.setStringList(
        'ff_blockedUsers', _blockedUsers.map((x) => x.path).toList());
  }

  UpdateUserAccountStruct _updateUserDetails =
      UpdateUserAccountStruct.fromSerializableMap(
          jsonDecode('{\"display_bio\":\"false\",\"display_link\":\"false\"}'));
  UpdateUserAccountStruct get updateUserDetails => _updateUserDetails;
  set updateUserDetails(UpdateUserAccountStruct value) {
    _updateUserDetails = value;
  }

  void updateUpdateUserDetailsStruct(
      Function(UpdateUserAccountStruct) updateFn) {
    updateFn(_updateUserDetails);
  }

  bool _privateMode = false;
  bool get privateMode => _privateMode;
  set privateMode(bool value) {
    _privateMode = value;
    secureStorage.setBool('ff_privateMode', value);
  }

  void deletePrivateMode() {
    secureStorage.delete(key: 'ff_privateMode');
  }

  bool _blurredMenuActive = false;
  bool get blurredMenuActive => _blurredMenuActive;
  set blurredMenuActive(bool value) {
    _blurredMenuActive = value;
  }

  ChatGPTBlockStruct _chatGPTBlock = ChatGPTBlockStruct();
  ChatGPTBlockStruct get chatGPTBlock => _chatGPTBlock;
  set chatGPTBlock(ChatGPTBlockStruct value) {
    _chatGPTBlock = value;
    secureStorage.setString('ff_chatGPTBlock', value.serialize());
  }

  void deleteChatGPTBlock() {
    secureStorage.delete(key: 'ff_chatGPTBlock');
  }

  void updateChatGPTBlockStruct(Function(ChatGPTBlockStruct) updateFn) {
    updateFn(_chatGPTBlock);
    secureStorage.setString('ff_chatGPTBlock', _chatGPTBlock.serialize());
  }

  double _progresssBar = 0.0;
  double get progresssBar => _progresssBar;
  set progresssBar(double value) {
    _progresssBar = value;
  }

  MomentsStruct _moments = MomentsStruct();
  MomentsStruct get moments => _moments;
  set moments(MomentsStruct value) {
    _moments = value;
  }

  void updateMomentsStruct(Function(MomentsStruct) updateFn) {
    updateFn(_moments);
  }

  DateTime? _momentsDate = DateTime.fromMillisecondsSinceEpoch(1702054740000);
  DateTime? get momentsDate => _momentsDate;
  set momentsDate(DateTime? value) {
    _momentsDate = value;
  }

  DocumentReference? _testUserID =
      FirebaseFirestore.instance.doc('/users/yMoBQJs77cPsqR6TeDj9oErqoDp1');
  DocumentReference? get testUserID => _testUserID;
  set testUserID(DocumentReference? value) {
    _testUserID = value;
  }

  int _withdrawAmount = 0;
  int get withdrawAmount => _withdrawAmount;
  set withdrawAmount(int value) {
    _withdrawAmount = value;
  }

  WithdrawStruct _withdraw = WithdrawStruct();
  WithdrawStruct get withdraw => _withdraw;
  set withdraw(WithdrawStruct value) {
    _withdraw = value;
  }

  void updateWithdrawStruct(Function(WithdrawStruct) updateFn) {
    updateFn(_withdraw);
  }

  bool _showNavbar = false;
  bool get showNavbar => _showNavbar;
  set showNavbar(bool value) {
    _showNavbar = value;
  }

  bool _switchFeeds = false;
  bool get switchFeeds => _switchFeeds;
  set switchFeeds(bool value) {
    _switchFeeds = value;
  }

  bool _exploreFeed = true;
  bool get exploreFeed => _exploreFeed;
  set exploreFeed(bool value) {
    _exploreFeed = value;
  }

  bool _logoAnimation = false;
  bool get logoAnimation => _logoAnimation;
  set logoAnimation(bool value) {
    _logoAnimation = value;
  }

  String _welcomeConditional = 'welcome';
  String get welcomeConditional => _welcomeConditional;
  set welcomeConditional(String value) {
    _welcomeConditional = value;
  }

  double _usersContainerHeight = 0.0;
  double get usersContainerHeight => _usersContainerHeight;
  set usersContainerHeight(double value) {
    _usersContainerHeight = value;
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}

Color? _colorFromIntValue(int? val) {
  if (val == null) {
    return null;
  }
  return Color(val);
}

extension FlutterSecureStorageExtensions on FlutterSecureStorage {
  static final _lock = Lock();

  Future<void> writeSync({required String key, String? value}) async =>
      await _lock.synchronized(() async {
        await write(key: key, value: value);
      });

  void remove(String key) => delete(key: key);

  Future<String?> getString(String key) async => await read(key: key);
  Future<void> setString(String key, String value) async =>
      await writeSync(key: key, value: value);

  Future<bool?> getBool(String key) async => (await read(key: key)) == 'true';
  Future<void> setBool(String key, bool value) async =>
      await writeSync(key: key, value: value.toString());

  Future<int?> getInt(String key) async =>
      int.tryParse(await read(key: key) ?? '');
  Future<void> setInt(String key, int value) async =>
      await writeSync(key: key, value: value.toString());

  Future<double?> getDouble(String key) async =>
      double.tryParse(await read(key: key) ?? '');
  Future<void> setDouble(String key, double value) async =>
      await writeSync(key: key, value: value.toString());

  Future<List<String>?> getStringList(String key) async =>
      await read(key: key).then((result) {
        if (result == null || result.isEmpty) {
          return null;
        }
        return const CsvToListConverter()
            .convert(result)
            .first
            .map((e) => e.toString())
            .toList();
      });
  Future<void> setStringList(String key, List<String> value) async =>
      await writeSync(key: key, value: const ListToCsvConverter().convert([value]));
}
