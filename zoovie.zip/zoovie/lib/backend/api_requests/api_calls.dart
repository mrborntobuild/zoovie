import 'dart:convert';

import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start Zoovie API Group Code

class ZoovieAPIGroup {
  static String getBaseUrl() => 'https://api.zoovie.com';
  static Map<String, String> headers = {
    'Authorization':
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWNmMzhjNTFjYTAyNjdjZGMzMzc2OGNjIiwiZW1haWwiOiJhZG1pbjFAem9vdmllLmNvbSIsInJvbGUiOiJhZG1pbiIsImlhdCI6MTcxNjY2NTk1OX0.XxzXgTEJt3fMxKqKrWg3_YOBBTx4YodV17rQSw-NN4Q',
  };
  static ClubListCall clubListCall = ClubListCall();
  static GetStatesCall getStatesCall = GetStatesCall();
}

class ClubListCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = ZoovieAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'Club List',
      apiUrl: '$baseUrl/api/clubs/clubList',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWNmMzhjNTFjYTAyNjdjZGMzMzc2OGNjIiwiZW1haWwiOiJhZG1pbjFAem9vdmllLmNvbSIsInJvbGUiOiJhZG1pbiIsImlhdCI6MTcxNjY2NTk1OX0.XxzXgTEJt3fMxKqKrWg3_YOBBTx4YodV17rQSw-NN4Q',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  List<String>? dataName(dynamic response) => (getJsonField(
        response,
        r'''$.data[:].name''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  List? data(dynamic response) => getJsonField(
        response,
        r'''$.data''',
        true,
      ) as List?;
  List<String>? status(dynamic response) => (getJsonField(
        response,
        r'''$.data[:].status''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
}

class GetStatesCall {
  Future<ApiCallResponse> call() async {
    final baseUrl = ZoovieAPIGroup.getBaseUrl();

    return ApiManager.instance.makeApiCall(
      callName: 'Get States',
      apiUrl: '$baseUrl/api/states/stateList',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNWNmMzhjNTFjYTAyNjdjZGMzMzc2OGNjIiwiZW1haWwiOiJhZG1pbjFAem9vdmllLmNvbSIsInJvbGUiOiJhZG1pbiIsImlhdCI6MTcxNjY2NTk1OX0.XxzXgTEJt3fMxKqKrWg3_YOBBTx4YodV17rQSw-NN4Q',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

/// End Zoovie API Group Code

class AddUserCall {
  static Future<ApiCallResponse> call({
    String? phoneNumber = '',
    String? referredBy = '',
    String? displayName = '',
    String? firebaseUID = '',
    String? dateOfBirth = '',
    String? referralCode = '',
    String? username = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Add User',
      apiUrl: 'https://x8ki-letl-twmt.n7.xano.io/api:3HDxlx_D/users',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}
