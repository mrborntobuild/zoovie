import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class EventsRecord extends FirestoreRecord {
  EventsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "event_image" field.
  String? _eventImage;
  String get eventImage => _eventImage ?? '';
  bool hasEventImage() => _eventImage != null;

  // "event_name" field.
  String? _eventName;
  String get eventName => _eventName ?? '';
  bool hasEventName() => _eventName != null;

  // "event_start_date" field.
  DateTime? _eventStartDate;
  DateTime? get eventStartDate => _eventStartDate;
  bool hasEventStartDate() => _eventStartDate != null;

  void _initializeFields() {
    _eventImage = snapshotData['event_image'] as String?;
    _eventName = snapshotData['event_name'] as String?;
    _eventStartDate = snapshotData['event_start_date'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('events');

  static Stream<EventsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => EventsRecord.fromSnapshot(s));

  static Future<EventsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => EventsRecord.fromSnapshot(s));

  static EventsRecord fromSnapshot(DocumentSnapshot snapshot) => EventsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static EventsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      EventsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'EventsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is EventsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createEventsRecordData({
  String? eventImage,
  String? eventName,
  DateTime? eventStartDate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'event_image': eventImage,
      'event_name': eventName,
      'event_start_date': eventStartDate,
    }.withoutNulls,
  );

  return firestoreData;
}

class EventsRecordDocumentEquality implements Equality<EventsRecord> {
  const EventsRecordDocumentEquality();

  @override
  bool equals(EventsRecord? e1, EventsRecord? e2) {
    return e1?.eventImage == e2?.eventImage &&
        e1?.eventName == e2?.eventName &&
        e1?.eventStartDate == e2?.eventStartDate;
  }

  @override
  int hash(EventsRecord? e) => const ListEquality()
      .hash([e?.eventImage, e?.eventName, e?.eventStartDate]);

  @override
  bool isValidKey(Object? o) => o is EventsRecord;
}
