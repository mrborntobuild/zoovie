import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class MemoriesRecord extends FirestoreRecord {
  MemoriesRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "userID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  // "photo" field.
  String? _photo;
  String get photo => _photo ?? '';
  bool hasPhoto() => _photo != null;

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "profile_picture" field.
  String? _profilePicture;
  String get profilePicture => _profilePicture ?? '';
  bool hasProfilePicture() => _profilePicture != null;

  // "pro_account" field.
  bool? _proAccount;
  bool get proAccount => _proAccount ?? false;
  bool hasProAccount() => _proAccount != null;

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  bool hasUsername() => _username != null;

  // "clicked" field.
  List<DocumentReference>? _clicked;
  List<DocumentReference> get clicked => _clicked ?? const [];
  bool hasClicked() => _clicked != null;

  // "blurHash" field.
  String? _blurHash;
  String get blurHash => _blurHash ?? '';
  bool hasBlurHash() => _blurHash != null;

  void _initializeFields() {
    _userID = snapshotData['userID'] as DocumentReference?;
    _photo = snapshotData['photo'] as String?;
    _createdAt = snapshotData['created_at'] as DateTime?;
    _profilePicture = snapshotData['profile_picture'] as String?;
    _proAccount = snapshotData['pro_account'] as bool?;
    _username = snapshotData['username'] as String?;
    _clicked = getDataList(snapshotData['clicked']);
    _blurHash = snapshotData['blurHash'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('memories');

  static Stream<MemoriesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MemoriesRecord.fromSnapshot(s));

  static Future<MemoriesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MemoriesRecord.fromSnapshot(s));

  static MemoriesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MemoriesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MemoriesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MemoriesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MemoriesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MemoriesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMemoriesRecordData({
  DocumentReference? userID,
  String? photo,
  DateTime? createdAt,
  String? profilePicture,
  bool? proAccount,
  String? username,
  String? blurHash,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userID': userID,
      'photo': photo,
      'created_at': createdAt,
      'profile_picture': profilePicture,
      'pro_account': proAccount,
      'username': username,
      'blurHash': blurHash,
    }.withoutNulls,
  );

  return firestoreData;
}

class MemoriesRecordDocumentEquality implements Equality<MemoriesRecord> {
  const MemoriesRecordDocumentEquality();

  @override
  bool equals(MemoriesRecord? e1, MemoriesRecord? e2) {
    const listEquality = ListEquality();
    return e1?.userID == e2?.userID &&
        e1?.photo == e2?.photo &&
        e1?.createdAt == e2?.createdAt &&
        e1?.profilePicture == e2?.profilePicture &&
        e1?.proAccount == e2?.proAccount &&
        e1?.username == e2?.username &&
        listEquality.equals(e1?.clicked, e2?.clicked) &&
        e1?.blurHash == e2?.blurHash;
  }

  @override
  int hash(MemoriesRecord? e) => const ListEquality().hash([
        e?.userID,
        e?.photo,
        e?.createdAt,
        e?.profilePicture,
        e?.proAccount,
        e?.username,
        e?.clicked,
        e?.blurHash
      ]);

  @override
  bool isValidKey(Object? o) => o is MemoriesRecord;
}
