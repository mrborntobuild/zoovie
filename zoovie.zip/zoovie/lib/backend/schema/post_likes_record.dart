import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class PostLikesRecord extends FirestoreRecord {
  PostLikesRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "userID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  // "postID" field.
  DocumentReference? _postID;
  DocumentReference? get postID => _postID;
  bool hasPostID() => _postID != null;

  // "date_created" field.
  DateTime? _dateCreated;
  DateTime? get dateCreated => _dateCreated;
  bool hasDateCreated() => _dateCreated != null;

  // "uniqueID" field.
  String? _uniqueID;
  String get uniqueID => _uniqueID ?? '';
  bool hasUniqueID() => _uniqueID != null;

  void _initializeFields() {
    _userID = snapshotData['userID'] as DocumentReference?;
    _postID = snapshotData['postID'] as DocumentReference?;
    _dateCreated = snapshotData['date_created'] as DateTime?;
    _uniqueID = snapshotData['uniqueID'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('post_likes');

  static Stream<PostLikesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PostLikesRecord.fromSnapshot(s));

  static Future<PostLikesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PostLikesRecord.fromSnapshot(s));

  static PostLikesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      PostLikesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PostLikesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PostLikesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PostLikesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PostLikesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPostLikesRecordData({
  DocumentReference? userID,
  DocumentReference? postID,
  DateTime? dateCreated,
  String? uniqueID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userID': userID,
      'postID': postID,
      'date_created': dateCreated,
      'uniqueID': uniqueID,
    }.withoutNulls,
  );

  return firestoreData;
}

class PostLikesRecordDocumentEquality implements Equality<PostLikesRecord> {
  const PostLikesRecordDocumentEquality();

  @override
  bool equals(PostLikesRecord? e1, PostLikesRecord? e2) {
    return e1?.userID == e2?.userID &&
        e1?.postID == e2?.postID &&
        e1?.dateCreated == e2?.dateCreated &&
        e1?.uniqueID == e2?.uniqueID;
  }

  @override
  int hash(PostLikesRecord? e) => const ListEquality()
      .hash([e?.userID, e?.postID, e?.dateCreated, e?.uniqueID]);

  @override
  bool isValidKey(Object? o) => o is PostLikesRecord;
}
