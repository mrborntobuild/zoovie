import 'dart:async';

import '/backend/algolia/serialization_util.dart';
import '/backend/algolia/algolia_manager.dart';
import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PostsRecord extends FirestoreRecord {
  PostsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "post_image" field.
  String? _postImage;
  String get postImage => _postImage ?? '';
  bool hasPostImage() => _postImage != null;

  // "caption" field.
  String? _caption;
  String get caption => _caption ?? '';
  bool hasCaption() => _caption != null;

  // "created_date" field.
  DateTime? _createdDate;
  DateTime? get createdDate => _createdDate;
  bool hasCreatedDate() => _createdDate != null;

  // "userID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  // "imageHash" field.
  String? _imageHash;
  String get imageHash => _imageHash ?? '';
  bool hasImageHash() => _imageHash != null;

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  bool hasUsername() => _username != null;

  // "is_user_verified" field.
  bool? _isUserVerified;
  bool get isUserVerified => _isUserVerified ?? false;
  bool hasIsUserVerified() => _isUserVerified != null;

  // "user_profile_picture" field.
  String? _userProfilePicture;
  String get userProfilePicture => _userProfilePicture ?? '';
  bool hasUserProfilePicture() => _userProfilePicture != null;

  // "comment_like" field.
  int? _commentLike;
  int get commentLike => _commentLike ?? 0;
  bool hasCommentLike() => _commentLike != null;

  // "tagged_users" field.
  List<DocumentReference>? _taggedUsers;
  List<DocumentReference> get taggedUsers => _taggedUsers ?? const [];
  bool hasTaggedUsers() => _taggedUsers != null;

  // "post_location_pin" field.
  LatLng? _postLocationPin;
  LatLng? get postLocationPin => _postLocationPin;
  bool hasPostLocationPin() => _postLocationPin != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  // "users_reported" field.
  List<DocumentReference>? _usersReported;
  List<DocumentReference> get usersReported => _usersReported ?? const [];
  bool hasUsersReported() => _usersReported != null;

  // "report_count" field.
  int? _reportCount;
  int get reportCount => _reportCount ?? 0;
  bool hasReportCount() => _reportCount != null;

  // "partnerred_with" field.
  DocumentReference? _partnerredWith;
  DocumentReference? get partnerredWith => _partnerredWith;
  bool hasPartnerredWith() => _partnerredWith != null;

  // "video_url" field.
  String? _videoUrl;
  String get videoUrl => _videoUrl ?? '';
  bool hasVideoUrl() => _videoUrl != null;

  // "video" field.
  bool? _video;
  bool get video => _video ?? false;
  bool hasVideo() => _video != null;

  // "hide_like_count" field.
  bool? _hideLikeCount;
  bool get hideLikeCount => _hideLikeCount ?? false;
  bool hasHideLikeCount() => _hideLikeCount != null;

  // "video_cover" field.
  String? _videoCover;
  String get videoCover => _videoCover ?? '';
  bool hasVideoCover() => _videoCover != null;

  // "video_cover_blur" field.
  String? _videoCoverBlur;
  String get videoCoverBlur => _videoCoverBlur ?? '';
  bool hasVideoCoverBlur() => _videoCoverBlur != null;

  void _initializeFields() {
    _postImage = snapshotData['post_image'] as String?;
    _caption = snapshotData['caption'] as String?;
    _createdDate = snapshotData['created_date'] as DateTime?;
    _userID = snapshotData['userID'] as DocumentReference?;
    _imageHash = snapshotData['imageHash'] as String?;
    _username = snapshotData['username'] as String?;
    _isUserVerified = snapshotData['is_user_verified'] as bool?;
    _userProfilePicture = snapshotData['user_profile_picture'] as String?;
    _commentLike = castToType<int>(snapshotData['comment_like']);
    _taggedUsers = getDataList(snapshotData['tagged_users']);
    _postLocationPin = snapshotData['post_location_pin'] as LatLng?;
    _location = snapshotData['location'] as String?;
    _usersReported = getDataList(snapshotData['users_reported']);
    _reportCount = castToType<int>(snapshotData['report_count']);
    _partnerredWith = snapshotData['partnerred_with'] as DocumentReference?;
    _videoUrl = snapshotData['video_url'] as String?;
    _video = snapshotData['video'] as bool?;
    _hideLikeCount = snapshotData['hide_like_count'] as bool?;
    _videoCover = snapshotData['video_cover'] as String?;
    _videoCoverBlur = snapshotData['video_cover_blur'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('posts');

  static Stream<PostsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PostsRecord.fromSnapshot(s));

  static Future<PostsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PostsRecord.fromSnapshot(s));

  static PostsRecord fromSnapshot(DocumentSnapshot snapshot) => PostsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PostsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PostsRecord._(reference, mapFromFirestore(data));

  static PostsRecord fromAlgolia(AlgoliaObjectSnapshot snapshot) =>
      PostsRecord.getDocumentFromData(
        {
          'post_image': snapshot.data['post_image'],
          'caption': snapshot.data['caption'],
          'created_date': convertAlgoliaParam(
            snapshot.data['created_date'],
            ParamType.DateTime,
            false,
          ),
          'userID': convertAlgoliaParam(
            snapshot.data['userID'],
            ParamType.DocumentReference,
            false,
          ),
          'imageHash': snapshot.data['imageHash'],
          'username': snapshot.data['username'],
          'is_user_verified': snapshot.data['is_user_verified'],
          'user_profile_picture': snapshot.data['user_profile_picture'],
          'comment_like': convertAlgoliaParam(
            snapshot.data['comment_like'],
            ParamType.int,
            false,
          ),
          'tagged_users': safeGet(
            () => convertAlgoliaParam<DocumentReference>(
              snapshot.data['tagged_users'],
              ParamType.DocumentReference,
              true,
            ).toList(),
          ),
          'post_location_pin': convertAlgoliaParam(
            snapshot.data,
            ParamType.LatLng,
            false,
          ),
          'location': snapshot.data['location'],
          'users_reported': safeGet(
            () => convertAlgoliaParam<DocumentReference>(
              snapshot.data['users_reported'],
              ParamType.DocumentReference,
              true,
            ).toList(),
          ),
          'report_count': convertAlgoliaParam(
            snapshot.data['report_count'],
            ParamType.int,
            false,
          ),
          'partnerred_with': convertAlgoliaParam(
            snapshot.data['partnerred_with'],
            ParamType.DocumentReference,
            false,
          ),
          'video_url': snapshot.data['video_url'],
          'video': snapshot.data['video'],
          'hide_like_count': snapshot.data['hide_like_count'],
          'video_cover': snapshot.data['video_cover'],
          'video_cover_blur': snapshot.data['video_cover_blur'],
        },
        PostsRecord.collection.doc(snapshot.objectID),
      );

  static Future<List<PostsRecord>> search({
    String? term,
    FutureOr<LatLng>? location,
    int? maxResults,
    double? searchRadiusMeters,
    bool useCache = false,
  }) =>
      FFAlgoliaManager.instance
          .algoliaQuery(
            index: 'posts',
            term: term,
            maxResults: maxResults,
            location: location,
            searchRadiusMeters: searchRadiusMeters,
            useCache: useCache,
          )
          .then((r) => r.map(fromAlgolia).toList());

  @override
  String toString() =>
      'PostsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PostsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPostsRecordData({
  String? postImage,
  String? caption,
  DateTime? createdDate,
  DocumentReference? userID,
  String? imageHash,
  String? username,
  bool? isUserVerified,
  String? userProfilePicture,
  int? commentLike,
  LatLng? postLocationPin,
  String? location,
  int? reportCount,
  DocumentReference? partnerredWith,
  String? videoUrl,
  bool? video,
  bool? hideLikeCount,
  String? videoCover,
  String? videoCoverBlur,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'post_image': postImage,
      'caption': caption,
      'created_date': createdDate,
      'userID': userID,
      'imageHash': imageHash,
      'username': username,
      'is_user_verified': isUserVerified,
      'user_profile_picture': userProfilePicture,
      'comment_like': commentLike,
      'post_location_pin': postLocationPin,
      'location': location,
      'report_count': reportCount,
      'partnerred_with': partnerredWith,
      'video_url': videoUrl,
      'video': video,
      'hide_like_count': hideLikeCount,
      'video_cover': videoCover,
      'video_cover_blur': videoCoverBlur,
    }.withoutNulls,
  );

  return firestoreData;
}

class PostsRecordDocumentEquality implements Equality<PostsRecord> {
  const PostsRecordDocumentEquality();

  @override
  bool equals(PostsRecord? e1, PostsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.postImage == e2?.postImage &&
        e1?.caption == e2?.caption &&
        e1?.createdDate == e2?.createdDate &&
        e1?.userID == e2?.userID &&
        e1?.imageHash == e2?.imageHash &&
        e1?.username == e2?.username &&
        e1?.isUserVerified == e2?.isUserVerified &&
        e1?.userProfilePicture == e2?.userProfilePicture &&
        e1?.commentLike == e2?.commentLike &&
        listEquality.equals(e1?.taggedUsers, e2?.taggedUsers) &&
        e1?.postLocationPin == e2?.postLocationPin &&
        e1?.location == e2?.location &&
        listEquality.equals(e1?.usersReported, e2?.usersReported) &&
        e1?.reportCount == e2?.reportCount &&
        e1?.partnerredWith == e2?.partnerredWith &&
        e1?.videoUrl == e2?.videoUrl &&
        e1?.video == e2?.video &&
        e1?.hideLikeCount == e2?.hideLikeCount &&
        e1?.videoCover == e2?.videoCover &&
        e1?.videoCoverBlur == e2?.videoCoverBlur;
  }

  @override
  int hash(PostsRecord? e) => const ListEquality().hash([
        e?.postImage,
        e?.caption,
        e?.createdDate,
        e?.userID,
        e?.imageHash,
        e?.username,
        e?.isUserVerified,
        e?.userProfilePicture,
        e?.commentLike,
        e?.taggedUsers,
        e?.postLocationPin,
        e?.location,
        e?.usersReported,
        e?.reportCount,
        e?.partnerredWith,
        e?.videoUrl,
        e?.video,
        e?.hideLikeCount,
        e?.videoCover,
        e?.videoCoverBlur
      ]);

  @override
  bool isValidKey(Object? o) => o is PostsRecord;
}
