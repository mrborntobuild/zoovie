import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class ReferralCodesRecord extends FirestoreRecord {
  ReferralCodesRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "referral_code" field.
  String? _referralCode;
  String get referralCode => _referralCode ?? '';
  bool hasReferralCode() => _referralCode != null;

  // "userID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  void _initializeFields() {
    _referralCode = snapshotData['referral_code'] as String?;
    _userID = snapshotData['userID'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('referral_codes');

  static Stream<ReferralCodesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ReferralCodesRecord.fromSnapshot(s));

  static Future<ReferralCodesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ReferralCodesRecord.fromSnapshot(s));

  static ReferralCodesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ReferralCodesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ReferralCodesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ReferralCodesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ReferralCodesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ReferralCodesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createReferralCodesRecordData({
  String? referralCode,
  DocumentReference? userID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'referral_code': referralCode,
      'userID': userID,
    }.withoutNulls,
  );

  return firestoreData;
}

class ReferralCodesRecordDocumentEquality
    implements Equality<ReferralCodesRecord> {
  const ReferralCodesRecordDocumentEquality();

  @override
  bool equals(ReferralCodesRecord? e1, ReferralCodesRecord? e2) {
    return e1?.referralCode == e2?.referralCode && e1?.userID == e2?.userID;
  }

  @override
  int hash(ReferralCodesRecord? e) =>
      const ListEquality().hash([e?.referralCode, e?.userID]);

  @override
  bool isValidKey(Object? o) => o is ReferralCodesRecord;
}
