import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class RepliesRecord extends FirestoreRecord {
  RepliesRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "userID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  // "reply_text" field.
  String? _replyText;
  String get replyText => _replyText ?? '';
  bool hasReplyText() => _replyText != null;

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  // "replied_to_comment" field.
  DocumentReference? _repliedToComment;
  DocumentReference? get repliedToComment => _repliedToComment;
  bool hasRepliedToComment() => _repliedToComment != null;

  // "replied_to_reply" field.
  DocumentReference? _repliedToReply;
  DocumentReference? get repliedToReply => _repliedToReply;
  bool hasRepliedToReply() => _repliedToReply != null;

  // "post_id" field.
  DocumentReference? _postId;
  DocumentReference? get postId => _postId;
  bool hasPostId() => _postId != null;

  // "likes" field.
  List<DocumentReference>? _likes;
  List<DocumentReference> get likes => _likes ?? const [];
  bool hasLikes() => _likes != null;

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  bool hasUsername() => _username != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _userID = snapshotData['userID'] as DocumentReference?;
    _replyText = snapshotData['reply_text'] as String?;
    _date = snapshotData['date'] as DateTime?;
    _repliedToComment =
        snapshotData['replied_to_comment'] as DocumentReference?;
    _repliedToReply = snapshotData['replied_to_reply'] as DocumentReference?;
    _postId = snapshotData['post_id'] as DocumentReference?;
    _likes = getDataList(snapshotData['likes']);
    _username = snapshotData['username'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('replies')
          : FirebaseFirestore.instance.collectionGroup('replies');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('replies').doc(id);

  static Stream<RepliesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RepliesRecord.fromSnapshot(s));

  static Future<RepliesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RepliesRecord.fromSnapshot(s));

  static RepliesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RepliesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RepliesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RepliesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RepliesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RepliesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRepliesRecordData({
  DocumentReference? userID,
  String? replyText,
  DateTime? date,
  DocumentReference? repliedToComment,
  DocumentReference? repliedToReply,
  DocumentReference? postId,
  String? username,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userID': userID,
      'reply_text': replyText,
      'date': date,
      'replied_to_comment': repliedToComment,
      'replied_to_reply': repliedToReply,
      'post_id': postId,
      'username': username,
    }.withoutNulls,
  );

  return firestoreData;
}

class RepliesRecordDocumentEquality implements Equality<RepliesRecord> {
  const RepliesRecordDocumentEquality();

  @override
  bool equals(RepliesRecord? e1, RepliesRecord? e2) {
    const listEquality = ListEquality();
    return e1?.userID == e2?.userID &&
        e1?.replyText == e2?.replyText &&
        e1?.date == e2?.date &&
        e1?.repliedToComment == e2?.repliedToComment &&
        e1?.repliedToReply == e2?.repliedToReply &&
        e1?.postId == e2?.postId &&
        listEquality.equals(e1?.likes, e2?.likes) &&
        e1?.username == e2?.username;
  }

  @override
  int hash(RepliesRecord? e) => const ListEquality().hash([
        e?.userID,
        e?.replyText,
        e?.date,
        e?.repliedToComment,
        e?.repliedToReply,
        e?.postId,
        e?.likes,
        e?.username
      ]);

  @override
  bool isValidKey(Object? o) => o is RepliesRecord;
}
