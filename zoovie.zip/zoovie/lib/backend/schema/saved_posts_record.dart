import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class SavedPostsRecord extends FirestoreRecord {
  SavedPostsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "userID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  // "postID" field.
  DocumentReference? _postID;
  DocumentReference? get postID => _postID;
  bool hasPostID() => _postID != null;

  // "uniqueID" field.
  String? _uniqueID;
  String get uniqueID => _uniqueID ?? '';
  bool hasUniqueID() => _uniqueID != null;

  // "post_image" field.
  String? _postImage;
  String get postImage => _postImage ?? '';
  bool hasPostImage() => _postImage != null;

  // "saved_date" field.
  DateTime? _savedDate;
  DateTime? get savedDate => _savedDate;
  bool hasSavedDate() => _savedDate != null;

  // "video" field.
  bool? _video;
  bool get video => _video ?? false;
  bool hasVideo() => _video != null;

  // "video_url" field.
  String? _videoUrl;
  String get videoUrl => _videoUrl ?? '';
  bool hasVideoUrl() => _videoUrl != null;

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  bool hasUsername() => _username != null;

  // "video_cover" field.
  String? _videoCover;
  String get videoCover => _videoCover ?? '';
  bool hasVideoCover() => _videoCover != null;

  void _initializeFields() {
    _userID = snapshotData['userID'] as DocumentReference?;
    _postID = snapshotData['postID'] as DocumentReference?;
    _uniqueID = snapshotData['uniqueID'] as String?;
    _postImage = snapshotData['post_image'] as String?;
    _savedDate = snapshotData['saved_date'] as DateTime?;
    _video = snapshotData['video'] as bool?;
    _videoUrl = snapshotData['video_url'] as String?;
    _username = snapshotData['username'] as String?;
    _videoCover = snapshotData['video_cover'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('saved_posts');

  static Stream<SavedPostsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SavedPostsRecord.fromSnapshot(s));

  static Future<SavedPostsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SavedPostsRecord.fromSnapshot(s));

  static SavedPostsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SavedPostsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SavedPostsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SavedPostsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SavedPostsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SavedPostsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSavedPostsRecordData({
  DocumentReference? userID,
  DocumentReference? postID,
  String? uniqueID,
  String? postImage,
  DateTime? savedDate,
  bool? video,
  String? videoUrl,
  String? username,
  String? videoCover,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userID': userID,
      'postID': postID,
      'uniqueID': uniqueID,
      'post_image': postImage,
      'saved_date': savedDate,
      'video': video,
      'video_url': videoUrl,
      'username': username,
      'video_cover': videoCover,
    }.withoutNulls,
  );

  return firestoreData;
}

class SavedPostsRecordDocumentEquality implements Equality<SavedPostsRecord> {
  const SavedPostsRecordDocumentEquality();

  @override
  bool equals(SavedPostsRecord? e1, SavedPostsRecord? e2) {
    return e1?.userID == e2?.userID &&
        e1?.postID == e2?.postID &&
        e1?.uniqueID == e2?.uniqueID &&
        e1?.postImage == e2?.postImage &&
        e1?.savedDate == e2?.savedDate &&
        e1?.video == e2?.video &&
        e1?.videoUrl == e2?.videoUrl &&
        e1?.username == e2?.username &&
        e1?.videoCover == e2?.videoCover;
  }

  @override
  int hash(SavedPostsRecord? e) => const ListEquality().hash([
        e?.userID,
        e?.postID,
        e?.uniqueID,
        e?.postImage,
        e?.savedDate,
        e?.video,
        e?.videoUrl,
        e?.username,
        e?.videoCover
      ]);

  @override
  bool isValidKey(Object? o) => o is SavedPostsRecord;
}
