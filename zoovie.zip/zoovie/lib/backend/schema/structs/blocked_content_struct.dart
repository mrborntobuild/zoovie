// ignore_for_file: unnecessary_getters_setters
import '/backend/algolia/serialization_util.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BlockedContentStruct extends FFFirebaseStruct {
  BlockedContentStruct({
    List<DocumentReference>? users,
    List<DocumentReference>? posts,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _users = users,
        _posts = posts,
        super(firestoreUtilData);

  // "users" field.
  List<DocumentReference>? _users;
  List<DocumentReference> get users => _users ?? const [];
  set users(List<DocumentReference>? val) => _users = val;
  void updateUsers(Function(List<DocumentReference>) updateFn) =>
      updateFn(_users ??= []);
  bool hasUsers() => _users != null;

  // "posts" field.
  List<DocumentReference>? _posts;
  List<DocumentReference> get posts => _posts ?? const [];
  set posts(List<DocumentReference>? val) => _posts = val;
  void updatePosts(Function(List<DocumentReference>) updateFn) =>
      updateFn(_posts ??= []);
  bool hasPosts() => _posts != null;

  static BlockedContentStruct fromMap(Map<String, dynamic> data) =>
      BlockedContentStruct(
        users: getDataList(data['users']),
        posts: getDataList(data['posts']),
      );

  static BlockedContentStruct? maybeFromMap(dynamic data) => data is Map
      ? BlockedContentStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'users': _users,
        'posts': _posts,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'users': serializeParam(
          _users,
          ParamType.DocumentReference,
          true,
        ),
        'posts': serializeParam(
          _posts,
          ParamType.DocumentReference,
          true,
        ),
      }.withoutNulls;

  static BlockedContentStruct fromSerializableMap(Map<String, dynamic> data) =>
      BlockedContentStruct(
        users: deserializeParam<DocumentReference>(
          data['users'],
          ParamType.DocumentReference,
          true,
          collectionNamePath: ['users'],
        ),
        posts: deserializeParam<DocumentReference>(
          data['posts'],
          ParamType.DocumentReference,
          true,
          collectionNamePath: ['posts'],
        ),
      );

  static BlockedContentStruct fromAlgoliaData(Map<String, dynamic> data) =>
      BlockedContentStruct(
        users: convertAlgoliaParam<DocumentReference>(
          data['users'],
          ParamType.DocumentReference,
          true,
        ),
        posts: convertAlgoliaParam<DocumentReference>(
          data['posts'],
          ParamType.DocumentReference,
          true,
        ),
        firestoreUtilData: const FirestoreUtilData(
          clearUnsetFields: false,
          create: true,
        ),
      );

  @override
  String toString() => 'BlockedContentStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is BlockedContentStruct &&
        listEquality.equals(users, other.users) &&
        listEquality.equals(posts, other.posts);
  }

  @override
  int get hashCode => const ListEquality().hash([users, posts]);
}

BlockedContentStruct createBlockedContentStruct({
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    BlockedContentStruct(
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

BlockedContentStruct? updateBlockedContentStruct(
  BlockedContentStruct? blockedContent, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    blockedContent
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addBlockedContentStructData(
  Map<String, dynamic> firestoreData,
  BlockedContentStruct? blockedContent,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (blockedContent == null) {
    return;
  }
  if (blockedContent.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && blockedContent.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final blockedContentData =
      getBlockedContentFirestoreData(blockedContent, forFieldValue);
  final nestedData =
      blockedContentData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = blockedContent.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getBlockedContentFirestoreData(
  BlockedContentStruct? blockedContent, [
  bool forFieldValue = false,
]) {
  if (blockedContent == null) {
    return {};
  }
  final firestoreData = mapToFirestore(blockedContent.toMap());

  // Add any Firestore field values
  blockedContent.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getBlockedContentListFirestoreData(
  List<BlockedContentStruct>? blockedContents,
) =>
    blockedContents
        ?.map((e) => getBlockedContentFirestoreData(e, true))
        .toList() ??
    [];
