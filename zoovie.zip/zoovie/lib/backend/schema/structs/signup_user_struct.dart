// ignore_for_file: unnecessary_getters_setters
import '/backend/algolia/serialization_util.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SignupUserStruct extends FFFirebaseStruct {
  SignupUserStruct({
    String? name,
    DateTime? birthday,
    String? username,
    String? phoneNumber,
    String? email,
    String? referralCode,
    DocumentReference? referredBy,
    String? password,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _name = name,
        _birthday = birthday,
        _username = username,
        _phoneNumber = phoneNumber,
        _email = email,
        _referralCode = referralCode,
        _referredBy = referredBy,
        _password = password,
        super(firestoreUtilData);

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;
  bool hasName() => _name != null;

  // "birthday" field.
  DateTime? _birthday;
  DateTime? get birthday => _birthday;
  set birthday(DateTime? val) => _birthday = val;
  bool hasBirthday() => _birthday != null;

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  set username(String? val) => _username = val;
  bool hasUsername() => _username != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  set phoneNumber(String? val) => _phoneNumber = val;
  bool hasPhoneNumber() => _phoneNumber != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  set email(String? val) => _email = val;
  bool hasEmail() => _email != null;

  // "referral_code" field.
  String? _referralCode;
  String get referralCode => _referralCode ?? '';
  set referralCode(String? val) => _referralCode = val;
  bool hasReferralCode() => _referralCode != null;

  // "referredBy" field.
  DocumentReference? _referredBy;
  DocumentReference? get referredBy => _referredBy;
  set referredBy(DocumentReference? val) => _referredBy = val;
  bool hasReferredBy() => _referredBy != null;

  // "password" field.
  String? _password;
  String get password => _password ?? '';
  set password(String? val) => _password = val;
  bool hasPassword() => _password != null;

  static SignupUserStruct fromMap(Map<String, dynamic> data) =>
      SignupUserStruct(
        name: data['name'] as String?,
        birthday: data['birthday'] as DateTime?,
        username: data['username'] as String?,
        phoneNumber: data['phone_number'] as String?,
        email: data['email'] as String?,
        referralCode: data['referral_code'] as String?,
        referredBy: data['referredBy'] as DocumentReference?,
        password: data['password'] as String?,
      );

  static SignupUserStruct? maybeFromMap(dynamic data) => data is Map
      ? SignupUserStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'name': _name,
        'birthday': _birthday,
        'username': _username,
        'phone_number': _phoneNumber,
        'email': _email,
        'referral_code': _referralCode,
        'referredBy': _referredBy,
        'password': _password,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'birthday': serializeParam(
          _birthday,
          ParamType.DateTime,
        ),
        'username': serializeParam(
          _username,
          ParamType.String,
        ),
        'phone_number': serializeParam(
          _phoneNumber,
          ParamType.String,
        ),
        'email': serializeParam(
          _email,
          ParamType.String,
        ),
        'referral_code': serializeParam(
          _referralCode,
          ParamType.String,
        ),
        'referredBy': serializeParam(
          _referredBy,
          ParamType.DocumentReference,
        ),
        'password': serializeParam(
          _password,
          ParamType.String,
        ),
      }.withoutNulls;

  static SignupUserStruct fromSerializableMap(Map<String, dynamic> data) =>
      SignupUserStruct(
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        birthday: deserializeParam(
          data['birthday'],
          ParamType.DateTime,
          false,
        ),
        username: deserializeParam(
          data['username'],
          ParamType.String,
          false,
        ),
        phoneNumber: deserializeParam(
          data['phone_number'],
          ParamType.String,
          false,
        ),
        email: deserializeParam(
          data['email'],
          ParamType.String,
          false,
        ),
        referralCode: deserializeParam(
          data['referral_code'],
          ParamType.String,
          false,
        ),
        referredBy: deserializeParam(
          data['referredBy'],
          ParamType.DocumentReference,
          false,
          collectionNamePath: ['users'],
        ),
        password: deserializeParam(
          data['password'],
          ParamType.String,
          false,
        ),
      );

  static SignupUserStruct fromAlgoliaData(Map<String, dynamic> data) =>
      SignupUserStruct(
        name: convertAlgoliaParam(
          data['name'],
          ParamType.String,
          false,
        ),
        birthday: convertAlgoliaParam(
          data['birthday'],
          ParamType.DateTime,
          false,
        ),
        username: convertAlgoliaParam(
          data['username'],
          ParamType.String,
          false,
        ),
        phoneNumber: convertAlgoliaParam(
          data['phone_number'],
          ParamType.String,
          false,
        ),
        email: convertAlgoliaParam(
          data['email'],
          ParamType.String,
          false,
        ),
        referralCode: convertAlgoliaParam(
          data['referral_code'],
          ParamType.String,
          false,
        ),
        referredBy: convertAlgoliaParam(
          data['referredBy'],
          ParamType.DocumentReference,
          false,
        ),
        password: convertAlgoliaParam(
          data['password'],
          ParamType.String,
          false,
        ),
        firestoreUtilData: const FirestoreUtilData(
          clearUnsetFields: false,
          create: true,
        ),
      );

  @override
  String toString() => 'SignupUserStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SignupUserStruct &&
        name == other.name &&
        birthday == other.birthday &&
        username == other.username &&
        phoneNumber == other.phoneNumber &&
        email == other.email &&
        referralCode == other.referralCode &&
        referredBy == other.referredBy &&
        password == other.password;
  }

  @override
  int get hashCode => const ListEquality().hash([
        name,
        birthday,
        username,
        phoneNumber,
        email,
        referralCode,
        referredBy,
        password
      ]);
}

SignupUserStruct createSignupUserStruct({
  String? name,
  DateTime? birthday,
  String? username,
  String? phoneNumber,
  String? email,
  String? referralCode,
  DocumentReference? referredBy,
  String? password,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    SignupUserStruct(
      name: name,
      birthday: birthday,
      username: username,
      phoneNumber: phoneNumber,
      email: email,
      referralCode: referralCode,
      referredBy: referredBy,
      password: password,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

SignupUserStruct? updateSignupUserStruct(
  SignupUserStruct? signupUser, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    signupUser
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addSignupUserStructData(
  Map<String, dynamic> firestoreData,
  SignupUserStruct? signupUser,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (signupUser == null) {
    return;
  }
  if (signupUser.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && signupUser.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final signupUserData = getSignupUserFirestoreData(signupUser, forFieldValue);
  final nestedData = signupUserData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = signupUser.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getSignupUserFirestoreData(
  SignupUserStruct? signupUser, [
  bool forFieldValue = false,
]) {
  if (signupUser == null) {
    return {};
  }
  final firestoreData = mapToFirestore(signupUser.toMap());

  // Add any Firestore field values
  signupUser.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getSignupUserListFirestoreData(
  List<SignupUserStruct>? signupUsers,
) =>
    signupUsers?.map((e) => getSignupUserFirestoreData(e, true)).toList() ?? [];
