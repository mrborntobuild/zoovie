// ignore_for_file: unnecessary_getters_setters
import '/backend/algolia/serialization_util.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SwitchToProfessionalStruct extends FFFirebaseStruct {
  SwitchToProfessionalStruct({
    String? logo,
    String? name,
    String? username,
    String? bio,
    String? website,
    String? category,
    String? streetAddress,
    String? cityTown,
    String? postalCode,
    String? country,
    LatLng? locationPin,
    String? phone,
    String? email,
    bool? businessAccount,
    DateTime? birthday,
    bool? displayCategory,
    bool? displayContact,
    bool? displayWebsite,
    bool? displayShop,
    bool? displayVerified,
    bool? proChecked,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _logo = logo,
        _name = name,
        _username = username,
        _bio = bio,
        _website = website,
        _category = category,
        _streetAddress = streetAddress,
        _cityTown = cityTown,
        _postalCode = postalCode,
        _country = country,
        _locationPin = locationPin,
        _phone = phone,
        _email = email,
        _businessAccount = businessAccount,
        _birthday = birthday,
        _displayCategory = displayCategory,
        _displayContact = displayContact,
        _displayWebsite = displayWebsite,
        _displayShop = displayShop,
        _displayVerified = displayVerified,
        _proChecked = proChecked,
        super(firestoreUtilData);

  // "logo" field.
  String? _logo;
  String get logo => _logo ?? '';
  set logo(String? val) => _logo = val;
  bool hasLogo() => _logo != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;
  bool hasName() => _name != null;

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  set username(String? val) => _username = val;
  bool hasUsername() => _username != null;

  // "bio" field.
  String? _bio;
  String get bio => _bio ?? '';
  set bio(String? val) => _bio = val;
  bool hasBio() => _bio != null;

  // "website" field.
  String? _website;
  String get website => _website ?? '';
  set website(String? val) => _website = val;
  bool hasWebsite() => _website != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  set category(String? val) => _category = val;
  bool hasCategory() => _category != null;

  // "street_address" field.
  String? _streetAddress;
  String get streetAddress => _streetAddress ?? '';
  set streetAddress(String? val) => _streetAddress = val;
  bool hasStreetAddress() => _streetAddress != null;

  // "city_town" field.
  String? _cityTown;
  String get cityTown => _cityTown ?? '';
  set cityTown(String? val) => _cityTown = val;
  bool hasCityTown() => _cityTown != null;

  // "postal_code" field.
  String? _postalCode;
  String get postalCode => _postalCode ?? '';
  set postalCode(String? val) => _postalCode = val;
  bool hasPostalCode() => _postalCode != null;

  // "country" field.
  String? _country;
  String get country => _country ?? '';
  set country(String? val) => _country = val;
  bool hasCountry() => _country != null;

  // "location_pin" field.
  LatLng? _locationPin;
  LatLng? get locationPin => _locationPin;
  set locationPin(LatLng? val) => _locationPin = val;
  bool hasLocationPin() => _locationPin != null;

  // "phone" field.
  String? _phone;
  String get phone => _phone ?? '';
  set phone(String? val) => _phone = val;
  bool hasPhone() => _phone != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  set email(String? val) => _email = val;
  bool hasEmail() => _email != null;

  // "business_account" field.
  bool? _businessAccount;
  bool get businessAccount => _businessAccount ?? false;
  set businessAccount(bool? val) => _businessAccount = val;
  bool hasBusinessAccount() => _businessAccount != null;

  // "birthday" field.
  DateTime? _birthday;
  DateTime? get birthday => _birthday;
  set birthday(DateTime? val) => _birthday = val;
  bool hasBirthday() => _birthday != null;

  // "display_category" field.
  bool? _displayCategory;
  bool get displayCategory => _displayCategory ?? false;
  set displayCategory(bool? val) => _displayCategory = val;
  bool hasDisplayCategory() => _displayCategory != null;

  // "display_contact" field.
  bool? _displayContact;
  bool get displayContact => _displayContact ?? false;
  set displayContact(bool? val) => _displayContact = val;
  bool hasDisplayContact() => _displayContact != null;

  // "display_website" field.
  bool? _displayWebsite;
  bool get displayWebsite => _displayWebsite ?? false;
  set displayWebsite(bool? val) => _displayWebsite = val;
  bool hasDisplayWebsite() => _displayWebsite != null;

  // "display_shop" field.
  bool? _displayShop;
  bool get displayShop => _displayShop ?? false;
  set displayShop(bool? val) => _displayShop = val;
  bool hasDisplayShop() => _displayShop != null;

  // "display_verified" field.
  bool? _displayVerified;
  bool get displayVerified => _displayVerified ?? false;
  set displayVerified(bool? val) => _displayVerified = val;
  bool hasDisplayVerified() => _displayVerified != null;

  // "pro_checked" field.
  bool? _proChecked;
  bool get proChecked => _proChecked ?? false;
  set proChecked(bool? val) => _proChecked = val;
  bool hasProChecked() => _proChecked != null;

  static SwitchToProfessionalStruct fromMap(Map<String, dynamic> data) =>
      SwitchToProfessionalStruct(
        logo: data['logo'] as String?,
        name: data['name'] as String?,
        username: data['username'] as String?,
        bio: data['bio'] as String?,
        website: data['website'] as String?,
        category: data['category'] as String?,
        streetAddress: data['street_address'] as String?,
        cityTown: data['city_town'] as String?,
        postalCode: data['postal_code'] as String?,
        country: data['country'] as String?,
        locationPin: data['location_pin'] as LatLng?,
        phone: data['phone'] as String?,
        email: data['email'] as String?,
        businessAccount: data['business_account'] as bool?,
        birthday: data['birthday'] as DateTime?,
        displayCategory: data['display_category'] as bool?,
        displayContact: data['display_contact'] as bool?,
        displayWebsite: data['display_website'] as bool?,
        displayShop: data['display_shop'] as bool?,
        displayVerified: data['display_verified'] as bool?,
        proChecked: data['pro_checked'] as bool?,
      );

  static SwitchToProfessionalStruct? maybeFromMap(dynamic data) => data is Map
      ? SwitchToProfessionalStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'logo': _logo,
        'name': _name,
        'username': _username,
        'bio': _bio,
        'website': _website,
        'category': _category,
        'street_address': _streetAddress,
        'city_town': _cityTown,
        'postal_code': _postalCode,
        'country': _country,
        'location_pin': _locationPin,
        'phone': _phone,
        'email': _email,
        'business_account': _businessAccount,
        'birthday': _birthday,
        'display_category': _displayCategory,
        'display_contact': _displayContact,
        'display_website': _displayWebsite,
        'display_shop': _displayShop,
        'display_verified': _displayVerified,
        'pro_checked': _proChecked,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'logo': serializeParam(
          _logo,
          ParamType.String,
        ),
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'username': serializeParam(
          _username,
          ParamType.String,
        ),
        'bio': serializeParam(
          _bio,
          ParamType.String,
        ),
        'website': serializeParam(
          _website,
          ParamType.String,
        ),
        'category': serializeParam(
          _category,
          ParamType.String,
        ),
        'street_address': serializeParam(
          _streetAddress,
          ParamType.String,
        ),
        'city_town': serializeParam(
          _cityTown,
          ParamType.String,
        ),
        'postal_code': serializeParam(
          _postalCode,
          ParamType.String,
        ),
        'country': serializeParam(
          _country,
          ParamType.String,
        ),
        'location_pin': serializeParam(
          _locationPin,
          ParamType.LatLng,
        ),
        'phone': serializeParam(
          _phone,
          ParamType.String,
        ),
        'email': serializeParam(
          _email,
          ParamType.String,
        ),
        'business_account': serializeParam(
          _businessAccount,
          ParamType.bool,
        ),
        'birthday': serializeParam(
          _birthday,
          ParamType.DateTime,
        ),
        'display_category': serializeParam(
          _displayCategory,
          ParamType.bool,
        ),
        'display_contact': serializeParam(
          _displayContact,
          ParamType.bool,
        ),
        'display_website': serializeParam(
          _displayWebsite,
          ParamType.bool,
        ),
        'display_shop': serializeParam(
          _displayShop,
          ParamType.bool,
        ),
        'display_verified': serializeParam(
          _displayVerified,
          ParamType.bool,
        ),
        'pro_checked': serializeParam(
          _proChecked,
          ParamType.bool,
        ),
      }.withoutNulls;

  static SwitchToProfessionalStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      SwitchToProfessionalStruct(
        logo: deserializeParam(
          data['logo'],
          ParamType.String,
          false,
        ),
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        username: deserializeParam(
          data['username'],
          ParamType.String,
          false,
        ),
        bio: deserializeParam(
          data['bio'],
          ParamType.String,
          false,
        ),
        website: deserializeParam(
          data['website'],
          ParamType.String,
          false,
        ),
        category: deserializeParam(
          data['category'],
          ParamType.String,
          false,
        ),
        streetAddress: deserializeParam(
          data['street_address'],
          ParamType.String,
          false,
        ),
        cityTown: deserializeParam(
          data['city_town'],
          ParamType.String,
          false,
        ),
        postalCode: deserializeParam(
          data['postal_code'],
          ParamType.String,
          false,
        ),
        country: deserializeParam(
          data['country'],
          ParamType.String,
          false,
        ),
        locationPin: deserializeParam(
          data['location_pin'],
          ParamType.LatLng,
          false,
        ),
        phone: deserializeParam(
          data['phone'],
          ParamType.String,
          false,
        ),
        email: deserializeParam(
          data['email'],
          ParamType.String,
          false,
        ),
        businessAccount: deserializeParam(
          data['business_account'],
          ParamType.bool,
          false,
        ),
        birthday: deserializeParam(
          data['birthday'],
          ParamType.DateTime,
          false,
        ),
        displayCategory: deserializeParam(
          data['display_category'],
          ParamType.bool,
          false,
        ),
        displayContact: deserializeParam(
          data['display_contact'],
          ParamType.bool,
          false,
        ),
        displayWebsite: deserializeParam(
          data['display_website'],
          ParamType.bool,
          false,
        ),
        displayShop: deserializeParam(
          data['display_shop'],
          ParamType.bool,
          false,
        ),
        displayVerified: deserializeParam(
          data['display_verified'],
          ParamType.bool,
          false,
        ),
        proChecked: deserializeParam(
          data['pro_checked'],
          ParamType.bool,
          false,
        ),
      );

  static SwitchToProfessionalStruct fromAlgoliaData(
          Map<String, dynamic> data) =>
      SwitchToProfessionalStruct(
        logo: convertAlgoliaParam(
          data['logo'],
          ParamType.String,
          false,
        ),
        name: convertAlgoliaParam(
          data['name'],
          ParamType.String,
          false,
        ),
        username: convertAlgoliaParam(
          data['username'],
          ParamType.String,
          false,
        ),
        bio: convertAlgoliaParam(
          data['bio'],
          ParamType.String,
          false,
        ),
        website: convertAlgoliaParam(
          data['website'],
          ParamType.String,
          false,
        ),
        category: convertAlgoliaParam(
          data['category'],
          ParamType.String,
          false,
        ),
        streetAddress: convertAlgoliaParam(
          data['street_address'],
          ParamType.String,
          false,
        ),
        cityTown: convertAlgoliaParam(
          data['city_town'],
          ParamType.String,
          false,
        ),
        postalCode: convertAlgoliaParam(
          data['postal_code'],
          ParamType.String,
          false,
        ),
        country: convertAlgoliaParam(
          data['country'],
          ParamType.String,
          false,
        ),
        locationPin: convertAlgoliaParam(
          data,
          ParamType.LatLng,
          false,
        ),
        phone: convertAlgoliaParam(
          data['phone'],
          ParamType.String,
          false,
        ),
        email: convertAlgoliaParam(
          data['email'],
          ParamType.String,
          false,
        ),
        businessAccount: convertAlgoliaParam(
          data['business_account'],
          ParamType.bool,
          false,
        ),
        birthday: convertAlgoliaParam(
          data['birthday'],
          ParamType.DateTime,
          false,
        ),
        displayCategory: convertAlgoliaParam(
          data['display_category'],
          ParamType.bool,
          false,
        ),
        displayContact: convertAlgoliaParam(
          data['display_contact'],
          ParamType.bool,
          false,
        ),
        displayWebsite: convertAlgoliaParam(
          data['display_website'],
          ParamType.bool,
          false,
        ),
        displayShop: convertAlgoliaParam(
          data['display_shop'],
          ParamType.bool,
          false,
        ),
        displayVerified: convertAlgoliaParam(
          data['display_verified'],
          ParamType.bool,
          false,
        ),
        proChecked: convertAlgoliaParam(
          data['pro_checked'],
          ParamType.bool,
          false,
        ),
        firestoreUtilData: const FirestoreUtilData(
          clearUnsetFields: false,
          create: true,
        ),
      );

  @override
  String toString() => 'SwitchToProfessionalStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SwitchToProfessionalStruct &&
        logo == other.logo &&
        name == other.name &&
        username == other.username &&
        bio == other.bio &&
        website == other.website &&
        category == other.category &&
        streetAddress == other.streetAddress &&
        cityTown == other.cityTown &&
        postalCode == other.postalCode &&
        country == other.country &&
        locationPin == other.locationPin &&
        phone == other.phone &&
        email == other.email &&
        businessAccount == other.businessAccount &&
        birthday == other.birthday &&
        displayCategory == other.displayCategory &&
        displayContact == other.displayContact &&
        displayWebsite == other.displayWebsite &&
        displayShop == other.displayShop &&
        displayVerified == other.displayVerified &&
        proChecked == other.proChecked;
  }

  @override
  int get hashCode => const ListEquality().hash([
        logo,
        name,
        username,
        bio,
        website,
        category,
        streetAddress,
        cityTown,
        postalCode,
        country,
        locationPin,
        phone,
        email,
        businessAccount,
        birthday,
        displayCategory,
        displayContact,
        displayWebsite,
        displayShop,
        displayVerified,
        proChecked
      ]);
}

SwitchToProfessionalStruct createSwitchToProfessionalStruct({
  String? logo,
  String? name,
  String? username,
  String? bio,
  String? website,
  String? category,
  String? streetAddress,
  String? cityTown,
  String? postalCode,
  String? country,
  LatLng? locationPin,
  String? phone,
  String? email,
  bool? businessAccount,
  DateTime? birthday,
  bool? displayCategory,
  bool? displayContact,
  bool? displayWebsite,
  bool? displayShop,
  bool? displayVerified,
  bool? proChecked,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    SwitchToProfessionalStruct(
      logo: logo,
      name: name,
      username: username,
      bio: bio,
      website: website,
      category: category,
      streetAddress: streetAddress,
      cityTown: cityTown,
      postalCode: postalCode,
      country: country,
      locationPin: locationPin,
      phone: phone,
      email: email,
      businessAccount: businessAccount,
      birthday: birthday,
      displayCategory: displayCategory,
      displayContact: displayContact,
      displayWebsite: displayWebsite,
      displayShop: displayShop,
      displayVerified: displayVerified,
      proChecked: proChecked,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

SwitchToProfessionalStruct? updateSwitchToProfessionalStruct(
  SwitchToProfessionalStruct? switchToProfessional, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    switchToProfessional
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addSwitchToProfessionalStructData(
  Map<String, dynamic> firestoreData,
  SwitchToProfessionalStruct? switchToProfessional,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (switchToProfessional == null) {
    return;
  }
  if (switchToProfessional.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && switchToProfessional.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final switchToProfessionalData =
      getSwitchToProfessionalFirestoreData(switchToProfessional, forFieldValue);
  final nestedData =
      switchToProfessionalData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields =
      switchToProfessional.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getSwitchToProfessionalFirestoreData(
  SwitchToProfessionalStruct? switchToProfessional, [
  bool forFieldValue = false,
]) {
  if (switchToProfessional == null) {
    return {};
  }
  final firestoreData = mapToFirestore(switchToProfessional.toMap());

  // Add any Firestore field values
  switchToProfessional.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getSwitchToProfessionalListFirestoreData(
  List<SwitchToProfessionalStruct>? switchToProfessionals,
) =>
    switchToProfessionals
        ?.map((e) => getSwitchToProfessionalFirestoreData(e, true))
        .toList() ??
    [];
