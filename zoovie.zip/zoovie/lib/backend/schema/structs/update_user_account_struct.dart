// ignore_for_file: unnecessary_getters_setters
import '/backend/algolia/serialization_util.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UpdateUserAccountStruct extends FFFirebaseStruct {
  UpdateUserAccountStruct({
    String? profilePicture,
    String? name,
    String? username,
    String? bio,
    String? link,
    bool? displayBio,
    bool? displayLink,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _profilePicture = profilePicture,
        _name = name,
        _username = username,
        _bio = bio,
        _link = link,
        _displayBio = displayBio,
        _displayLink = displayLink,
        super(firestoreUtilData);

  // "profile_picture" field.
  String? _profilePicture;
  String get profilePicture => _profilePicture ?? '';
  set profilePicture(String? val) => _profilePicture = val;
  bool hasProfilePicture() => _profilePicture != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;
  bool hasName() => _name != null;

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  set username(String? val) => _username = val;
  bool hasUsername() => _username != null;

  // "bio" field.
  String? _bio;
  String get bio => _bio ?? '';
  set bio(String? val) => _bio = val;
  bool hasBio() => _bio != null;

  // "link" field.
  String? _link;
  String get link => _link ?? '';
  set link(String? val) => _link = val;
  bool hasLink() => _link != null;

  // "display_bio" field.
  bool? _displayBio;
  bool get displayBio => _displayBio ?? false;
  set displayBio(bool? val) => _displayBio = val;
  bool hasDisplayBio() => _displayBio != null;

  // "display_link" field.
  bool? _displayLink;
  bool get displayLink => _displayLink ?? false;
  set displayLink(bool? val) => _displayLink = val;
  bool hasDisplayLink() => _displayLink != null;

  static UpdateUserAccountStruct fromMap(Map<String, dynamic> data) =>
      UpdateUserAccountStruct(
        profilePicture: data['profile_picture'] as String?,
        name: data['name'] as String?,
        username: data['username'] as String?,
        bio: data['bio'] as String?,
        link: data['link'] as String?,
        displayBio: data['display_bio'] as bool?,
        displayLink: data['display_link'] as bool?,
      );

  static UpdateUserAccountStruct? maybeFromMap(dynamic data) => data is Map
      ? UpdateUserAccountStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'profile_picture': _profilePicture,
        'name': _name,
        'username': _username,
        'bio': _bio,
        'link': _link,
        'display_bio': _displayBio,
        'display_link': _displayLink,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'profile_picture': serializeParam(
          _profilePicture,
          ParamType.String,
        ),
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'username': serializeParam(
          _username,
          ParamType.String,
        ),
        'bio': serializeParam(
          _bio,
          ParamType.String,
        ),
        'link': serializeParam(
          _link,
          ParamType.String,
        ),
        'display_bio': serializeParam(
          _displayBio,
          ParamType.bool,
        ),
        'display_link': serializeParam(
          _displayLink,
          ParamType.bool,
        ),
      }.withoutNulls;

  static UpdateUserAccountStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      UpdateUserAccountStruct(
        profilePicture: deserializeParam(
          data['profile_picture'],
          ParamType.String,
          false,
        ),
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        username: deserializeParam(
          data['username'],
          ParamType.String,
          false,
        ),
        bio: deserializeParam(
          data['bio'],
          ParamType.String,
          false,
        ),
        link: deserializeParam(
          data['link'],
          ParamType.String,
          false,
        ),
        displayBio: deserializeParam(
          data['display_bio'],
          ParamType.bool,
          false,
        ),
        displayLink: deserializeParam(
          data['display_link'],
          ParamType.bool,
          false,
        ),
      );

  static UpdateUserAccountStruct fromAlgoliaData(Map<String, dynamic> data) =>
      UpdateUserAccountStruct(
        profilePicture: convertAlgoliaParam(
          data['profile_picture'],
          ParamType.String,
          false,
        ),
        name: convertAlgoliaParam(
          data['name'],
          ParamType.String,
          false,
        ),
        username: convertAlgoliaParam(
          data['username'],
          ParamType.String,
          false,
        ),
        bio: convertAlgoliaParam(
          data['bio'],
          ParamType.String,
          false,
        ),
        link: convertAlgoliaParam(
          data['link'],
          ParamType.String,
          false,
        ),
        displayBio: convertAlgoliaParam(
          data['display_bio'],
          ParamType.bool,
          false,
        ),
        displayLink: convertAlgoliaParam(
          data['display_link'],
          ParamType.bool,
          false,
        ),
        firestoreUtilData: const FirestoreUtilData(
          clearUnsetFields: false,
          create: true,
        ),
      );

  @override
  String toString() => 'UpdateUserAccountStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is UpdateUserAccountStruct &&
        profilePicture == other.profilePicture &&
        name == other.name &&
        username == other.username &&
        bio == other.bio &&
        link == other.link &&
        displayBio == other.displayBio &&
        displayLink == other.displayLink;
  }

  @override
  int get hashCode => const ListEquality().hash(
      [profilePicture, name, username, bio, link, displayBio, displayLink]);
}

UpdateUserAccountStruct createUpdateUserAccountStruct({
  String? profilePicture,
  String? name,
  String? username,
  String? bio,
  String? link,
  bool? displayBio,
  bool? displayLink,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    UpdateUserAccountStruct(
      profilePicture: profilePicture,
      name: name,
      username: username,
      bio: bio,
      link: link,
      displayBio: displayBio,
      displayLink: displayLink,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

UpdateUserAccountStruct? updateUpdateUserAccountStruct(
  UpdateUserAccountStruct? updateUserAccount, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    updateUserAccount
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addUpdateUserAccountStructData(
  Map<String, dynamic> firestoreData,
  UpdateUserAccountStruct? updateUserAccount,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (updateUserAccount == null) {
    return;
  }
  if (updateUserAccount.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && updateUserAccount.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final updateUserAccountData =
      getUpdateUserAccountFirestoreData(updateUserAccount, forFieldValue);
  final nestedData =
      updateUserAccountData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = updateUserAccount.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getUpdateUserAccountFirestoreData(
  UpdateUserAccountStruct? updateUserAccount, [
  bool forFieldValue = false,
]) {
  if (updateUserAccount == null) {
    return {};
  }
  final firestoreData = mapToFirestore(updateUserAccount.toMap());

  // Add any Firestore field values
  updateUserAccount.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getUpdateUserAccountListFirestoreData(
  List<UpdateUserAccountStruct>? updateUserAccounts,
) =>
    updateUserAccounts
        ?.map((e) => getUpdateUserAccountFirestoreData(e, true))
        .toList() ??
    [];
