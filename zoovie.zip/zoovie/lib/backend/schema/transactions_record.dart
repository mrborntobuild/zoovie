import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TransactionsRecord extends FirestoreRecord {
  TransactionsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "userID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  // "vendorID" field.
  DocumentReference? _vendorID;
  DocumentReference? get vendorID => _vendorID;
  bool hasVendorID() => _vendorID != null;

  // "referredBy" field.
  DocumentReference? _referredBy;
  DocumentReference? get referredBy => _referredBy;
  bool hasReferredBy() => _referredBy != null;

  // "transaction_amount" field.
  double? _transactionAmount;
  double get transactionAmount => _transactionAmount ?? 0.0;
  bool hasTransactionAmount() => _transactionAmount != null;

  // "transaction_date" field.
  DateTime? _transactionDate;
  DateTime? get transactionDate => _transactionDate;
  bool hasTransactionDate() => _transactionDate != null;

  // "transaction_location" field.
  LatLng? _transactionLocation;
  LatLng? get transactionLocation => _transactionLocation;
  bool hasTransactionLocation() => _transactionLocation != null;

  // "vendor_name" field.
  String? _vendorName;
  String get vendorName => _vendorName ?? '';
  bool hasVendorName() => _vendorName != null;

  // "vendor_logo" field.
  String? _vendorLogo;
  String get vendorLogo => _vendorLogo ?? '';
  bool hasVendorLogo() => _vendorLogo != null;

  // "discount" field.
  double? _discount;
  double get discount => _discount ?? 0.0;
  bool hasDiscount() => _discount != null;

  // "saved" field.
  double? _saved;
  double get saved => _saved ?? 0.0;
  bool hasSaved() => _saved != null;

  // "payout_status" field.
  bool? _payoutStatus;
  bool get payoutStatus => _payoutStatus ?? false;
  bool hasPayoutStatus() => _payoutStatus != null;

  // "finalAmount" field.
  double? _finalAmount;
  double get finalAmount => _finalAmount ?? 0.0;
  bool hasFinalAmount() => _finalAmount != null;

  // "referrerPayout" field.
  double? _referrerPayout;
  double get referrerPayout => _referrerPayout ?? 0.0;
  bool hasReferrerPayout() => _referrerPayout != null;

  // "buyer_username" field.
  String? _buyerUsername;
  String get buyerUsername => _buyerUsername ?? '';
  bool hasBuyerUsername() => _buyerUsername != null;

  // "beneree_fee" field.
  double? _benereeFee;
  double get benereeFee => _benereeFee ?? 0.0;
  bool hasBenereeFee() => _benereeFee != null;

  // "vendorDiscount" field.
  double? _vendorDiscount;
  double get vendorDiscount => _vendorDiscount ?? 0.0;
  bool hasVendorDiscount() => _vendorDiscount != null;

  // "cancelled_vendor" field.
  bool? _cancelledVendor;
  bool get cancelledVendor => _cancelledVendor ?? false;
  bool hasCancelledVendor() => _cancelledVendor != null;

  // "scanned_by_user" field.
  bool? _scannedByUser;
  bool get scannedByUser => _scannedByUser ?? false;
  bool hasScannedByUser() => _scannedByUser != null;

  // "referral_reward_amount" field.
  double? _referralRewardAmount;
  double get referralRewardAmount => _referralRewardAmount ?? 0.0;
  bool hasReferralRewardAmount() => _referralRewardAmount != null;

  // "referral_amount_owner" field.
  DocumentReference? _referralAmountOwner;
  DocumentReference? get referralAmountOwner => _referralAmountOwner;
  bool hasReferralAmountOwner() => _referralAmountOwner != null;

  // "city" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "withdraw" field.
  bool? _withdraw;
  bool get withdraw => _withdraw ?? false;
  bool hasWithdraw() => _withdraw != null;

  void _initializeFields() {
    _userID = snapshotData['userID'] as DocumentReference?;
    _vendorID = snapshotData['vendorID'] as DocumentReference?;
    _referredBy = snapshotData['referredBy'] as DocumentReference?;
    _transactionAmount = castToType<double>(snapshotData['transaction_amount']);
    _transactionDate = snapshotData['transaction_date'] as DateTime?;
    _transactionLocation = snapshotData['transaction_location'] as LatLng?;
    _vendorName = snapshotData['vendor_name'] as String?;
    _vendorLogo = snapshotData['vendor_logo'] as String?;
    _discount = castToType<double>(snapshotData['discount']);
    _saved = castToType<double>(snapshotData['saved']);
    _payoutStatus = snapshotData['payout_status'] as bool?;
    _finalAmount = castToType<double>(snapshotData['finalAmount']);
    _referrerPayout = castToType<double>(snapshotData['referrerPayout']);
    _buyerUsername = snapshotData['buyer_username'] as String?;
    _benereeFee = castToType<double>(snapshotData['beneree_fee']);
    _vendorDiscount = castToType<double>(snapshotData['vendorDiscount']);
    _cancelledVendor = snapshotData['cancelled_vendor'] as bool?;
    _scannedByUser = snapshotData['scanned_by_user'] as bool?;
    _referralRewardAmount =
        castToType<double>(snapshotData['referral_reward_amount']);
    _referralAmountOwner =
        snapshotData['referral_amount_owner'] as DocumentReference?;
    _city = snapshotData['city'] as String?;
    _withdraw = snapshotData['withdraw'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('transactions');

  static Stream<TransactionsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TransactionsRecord.fromSnapshot(s));

  static Future<TransactionsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TransactionsRecord.fromSnapshot(s));

  static TransactionsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      TransactionsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TransactionsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TransactionsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TransactionsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TransactionsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTransactionsRecordData({
  DocumentReference? userID,
  DocumentReference? vendorID,
  DocumentReference? referredBy,
  double? transactionAmount,
  DateTime? transactionDate,
  LatLng? transactionLocation,
  String? vendorName,
  String? vendorLogo,
  double? discount,
  double? saved,
  bool? payoutStatus,
  double? finalAmount,
  double? referrerPayout,
  String? buyerUsername,
  double? benereeFee,
  double? vendorDiscount,
  bool? cancelledVendor,
  bool? scannedByUser,
  double? referralRewardAmount,
  DocumentReference? referralAmountOwner,
  String? city,
  bool? withdraw,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userID': userID,
      'vendorID': vendorID,
      'referredBy': referredBy,
      'transaction_amount': transactionAmount,
      'transaction_date': transactionDate,
      'transaction_location': transactionLocation,
      'vendor_name': vendorName,
      'vendor_logo': vendorLogo,
      'discount': discount,
      'saved': saved,
      'payout_status': payoutStatus,
      'finalAmount': finalAmount,
      'referrerPayout': referrerPayout,
      'buyer_username': buyerUsername,
      'beneree_fee': benereeFee,
      'vendorDiscount': vendorDiscount,
      'cancelled_vendor': cancelledVendor,
      'scanned_by_user': scannedByUser,
      'referral_reward_amount': referralRewardAmount,
      'referral_amount_owner': referralAmountOwner,
      'city': city,
      'withdraw': withdraw,
    }.withoutNulls,
  );

  return firestoreData;
}

class TransactionsRecordDocumentEquality
    implements Equality<TransactionsRecord> {
  const TransactionsRecordDocumentEquality();

  @override
  bool equals(TransactionsRecord? e1, TransactionsRecord? e2) {
    return e1?.userID == e2?.userID &&
        e1?.vendorID == e2?.vendorID &&
        e1?.referredBy == e2?.referredBy &&
        e1?.transactionAmount == e2?.transactionAmount &&
        e1?.transactionDate == e2?.transactionDate &&
        e1?.transactionLocation == e2?.transactionLocation &&
        e1?.vendorName == e2?.vendorName &&
        e1?.vendorLogo == e2?.vendorLogo &&
        e1?.discount == e2?.discount &&
        e1?.saved == e2?.saved &&
        e1?.payoutStatus == e2?.payoutStatus &&
        e1?.finalAmount == e2?.finalAmount &&
        e1?.referrerPayout == e2?.referrerPayout &&
        e1?.buyerUsername == e2?.buyerUsername &&
        e1?.benereeFee == e2?.benereeFee &&
        e1?.vendorDiscount == e2?.vendorDiscount &&
        e1?.cancelledVendor == e2?.cancelledVendor &&
        e1?.scannedByUser == e2?.scannedByUser &&
        e1?.referralRewardAmount == e2?.referralRewardAmount &&
        e1?.referralAmountOwner == e2?.referralAmountOwner &&
        e1?.city == e2?.city &&
        e1?.withdraw == e2?.withdraw;
  }

  @override
  int hash(TransactionsRecord? e) => const ListEquality().hash([
        e?.userID,
        e?.vendorID,
        e?.referredBy,
        e?.transactionAmount,
        e?.transactionDate,
        e?.transactionLocation,
        e?.vendorName,
        e?.vendorLogo,
        e?.discount,
        e?.saved,
        e?.payoutStatus,
        e?.finalAmount,
        e?.referrerPayout,
        e?.buyerUsername,
        e?.benereeFee,
        e?.vendorDiscount,
        e?.cancelledVendor,
        e?.scannedByUser,
        e?.referralRewardAmount,
        e?.referralAmountOwner,
        e?.city,
        e?.withdraw
      ]);

  @override
  bool isValidKey(Object? o) => o is TransactionsRecord;
}
