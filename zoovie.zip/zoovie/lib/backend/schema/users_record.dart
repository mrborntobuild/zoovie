import 'dart:async';

import '/backend/algolia/serialization_util.dart';
import '/backend/algolia/algolia_manager.dart';
import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "date_of_birth" field.
  DateTime? _dateOfBirth;
  DateTime? get dateOfBirth => _dateOfBirth;
  bool hasDateOfBirth() => _dateOfBirth != null;

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  bool hasUsername() => _username != null;

  // "following" field.
  List<DocumentReference>? _following;
  List<DocumentReference> get following => _following ?? const [];
  bool hasFollowing() => _following != null;

  // "followers" field.
  List<DocumentReference>? _followers;
  List<DocumentReference> get followers => _followers ?? const [];
  bool hasFollowers() => _followers != null;

  // "current_location" field.
  LatLng? _currentLocation;
  LatLng? get currentLocation => _currentLocation;
  bool hasCurrentLocation() => _currentLocation != null;

  // "last_visited" field.
  DateTime? _lastVisited;
  DateTime? get lastVisited => _lastVisited;
  bool hasLastVisited() => _lastVisited != null;

  // "premium_account" field.
  bool? _premiumAccount;
  bool get premiumAccount => _premiumAccount ?? false;
  bool hasPremiumAccount() => _premiumAccount != null;

  // "bio" field.
  String? _bio;
  String get bio => _bio ?? '';
  bool hasBio() => _bio != null;

  // "link" field.
  String? _link;
  String get link => _link ?? '';
  bool hasLink() => _link != null;

  // "referredBy" field.
  DocumentReference? _referredBy;
  DocumentReference? get referredBy => _referredBy;
  bool hasReferredBy() => _referredBy != null;

  // "invitedUsers" field.
  List<DocumentReference>? _invitedUsers;
  List<DocumentReference> get invitedUsers => _invitedUsers ?? const [];
  bool hasInvitedUsers() => _invitedUsers != null;

  // "new_notification" field.
  bool? _newNotification;
  bool get newNotification => _newNotification ?? false;
  bool hasNewNotification() => _newNotification != null;

  // "partner" field.
  bool? _partner;
  bool get partner => _partner ?? false;
  bool hasPartner() => _partner != null;

  // "new_message" field.
  bool? _newMessage;
  bool get newMessage => _newMessage ?? false;
  bool hasNewMessage() => _newMessage != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  bool hasCategory() => _category != null;

  // "street_address" field.
  String? _streetAddress;
  String get streetAddress => _streetAddress ?? '';
  bool hasStreetAddress() => _streetAddress != null;

  // "city_town" field.
  String? _cityTown;
  String get cityTown => _cityTown ?? '';
  bool hasCityTown() => _cityTown != null;

  // "postal_code" field.
  String? _postalCode;
  String get postalCode => _postalCode ?? '';
  bool hasPostalCode() => _postalCode != null;

  // "country" field.
  String? _country;
  String get country => _country ?? '';
  bool hasCountry() => _country != null;

  // "business_location_pin" field.
  LatLng? _businessLocationPin;
  LatLng? get businessLocationPin => _businessLocationPin;
  bool hasBusinessLocationPin() => _businessLocationPin != null;

  // "business_account" field.
  bool? _businessAccount;
  bool get businessAccount => _businessAccount ?? false;
  bool hasBusinessAccount() => _businessAccount != null;

  // "display_business_category" field.
  bool? _displayBusinessCategory;
  bool get displayBusinessCategory => _displayBusinessCategory ?? false;
  bool hasDisplayBusinessCategory() => _displayBusinessCategory != null;

  // "display_business_contact" field.
  bool? _displayBusinessContact;
  bool get displayBusinessContact => _displayBusinessContact ?? false;
  bool hasDisplayBusinessContact() => _displayBusinessContact != null;

  // "display_bio" field.
  bool? _displayBio;
  bool get displayBio => _displayBio ?? false;
  bool hasDisplayBio() => _displayBio != null;

  // "display_link" field.
  bool? _displayLink;
  bool get displayLink => _displayLink ?? false;
  bool hasDisplayLink() => _displayLink != null;

  // "referral_code" field.
  String? _referralCode;
  String get referralCode => _referralCode ?? '';
  bool hasReferralCode() => _referralCode != null;

  // "partner_ID" field.
  DocumentReference? _partnerID;
  DocumentReference? get partnerID => _partnerID;
  bool hasPartnerID() => _partnerID != null;

  // "suspended" field.
  bool? _suspended;
  bool get suspended => _suspended ?? false;
  bool hasSuspended() => _suspended != null;

  // "subscription_id" field.
  DocumentReference? _subscriptionId;
  DocumentReference? get subscriptionId => _subscriptionId;
  bool hasSubscriptionId() => _subscriptionId != null;

  // "blocked_users" field.
  List<DocumentReference>? _blockedUsers;
  List<DocumentReference> get blockedUsers => _blockedUsers ?? const [];
  bool hasBlockedUsers() => _blockedUsers != null;

  // "profile_blur_hash" field.
  String? _profileBlurHash;
  String get profileBlurHash => _profileBlurHash ?? '';
  bool hasProfileBlurHash() => _profileBlurHash != null;

  // "points" field.
  int? _points;
  int get points => _points ?? 0;
  bool hasPoints() => _points != null;

  // "vendorDiscount" field.
  double? _vendorDiscount;
  double get vendorDiscount => _vendorDiscount ?? 0.0;
  bool hasVendorDiscount() => _vendorDiscount != null;

  // "x_points" field.
  int? _xPoints;
  int get xPoints => _xPoints ?? 0;
  bool hasXPoints() => _xPoints != null;

  // "due_fees" field.
  double? _dueFees;
  double get dueFees => _dueFees ?? 0.0;
  bool hasDueFees() => _dueFees != null;

  // "total_earned" field.
  double? _totalEarned;
  double get totalEarned => _totalEarned ?? 0.0;
  bool hasTotalEarned() => _totalEarned != null;

  // "allow_scanning" field.
  bool? _allowScanning;
  bool get allowScanning => _allowScanning ?? false;
  bool hasAllowScanning() => _allowScanning != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _dateOfBirth = snapshotData['date_of_birth'] as DateTime?;
    _username = snapshotData['username'] as String?;
    _following = getDataList(snapshotData['following']);
    _followers = getDataList(snapshotData['followers']);
    _currentLocation = snapshotData['current_location'] as LatLng?;
    _lastVisited = snapshotData['last_visited'] as DateTime?;
    _premiumAccount = snapshotData['premium_account'] as bool?;
    _bio = snapshotData['bio'] as String?;
    _link = snapshotData['link'] as String?;
    _referredBy = snapshotData['referredBy'] as DocumentReference?;
    _invitedUsers = getDataList(snapshotData['invitedUsers']);
    _newNotification = snapshotData['new_notification'] as bool?;
    _partner = snapshotData['partner'] as bool?;
    _newMessage = snapshotData['new_message'] as bool?;
    _category = snapshotData['category'] as String?;
    _streetAddress = snapshotData['street_address'] as String?;
    _cityTown = snapshotData['city_town'] as String?;
    _postalCode = snapshotData['postal_code'] as String?;
    _country = snapshotData['country'] as String?;
    _businessLocationPin = snapshotData['business_location_pin'] as LatLng?;
    _businessAccount = snapshotData['business_account'] as bool?;
    _displayBusinessCategory =
        snapshotData['display_business_category'] as bool?;
    _displayBusinessContact = snapshotData['display_business_contact'] as bool?;
    _displayBio = snapshotData['display_bio'] as bool?;
    _displayLink = snapshotData['display_link'] as bool?;
    _referralCode = snapshotData['referral_code'] as String?;
    _partnerID = snapshotData['partner_ID'] as DocumentReference?;
    _suspended = snapshotData['suspended'] as bool?;
    _subscriptionId = snapshotData['subscription_id'] as DocumentReference?;
    _blockedUsers = getDataList(snapshotData['blocked_users']);
    _profileBlurHash = snapshotData['profile_blur_hash'] as String?;
    _points = castToType<int>(snapshotData['points']);
    _vendorDiscount = castToType<double>(snapshotData['vendorDiscount']);
    _xPoints = castToType<int>(snapshotData['x_points']);
    _dueFees = castToType<double>(snapshotData['due_fees']);
    _totalEarned = castToType<double>(snapshotData['total_earned']);
    _allowScanning = snapshotData['allow_scanning'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  static UsersRecord fromAlgolia(AlgoliaObjectSnapshot snapshot) =>
      UsersRecord.getDocumentFromData(
        {
          'email': snapshot.data['email'],
          'display_name': snapshot.data['display_name'],
          'photo_url': snapshot.data['photo_url'],
          'uid': snapshot.data['uid'],
          'created_time': convertAlgoliaParam(
            snapshot.data['created_time'],
            ParamType.DateTime,
            false,
          ),
          'phone_number': snapshot.data['phone_number'],
          'date_of_birth': convertAlgoliaParam(
            snapshot.data['date_of_birth'],
            ParamType.DateTime,
            false,
          ),
          'username': snapshot.data['username'],
          'following': safeGet(
            () => convertAlgoliaParam<DocumentReference>(
              snapshot.data['following'],
              ParamType.DocumentReference,
              true,
            ).toList(),
          ),
          'followers': safeGet(
            () => convertAlgoliaParam<DocumentReference>(
              snapshot.data['followers'],
              ParamType.DocumentReference,
              true,
            ).toList(),
          ),
          'current_location': convertAlgoliaParam(
            snapshot.data,
            ParamType.LatLng,
            false,
          ),
          'last_visited': convertAlgoliaParam(
            snapshot.data['last_visited'],
            ParamType.DateTime,
            false,
          ),
          'premium_account': snapshot.data['premium_account'],
          'bio': snapshot.data['bio'],
          'link': snapshot.data['link'],
          'referredBy': convertAlgoliaParam(
            snapshot.data['referredBy'],
            ParamType.DocumentReference,
            false,
          ),
          'invitedUsers': safeGet(
            () => convertAlgoliaParam<DocumentReference>(
              snapshot.data['invitedUsers'],
              ParamType.DocumentReference,
              true,
            ).toList(),
          ),
          'new_notification': snapshot.data['new_notification'],
          'partner': snapshot.data['partner'],
          'new_message': snapshot.data['new_message'],
          'category': snapshot.data['category'],
          'street_address': snapshot.data['street_address'],
          'city_town': snapshot.data['city_town'],
          'postal_code': snapshot.data['postal_code'],
          'country': snapshot.data['country'],
          'business_location_pin': convertAlgoliaParam(
            snapshot.data,
            ParamType.LatLng,
            false,
          ),
          'business_account': snapshot.data['business_account'],
          'display_business_category':
              snapshot.data['display_business_category'],
          'display_business_contact': snapshot.data['display_business_contact'],
          'display_bio': snapshot.data['display_bio'],
          'display_link': snapshot.data['display_link'],
          'referral_code': snapshot.data['referral_code'],
          'partner_ID': convertAlgoliaParam(
            snapshot.data['partner_ID'],
            ParamType.DocumentReference,
            false,
          ),
          'suspended': snapshot.data['suspended'],
          'subscription_id': convertAlgoliaParam(
            snapshot.data['subscription_id'],
            ParamType.DocumentReference,
            false,
          ),
          'blocked_users': safeGet(
            () => convertAlgoliaParam<DocumentReference>(
              snapshot.data['blocked_users'],
              ParamType.DocumentReference,
              true,
            ).toList(),
          ),
          'profile_blur_hash': snapshot.data['profile_blur_hash'],
          'points': convertAlgoliaParam(
            snapshot.data['points'],
            ParamType.int,
            false,
          ),
          'vendorDiscount': convertAlgoliaParam(
            snapshot.data['vendorDiscount'],
            ParamType.double,
            false,
          ),
          'x_points': convertAlgoliaParam(
            snapshot.data['x_points'],
            ParamType.int,
            false,
          ),
          'due_fees': convertAlgoliaParam(
            snapshot.data['due_fees'],
            ParamType.double,
            false,
          ),
          'total_earned': convertAlgoliaParam(
            snapshot.data['total_earned'],
            ParamType.double,
            false,
          ),
          'allow_scanning': snapshot.data['allow_scanning'],
        },
        UsersRecord.collection.doc(snapshot.objectID),
      );

  static Future<List<UsersRecord>> search({
    String? term,
    FutureOr<LatLng>? location,
    int? maxResults,
    double? searchRadiusMeters,
    bool useCache = false,
  }) =>
      FFAlgoliaManager.instance
          .algoliaQuery(
            index: 'users',
            term: term,
            maxResults: maxResults,
            location: location,
            searchRadiusMeters: searchRadiusMeters,
            useCache: useCache,
          )
          .then((r) => r.map(fromAlgolia).toList());

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  DateTime? dateOfBirth,
  String? username,
  LatLng? currentLocation,
  DateTime? lastVisited,
  bool? premiumAccount,
  String? bio,
  String? link,
  DocumentReference? referredBy,
  bool? newNotification,
  bool? partner,
  bool? newMessage,
  String? category,
  String? streetAddress,
  String? cityTown,
  String? postalCode,
  String? country,
  LatLng? businessLocationPin,
  bool? businessAccount,
  bool? displayBusinessCategory,
  bool? displayBusinessContact,
  bool? displayBio,
  bool? displayLink,
  String? referralCode,
  DocumentReference? partnerID,
  bool? suspended,
  DocumentReference? subscriptionId,
  String? profileBlurHash,
  int? points,
  double? vendorDiscount,
  int? xPoints,
  double? dueFees,
  double? totalEarned,
  bool? allowScanning,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'date_of_birth': dateOfBirth,
      'username': username,
      'current_location': currentLocation,
      'last_visited': lastVisited,
      'premium_account': premiumAccount,
      'bio': bio,
      'link': link,
      'referredBy': referredBy,
      'new_notification': newNotification,
      'partner': partner,
      'new_message': newMessage,
      'category': category,
      'street_address': streetAddress,
      'city_town': cityTown,
      'postal_code': postalCode,
      'country': country,
      'business_location_pin': businessLocationPin,
      'business_account': businessAccount,
      'display_business_category': displayBusinessCategory,
      'display_business_contact': displayBusinessContact,
      'display_bio': displayBio,
      'display_link': displayLink,
      'referral_code': referralCode,
      'partner_ID': partnerID,
      'suspended': suspended,
      'subscription_id': subscriptionId,
      'profile_blur_hash': profileBlurHash,
      'points': points,
      'vendorDiscount': vendorDiscount,
      'x_points': xPoints,
      'due_fees': dueFees,
      'total_earned': totalEarned,
      'allow_scanning': allowScanning,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.dateOfBirth == e2?.dateOfBirth &&
        e1?.username == e2?.username &&
        listEquality.equals(e1?.following, e2?.following) &&
        listEquality.equals(e1?.followers, e2?.followers) &&
        e1?.currentLocation == e2?.currentLocation &&
        e1?.lastVisited == e2?.lastVisited &&
        e1?.premiumAccount == e2?.premiumAccount &&
        e1?.bio == e2?.bio &&
        e1?.link == e2?.link &&
        e1?.referredBy == e2?.referredBy &&
        listEquality.equals(e1?.invitedUsers, e2?.invitedUsers) &&
        e1?.newNotification == e2?.newNotification &&
        e1?.partner == e2?.partner &&
        e1?.newMessage == e2?.newMessage &&
        e1?.category == e2?.category &&
        e1?.streetAddress == e2?.streetAddress &&
        e1?.cityTown == e2?.cityTown &&
        e1?.postalCode == e2?.postalCode &&
        e1?.country == e2?.country &&
        e1?.businessLocationPin == e2?.businessLocationPin &&
        e1?.businessAccount == e2?.businessAccount &&
        e1?.displayBusinessCategory == e2?.displayBusinessCategory &&
        e1?.displayBusinessContact == e2?.displayBusinessContact &&
        e1?.displayBio == e2?.displayBio &&
        e1?.displayLink == e2?.displayLink &&
        e1?.referralCode == e2?.referralCode &&
        e1?.partnerID == e2?.partnerID &&
        e1?.suspended == e2?.suspended &&
        e1?.subscriptionId == e2?.subscriptionId &&
        listEquality.equals(e1?.blockedUsers, e2?.blockedUsers) &&
        e1?.profileBlurHash == e2?.profileBlurHash &&
        e1?.points == e2?.points &&
        e1?.vendorDiscount == e2?.vendorDiscount &&
        e1?.xPoints == e2?.xPoints &&
        e1?.dueFees == e2?.dueFees &&
        e1?.totalEarned == e2?.totalEarned &&
        e1?.allowScanning == e2?.allowScanning;
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.dateOfBirth,
        e?.username,
        e?.following,
        e?.followers,
        e?.currentLocation,
        e?.lastVisited,
        e?.premiumAccount,
        e?.bio,
        e?.link,
        e?.referredBy,
        e?.invitedUsers,
        e?.newNotification,
        e?.partner,
        e?.newMessage,
        e?.category,
        e?.streetAddress,
        e?.cityTown,
        e?.postalCode,
        e?.country,
        e?.businessLocationPin,
        e?.businessAccount,
        e?.displayBusinessCategory,
        e?.displayBusinessContact,
        e?.displayBio,
        e?.displayLink,
        e?.referralCode,
        e?.partnerID,
        e?.suspended,
        e?.subscriptionId,
        e?.blockedUsers,
        e?.profileBlurHash,
        e?.points,
        e?.vendorDiscount,
        e?.xPoints,
        e?.dueFees,
        e?.totalEarned,
        e?.allowScanning
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
