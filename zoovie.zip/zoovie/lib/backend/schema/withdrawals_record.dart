import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class WithdrawalsRecord extends FirestoreRecord {
  WithdrawalsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "userID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  // "location" field.
  LatLng? _location;
  LatLng? get location => _location;
  bool hasLocation() => _location != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "phone" field.
  String? _phone;
  String get phone => _phone ?? '';
  bool hasPhone() => _phone != null;

  // "transactionID" field.
  DocumentReference? _transactionID;
  DocumentReference? get transactionID => _transactionID;
  bool hasTransactionID() => _transactionID != null;

  // "cashAmount" field.
  double? _cashAmount;
  double get cashAmount => _cashAmount ?? 0.0;
  bool hasCashAmount() => _cashAmount != null;

  // "pointAmount" field.
  int? _pointAmount;
  int get pointAmount => _pointAmount ?? 0;
  bool hasPointAmount() => _pointAmount != null;

  void _initializeFields() {
    _userID = snapshotData['userID'] as DocumentReference?;
    _name = snapshotData['name'] as String?;
    _date = snapshotData['date'] as DateTime?;
    _location = snapshotData['location'] as LatLng?;
    _email = snapshotData['email'] as String?;
    _phone = snapshotData['phone'] as String?;
    _transactionID = snapshotData['transactionID'] as DocumentReference?;
    _cashAmount = castToType<double>(snapshotData['cashAmount']);
    _pointAmount = castToType<int>(snapshotData['pointAmount']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('withdrawals');

  static Stream<WithdrawalsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => WithdrawalsRecord.fromSnapshot(s));

  static Future<WithdrawalsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => WithdrawalsRecord.fromSnapshot(s));

  static WithdrawalsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      WithdrawalsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static WithdrawalsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      WithdrawalsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'WithdrawalsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is WithdrawalsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createWithdrawalsRecordData({
  DocumentReference? userID,
  String? name,
  DateTime? date,
  LatLng? location,
  String? email,
  String? phone,
  DocumentReference? transactionID,
  double? cashAmount,
  int? pointAmount,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userID': userID,
      'name': name,
      'date': date,
      'location': location,
      'email': email,
      'phone': phone,
      'transactionID': transactionID,
      'cashAmount': cashAmount,
      'pointAmount': pointAmount,
    }.withoutNulls,
  );

  return firestoreData;
}

class WithdrawalsRecordDocumentEquality implements Equality<WithdrawalsRecord> {
  const WithdrawalsRecordDocumentEquality();

  @override
  bool equals(WithdrawalsRecord? e1, WithdrawalsRecord? e2) {
    return e1?.userID == e2?.userID &&
        e1?.name == e2?.name &&
        e1?.date == e2?.date &&
        e1?.location == e2?.location &&
        e1?.email == e2?.email &&
        e1?.phone == e2?.phone &&
        e1?.transactionID == e2?.transactionID &&
        e1?.cashAmount == e2?.cashAmount &&
        e1?.pointAmount == e2?.pointAmount;
  }

  @override
  int hash(WithdrawalsRecord? e) => const ListEquality().hash([
        e?.userID,
        e?.name,
        e?.date,
        e?.location,
        e?.email,
        e?.phone,
        e?.transactionID,
        e?.cashAmount,
        e?.pointAmount
      ]);

  @override
  bool isValidKey(Object? o) => o is WithdrawalsRecord;
}
