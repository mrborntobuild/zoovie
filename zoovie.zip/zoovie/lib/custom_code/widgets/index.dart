export 'custom_video_player.dart' show CustomVideoPlayer;
