import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/auth/firebase_auth/auth_util.dart';

String usernameStandardiser(String username) {
  // return username lowercase without spaces and without special characters
  return username.toLowerCase().replaceAll(RegExp(r'[^a-zA-Z0-9]'), '');
}

String formatAmount(double transactionAmount) {
  // return a double as an input and returns it as a string with 2 decimal places
  return transactionAmount.toStringAsFixed(2).replaceAllMapped(
      new RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},');
}

List<dynamic> refreshChatHistory(
  List<dynamic> chatHistory,
  dynamic chatResponse,
) {
  // When ChatGPT responds we need to take the new response and add it
  // to our chatHistory list. We then pass back the chatHistory list
  // to the calling function which will typically update the AppState
  // with the new list.
  chatHistory.add(chatResponse);
  return chatHistory;
}

List<dynamic> prepareChatHistory(
  List<dynamic> chatHistory,
  String newChat,
) {
  // This function will create a ChatGPT shaped conversation and add it to our
  // chatHistory list. This function is typically called before we make a call
  // in to the ChatGPT API.

  // Add our shaped conversation to our list
  chatHistory.add({"role": "user", "content": newChat.trim()});
  // Return our chatHistory list back which is then typically written back
  // to our App State variable
  return chatHistory;
}

dynamic prepareSaveChat(
  String title,
  String description,
  List<dynamic> chat,
) {
  dynamic savedChat = {
    "title": title,
    "description": description,
    "history": chat
  };
  return savedChat;
}

int calculateDays(
  DateTime lastChangeDate,
  DateTime currentDate,
) {
  // return number of days as integer from 2 dates
  return currentDate.difference(lastChangeDate).inDays;
}

int characterCount(String input) {
  // coutn character number include spaces and special characters return ineger
  int count = 0;
  for (int i = 0; i < input.length; i++) {
    count++;
  }
  return count;
}

String returnCapitalCaracters(String string) {
  // return full string in capital letters
  return string.toUpperCase();
}

String updateAppState(
  String currentNumber,
  String inputNumber,
) {
  // updateAppState currentNumber by adding new inputNumber
  if (inputNumber == '.') {
    if (currentNumber.toString().contains('.')) {
      return currentNumber.toString();
    } else {
      return currentNumber.toString() + inputNumber;
    }
  } else {
    if (currentNumber == 0.0) {
      return inputNumber;
    } else {
      return currentNumber.toString() + inputNumber;
    }
  }
}

double convertStringToDouble(String currentNumber) {
  // Convert scring to double
  return double.parse(currentNumber);
}

String formatDiscount(double discount) {
  // return a double as a string with 1 decimal places
  return discount.toStringAsFixed(1);
}

String updateDocumentId(
  DocumentReference userID,
  DocumentReference user2ID,
) {
  // generate custom document ID combining userID and user2ID in this format userID_user2ID
  String userIDString = userID.id;
  String user2IDString = user2ID.id;
  return '$userIDString' + '_' + '$user2IDString';
}

int countCharacters(String message) {
  // return number of caracters, special symbols and spaces in total
  int charCount = 0;
  int specialCount = 0;
  int spaceCount = 0;

  for (int i = 0; i < message.length; i++) {
    String char = message[i];
    if (char.trim().isEmpty) {
      spaceCount++;
    } else if (char.contains(new RegExp(r'[!@#$%^&*(),.?":{}|<>]'))) {
      specialCount++;
    } else {
      charCount++;
    }
  }

  return charCount + specialCount + spaceCount;
}

bool checkIfDataProvided(
  String logo,
  String name,
  String bio,
  String category,
) {
  // Return boolean false if any of arguments are empty or not set
  if (logo.isEmpty || name.isEmpty || bio.isEmpty || category.isEmpty) {
    return false;
  }
  return true;
}

String checkCurrentMonth(DateTime currentDate) {
  // Check current date and return name of the month and year
  final DateFormat formatter = DateFormat('MMMM yyyy');
  final String formatted = formatter.format(currentDate);
  return formatted;
}

String nameShortener(String name) {
  // Shortenr name and add 2 numbers. Min 4 Max 6 symbols combine low and upper case
  String shortenedName = '';
  for (int i = 0; i < name.length; i++) {
    if (i == 0) {
      shortenedName += name[i].toLowerCase();
    } else if (name[i] == ' ') {
      continue;
    } else if (name[i - 1] == ' ') {
      shortenedName += name[i].toUpperCase();
    }
  }
  int num1 = math.Random().nextInt(10);
  int num2 = math.Random().nextInt(10);
  return shortenedName + num1.toString() + num2.toString();
}

String formatPhoneNumber(String phoneNumber) {
  // format phone number by removing spacess and if contry code formated 00 change to +
  phoneNumber = phoneNumber.replaceAll(' ', '');
  if (phoneNumber.startsWith('00')) {
    phoneNumber = '+' + phoneNumber.substring(2);
  }
  return phoneNumber;
}

String linkStandariser(String link) {
  // remove https://, http://, www from the link
  link = link.replaceAll('https://', '');
  link = link.replaceAll('http://', '');
  link = link.replaceAll('www.', '');
  return link;
}

int returnHoursFromTwoDates(
  DateTime pastDate,
  DateTime currentDate,
) {
  // Return number of hours from 2 dates
  final difference = currentDate.difference(pastDate);
  final hours = difference.inHours;
  return hours;
}

DateTime? yesterdayDate(DateTime? currentTime) {
  if (currentTime == null) return null;
  final yesterday = currentTime.subtract(Duration(days: 1));
  return DateTime(yesterday.year, yesterday.month, yesterday.day);
}

int withdrawFormat(
  int currentNumber,
  int addNumber,
) {
  // addNumber to currentNumber. If current number is 2 and iadd 4 return 24
  return int.parse('$currentNumber$addNumber');
}

int roun(double transactionAmount) {
  // Roundup transaction amount to closest number when i 1.49 will be 1 when will be 1.50 will be 2
  return (transactionAmount + 0.5).floor();
}

int convertStringToInteger(String currentNumber) {
  // Convert string to integer. Remove decimal and round it to closest integer.
  double parsedNumber = double.parse(currentNumber);
  int roundedNumber = parsedNumber.round();
  return roundedNumber;
}

double returnAverageRating(List<int> rating) {
  // Get average rating to one decimal point from a list of reviews
  if (rating.isEmpty) return 0.0;
  double sum = 0.0;
  for (final r in rating) {
    sum += r;
  }
  return (sum / rating.length * 10).round() / 10;
}

String shortenComment(String comment) {
  // Shorten string to max 30 characters
  if (comment.length > 30) {
    return comment.substring(0, 30) + '...';
  } else {
    return comment;
  }
}

String getGreeting(DateTime time) {
  // Get gree ting Good Morning when time is before 12PM, Good Afternoon after 12PM
  if (time.hour < 12) {
    return 'Morning';
  } else if (time.hour >= 12 && time.hour < 17) {
    return 'Afternoon';
  } else {
    return 'Evening';
  }
}

String formatDate(
  DateTime eventDateStart,
  DateTime eventDateEnd,
  DateTime currentTime,
) {
  // Check if the event is happening now
  if (currentTime.isAfter(eventDateStart) &&
      currentTime.isBefore(eventDateEnd)) {
    return 'Now';
  }

  // Check if the event is over
  if (currentTime.isAfter(eventDateEnd)) {
    return 'Ended';
  }

  // Check if the event is within the next 24 hours
  if (eventDateStart.isAfter(currentTime) &&
      eventDateStart.difference(currentTime).inHours <= 24) {
    final hoursDifference = eventDateStart.difference(currentTime).inHours;
    if (hoursDifference > 1) {
      return 'in $hoursDifference' 'h';
    } else if (hoursDifference == 1) {
      return 'in 1' 'h';
    } else {
      final minutesDifference =
          eventDateStart.difference(currentTime).inMinutes;
      return 'in $minutesDifference' 'm';
    }
  }

  // Return 'In one day' if the event is one day away
  if (eventDateStart.difference(currentTime).inDays == 1) {
    return 'in 1' 'd';
  }

  // Return Tomorrow, in 2 days, in 3 days, and so on for the first 7 days
  final diff = eventDateStart.difference(currentTime);
  if (diff.inDays == 1) {
    return 'Tomorrow';
  } else if (diff.inDays == 2) {
    return 'in 2' 'd';
  } else if (diff.inDays > 2 && diff.inDays <= 7) {
    return 'in ${diff.inDays}' 'd';
  }

  // Return an empty string for dates more than 7 days away
  return '';
}

int returnAttendees(List<DocumentReference> users) {
  // return number of users from the list minus 5
  return users.length - 6;
}

List<dynamic> filterDeletedStatus(List<dynamic> items) {
  return items.where((item) => item['status'] == 'active').toList();
}
