import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';

import '/auth/base_auth_user_provider.dart';

import '/index.dart';
import '/flutter_flow/flutter_flow_util.dart';

export 'package:go_router/go_router.dart';
export 'serialization_util.dart';

const kTransitionInfoKey = '__transition_info__';

class AppStateNotifier extends ChangeNotifier {
  AppStateNotifier._();

  static AppStateNotifier? _instance;
  static AppStateNotifier get instance => _instance ??= AppStateNotifier._();

  BaseAuthUser? initialUser;
  BaseAuthUser? user;
  bool showSplashImage = true;
  String? _redirectLocation;

  /// Determines whether the app will refresh and build again when a sign
  /// in or sign out happens. This is useful when the app is launched or
  /// on an unexpected logout. However, this must be turned off when we
  /// intend to sign in/out and then navigate or perform any actions after.
  /// Otherwise, this will trigger a refresh and interrupt the action(s).
  bool notifyOnAuthChange = true;

  bool get loading => user == null || showSplashImage;
  bool get loggedIn => user?.loggedIn ?? false;
  bool get initiallyLoggedIn => initialUser?.loggedIn ?? false;
  bool get shouldRedirect => loggedIn && _redirectLocation != null;

  String getRedirectLocation() => _redirectLocation!;
  bool hasRedirect() => _redirectLocation != null;
  void setRedirectLocationIfUnset(String loc) => _redirectLocation ??= loc;
  void clearRedirectLocation() => _redirectLocation = null;

  /// Mark as not needing to notify on a sign in / out when we intend
  /// to perform subsequent actions (such as navigation) afterwards.
  void updateNotifyOnAuthChange(bool notify) => notifyOnAuthChange = notify;

  void update(BaseAuthUser newUser) {
    final shouldUpdate =
        user?.uid == null || newUser.uid == null || user?.uid != newUser.uid;
    initialUser ??= newUser;
    user = newUser;
    // Refresh the app on auth change unless explicitly marked otherwise.
    // No need to update unless the user has changed.
    if (notifyOnAuthChange && shouldUpdate) {
      notifyListeners();
    }
    // Once again mark the notifier as needing to update on auth change
    // (in order to catch sign in / out events).
    updateNotifyOnAuthChange(true);
  }

  void stopShowingSplashImage() {
    showSplashImage = false;
    notifyListeners();
  }
}

GoRouter createRouter(AppStateNotifier appStateNotifier) => GoRouter(
      initialLocation: '/',
      debugLogDiagnostics: true,
      refreshListenable: appStateNotifier,
      errorBuilder: (context, state) =>
          appStateNotifier.loggedIn ? const HomeWidget() : const AccessWidget(),
      routes: [
        FFRoute(
          name: '_initialize',
          path: '/',
          builder: (context, _) =>
              appStateNotifier.loggedIn ? const HomeWidget() : const AccessWidget(),
          routes: [
            FFRoute(
              name: 'resetPasswordConfirmation',
              path: 'resetPasswordConfirmation',
              builder: (context, params) => const ResetPasswordConfirmationWidget(),
            ),
            FFRoute(
              name: 'Access',
              path: 'access',
              builder: (context, params) => const AccessWidget(),
            ),
            FFRoute(
              name: 'legalPolicies',
              path: 'legalPolicies',
              builder: (context, params) => const LegalPoliciesWidget(),
            ),
            FFRoute(
              name: 'newOnboarding1_name',
              path: 'newOnboarding1Name',
              builder: (context, params) => const NewOnboarding1NameWidget(),
            ),
            FFRoute(
              name: 'password',
              path: 'password',
              builder: (context, params) => const PasswordWidget(),
            ),
            FFRoute(
              name: 'createRew',
              path: 'createRew',
              builder: (context, params) => CreateRewWidget(
                userReferralCode: params.getParam(
                  'userReferralCode',
                  ParamType.String,
                ),
              ),
            ),
            FFRoute(
              name: 'postPhoto',
              path: 'postPhoto',
              requireAuth: true,
              builder: (context, params) => const PostPhotoWidget(),
            ),
            FFRoute(
              name: 'postPhotoCaption',
              path: 'postPhotoCaption',
              requireAuth: true,
              builder: (context, params) => const PostPhotoCaptionWidget(),
            ),
            FFRoute(
              name: 'AccountSet',
              path: 'AccountSet',
              builder: (context, params) => const AccountSetWidget(),
            ),
            FFRoute(
              name: 'comments',
              path: 'comments',
              requireAuth: true,
              builder: (context, params) => CommentsWidget(
                postReference: params.getParam(
                  'postReference',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['posts'],
                ),
              ),
            ),
            FFRoute(
              name: 'invite',
              path: 'invite',
              requireAuth: true,
              builder: (context, params) => const InviteWidget(),
            ),
            FFRoute(
              name: 'publicProfile',
              path: 'publicProfile',
              requireAuth: true,
              builder: (context, params) => PublicProfileWidget(
                userReference: params.getParam(
                  'userReference',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['users'],
                ),
              ),
            ),
            FFRoute(
              name: 'shareProfile',
              path: 'shareProfile',
              requireAuth: true,
              builder: (context, params) => ShareProfileWidget(
                link: params.getParam(
                  'link',
                  ParamType.String,
                ),
              ),
            ),
            FFRoute(
              name: 'redeemPoints',
              path: 'redeemPoints',
              requireAuth: true,
              builder: (context, params) => const RedeemPointsWidget(),
            ),
            FFRoute(
              name: 'search',
              path: 'search',
              requireAuth: true,
              builder: (context, params) => const SearchWidget(),
            ),
            FFRoute(
              name: 'usersToChat',
              path: 'usersToChat',
              requireAuth: true,
              builder: (context, params) => const UsersToChatWidget(),
            ),
            FFRoute(
              name: 'chats',
              path: 'chats',
              requireAuth: true,
              builder: (context, params) => const ChatsWidget(),
            ),
            FFRoute(
              name: 'image_message',
              path: 'imageMessage',
              requireAuth: true,
              builder: (context, params) => ImageMessageWidget(
                chatReference: params.getParam(
                  'chatReference',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['chats'],
                ),
                userA: params.getParam(
                  'userA',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['users'],
                ),
                userB: params.getParam(
                  'userB',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['users'],
                ),
              ),
            ),
            FFRoute(
              name: 'following_followers',
              path: 'followingFollowers',
              requireAuth: true,
              builder: (context, params) => const FollowingFollowersWidget(),
            ),
            FFRoute(
              name: 'messages',
              path: 'messages',
              requireAuth: true,
              builder: (context, params) => MessagesWidget(
                chatReference: params.getParam(
                  'chatReference',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['chats'],
                ),
              ),
            ),
            FFRoute(
              name: 'following_followers_2',
              path: 'followingFollowers2',
              requireAuth: true,
              builder: (context, params) => FollowingFollowers2Widget(
                userReference: params.getParam(
                  'userReference',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['users'],
                ),
              ),
            ),
            FFRoute(
              name: 'professionalAccount',
              path: 'professionalAccount',
              requireAuth: true,
              builder: (context, params) => const ProfessionalAccountWidget(),
            ),
            FFRoute(
              name: 'addPhotoLocation',
              path: 'addPhotoLocation',
              requireAuth: true,
              builder: (context, params) => const AddPhotoLocationWidget(),
            ),
            FFRoute(
              name: 'addBusinessName',
              path: 'addBusinessName',
              requireAuth: true,
              builder: (context, params) => const AddBusinessNameWidget(),
            ),
            FFRoute(
              name: 'addBusinessWebsite',
              path: 'addBusinessWebsite',
              requireAuth: true,
              builder: (context, params) => const AddBusinessWebsiteWidget(),
            ),
            FFRoute(
              name: 'addBusinessBio',
              path: 'addBusinessBio',
              requireAuth: true,
              builder: (context, params) => const AddBusinessBioWidget(),
            ),
            FFRoute(
              name: 'editBusinessProfile',
              path: 'editBusinessProfile',
              requireAuth: true,
              builder: (context, params) => const EditBusinessProfileWidget(),
            ),
            FFRoute(
              name: 'addBusinessUsername',
              path: 'addBusinessUsername',
              requireAuth: true,
              builder: (context, params) => const AddBusinessUsernameWidget(),
            ),
            FFRoute(
              name: 'addBusinessPhone',
              path: 'addBusinessPhone',
              requireAuth: true,
              builder: (context, params) => const AddBusinessPhoneWidget(),
            ),
            FFRoute(
              name: 'addBusinessCategory',
              path: 'addBusinessCategory',
              requireAuth: true,
              builder: (context, params) => const AddBusinessCategoryWidget(),
            ),
            FFRoute(
              name: 'addBusinessEmail',
              path: 'addBusinessEmail',
              requireAuth: true,
              builder: (context, params) => const AddBusinessEmailWidget(),
            ),
            FFRoute(
              name: 'addBusinessAddress',
              path: 'addBusinessAddress',
              requireAuth: true,
              builder: (context, params) => const AddBusinessAddressWidget(),
            ),
            FFRoute(
              name: 'profileDisplay',
              path: 'profileDisplay',
              builder: (context, params) => const ProfileDisplayWidget(),
            ),
            FFRoute(
              name: 'categorySearch',
              path: 'categorySearch',
              requireAuth: true,
              builder: (context, params) => const CategorySearchWidget(),
            ),
            FFRoute(
              name: 'addBusinessPassword',
              path: 'addBusinessPassword',
              requireAuth: true,
              builder: (context, params) => const AddBusinessPasswordWidget(),
            ),
            FFRoute(
              name: 'businessAccountCreated',
              path: 'businessaccountcreated',
              requireAuth: true,
              builder: (context, params) => const BusinessAccountCreatedWidget(),
            ),
            FFRoute(
              name: 'taggUsers',
              path: 'taggUsers',
              requireAuth: true,
              builder: (context, params) => const TaggUsersWidget(),
            ),
            FFRoute(
              name: 'postReported',
              path: 'postReported',
              builder: (context, params) => PostReportedWidget(
                postReference: params.getParam(
                  'postReference',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['posts'],
                ),
              ),
            ),
            FFRoute(
              name: 'editName',
              path: 'editName',
              requireAuth: true,
              builder: (context, params) => const EditNameWidget(),
            ),
            FFRoute(
              name: 'profile',
              path: 'profile',
              requireAuth: true,
              builder: (context, params) => const ProfileWidget(),
            ),
            FFRoute(
              name: 'editProfile',
              path: 'editProfile',
              requireAuth: true,
              builder: (context, params) => const EditProfileWidget(),
            ),
            FFRoute(
              name: 'editUsername',
              path: 'editUsername',
              requireAuth: true,
              builder: (context, params) => const EditUsernameWidget(),
            ),
            FFRoute(
              name: 'editBio',
              path: 'editBio',
              requireAuth: true,
              builder: (context, params) => const EditBioWidget(),
            ),
            FFRoute(
              name: 'editLink',
              path: 'editLink',
              requireAuth: true,
              builder: (context, params) => const EditLinkWidget(),
            ),
            FFRoute(
              name: 'aboutThisAccount',
              path: 'aboutThisAccount',
              requireAuth: true,
              builder: (context, params) => AboutThisAccountWidget(
                userReference: params.getParam(
                  'userReference',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['users'],
                ),
              ),
            ),
            FFRoute(
              name: 'newOnboarding2_dateofbirth',
              path: 'newOnboarding2Dateofbirth',
              builder: (context, params) => const NewOnboarding2DateofbirthWidget(),
            ),
            FFRoute(
              name: 'username',
              path: 'username',
              builder: (context, params) => const UsernameWidget(),
            ),
            FFRoute(
              name: 'email',
              path: 'email',
              builder: (context, params) => const EmailWidget(),
            ),
            FFRoute(
              name: 'userLogin',
              path: 'userLogin',
              builder: (context, params) => const UserLoginWidget(),
            ),
            FFRoute(
              name: 'newOnboarding3_signup',
              path: 'newOnboarding3Signup',
              builder: (context, params) => const NewOnboarding3SignupWidget(),
            ),
            FFRoute(
              name: 'newOnboarding4_verificationCode',
              path: 'newOnboarding4VerificationCode',
              builder: (context, params) =>
                  const NewOnboarding4VerificationCodeWidget(),
            ),
            FFRoute(
              name: 'addProduct',
              path: 'addProduct',
              requireAuth: true,
              builder: (context, params) => AddProductWidget(
                partnerID: params.getParam(
                  'partnerID',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['partners'],
                ),
              ),
            ),
            FFRoute(
              name: 'accountRrestricted',
              path: 'accountRrestricted',
              requireAuth: true,
              builder: (context, params) => const AccountRrestrictedWidget(),
            ),
            FFRoute(
              name: 'ChatGPT',
              path: 'chatGPT',
              requireAuth: true,
              builder: (context, params) => const ChatGPTWidget(),
            ),
            FFRoute(
              name: 'subscription_ConfirmationBusiness',
              path: 'navigationv',
              builder: (context, params) =>
                  const SubscriptionConfirmationBusinessWidget(),
            ),
            FFRoute(
              name: 'subscription_Confirmation',
              path: 'subscriptionConfirmation',
              builder: (context, params) => const SubscriptionConfirmationWidget(),
            ),
            FFRoute(
              name: 'forgotPassword',
              path: 'forgotPassword',
              builder: (context, params) => ForgotPasswordWidget(
                userReference: params.getParam(
                  'userReference',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['users'],
                ),
              ),
            ),
            FFRoute(
              name: 'update',
              path: 'update',
              requireAuth: true,
              builder: (context, params) => const UpdateWidget(),
            ),
            FFRoute(
              name: 'editPost',
              path: 'editPost',
              requireAuth: true,
              builder: (context, params) => EditPostWidget(
                postID: params.getParam(
                  'postID',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['posts'],
                ),
              ),
            ),
            FFRoute(
              name: 'createMoment',
              path: 'createMoment',
              requireAuth: true,
              builder: (context, params) => const CreateMomentWidget(),
            ),
            FFRoute(
              name: 'momentPage',
              path: 'momentPage',
              requireAuth: true,
              builder: (context, params) => MomentPageWidget(
                memoryReference: params.getParam(
                  'memoryReference',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['memories'],
                ),
              ),
            ),
            FFRoute(
              name: 'withdrawalConfirmation',
              path: 'withdrawalConfirmation',
              builder: (context, params) => const WithdrawalConfirmationWidget(),
            ),
            FFRoute(
              name: 'rewardConfirmation',
              path: 'rewardConfirmation',
              requireAuth: true,
              builder: (context, params) => RewardConfirmationWidget(
                pointsID: params.getParam(
                  'pointsID',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['points'],
                ),
              ),
            ),
            FFRoute(
              name: 'points',
              path: 'points',
              requireAuth: true,
              builder: (context, params) => const PointsWidget(),
            ),
            FFRoute(
              name: 'shop',
              path: 'shop',
              requireAuth: true,
              builder: (context, params) => const ShopWidget(),
            ),
            FFRoute(
              name: 'notifications',
              path: 'notifications',
              requireAuth: true,
              builder: (context, params) => const NotificationsWidget(),
            ),
            FFRoute(
              name: 'shopDetails',
              path: 'shopDetails',
              requireAuth: true,
              builder: (context, params) => ShopDetailsWidget(
                event: params.getParam(
                  'event',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['events'],
                ),
              ),
            ),
            FFRoute(
              name: 'ScanQRCode',
              path: 'scanQRCode',
              requireAuth: true,
              builder: (context, params) => const ScanQRCodeWidget(),
            ),
            FFRoute(
              name: 'pointsBusiness',
              path: 'pointsBusiness',
              requireAuth: true,
              builder: (context, params) => const PointsBusinessWidget(),
            ),
            FFRoute(
              name: 'welcome',
              path: 'welcome',
              requireAuth: true,
              builder: (context, params) => const WelcomeWidget(),
            ),
            FFRoute(
              name: 'home',
              path: 'home',
              requireAuth: true,
              builder: (context, params) => const HomeWidget(),
            ),
            FFRoute(
              name: 'postVideo',
              path: 'postVideo',
              requireAuth: true,
              builder: (context, params) => const PostVideoWidget(),
            ),
            FFRoute(
              name: 'postVideoCaption',
              path: 'postVideoCaption',
              requireAuth: true,
              builder: (context, params) => const PostVideoCaptionWidget(),
            ),
            FFRoute(
              name: 'userPosts',
              path: 'userPosts',
              requireAuth: true,
              builder: (context, params) => UserPostsWidget(
                index: params.getParam(
                  'index',
                  ParamType.int,
                ),
                username: params.getParam(
                  'username',
                  ParamType.String,
                ),
              ),
            ),
            FFRoute(
              name: 'notificationsPost',
              path: 'notificationsPost',
              requireAuth: true,
              builder: (context, params) => NotificationsPostWidget(
                postReference: params.getParam(
                  'postReference',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['posts'],
                ),
              ),
            ),
            FFRoute(
              name: 'otherUserPosts',
              path: 'otherUserPosts',
              requireAuth: true,
              builder: (context, params) => OtherUserPostsWidget(
                index: params.getParam(
                  'index',
                  ParamType.int,
                ),
                username: params.getParam(
                  'username',
                  ParamType.String,
                ),
                userReference: params.getParam(
                  'userReference',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['users'],
                ),
              ),
            ),
            FFRoute(
              name: 'userSinglePosts',
              path: 'userSinglePosts',
              requireAuth: true,
              builder: (context, params) => UserSinglePostsWidget(
                postReference: params.getParam(
                  'postReference',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['posts'],
                ),
              ),
            ),
            FFRoute(
              name: 'otherUserSinglePost',
              path: 'otherUserSinglePost',
              requireAuth: true,
              builder: (context, params) => OtherUserSinglePostWidget(
                postReference: params.getParam(
                  'postReference',
                  ParamType.DocumentReference,
                  isList: false,
                  collectionNamePath: ['posts'],
                ),
              ),
            ),
            FFRoute(
              name: 'bookings',
              path: 'bookings',
              requireAuth: true,
              builder: (context, params) => const BookingsWidget(),
            ),
            FFRoute(
              name: 'newOnboarding_login1',
              path: 'newOnboardingLogin1',
              builder: (context, params) => const NewOnboardingLogin1Widget(),
            ),
            FFRoute(
              name: 'newOnboarding_login2',
              path: 'newOnboardingLogin2',
              builder: (context, params) => const NewOnboardingLogin2Widget(),
            ),
            FFRoute(
              name: 'newOnboarding1_emailTest',
              path: 'newOnboarding1EmailTest',
              builder: (context, params) => const NewOnboarding1EmailTestWidget(),
            )
          ].map((r) => r.toRoute(appStateNotifier)).toList(),
        ),
      ].map((r) => r.toRoute(appStateNotifier)).toList(),
      observers: [routeObserver],
    );

extension NavParamExtensions on Map<String, String?> {
  Map<String, String> get withoutNulls => Map.fromEntries(
        entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
}

extension NavigationExtensions on BuildContext {
  void goNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : goNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void pushNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : pushNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void safePop() {
    // If there is only one route on the stack, navigate to the initial
    // page instead of popping.
    if (canPop()) {
      pop();
    } else {
      go('/');
    }
  }
}

extension GoRouterExtensions on GoRouter {
  AppStateNotifier get appState => AppStateNotifier.instance;
  void prepareAuthEvent([bool ignoreRedirect = false]) =>
      appState.hasRedirect() && !ignoreRedirect
          ? null
          : appState.updateNotifyOnAuthChange(false);
  bool shouldRedirect(bool ignoreRedirect) =>
      !ignoreRedirect && appState.hasRedirect();
  void clearRedirectLocation() => appState.clearRedirectLocation();
  void setRedirectLocationIfUnset(String location) =>
      appState.updateNotifyOnAuthChange(false);
}

extension _GoRouterStateExtensions on GoRouterState {
  Map<String, dynamic> get extraMap =>
      extra != null ? extra as Map<String, dynamic> : {};
  Map<String, dynamic> get allParams => <String, dynamic>{}
    ..addAll(pathParameters)
    ..addAll(uri.queryParameters)
    ..addAll(extraMap);
  TransitionInfo get transitionInfo => extraMap.containsKey(kTransitionInfoKey)
      ? extraMap[kTransitionInfoKey] as TransitionInfo
      : TransitionInfo.appDefault();
}

class FFParameters {
  FFParameters(this.state, [this.asyncParams = const {}]);

  final GoRouterState state;
  final Map<String, Future<dynamic> Function(String)> asyncParams;

  Map<String, dynamic> futureParamValues = {};

  // Parameters are empty if the params map is empty or if the only parameter
  // present is the special extra parameter reserved for the transition info.
  bool get isEmpty =>
      state.allParams.isEmpty ||
      (state.allParams.length == 1 &&
          state.extraMap.containsKey(kTransitionInfoKey));
  bool isAsyncParam(MapEntry<String, dynamic> param) =>
      asyncParams.containsKey(param.key) && param.value is String;
  bool get hasFutures => state.allParams.entries.any(isAsyncParam);
  Future<bool> completeFutures() => Future.wait(
        state.allParams.entries.where(isAsyncParam).map(
          (param) async {
            final doc = await asyncParams[param.key]!(param.value)
                .onError((_, __) => null);
            if (doc != null) {
              futureParamValues[param.key] = doc;
              return true;
            }
            return false;
          },
        ),
      ).onError((_, __) => [false]).then((v) => v.every((e) => e));

  dynamic getParam<T>(
    String paramName,
    ParamType type, {
    bool isList = false,
    List<String>? collectionNamePath,
    StructBuilder<T>? structBuilder,
  }) {
    if (futureParamValues.containsKey(paramName)) {
      return futureParamValues[paramName];
    }
    if (!state.allParams.containsKey(paramName)) {
      return null;
    }
    final param = state.allParams[paramName];
    // Got parameter from `extras`, so just directly return it.
    if (param is! String) {
      return param;
    }
    // Return serialized value.
    return deserializeParam<T>(
      param,
      type,
      isList,
      collectionNamePath: collectionNamePath,
      structBuilder: structBuilder,
    );
  }
}

class FFRoute {
  const FFRoute({
    required this.name,
    required this.path,
    required this.builder,
    this.requireAuth = false,
    this.asyncParams = const {},
    this.routes = const [],
  });

  final String name;
  final String path;
  final bool requireAuth;
  final Map<String, Future<dynamic> Function(String)> asyncParams;
  final Widget Function(BuildContext, FFParameters) builder;
  final List<GoRoute> routes;

  GoRoute toRoute(AppStateNotifier appStateNotifier) => GoRoute(
        name: name,
        path: path,
        redirect: (context, state) {
          if (appStateNotifier.shouldRedirect) {
            final redirectLocation = appStateNotifier.getRedirectLocation();
            appStateNotifier.clearRedirectLocation();
            return redirectLocation;
          }

          if (requireAuth && !appStateNotifier.loggedIn) {
            appStateNotifier.setRedirectLocationIfUnset(state.uri.toString());
            return '/access';
          }
          return null;
        },
        pageBuilder: (context, state) {
          fixStatusBarOniOS16AndBelow(context);
          final ffParams = FFParameters(state, asyncParams);
          final page = ffParams.hasFutures
              ? FutureBuilder(
                  future: ffParams.completeFutures(),
                  builder: (context, _) => builder(context, ffParams),
                )
              : builder(context, ffParams);
          final child = appStateNotifier.loading
              ? Container(
                  color: Colors.transparent,
                  child: Image.asset(
                    'assets/images/Untitled_document_(10).png',
                    fit: BoxFit.cover,
                  ),
                )
              : page;

          final transitionInfo = state.transitionInfo;
          return transitionInfo.hasTransition
              ? CustomTransitionPage(
                  key: state.pageKey,
                  child: child,
                  transitionDuration: transitionInfo.duration,
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          PageTransition(
                    type: transitionInfo.transitionType,
                    duration: transitionInfo.duration,
                    reverseDuration: transitionInfo.duration,
                    alignment: transitionInfo.alignment,
                    child: child,
                  ).buildTransitions(
                    context,
                    animation,
                    secondaryAnimation,
                    child,
                  ),
                )
              : MaterialPage(key: state.pageKey, child: child);
        },
        routes: routes,
      );
}

class TransitionInfo {
  const TransitionInfo({
    required this.hasTransition,
    this.transitionType = PageTransitionType.fade,
    this.duration = const Duration(milliseconds: 300),
    this.alignment,
  });

  final bool hasTransition;
  final PageTransitionType transitionType;
  final Duration duration;
  final Alignment? alignment;

  static TransitionInfo appDefault() => const TransitionInfo(hasTransition: false);
}

class RootPageContext {
  const RootPageContext(this.isRootPage, [this.errorRoute]);
  final bool isRootPage;
  final String? errorRoute;

  static bool isInactiveRootPage(BuildContext context) {
    final rootPageContext = context.read<RootPageContext?>();
    final isRootPage = rootPageContext?.isRootPage ?? false;
    final location = GoRouterState.of(context).uri.toString();
    return isRootPage &&
        location != '/' &&
        location != rootPageContext?.errorRoute;
  }

  static Widget wrap(Widget child, {String? errorRoute}) => Provider.value(
        value: RootPageContext(true, errorRoute),
        child: child,
      );
}

extension GoRouterLocationExtension on GoRouter {
  String getCurrentLocation() {
    final RouteMatch lastMatch = routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }
}
