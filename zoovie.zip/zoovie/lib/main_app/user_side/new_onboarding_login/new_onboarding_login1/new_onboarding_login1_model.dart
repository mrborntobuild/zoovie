import '/flutter_flow/flutter_flow_util.dart';
import 'new_onboarding_login1_widget.dart' show NewOnboardingLogin1Widget;
import 'package:flutter/material.dart';

class NewOnboardingLogin1Model
    extends FlutterFlowModel<NewOnboardingLogin1Widget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // State field(s) for loginPhoneNumber widget.
  FocusNode? loginPhoneNumberFocusNode;
  TextEditingController? loginPhoneNumberTextController;
  String? Function(BuildContext, String?)?
      loginPhoneNumberTextControllerValidator;
  String? _loginPhoneNumberTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        '4txzdewb' /* Field is required */,
      );
    }

    if (!RegExp(kTextValidatorEmailRegex).hasMatch(val)) {
      return 'Has to be a valid email address.';
    }
    return null;
  }

  @override
  void initState(BuildContext context) {
    loginPhoneNumberTextControllerValidator =
        _loginPhoneNumberTextControllerValidator;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    loginPhoneNumberFocusNode?.dispose();
    loginPhoneNumberTextController?.dispose();
  }
}
