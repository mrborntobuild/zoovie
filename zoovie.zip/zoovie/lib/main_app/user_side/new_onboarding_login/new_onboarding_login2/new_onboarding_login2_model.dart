import '/flutter_flow/flutter_flow_util.dart';
import 'new_onboarding_login2_widget.dart' show NewOnboardingLogin2Widget;
import 'package:flutter/material.dart';

class NewOnboardingLogin2Model
    extends FlutterFlowModel<NewOnboardingLogin2Widget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // State field(s) for registrationPinCode widget.
  TextEditingController? registrationPinCode;
  String? Function(BuildContext, String?)? registrationPinCodeValidator;

  @override
  void initState(BuildContext context) {
    registrationPinCode = TextEditingController();
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    registrationPinCode?.dispose();
  }
}
