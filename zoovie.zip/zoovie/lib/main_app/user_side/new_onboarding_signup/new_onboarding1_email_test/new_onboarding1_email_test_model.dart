import '/flutter_flow/flutter_flow_util.dart';
import 'new_onboarding1_email_test_widget.dart'
    show NewOnboarding1EmailTestWidget;
import 'package:flutter/material.dart';

class NewOnboarding1EmailTestModel
    extends FlutterFlowModel<NewOnboarding1EmailTestWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for registrationName widget.
  FocusNode? registrationNameFocusNode;
  TextEditingController? registrationNameTextController;
  String? Function(BuildContext, String?)?
      registrationNameTextControllerValidator;
  // State field(s) for emaill widget.
  FocusNode? emaillFocusNode;
  TextEditingController? emaillTextController;
  String? Function(BuildContext, String?)? emaillTextControllerValidator;
  // State field(s) for passwordd widget.
  FocusNode? passworddFocusNode;
  TextEditingController? passworddTextController;
  late bool passworddVisibility;
  String? Function(BuildContext, String?)? passworddTextControllerValidator;
  // State field(s) for confirm_password widget.
  FocusNode? confirmPasswordFocusNode;
  TextEditingController? confirmPasswordTextController;
  late bool confirmPasswordVisibility;
  String? Function(BuildContext, String?)?
      confirmPasswordTextControllerValidator;

  @override
  void initState(BuildContext context) {
    passworddVisibility = false;
    confirmPasswordVisibility = false;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    registrationNameFocusNode?.dispose();
    registrationNameTextController?.dispose();

    emaillFocusNode?.dispose();
    emaillTextController?.dispose();

    passworddFocusNode?.dispose();
    passworddTextController?.dispose();

    confirmPasswordFocusNode?.dispose();
    confirmPasswordTextController?.dispose();
  }
}
