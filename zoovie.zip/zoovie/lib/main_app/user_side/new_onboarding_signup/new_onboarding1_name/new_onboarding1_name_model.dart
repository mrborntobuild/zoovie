import '/flutter_flow/flutter_flow_util.dart';
import 'new_onboarding1_name_widget.dart' show NewOnboarding1NameWidget;
import 'package:flutter/material.dart';

class NewOnboarding1NameModel
    extends FlutterFlowModel<NewOnboarding1NameWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // State field(s) for registrationName widget.
  FocusNode? registrationNameFocusNode;
  TextEditingController? registrationNameTextController;
  String? Function(BuildContext, String?)?
      registrationNameTextControllerValidator;
  String? _registrationNameTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'sxu090yg' /* Name required. */,
      );
    }

    return null;
  }

  @override
  void initState(BuildContext context) {
    registrationNameTextControllerValidator =
        _registrationNameTextControllerValidator;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    registrationNameFocusNode?.dispose();
    registrationNameTextController?.dispose();
  }
}
