import '/flutter_flow/flutter_flow_util.dart';
import 'new_onboarding2_dateofbirth_widget.dart'
    show NewOnboarding2DateofbirthWidget;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class NewOnboarding2DateofbirthModel
    extends FlutterFlowModel<NewOnboarding2DateofbirthWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  DateTime? datePicked;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
