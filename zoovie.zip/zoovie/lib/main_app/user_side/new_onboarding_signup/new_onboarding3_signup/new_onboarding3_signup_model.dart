import '/flutter_flow/flutter_flow_util.dart';
import 'new_onboarding3_signup_widget.dart' show NewOnboarding3SignupWidget;
import 'package:flutter/material.dart';

class NewOnboarding3SignupModel
    extends FlutterFlowModel<NewOnboarding3SignupWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // State field(s) for registrationPhone widget.
  FocusNode? registrationPhoneFocusNode;
  TextEditingController? registrationPhoneTextController;
  String? Function(BuildContext, String?)?
      registrationPhoneTextControllerValidator;
  String? _registrationPhoneTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'rakecctq' /* Phone number is required. */,
      );
    }

    return null;
  }

  @override
  void initState(BuildContext context) {
    registrationPhoneTextControllerValidator =
        _registrationPhoneTextControllerValidator;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    registrationPhoneFocusNode?.dispose();
    registrationPhoneTextController?.dispose();
  }
}
