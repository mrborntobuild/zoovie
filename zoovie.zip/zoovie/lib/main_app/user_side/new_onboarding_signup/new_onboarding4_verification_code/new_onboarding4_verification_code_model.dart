import '/flutter_flow/flutter_flow_util.dart';
import 'new_onboarding4_verification_code_widget.dart'
    show NewOnboarding4VerificationCodeWidget;
import 'package:flutter/material.dart';

class NewOnboarding4VerificationCodeModel
    extends FlutterFlowModel<NewOnboarding4VerificationCodeWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for registrationPinCode widget.
  TextEditingController? registrationPinCode;
  String? Function(BuildContext, String?)? registrationPinCodeValidator;

  @override
  void initState(BuildContext context) {
    registrationPinCode = TextEditingController();
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    registrationPinCode?.dispose();
  }
}
