import '/flutter_flow/flutter_flow_util.dart';
import 'update_widget.dart' show UpdateWidget;
import 'package:flutter/material.dart';

class UpdateModel extends FlutterFlowModel<UpdateWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
