import '/flutter_flow/flutter_flow_util.dart';
import 'add_product_widget.dart' show AddProductWidget;
import 'package:flutter/material.dart';

class AddProductModel extends FlutterFlowModel<AddProductWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for BusinessName widget.
  FocusNode? businessNameFocusNode1;
  TextEditingController? businessNameTextController1;
  String? Function(BuildContext, String?)? businessNameTextController1Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController2;
  String? Function(BuildContext, String?)? textController2Validator;
  // State field(s) for BusinessName widget.
  FocusNode? businessNameFocusNode2;
  TextEditingController? businessNameTextController2;
  String? Function(BuildContext, String?)? businessNameTextController2Validator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    businessNameFocusNode1?.dispose();
    businessNameTextController1?.dispose();

    textFieldFocusNode?.dispose();
    textController2?.dispose();

    businessNameFocusNode2?.dispose();
    businessNameTextController2?.dispose();
  }
}
