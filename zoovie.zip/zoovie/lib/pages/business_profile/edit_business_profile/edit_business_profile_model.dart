import '/flutter_flow/flutter_flow_util.dart';
import 'edit_business_profile_widget.dart' show EditBusinessProfileWidget;
import 'package:flutter/material.dart';

class EditBusinessProfileModel
    extends FlutterFlowModel<EditBusinessProfileWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
