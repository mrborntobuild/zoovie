import '/flutter_flow/flutter_flow_util.dart';
import '/pages/components/message_emoji/message_emoji_widget.dart';
import '/pages/components/reply/reply_widget.dart';
import 'messages_widget.dart' show MessagesWidget;
import 'package:flutter/material.dart';
import 'package:record/record.dart';

class MessagesModel extends FlutterFlowModel<MessagesWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Model for reply component.
  late ReplyModel replyModel;
  String? newVoiceMessage;
  FFUploadedFile recordedFileBytes =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  AudioRecorder? audioRecorder;
  // Model for messageEmoji component.
  late MessageEmojiModel messageEmojiModel;

  @override
  void initState(BuildContext context) {
    replyModel = createModel(context, () => ReplyModel());
    messageEmojiModel = createModel(context, () => MessageEmojiModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    replyModel.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();

    messageEmojiModel.dispose();
  }
}
