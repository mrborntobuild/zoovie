import '/flutter_flow/flutter_flow_util.dart';
import '/pages/components/chat_g_p_t_menu/chat_g_p_t_menu_widget.dart';
import 'chat_g_p_t_widget.dart' show ChatGPTWidget;
import 'package:flutter/material.dart';

class ChatGPTModel extends FlutterFlowModel<ChatGPTWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for ChatList widget.
  ScrollController? chatList;
  // State field(s) for inputMessage widget.
  FocusNode? inputMessageFocusNode;
  TextEditingController? inputMessageTextController;
  String? Function(BuildContext, String?)? inputMessageTextControllerValidator;
  // Stores action output result for [Custom Action - invokeChatGPT] action in Button widget.
  dynamic chatResult;
  // Stores action output result for [Custom Action - invokeChatGPT] action in Button widget.
  dynamic chatResult2;
  // Model for chatGPTMenu component.
  late ChatGPTMenuModel chatGPTMenuModel;

  @override
  void initState(BuildContext context) {
    chatList = ScrollController();
    chatGPTMenuModel = createModel(context, () => ChatGPTMenuModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    chatList?.dispose();
    inputMessageFocusNode?.dispose();
    inputMessageTextController?.dispose();

    chatGPTMenuModel.dispose();
  }
}
