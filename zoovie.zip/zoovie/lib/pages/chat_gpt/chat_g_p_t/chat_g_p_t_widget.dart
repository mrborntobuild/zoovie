import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pages/components/chat_g_p_t_emty_lisy/chat_g_p_t_emty_lisy_widget.dart';
import '/pages/components/chat_g_p_t_menu/chat_g_p_t_menu_widget.dart';
import '/pages/components/pro_business/pro_business_widget.dart';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'chat_g_p_t_model.dart';
export 'chat_g_p_t_model.dart';

class ChatGPTWidget extends StatefulWidget {
  const ChatGPTWidget({super.key});

  @override
  State<ChatGPTWidget> createState() => _ChatGPTWidgetState();
}

class _ChatGPTWidgetState extends State<ChatGPTWidget> {
  late ChatGPTModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ChatGPTModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      setState(() {
        FFAppState().updateChatGPTBlockStruct(
          (e) => e
            ..hours = functions.returnHoursFromTwoDates(
                FFAppState().chatGPTBlock.firstMessageDate!,
                getCurrentTimestamp),
        );
      });
      if (FFAppState().chatGPTBlock.hours > 23) {
        setState(() {
          FFAppState().updateChatGPTBlockStruct(
            (e) => e
              ..hours = null
              ..messageCount = null,
          );
        });
      }
    });

    _model.inputMessageTextController ??=
        TextEditingController(text: FFAppState().topicMessage);
    _model.inputMessageFocusNode ??= FocusNode();
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(50.0),
          child: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            automaticallyImplyLeading: false,
            title: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 45.0,
                  height: 45.0,
                  decoration: const BoxDecoration(),
                  child: InkWell(
                    splashColor: Colors.transparent,
                    focusColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onTap: () async {
                      context.safePop();
                    },
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SvgPicture.asset(
                          'assets/images/Alt_Arrow_Linear_Left_White.svg',
                          width: 22.0,
                          height: 22.0,
                          fit: BoxFit.cover,
                        ),
                      ],
                    ),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        setState(() {
                          FFAppState().updateChatGPTBlockStruct(
                            (e) => e..messageCount = null,
                          );
                        });
                      },
                      child: Text(
                        FFLocalizations.of(context).getText(
                          'j6gj9efj' /* Luminary */,
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              fontSize: 18.0,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                    ),
                  ],
                ),
                Container(
                  width: 45.0,
                  height: 45.0,
                  decoration: const BoxDecoration(),
                  child: InkWell(
                    splashColor: Colors.transparent,
                    focusColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onTap: () async {
                      HapticFeedback.lightImpact();
                      FFAppState().update(() {
                        FFAppState().chatGPTMenuActive = true;
                      });
                    },
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        SvgPicture.asset(
                          'assets/images/More_Dots_White.svg',
                          width: 22.0,
                          height: 22.0,
                          fit: BoxFit.cover,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            actions: const [],
            centerTitle: false,
            elevation: 0.0,
          ),
        ),
        body: SafeArea(
          top: true,
          child: Stack(
            children: [
              Container(
                width: double.infinity,
                height: double.infinity,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).primaryBackground,
                  borderRadius: BorderRadius.circular(30.0),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Expanded(
                      child: Container(
                        width: double.infinity,
                        height: double.infinity,
                        decoration: const BoxDecoration(),
                        child: Builder(
                          builder: (context) {
                            final chatCurrent =
                                FFAppState().currentConversation.toList();
                            if (chatCurrent.isEmpty) {
                              return const ChatGPTEmtyLisyWidget();
                            }
                            return ListView.separated(
                              padding: const EdgeInsets.fromLTRB(
                                0,
                                5.0,
                                0,
                                5.0,
                              ),
                              primary: false,
                              shrinkWrap: true,
                              scrollDirection: Axis.vertical,
                              itemCount: chatCurrent.length,
                              separatorBuilder: (_, __) =>
                                  const SizedBox(height: 30.0),
                              itemBuilder: (context, chatCurrentIndex) {
                                final chatCurrentItem =
                                    chatCurrent[chatCurrentIndex];
                                return Stack(
                                  children: [
                                    if ((int index) {
                                      return index % 2 != 0;
                                    }(chatCurrentIndex))
                                      Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              decoration: const BoxDecoration(),
                                              child: InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor:
                                                    Colors.transparent,
                                                onLongPress: () async {
                                                  await Clipboard.setData(
                                                      ClipboardData(
                                                          text: getJsonField(
                                                    chatCurrentItem,
                                                    r'''$.content''',
                                                  ).toString()));
                                                  ScaffoldMessenger.of(context)
                                                      .showSnackBar(
                                                    SnackBar(
                                                      content: Text(
                                                        'Copied to clipboard',
                                                        style: TextStyle(
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primaryText,
                                                        ),
                                                      ),
                                                      duration: const Duration(
                                                          milliseconds: 4000),
                                                      backgroundColor:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .secondary,
                                                    ),
                                                  );
                                                },
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              const EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      15.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        50.0),
                                                            child: SvgPicture
                                                                .asset(
                                                              'assets/images/ChatGPT_Linear_Blue.svg',
                                                              width: 20.0,
                                                              height: 20.0,
                                                              fit: BoxFit.cover,
                                                            ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      10.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: Text(
                                                            FFLocalizations.of(
                                                                    context)
                                                                .getText(
                                                              'j2eiw1mg' /* LUMINARY */,
                                                            ),
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Inter',
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .secondaryText,
                                                                  fontSize:
                                                                      12.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Padding(
                                                      padding:
                                                          const EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  45.0,
                                                                  5.0,
                                                                  20.0,
                                                                  0.0),
                                                      child: Text(
                                                        getJsonField(
                                                          chatCurrentItem,
                                                          r'''$.content''',
                                                        ).toString(),
                                                        textAlign:
                                                            TextAlign.start,
                                                        style:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Inter',
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .primaryText,
                                                                  fontSize:
                                                                      16.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    if (chatCurrentIndex % 2 == 0)
                                      Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              decoration: const BoxDecoration(),
                                              child: InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor:
                                                    Colors.transparent,
                                                onLongPress: () async {
                                                  await Clipboard.setData(
                                                      ClipboardData(
                                                          text: getJsonField(
                                                    chatCurrentItem,
                                                    r'''$.content''',
                                                  ).toString()));
                                                  ScaffoldMessenger.of(context)
                                                      .showSnackBar(
                                                    SnackBar(
                                                      content: Text(
                                                        'Copied to clipboard',
                                                        style: TextStyle(
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primaryText,
                                                        ),
                                                      ),
                                                      duration: const Duration(
                                                          milliseconds: 4000),
                                                      backgroundColor:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .secondary,
                                                    ),
                                                  );
                                                },
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              const EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      15.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0),
                                                          child:
                                                              AuthUserStreamWidget(
                                                            builder:
                                                                (context) =>
                                                                    ClipRRect(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          50.0),
                                                              child:
                                                                  CachedNetworkImage(
                                                                fadeInDuration:
                                                                    const Duration(
                                                                        milliseconds:
                                                                            500),
                                                                fadeOutDuration:
                                                                    const Duration(
                                                                        milliseconds:
                                                                            500),
                                                                imageUrl:
                                                                    valueOrDefault<
                                                                        String>(
                                                                  currentUserPhoto,
                                                                  'https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/beneree-t2ym3b/assets/ka2n03qkats7/User_Placeholder_Empty.jpg',
                                                                ),
                                                                width: 20.0,
                                                                height: 20.0,
                                                                fit: BoxFit
                                                                    .cover,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      10.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0),
                                                          child:
                                                              AuthUserStreamWidget(
                                                            builder:
                                                                (context) =>
                                                                    Text(
                                                              functions.returnCapitalCaracters(
                                                                  valueOrDefault(
                                                                      currentUserDocument
                                                                          ?.username,
                                                                      '')),
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Inter',
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .secondaryText,
                                                                    fontSize:
                                                                        12.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                  ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Padding(
                                                      padding:
                                                          const EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  45.0,
                                                                  5.0,
                                                                  20.0,
                                                                  0.0),
                                                      child: Text(
                                                        getJsonField(
                                                          chatCurrentItem,
                                                          r'''$.content''',
                                                        ).toString(),
                                                        textAlign:
                                                            TextAlign.start,
                                                        style:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Inter',
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .primaryText,
                                                                  fontSize:
                                                                      16.0,
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                  ],
                                );
                              },
                              controller: _model.chatList,
                            );
                          },
                        ),
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).primaryBackground,
                        borderRadius: BorderRadius.circular(0.0),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 1.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                            ),
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsetsDirectional.fromSTEB(
                                      15.0, 5.0, 10.0, 5.0),
                                  child: TextFormField(
                                    controller:
                                        _model.inputMessageTextController,
                                    focusNode: _model.inputMessageFocusNode,
                                    autofocus: false,
                                    textCapitalization:
                                        TextCapitalization.sentences,
                                    obscureText: false,
                                    decoration: InputDecoration(
                                      isDense: true,
                                      hintText:
                                          FFLocalizations.of(context).getText(
                                        '9bunula4' /* Ask me a question... */,
                                      ),
                                      hintStyle: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Inter',
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryText,
                                            fontSize: 13.0,
                                            letterSpacing: 0.0,
                                          ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          color: FlutterFlowTheme.of(context)
                                              .greyButtonLine,
                                          width: 1.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(20.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                          color: Color(0x00000000),
                                          width: 1.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(20.0),
                                      ),
                                      errorBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                          color: Color(0x00000000),
                                          width: 1.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(20.0),
                                      ),
                                      focusedErrorBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(
                                          color: Color(0x00000000),
                                          width: 1.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(20.0),
                                      ),
                                      filled: true,
                                      fillColor: FlutterFlowTheme.of(context)
                                          .secondaryBackground,
                                      contentPadding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              13.0, 12.0, 13.0, 12.0),
                                    ),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          fontSize: 14.0,
                                          letterSpacing: 0.0,
                                        ),
                                    maxLines: 5,
                                    minLines: 1,
                                    keyboardType: TextInputType.multiline,
                                    cursorColor:
                                        FlutterFlowTheme.of(context).buttonBlue,
                                    validator: _model
                                        .inputMessageTextControllerValidator
                                        .asValidator(context),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 15.0, 0.0),
                                child: Container(
                                  width: 45.0,
                                  height: 45.0,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50.0),
                                  ),
                                  child: Align(
                                    alignment: const AlignmentDirectional(0.0, 0.0),
                                    child: Stack(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.all(5.0),
                                          child: Image.asset(
                                            'assets/images/Send_Circle_Blue.png',
                                            width: 100.0,
                                            height: 100.0,
                                            fit: BoxFit.contain,
                                          ),
                                        ),
                                        Align(
                                          alignment:
                                              const AlignmentDirectional(0.0, 0.0),
                                          child: FFButtonWidget(
                                            onPressed: () async {
                                              if (valueOrDefault<bool>(
                                                      currentUserDocument
                                                          ?.premiumAccount,
                                                      false) ==
                                                  false) {
                                                if (FFAppState()
                                                        .chatGPTBlock
                                                        .messageCount <
                                                    2) {
                                                  if (_model.inputMessageTextController
                                                              .text !=
                                                          '') {
                                                    setState(() {
                                                      FFAppState()
                                                              .currentConversation =
                                                          functions
                                                              .prepareChatHistory(
                                                                  FFAppState()
                                                                      .currentConversation
                                                                      .toList(),
                                                                  _model
                                                                      .inputMessageTextController
                                                                      .text)
                                                              .toList()
                                                              .cast<dynamic>();
                                                    });
                                                    _model.chatResult =
                                                        await actions
                                                            .invokeChatGPT(
                                                      FFAppState().apiKey,
                                                      FFAppState()
                                                          .currentConversation
                                                          .toList(),
                                                    );
                                                    setState(() {
                                                      FFAppState()
                                                              .currentConversation =
                                                          functions
                                                              .refreshChatHistory(
                                                                  FFAppState()
                                                                      .currentConversation
                                                                      .toList(),
                                                                  getJsonField(
                                                                    _model
                                                                        .chatResult,
                                                                    r'''$.choices[0].message''',
                                                                  ))
                                                              .toList()
                                                              .cast<dynamic>();
                                                    });
                                                    setState(() {
                                                      FFAppState()
                                                          .updateChatGPTBlockStruct(
                                                        (e) => e
                                                          ..incrementMessageCount(
                                                              1)
                                                          ..firstMessageDate =
                                                              getCurrentTimestamp,
                                                      );
                                                    });
                                                    HapticFeedback
                                                        .lightImpact();
                                                    setState(() {
                                                      _model
                                                          .inputMessageTextController
                                                          ?.clear();
                                                    });
                                                    await Future.delayed(
                                                        const Duration(
                                                            milliseconds: 800));
                                                    await _model.chatList
                                                        ?.animateTo(
                                                      _model.chatList!.position
                                                          .maxScrollExtent,
                                                      duration: const Duration(
                                                          milliseconds: 200),
                                                      curve: Curves.ease,
                                                    );
                                                  }
                                                } else {
                                                  if (valueOrDefault<bool>(
                                                          currentUserDocument
                                                              ?.businessAccount,
                                                          false) !=
                                                      false) {
                                                    await showModalBottomSheet(
                                                      isScrollControlled: true,
                                                      backgroundColor:
                                                          Colors.transparent,
                                                      barrierColor:
                                                          const Color(0xB3010101),
                                                      isDismissible: false,
                                                      context: context,
                                                      builder: (context) {
                                                        return GestureDetector(
                                                          onTap: () => _model
                                                                  .unfocusNode
                                                                  .canRequestFocus
                                                              ? FocusScope.of(
                                                                      context)
                                                                  .requestFocus(
                                                                      _model
                                                                          .unfocusNode)
                                                              : FocusScope.of(
                                                                      context)
                                                                  .unfocus(),
                                                          child: Padding(
                                                            padding: MediaQuery
                                                                .viewInsetsOf(
                                                                    context),
                                                            child: SizedBox(
                                                              height: MediaQuery
                                                                          .sizeOf(
                                                                              context)
                                                                      .height *
                                                                  0.95,
                                                              child:
                                                                  const ProBusinessWidget(),
                                                            ),
                                                          ),
                                                        );
                                                      },
                                                    ).then((value) =>
                                                        safeSetState(() {}));
                                                  }
                                                }
                                              } else {
                                                if (_model.inputMessageTextController
                                                            .text !=
                                                        '') {
                                                  setState(() {
                                                    FFAppState()
                                                            .currentConversation =
                                                        functions
                                                            .prepareChatHistory(
                                                                FFAppState()
                                                                    .currentConversation
                                                                    .toList(),
                                                                _model
                                                                    .inputMessageTextController
                                                                    .text)
                                                            .toList()
                                                            .cast<dynamic>();
                                                  });
                                                  _model.chatResult2 =
                                                      await actions
                                                          .invokeChatGPT(
                                                    FFAppState().apiKey,
                                                    FFAppState()
                                                        .currentConversation
                                                        .toList(),
                                                  );
                                                  setState(() {
                                                    FFAppState()
                                                            .currentConversation =
                                                        functions
                                                            .refreshChatHistory(
                                                                FFAppState()
                                                                    .currentConversation
                                                                    .toList(),
                                                                getJsonField(
                                                                  _model
                                                                      .chatResult2,
                                                                  r'''$.choices[0].message''',
                                                                ))
                                                            .toList()
                                                            .cast<dynamic>();
                                                  });
                                                  setState(() {
                                                    FFAppState()
                                                        .updateChatGPTBlockStruct(
                                                      (e) => e
                                                        ..incrementMessageCount(
                                                            1)
                                                        ..firstMessageDate =
                                                            getCurrentTimestamp,
                                                    );
                                                  });
                                                  HapticFeedback.lightImpact();
                                                  setState(() {
                                                    _model
                                                        .inputMessageTextController
                                                        ?.clear();
                                                  });
                                                  await Future.delayed(
                                                      const Duration(
                                                          milliseconds: 800));
                                                  await _model.chatList
                                                      ?.animateTo(
                                                    _model.chatList!.position
                                                        .maxScrollExtent,
                                                    duration: const Duration(
                                                        milliseconds: 200),
                                                    curve: Curves.ease,
                                                  );
                                                }
                                              }

                                              setState(() {});
                                            },
                                            text: '',
                                            options: FFButtonOptions(
                                              width: 45.0,
                                              height: 45.0,
                                              padding: const EdgeInsetsDirectional
                                                  .fromSTEB(0.0, 0.0, 0.0, 0.0),
                                              iconPadding: const EdgeInsetsDirectional
                                                  .fromSTEB(0.0, 0.0, 0.0, 0.0),
                                              color: Colors.transparent,
                                              textStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .titleSmall
                                                      .override(
                                                        fontFamily: 'Inter',
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .blackText,
                                                        fontSize: 10.0,
                                                        letterSpacing: 0.0,
                                                      ),
                                              elevation: 0.0,
                                              borderSide: const BorderSide(
                                                color: Colors.transparent,
                                                width: 1.0,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(50.0),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              if (FFAppState().chatGPTMenuActive == true)
                wrapWithModel(
                  model: _model.chatGPTMenuModel,
                  updateCallback: () => setState(() {}),
                  child: const ChatGPTMenuWidget(
                    blueBubble: false,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
