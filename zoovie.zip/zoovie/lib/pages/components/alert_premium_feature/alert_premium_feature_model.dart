import '/flutter_flow/flutter_flow_util.dart';
import 'alert_premium_feature_widget.dart' show AlertPremiumFeatureWidget;
import 'package:flutter/material.dart';

class AlertPremiumFeatureModel
    extends FlutterFlowModel<AlertPremiumFeatureWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
