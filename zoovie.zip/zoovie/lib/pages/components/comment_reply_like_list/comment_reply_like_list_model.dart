import '/flutter_flow/flutter_flow_util.dart';
import 'comment_reply_like_list_widget.dart' show CommentReplyLikeListWidget;
import 'package:flutter/material.dart';

class CommentReplyLikeListModel
    extends FlutterFlowModel<CommentReplyLikeListWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
