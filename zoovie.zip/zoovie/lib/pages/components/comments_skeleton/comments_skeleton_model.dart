import '/flutter_flow/flutter_flow_util.dart';
import 'comments_skeleton_widget.dart' show CommentsSkeletonWidget;
import 'package:flutter/material.dart';

class CommentsSkeletonModel extends FlutterFlowModel<CommentsSkeletonWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
