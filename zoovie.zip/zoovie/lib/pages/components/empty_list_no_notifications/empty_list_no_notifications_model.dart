import '/flutter_flow/flutter_flow_util.dart';
import 'empty_list_no_notifications_widget.dart'
    show EmptyListNoNotificationsWidget;
import 'package:flutter/material.dart';

class EmptyListNoNotificationsModel
    extends FlutterFlowModel<EmptyListNoNotificationsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
