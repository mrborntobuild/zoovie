import '/flutter_flow/flutter_flow_util.dart';
import 'emptylist_nothing_to_show_widget.dart'
    show EmptylistNothingToShowWidget;
import 'package:flutter/material.dart';

class EmptylistNothingToShowModel
    extends FlutterFlowModel<EmptylistNothingToShowWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
