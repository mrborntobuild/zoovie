import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'g_p_t_no_chats_model.dart';
export 'g_p_t_no_chats_model.dart';

class GPTNoChatsWidget extends StatefulWidget {
  const GPTNoChatsWidget({super.key});

  @override
  State<GPTNoChatsWidget> createState() => _GPTNoChatsWidgetState();
}

class _GPTNoChatsWidgetState extends State<GPTNoChatsWidget> {
  late GPTNoChatsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GPTNoChatsModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsetsDirectional.fromSTEB(15.0, 0.0, 15.0, 0.0),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(0.0, 15.0, 15.0, 15.0),
            child: Text(
              FFLocalizations.of(context).getText(
                'f068oztn' /* You don't have any chats saved... */,
              ),
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    color: FlutterFlowTheme.of(context).secondaryText,
                    fontSize: 13.0,
                    letterSpacing: 0.0,
                    fontWeight: FontWeight.normal,
                  ),
            ),
          ),
        ],
      ),
    );
  }
}
