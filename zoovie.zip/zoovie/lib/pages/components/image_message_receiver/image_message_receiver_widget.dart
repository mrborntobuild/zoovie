import '/flutter_flow/flutter_flow_expanded_image_view.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:octo_image/octo_image.dart';
import 'image_message_receiver_model.dart';
export 'image_message_receiver_model.dart';

class ImageMessageReceiverWidget extends StatefulWidget {
  const ImageMessageReceiverWidget({
    super.key,
    this.parameter1,
  });

  final String? parameter1;

  @override
  State<ImageMessageReceiverWidget> createState() =>
      _ImageMessageReceiverWidgetState();
}

class _ImageMessageReceiverWidgetState
    extends State<ImageMessageReceiverWidget> {
  late ImageMessageReceiverModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ImageMessageReceiverModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              await Navigator.push(
                context,
                PageTransition(
                  type: PageTransitionType.fade,
                  child: FlutterFlowExpandedImageView(
                    image: OctoImage(
                      placeholderBuilder: (_) => const SizedBox.expand(
                        child: Image(
                          image: BlurHashImage('LEHV6nWB2yk8pyo0adR*.7kCMdnj'),
                          fit: BoxFit.cover,
                        ),
                      ),
                      image: NetworkImage(
                        widget.parameter1!,
                      ),
                      fit: BoxFit.contain,
                    ),
                    allowRotation: false,
                    tag: widget.parameter1!,
                    useHeroAnimation: true,
                  ),
                ),
              );
            },
            child: Hero(
              tag: widget.parameter1!,
              transitionOnUserGestures: true,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(13.0),
                child: OctoImage(
                  placeholderBuilder: (_) => const SizedBox.expand(
                    child: Image(
                      image: BlurHashImage('LEHV6nWB2yk8pyo0adR*.7kCMdnj'),
                      fit: BoxFit.cover,
                    ),
                  ),
                  image: NetworkImage(
                    widget.parameter1!,
                  ),
                  width: MediaQuery.sizeOf(context).width * 0.65,
                  height: 340.0,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
