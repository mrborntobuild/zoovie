import '/flutter_flow/flutter_flow_util.dart';
import 'image_message_sender_widget.dart' show ImageMessageSenderWidget;
import 'package:flutter/material.dart';

class ImageMessageSenderModel
    extends FlutterFlowModel<ImageMessageSenderWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
