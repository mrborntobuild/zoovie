import '/flutter_flow/flutter_flow_util.dart';
import 'like_skeleton_widget.dart' show LikeSkeletonWidget;
import 'package:flutter/material.dart';

class LikeSkeletonModel extends FlutterFlowModel<LikeSkeletonWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
