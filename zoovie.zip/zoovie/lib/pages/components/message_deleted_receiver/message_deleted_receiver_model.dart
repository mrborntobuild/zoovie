import '/flutter_flow/flutter_flow_util.dart';
import 'message_deleted_receiver_widget.dart' show MessageDeletedReceiverWidget;
import 'package:flutter/material.dart';

class MessageDeletedReceiverModel
    extends FlutterFlowModel<MessageDeletedReceiverWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
