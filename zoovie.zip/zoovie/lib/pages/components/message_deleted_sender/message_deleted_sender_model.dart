import '/flutter_flow/flutter_flow_util.dart';
import 'message_deleted_sender_widget.dart' show MessageDeletedSenderWidget;
import 'package:flutter/material.dart';

class MessageDeletedSenderModel
    extends FlutterFlowModel<MessageDeletedSenderWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
