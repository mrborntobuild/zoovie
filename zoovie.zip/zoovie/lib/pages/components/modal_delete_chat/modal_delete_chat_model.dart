import '/flutter_flow/flutter_flow_util.dart';
import 'modal_delete_chat_widget.dart' show ModalDeleteChatWidget;
import 'package:flutter/material.dart';

class ModalDeleteChatModel extends FlutterFlowModel<ModalDeleteChatWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
