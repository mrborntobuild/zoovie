import '/flutter_flow/flutter_flow_util.dart';
import 'modal_no_internet_widget.dart' show ModalNoInternetWidget;
import 'package:flutter/material.dart';

class ModalNoInternetModel extends FlutterFlowModel<ModalNoInternetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
