import '/flutter_flow/flutter_flow_util.dart';
import 'modal_post_owner_widget.dart' show ModalPostOwnerWidget;
import 'package:flutter/material.dart';

class ModalPostOwnerModel extends FlutterFlowModel<ModalPostOwnerWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
