import '/flutter_flow/flutter_flow_util.dart';
import 'modal_select_image_video_widget.dart' show ModalSelectImageVideoWidget;
import 'package:flutter/material.dart';

class ModalSelectImageVideoModel
    extends FlutterFlowModel<ModalSelectImageVideoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
