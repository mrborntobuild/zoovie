import '/flutter_flow/flutter_flow_util.dart';
import 'no_rewards_widget.dart' show NoRewardsWidget;
import 'package:flutter/material.dart';

class NoRewardsModel extends FlutterFlowModel<NoRewardsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
