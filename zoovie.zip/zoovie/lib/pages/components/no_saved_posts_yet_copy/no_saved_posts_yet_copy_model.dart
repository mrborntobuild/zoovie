import '/flutter_flow/flutter_flow_util.dart';
import 'no_saved_posts_yet_copy_widget.dart' show NoSavedPostsYetCopyWidget;
import 'package:flutter/material.dart';

class NoSavedPostsYetCopyModel
    extends FlutterFlowModel<NoSavedPostsYetCopyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
