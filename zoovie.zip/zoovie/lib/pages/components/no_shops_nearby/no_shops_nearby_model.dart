import '/flutter_flow/flutter_flow_util.dart';
import 'no_shops_nearby_widget.dart' show NoShopsNearbyWidget;
import 'package:flutter/material.dart';

class NoShopsNearbyModel extends FlutterFlowModel<NoShopsNearbyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
