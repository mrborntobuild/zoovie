import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'no_shops_nearby_model.dart';
export 'no_shops_nearby_model.dart';

class NoShopsNearbyWidget extends StatefulWidget {
  const NoShopsNearbyWidget({super.key});

  @override
  State<NoShopsNearbyWidget> createState() => _NoShopsNearbyWidgetState();
}

class _NoShopsNearbyWidgetState extends State<NoShopsNearbyWidget> {
  late NoShopsNearbyModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NoShopsNearbyModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsetsDirectional.fromSTEB(35.0, 15.0, 35.0, 15.0),
                child: Text(
                  FFLocalizations.of(context).getText(
                    's35sscbh' /* Sorry, no nearby shops found. */,
                  ),
                  textAlign: TextAlign.center,
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).secondaryText,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w500,
                      ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
