import '/flutter_flow/flutter_flow_util.dart';
import 'no_transaction_widget.dart' show NoTransactionWidget;
import 'package:flutter/material.dart';

class NoTransactionModel extends FlutterFlowModel<NoTransactionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
