import '/flutter_flow/flutter_flow_util.dart';
import 'post_like_list_widget.dart' show PostLikeListWidget;
import 'package:flutter/material.dart';

class PostLikeListModel extends FlutterFlowModel<PostLikeListWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
