import '/flutter_flow/flutter_flow_util.dart';
import 'pro_business_widget.dart' show ProBusinessWidget;
import 'package:flutter/material.dart';

class ProBusinessModel extends FlutterFlowModel<ProBusinessWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
