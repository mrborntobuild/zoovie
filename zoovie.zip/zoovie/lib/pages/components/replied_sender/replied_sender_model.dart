import '/flutter_flow/flutter_flow_util.dart';
import 'replied_sender_widget.dart' show RepliedSenderWidget;
import 'package:flutter/material.dart';

class RepliedSenderModel extends FlutterFlowModel<RepliedSenderWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
