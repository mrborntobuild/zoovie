import '/flutter_flow/flutter_flow_util.dart';
import 'shimmer_feed_widget.dart' show ShimmerFeedWidget;
import 'package:flutter/material.dart';

class ShimmerFeedModel extends FlutterFlowModel<ShimmerFeedWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
