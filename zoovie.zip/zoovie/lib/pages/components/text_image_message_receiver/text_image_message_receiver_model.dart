import '/flutter_flow/flutter_flow_util.dart';
import 'text_image_message_receiver_widget.dart'
    show TextImageMessageReceiverWidget;
import 'package:flutter/material.dart';

class TextImageMessageReceiverModel
    extends FlutterFlowModel<TextImageMessageReceiverWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
