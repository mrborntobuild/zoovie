import '/flutter_flow/flutter_flow_util.dart';
import 'text_image_message_sender_widget.dart'
    show TextImageMessageSenderWidget;
import 'package:flutter/material.dart';

class TextImageMessageSenderModel
    extends FlutterFlowModel<TextImageMessageSenderWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
