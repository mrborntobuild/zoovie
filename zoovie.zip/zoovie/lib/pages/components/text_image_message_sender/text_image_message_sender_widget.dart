import '/flutter_flow/flutter_flow_expanded_image_view.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:octo_image/octo_image.dart';
import 'text_image_message_sender_model.dart';
export 'text_image_message_sender_model.dart';

class TextImageMessageSenderWidget extends StatefulWidget {
  const TextImageMessageSenderWidget({
    super.key,
    this.parameter1,
    this.parameter2,
    required this.parameter3,
  });

  final String? parameter1;
  final String? parameter2;
  final String? parameter3;

  @override
  State<TextImageMessageSenderWidget> createState() =>
      _TextImageMessageSenderWidgetState();
}

class _TextImageMessageSenderWidgetState
    extends State<TextImageMessageSenderWidget> {
  late TextImageMessageSenderModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TextImageMessageSenderModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              await Navigator.push(
                context,
                PageTransition(
                  type: PageTransitionType.fade,
                  child: FlutterFlowExpandedImageView(
                    image: OctoImage(
                      placeholderBuilder: (_) => const SizedBox.expand(
                        child: Image(
                          image: BlurHashImage('LEHV6nWB2yk8pyo0adR*.7kCMdnj'),
                          fit: BoxFit.cover,
                        ),
                      ),
                      image: NetworkImage(
                        widget.parameter1!,
                      ),
                      fit: BoxFit.contain,
                    ),
                    allowRotation: false,
                    tag: widget.parameter1!,
                    useHeroAnimation: true,
                  ),
                ),
              );
            },
            child: Hero(
              tag: widget.parameter1!,
              transitionOnUserGestures: true,
              child: ClipRRect(
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(0.0),
                  bottomRight: Radius.circular(0.0),
                  topLeft: Radius.circular(13.0),
                  topRight: Radius.circular(13.0),
                ),
                child: OctoImage(
                  placeholderBuilder: (_) => const SizedBox.expand(
                    child: Image(
                      image: BlurHashImage('LEHV6nWB2yk8pyo0adR*.7kCMdnj'),
                      fit: BoxFit.cover,
                    ),
                  ),
                  image: NetworkImage(
                    widget.parameter1!,
                  ),
                  width: MediaQuery.sizeOf(context).width * 0.65,
                  height: 340.0,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Container(
            width: MediaQuery.sizeOf(context).width * 0.65,
            decoration: BoxDecoration(
              color: FlutterFlowTheme.of(context).buttonBlue,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(15.0),
                bottomRight: Radius.circular(15.0),
                topLeft: Radius.circular(0.0),
                topRight: Radius.circular(0.0),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Flexible(
                      child: Padding(
                        padding: const EdgeInsetsDirectional.fromSTEB(
                            12.0, 8.0, 12.0, 8.0),
                        child: Text(
                          widget.parameter2!,
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    fontSize: 15.0,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 10.0, 8.0),
                      child: Text(
                        widget.parameter3!,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Inter',
                              color: FlutterFlowTheme.of(context).modalGrey,
                              fontSize: 11.0,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.w500,
                            ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
