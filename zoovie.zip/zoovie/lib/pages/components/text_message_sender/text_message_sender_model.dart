import '/flutter_flow/flutter_flow_util.dart';
import 'text_message_sender_widget.dart' show TextMessageSenderWidget;
import 'package:flutter/material.dart';

class TextMessageSenderModel extends FlutterFlowModel<TextMessageSenderWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
