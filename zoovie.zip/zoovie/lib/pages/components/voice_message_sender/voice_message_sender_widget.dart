import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:just_audio/just_audio.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import 'voice_message_sender_model.dart';
export 'voice_message_sender_model.dart';

class VoiceMessageSenderWidget extends StatefulWidget {
  const VoiceMessageSenderWidget({
    super.key,
    this.parameter1,
    this.parameter2,
    this.parameter3,
    required this.parameter4,
    this.parameter5,
  });

  final DocumentReference? parameter1;
  final DocumentReference? parameter2;
  final String? parameter3;
  final String? parameter4;
  final bool? parameter5;

  @override
  State<VoiceMessageSenderWidget> createState() =>
      _VoiceMessageSenderWidgetState();
}

class _VoiceMessageSenderWidgetState extends State<VoiceMessageSenderWidget> {
  late VoiceMessageSenderModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VoiceMessageSenderModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Container(
      width: MediaQuery.sizeOf(context).width * 0.75,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).buttonBlue,
        borderRadius: BorderRadius.circular(15.0),
      ),
      child: Padding(
        padding: const EdgeInsetsDirectional.fromSTEB(12.0, 10.0, 12.0, 10.0),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            StreamBuilder<UsersRecord>(
              stream: UsersRecord.getDocument(widget.parameter1!),
              builder: (context, snapshot) {
                // Customize what your widget looks like when it's loading.
                if (!snapshot.hasData) {
                  return Center(
                    child: SizedBox(
                      width: 20.0,
                      height: 20.0,
                      child: SpinKitCircle(
                        color: FlutterFlowTheme.of(context).greyButtonLine,
                        size: 20.0,
                      ),
                    ),
                  );
                }
                final imageUsersRecord = snapshot.data!;
                return ClipRRect(
                  borderRadius: BorderRadius.circular(50.0),
                  child: CachedNetworkImage(
                    fadeInDuration: const Duration(milliseconds: 500),
                    fadeOutDuration: const Duration(milliseconds: 500),
                    imageUrl: imageUsersRecord.photoUrl,
                    width: 45.0,
                    height: 45.0,
                    fit: BoxFit.cover,
                  ),
                );
              },
            ),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Stack(
                        children: [
                          if (FFAppState().playVoiceMessage == true)
                            Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  12.0, 6.0, 0.0, 6.0),
                              child: InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  setState(() {
                                    FFAppState().playVoiceMessage = false;
                                    FFAppState().currentVoiceMessageID =
                                        widget.parameter2;
                                  });
                                  _model.soundPlayer ??= AudioPlayer();
                                  if (_model.soundPlayer!.playing) {
                                    await _model.soundPlayer!.stop();
                                  }
                                  _model.soundPlayer!.setVolume(1.0);
                                  _model.soundPlayer!
                                      .setUrl(widget.parameter3!)
                                      .then((_) => _model.soundPlayer!.play());
                                },
                                child: SvgPicture.asset(
                                  'assets/images/Play_Bold_White.svg',
                                  width: 22.0,
                                  height: 22.0,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          if (FFAppState().playVoiceMessage == false)
                            Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  12.0, 6.0, 0.0, 6.0),
                              child: InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  _model.soundPlayer?.stop();
                                  setState(() {
                                    FFAppState().playVoiceMessage = true;
                                    FFAppState().currentVoiceMessageID = null;
                                  });
                                },
                                child: SvgPicture.asset(
                                  'assets/images/Stop_Bold_White.svg',
                                  width: 22.0,
                                  height: 22.0,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                        ],
                      ),
                      Expanded(
                        child: Lottie.asset(
                          'assets/lottie_animations/Animation_-_1689156849445.json',
                          height: 30.0,
                          fit: BoxFit.contain,
                          animate: true,
                        ),
                      ),
                    ],
                  ),
                  Padding(
                    padding:
                        const EdgeInsetsDirectional.fromSTEB(45.0, 2.0, 0.0, 0.0),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          widget.parameter4!,
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Inter',
                                    fontSize: 11.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
