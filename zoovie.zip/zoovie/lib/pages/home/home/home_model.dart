import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/instant_timer.dart';
import '/pages/components/logo_animation/logo_animation_widget.dart';
import '/pages/home/menu_feed_page/menu_feed_page_widget.dart';
import 'home_widget.dart' show HomeWidget;
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class HomeModel extends FlutterFlowModel<HomeWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Backend Call - API (Club List)] action in home widget.
  ApiCallResponse? aPICall;
  InstantTimer? instantTimer;
  // State field(s) for Carousel widget.
  CarouselController? carouselController1;

  int carouselCurrentIndex1 = 0;

  // Stores action output result for [Backend Call - Create Document] action in NotActiveHeart widget.
  PostLikesRecord? newLike2;
  // State field(s) for Carousel widget.
  CarouselController? carouselController2;

  int carouselCurrentIndex2 = 0;

  // Stores action output result for [Backend Call - Create Document] action in NotActiveHeart2 widget.
  PostLikesRecord? newLike22;
  // Model for logo_animation component.
  late LogoAnimationModel logoAnimationModel;
  // Model for menuFeedPage component.
  late MenuFeedPageModel menuFeedPageModel;

  @override
  void initState(BuildContext context) {
    logoAnimationModel = createModel(context, () => LogoAnimationModel());
    menuFeedPageModel = createModel(context, () => MenuFeedPageModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    instantTimer?.cancel();
    logoAnimationModel.dispose();
    menuFeedPageModel.dispose();
  }
}
