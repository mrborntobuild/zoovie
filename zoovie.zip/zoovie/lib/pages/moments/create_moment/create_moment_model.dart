import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'create_moment_widget.dart' show CreateMomentWidget;
import 'package:flutter/material.dart';

class CreateMomentModel extends FlutterFlowModel<CreateMomentWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  MemoriesRecord? newMoment;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
