import '/flutter_flow/flutter_flow_util.dart';
import 'alert_delete_notification_widget.dart'
    show AlertDeleteNotificationWidget;
import 'package:flutter/material.dart';

class AlertDeleteNotificationModel
    extends FlutterFlowModel<AlertDeleteNotificationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
