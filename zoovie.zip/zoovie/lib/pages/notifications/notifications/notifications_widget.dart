import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pages/notifications/alert_delete_notification/alert_delete_notification_widget.dart';
import '/pages/notifications/notifications_empty/notifications_empty_widget.dart';
import '/pages/notifications/shimmer_notifications/shimmer_notifications_widget.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'notifications_model.dart';
export 'notifications_model.dart';

class NotificationsWidget extends StatefulWidget {
  const NotificationsWidget({super.key});

  @override
  State<NotificationsWidget> createState() => _NotificationsWidgetState();
}

class _NotificationsWidgetState extends State<NotificationsWidget> {
  late NotificationsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NotificationsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: WillPopScope(
        onWillPop: () async => false,
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: PreferredSize(
            preferredSize: const Size.fromHeight(50.0),
            child: AppBar(
              backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
              iconTheme:
                  IconThemeData(color: FlutterFlowTheme.of(context).primary),
              automaticallyImplyLeading: false,
              leading: InkWell(
                splashColor: Colors.transparent,
                focusColor: Colors.transparent,
                hoverColor: Colors.transparent,
                highlightColor: Colors.transparent,
                onTap: () async {
                  context.pop();
                },
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding:
                          const EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 0.0, 0.0),
                      child: SvgPicture.asset(
                        'assets/images/Alt_Arrow_Linear_Left_White.svg',
                        width: 22.0,
                        height: 22.0,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ],
                ),
              ),
              title: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    FFLocalizations.of(context).getText(
                      '4dgauh4b' /* Notifications */,
                    ),
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Inter',
                          fontSize: 18.0,
                          letterSpacing: 0.0,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ],
              ),
              actions: const [],
              centerTitle: true,
              elevation: 0.0,
            ),
          ),
          body: StreamBuilder<List<NotificationsRecord>>(
            stream: queryNotificationsRecord(
              queryBuilder: (notificationsRecord) => notificationsRecord
                  .where(
                    'receiver_ID',
                    isEqualTo: currentUserReference,
                  )
                  .orderBy('date_created', descending: true),
            ),
            builder: (context, snapshot) {
              // Customize what your widget looks like when it's loading.
              if (!snapshot.hasData) {
                return const ShimmerNotificationsWidget();
              }
              List<NotificationsRecord> listViewNotificationsRecordList =
                  snapshot.data!;
              if (listViewNotificationsRecordList.isEmpty) {
                return const NotificationsEmptyWidget();
              }
              return ListView.builder(
                padding: const EdgeInsets.fromLTRB(
                  0,
                  0,
                  0,
                  30.0,
                ),
                scrollDirection: Axis.vertical,
                itemCount: listViewNotificationsRecordList.length,
                itemBuilder: (context, listViewIndex) {
                  final listViewNotificationsRecord =
                      listViewNotificationsRecordList[listViewIndex];
                  return Builder(
                    builder: (context) => InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onLongPress: () async {
                        await showDialog(
                          barrierColor: const Color(0xCD000000),
                          context: context,
                          builder: (dialogContext) {
                            return Dialog(
                              elevation: 0,
                              insetPadding: EdgeInsets.zero,
                              backgroundColor: Colors.transparent,
                              alignment: const AlignmentDirectional(0.0, 0.0)
                                  .resolve(Directionality.of(context)),
                              child: GestureDetector(
                                onTap: () => _model.unfocusNode.canRequestFocus
                                    ? FocusScope.of(context)
                                        .requestFocus(_model.unfocusNode)
                                    : FocusScope.of(context).unfocus(),
                                child: AlertDeleteNotificationWidget(
                                  notificationReference:
                                      listViewNotificationsRecord.reference,
                                ),
                              ),
                            );
                          },
                        ).then((value) => setState(() {}));
                      },
                      child: Container(
                        width: double.infinity,
                        decoration: const BoxDecoration(),
                        child: Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 20.0, 0.0),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          context.pushNamed(
                                            'publicProfile',
                                            queryParameters: {
                                              'userReference': serializeParam(
                                                listViewNotificationsRecord
                                                    .senderID,
                                                ParamType.DocumentReference,
                                              ),
                                            }.withoutNulls,
                                          );
                                        },
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(50.0),
                                          child: CachedNetworkImage(
                                            fadeInDuration:
                                                const Duration(milliseconds: 500),
                                            fadeOutDuration:
                                                const Duration(milliseconds: 500),
                                            imageUrl: valueOrDefault<String>(
                                              listViewNotificationsRecord
                                                  .senderProfilePicture,
                                              'https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/beneree-t2ym3b/assets/ka2n03qkats7/User_Placeholder_Empty.jpg',
                                            ),
                                            width: 40.0,
                                            height: 40.0,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Padding(
                                          padding:
                                              const EdgeInsetsDirectional.fromSTEB(
                                                  10.0, 0.0, 10.0, 0.0),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              RichText(
                                                textScaler:
                                                    MediaQuery.of(context)
                                                        .textScaler,
                                                text: TextSpan(
                                                  children: [
                                                    TextSpan(
                                                      text:
                                                          listViewNotificationsRecord
                                                              .senderUsername,
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .bodySmall
                                                          .override(
                                                            fontFamily: 'Inter',
                                                            fontSize: 14.0,
                                                            letterSpacing: 0.0,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                          ),
                                                    ),
                                                    TextSpan(
                                                      text:
                                                          listViewNotificationsRecord
                                                              .notification,
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .bodySmall
                                                          .override(
                                                            fontFamily: 'Inter',
                                                            color: FlutterFlowTheme
                                                                    .of(context)
                                                                .primaryText,
                                                            fontSize: 14.0,
                                                            letterSpacing: 0.0,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                          ),
                                                    ),
                                                    TextSpan(
                                                      text:
                                                          '${functions.shortenComment(listViewNotificationsRecord.comment)} ',
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .bodySmall
                                                          .override(
                                                            fontFamily: 'Inter',
                                                            color: FlutterFlowTheme
                                                                    .of(context)
                                                                .primaryText,
                                                            fontSize: 14.0,
                                                            letterSpacing: 0.0,
                                                          ),
                                                    ),
                                                    TextSpan(
                                                      text: dateTimeFormat(
                                                        'relative',
                                                        listViewNotificationsRecord
                                                            .dateCreated!,
                                                        locale: FFLocalizations
                                                                    .of(context)
                                                                .languageShortCode ??
                                                            FFLocalizations.of(
                                                                    context)
                                                                .languageCode,
                                                      ),
                                                      style: const TextStyle(),
                                                    )
                                                  ],
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Inter',
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .secondaryText,
                                                        fontSize: 14.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        lineHeight: 1.3,
                                                      ),
                                                ),
                                                maxLines: 2,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Align(
                                alignment: const AlignmentDirectional(1.0, 0.0),
                                child: Container(
                                  height: 50.0,
                                  decoration: const BoxDecoration(),
                                  child: Align(
                                    alignment: const AlignmentDirectional(1.0, 0.0),
                                    child: Stack(
                                      alignment: const AlignmentDirectional(1.0, 0.0),
                                      children: [
                                        if (listViewNotificationsRecord
                                                .followers ==
                                            true)
                                          AuthUserStreamWidget(
                                            builder: (context) =>
                                                FFButtonWidget(
                                              onPressed: () async {
                                                final firestoreBatch =
                                                    FirebaseFirestore.instance
                                                        .batch();
                                                try {
                                                  if ((currentUserDocument
                                                                  ?.following
                                                                  .toList() ??
                                                              [])
                                                          .contains(
                                                              listViewNotificationsRecord
                                                                  .senderID) ==
                                                      false) {
                                                    HapticFeedback
                                                        .lightImpact();

                                                    firestoreBatch.update(
                                                        currentUserReference!, {
                                                      ...mapToFirestore(
                                                        {
                                                          'following':
                                                              FieldValue
                                                                  .arrayUnion([
                                                            listViewNotificationsRecord
                                                                .senderID
                                                          ]),
                                                        },
                                                      ),
                                                    });

                                                    firestoreBatch.update(
                                                        listViewNotificationsRecord
                                                            .senderID!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'followers':
                                                                  FieldValue
                                                                      .arrayUnion([
                                                                currentUserReference
                                                              ]),
                                                            },
                                                          ),
                                                        });

                                                    firestoreBatch.set(
                                                        NotificationsRecord
                                                            .collection
                                                            .doc(),
                                                        createNotificationsRecordData(
                                                          dateCreated:
                                                              getCurrentTimestamp,
                                                          receiverID:
                                                              listViewNotificationsRecord
                                                                  .senderID,
                                                          senderID:
                                                              currentUserReference,
                                                          senderUsername:
                                                              valueOrDefault(
                                                                  currentUserDocument
                                                                      ?.username,
                                                                  ''),
                                                          senderProfilePicture:
                                                              currentUserPhoto,
                                                          followers: true,
                                                          notification:
                                                              ' started following you. ',
                                                        ));

                                                    firestoreBatch.update(
                                                        listViewNotificationsRecord
                                                            .receiverID!,
                                                        createUsersRecordData(
                                                          newNotification: true,
                                                        ));
                                                  } else {
                                                    firestoreBatch.update(
                                                        currentUserReference!, {
                                                      ...mapToFirestore(
                                                        {
                                                          'following':
                                                              FieldValue
                                                                  .arrayRemove([
                                                            listViewNotificationsRecord
                                                                .senderID
                                                          ]),
                                                        },
                                                      ),
                                                    });

                                                    firestoreBatch.update(
                                                        listViewNotificationsRecord
                                                            .senderID!,
                                                        {
                                                          ...mapToFirestore(
                                                            {
                                                              'followers':
                                                                  FieldValue
                                                                      .arrayRemove([
                                                                currentUserReference
                                                              ]),
                                                            },
                                                          ),
                                                        });
                                                    HapticFeedback
                                                        .mediumImpact();
                                                  }
                                                } finally {
                                                  await firestoreBatch.commit();
                                                }
                                              },
                                              text: (currentUserDocument
                                                                  ?.following
                                                                  .toList() ??
                                                              [])
                                                          .contains(
                                                              listViewNotificationsRecord
                                                                  .senderID) ==
                                                      true
                                                  ? 'Following'
                                                  : 'Follow',
                                              options: FFButtonOptions(
                                                height: 35.0,
                                                padding: const EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        15.0, 0.0, 15.0, 0.0),
                                                iconPadding:
                                                    const EdgeInsetsDirectional
                                                        .fromSTEB(
                                                            0.0, 0.0, 0.0, 0.0),
                                                color: (currentUserDocument
                                                                    ?.following
                                                                    .toList() ??
                                                                [])
                                                            .contains(
                                                                listViewNotificationsRecord
                                                                    .senderID) ==
                                                        true
                                                    ? FlutterFlowTheme.of(
                                                            context)
                                                        .greyButtonLine
                                                    : FlutterFlowTheme.of(
                                                            context)
                                                        .buttonBlue,
                                                textStyle: FlutterFlowTheme.of(
                                                        context)
                                                    .titleSmall
                                                    .override(
                                                      fontFamily: 'Inter',
                                                      color: (currentUserDocument
                                                                          ?.following
                                                                          .toList() ??
                                                                      [])
                                                                  .contains(
                                                                      listViewNotificationsRecord
                                                                          .senderID) ==
                                                              true
                                                          ? FlutterFlowTheme.of(
                                                                  context)
                                                              .primaryText
                                                          : FlutterFlowTheme.of(
                                                                  context)
                                                              .primaryText,
                                                      fontSize: 12.0,
                                                      letterSpacing: 0.0,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                elevation: 0.0,
                                                borderSide: const BorderSide(
                                                  color: Colors.transparent,
                                                  width: 1.0,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(50.0),
                                              ),
                                              showLoadingIndicator: false,
                                            ),
                                          ),
                                        if ((listViewNotificationsRecord.like ==
                                                true) ||
                                            (listViewNotificationsRecord
                                                    .itsComment ==
                                                true))
                                          Align(
                                            alignment:
                                                const AlignmentDirectional(1.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                context.pushNamed(
                                                  'notificationsPost',
                                                  queryParameters: {
                                                    'postReference':
                                                        serializeParam(
                                                      listViewNotificationsRecord
                                                          .postID,
                                                      ParamType
                                                          .DocumentReference,
                                                    ),
                                                  }.withoutNulls,
                                                );
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(10.0),
                                                child: CachedNetworkImage(
                                                  fadeInDuration: const Duration(
                                                      milliseconds: 500),
                                                  fadeOutDuration: const Duration(
                                                      milliseconds: 500),
                                                  imageUrl:
                                                      valueOrDefault<String>(
                                                    listViewNotificationsRecord
                                                                    .postImage !=
                                                                ''
                                                        ? listViewNotificationsRecord
                                                            .postImage
                                                        : listViewNotificationsRecord
                                                            .videoCover,
                                                    'https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/beneree-w6h1vi/assets/hzi9k5cvtmvi/Product_Square_Placeholder.png',
                                                  ),
                                                  width: 46.0,
                                                  height: 46.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
