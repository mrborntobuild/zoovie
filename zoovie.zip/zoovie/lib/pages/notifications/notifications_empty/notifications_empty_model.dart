import '/flutter_flow/flutter_flow_util.dart';
import 'notifications_empty_widget.dart' show NotificationsEmptyWidget;
import 'package:flutter/material.dart';

class NotificationsEmptyModel
    extends FlutterFlowModel<NotificationsEmptyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
