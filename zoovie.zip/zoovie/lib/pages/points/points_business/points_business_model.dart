import '/flutter_flow/flutter_flow_util.dart';
import 'points_business_widget.dart' show PointsBusinessWidget;
import 'package:flutter/material.dart';

class PointsBusinessModel extends FlutterFlowModel<PointsBusinessWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Custom Action - checkInternetConnection] action in pointsBusiness widget.
  bool? connectionResult;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
