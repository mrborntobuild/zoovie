import '/flutter_flow/flutter_flow_util.dart';
import 'edit_post_widget.dart' show EditPostWidget;
import 'package:flutter/material.dart';

class EditPostModel extends FlutterFlowModel<EditPostWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // State field(s) for postCaption widget.
  FocusNode? postCaptionFocusNode;
  TextEditingController? postCaptionTextController;
  String? Function(BuildContext, String?)? postCaptionTextControllerValidator;
  // State field(s) for Switch widget.
  bool? switchValue;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    postCaptionFocusNode?.dispose();
    postCaptionTextController?.dispose();
  }
}
