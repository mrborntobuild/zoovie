import '/flutter_flow/flutter_flow_util.dart';
import 'add_photo_location_widget.dart' show AddPhotoLocationWidget;
import 'package:flutter/material.dart';

class AddPhotoLocationModel extends FlutterFlowModel<AddPhotoLocationWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for location widget.
  FocusNode? locationFocusNode;
  TextEditingController? locationTextController;
  String? Function(BuildContext, String?)? locationTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    locationFocusNode?.dispose();
    locationTextController?.dispose();
  }
}
