import '/flutter_flow/flutter_flow_util.dart';
import 'modal_report_widget.dart' show ModalReportWidget;
import 'package:flutter/material.dart';

class ModalReportModel extends FlutterFlowModel<ModalReportWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
