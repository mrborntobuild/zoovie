import '/flutter_flow/flutter_flow_util.dart';
import 'add_business_password_widget.dart' show AddBusinessPasswordWidget;
import 'package:flutter/material.dart';

class AddBusinessPasswordModel
    extends FlutterFlowModel<AddBusinessPasswordWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for BusinessName widget.
  FocusNode? businessNameFocusNode;
  TextEditingController? businessNameTextController;
  late bool businessNameVisibility;
  String? Function(BuildContext, String?)? businessNameTextControllerValidator;

  @override
  void initState(BuildContext context) {
    businessNameVisibility = false;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    businessNameFocusNode?.dispose();
    businessNameTextController?.dispose();
  }
}
