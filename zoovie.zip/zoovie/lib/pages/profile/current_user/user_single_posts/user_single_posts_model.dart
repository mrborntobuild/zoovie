import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/home/menu_feed_page/menu_feed_page_widget.dart';
import 'user_single_posts_widget.dart' show UserSinglePostsWidget;
import 'package:carousel_slider/carousel_slider.dart';
import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';

class UserSinglePostsModel extends FlutterFlowModel<UserSinglePostsWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for Carousel widget.
  CarouselController? carouselController;

  int carouselCurrentIndex = 0;

  // State field(s) for Expandable widget.
  late ExpandableController expandableExpandableController;

  // Stores action output result for [Backend Call - Create Document] action in NotActiveHeart widget.
  PostLikesRecord? newLike;
  // Model for menuFeedPage component.
  late MenuFeedPageModel menuFeedPageModel;

  @override
  void initState(BuildContext context) {
    menuFeedPageModel = createModel(context, () => MenuFeedPageModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    expandableExpandableController.dispose();
    menuFeedPageModel.dispose();
  }
}
