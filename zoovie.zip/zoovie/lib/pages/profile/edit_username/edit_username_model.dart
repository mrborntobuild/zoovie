import '/flutter_flow/flutter_flow_util.dart';
import 'edit_username_widget.dart' show EditUsernameWidget;
import 'package:flutter/material.dart';

class EditUsernameModel extends FlutterFlowModel<EditUsernameWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // State field(s) for Username widget.
  FocusNode? usernameFocusNode;
  TextEditingController? usernameTextController;
  String? Function(BuildContext, String?)? usernameTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    usernameFocusNode?.dispose();
    usernameTextController?.dispose();
  }
}
