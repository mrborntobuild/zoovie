import '/flutter_flow/flutter_flow_util.dart';
import 'subscription_confirmation_business_widget.dart'
    show SubscriptionConfirmationBusinessWidget;
import 'package:flutter/material.dart';

class SubscriptionConfirmationBusinessModel
    extends FlutterFlowModel<SubscriptionConfirmationBusinessWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
